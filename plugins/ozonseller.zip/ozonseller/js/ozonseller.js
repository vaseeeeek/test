$(document).ready(function () {
    /**
     *  Переключение табов в окне Импорт/экспорт
     */
    $('#ozonseller-import-tabs').on('click', 'li', function (el) {
        $('.ozonseller-import-tab').hide();
        $('#ozonseller-import-tabs').find('li').removeClass('selected');
        $('#' + $(this).attr('tdiv')).show();
        $(this).addClass('selected');
        return false;
    });

    /**
     *  Ссылка Сохранить на вкладках настроек
     */
    $('a.ozonseller-settings-save').on('click', function () {
        $('#ozonseller-import-div').find('i.ozonseller-i-ready').hide();
        $('#ozonseller-import-div').find('i.ozonseller-i-processing').show();
        if (saveSettings($(this))) {
            $('#ozonseller-import-div').find('i.ozonseller-i-ready').show();
            $('#ozonseller-import-div').find('i.ozonseller-i-processing').hide();
        }
        return false;
    });

    /**
     *  Просмотр свойств категории / добавление новой
     */
    $('#ozonseller-import-tab-category').on('click', '.ozonseller-view-category-settings', function () {
        var div = $(this).closest('div');
        var el = $(this);
        var is_new = $(this).hasClass('new');
        if (is_new) {
            var category_id = $('#ozonseller-ozon-categories-select').val();
            clickOzonsellerButton($(el), 'settings');
        } else {
            var category_id = $(el).attr('category-id');
        }
        disableElements($(div));
        $.post('?plugin=ozonseller&action=getCategorySettings', {'category_id': category_id}, function (r) {
            if (r.status == 'ok') {
                $('#ozonseller-category').html(r.data);
                showCategorySettings();
                if (is_new) {
                    showCategoriesSelect(false);
                }
            } else {
                dialogError(r.errors);
            }
            disableElements($(div), true);
            if (is_new) {
                clickOzonsellerButton($(el), 'settings', false);
            }
        });
        return false;
    });

    /**
     *   Закрытие окна настроек категории
     */
    $('#ozonseller-import-tab-category').on('click', '.ozonseller-category-settings-close', function () {
        showCategorySettings(false);
        return false;
    });

    /**
     *  Ссылка Обновить категории Ozon
     */
    $('#ozonseller-import-category-check').on('click', function () {
        $('#ozonseller-i-loading').show();
        $('#ozonseller-i-update').hide();
        var el = $(this);
        var span = $(el).closest('div').find('span');
        $(span).show();
        $(el).hide();
        disableElements($('#ozonseller-import-div'));
        $.post('?plugin=ozonseller&action=refreshOzonCategory', function (data) {
            var procId = data.processId;
            if (!procId) {
                $('#ozonseller-i-loading').hide();
                $('#ozonseller-i-update').show();
                $(el).show();
                $(span).hide();
                dialogError(data.errors);
                return false;
            }
            var step = setInterval(function () {
                $.wa.errorHandler = function (xhr) {
                    return !((xhr.status >= 500) || (xhr.status == 0));
                };
                $.post('?plugin=ozonseller&action=refreshOzonCategory', {
                    processId: procId
                }, function fromstep(r) {
                    if (r.ready == true) {
                        clearInterval(step);
                        $('#ozonseller-i-loading').hide();
                        $('#ozonseller-i-update').show();
                        location.reload();
                    }
                }, 'json');
            }, 5000);
        }, 'json');
        return false;
    });

    /**
     *   Ссылка Изменить наценки
     */
    $('#ozonseller-import-tab-category').on('click', '.ozonseller-a-change-markups', function () {
        var view = $(this).closest('div.ozonseller-markups-div').find('.ozonseller-category-markups.view');
        var edit = $(this).closest('div.ozonseller-markups-div').find('.ozonseller-category-markups.edit');
        if ($(this).attr('mode') == 'edit') {
            disableElements($(edit), true);
            $(view).hide();
            $(edit).show();
        } else {
            disableElements($(edit));
            $(view).show();
            $(edit).hide();
        }
        return false;
    });

    /**
     *  Ссылка Добавить наценку
     */
    $('#ozonseller-import-tab-category').on('click', '.ozonseller-a-add-markup', function () {
        var link = $(this);
        var table = $(link).closest('div').find('table');
        var count = parseInt($(link).attr('count'));
        var ozon_category_id = $(this).closest('div').find('input[name="ozon_category_id"]').val();
        $.post('?plugin=ozonseller&action=addMarkup', {
            'count': count,
            'ozon_category_id': ozon_category_id
        }, function (r) {
            if (r.status == 'ok') {
                $(link).attr('count', count + 1);
                $(table).append(r.data);
            } else {
                dialogError(r.errors);
            }
        });
        return false;
    });

    /**
     *  Ссылка Сохранить наценки
     */
    $('#ozonseller-import-tab-category').on('click', '#save-markup', function () {
        var form = $(this).closest('.ozonseller-category-markups.edit').find('form');
        var ozon_category_id = $(form).find('input[name="ozon_category_id"]').val();
        var el = $(this);
        $.post('?plugin=ozonseller&action=saveMarkup', form.serialize(), function (r) {
            if (r.status == 'ok') {
                if (ozon_category_id == 'default') {
                    location.reload();
                } else {
                    $(el).closest('div.ozonseller-markups-div').find('div.ozonseller-category-markups-view-table').empty().html(r.data);
                    $(el).closest('span').find('a.ozonseller-a-change-markups').trigger('click');
                }
            } else {
                dialogError(r.errors);
            }
        });
        return false;
    });

    /**
     *   Ссылка Удалить наценку
     */
    $('#ozonseller-import-tab-category').on('click', '.ozonseller-markup-tr-remove', function () {
        $(this).closest('tr').remove();
        return false;
    });

    /**
     *  Ссылка Добавить категорию Ozon и отмена
     */
    $('.ozonseller-a-add-category').on('click', function () {
        showCategoriesSelect($(this).attr('mode') == 'show');
        return false;
    });

    /**
     *   Сохранение сопоставлений характеристик категории по типам
     */
    $('#ozonseller-import-tab-category').on('click', '.ozonseller-type-features-save', function () {
        var el = $(this);
        clickOzonsellerButton($(this), 'disk');
        var form = $(el).closest('form');
        var att_span = $(form).find('span#ozonseller-type-features-attention');
        $(att_span).hide();
        $.post('?plugin=ozonseller&action=saveCategoryTypeFeatures', $(form).serialize(), function (r) {
            if (r.status == 'ok') {
                if (r.data.attention != undefined) {
                    $(att_span).html(r.data.attention).show();
                }
                var ozon_id = $(form).find('input[name="category_id"]').val();
                var cat_name = $('#ozonseller-category').find('h2').html();
                if (!$('#ozonseller-list-categories').find('li[ozon-id="' + ozon_id + '"]').length) {
                    var li = '<li ozon-id="' + ozon_id + '"><a href="#" class="ozonseller-view-category-settings" category-id="' + ozon_id + '"><i class="icon16 folder"></i> ' + cat_name + '</a></li>';
                    $('#ozonseller-list-categories').append(li);
                }
            } else {
                dialogError(r.errors);
            }
            clickOzonsellerButton($(el), 'disk', false);
        });
        return false;
    });

    /**
     *   Изменение режима учета складов на вкладке настроек
     */
    $('#ozonseller-import-tab-settings-prices').on('change', '#wahtmlcontrol_shop_ozonseller_quantity', function () {
        if ($(this).val() == 'stock_ids') {
            $('#ozonseller-tab-settings-stocks').show();
        } else {
            $('#ozonseller-tab-settings-stocks').hide();
        }
    });

    /**
     *   Обновление списка акций
     */
    $('#ozonseller-import-tab-promos').on('click', '#ozonseller-refresh-promos', function () {
        var el = $(this);
        clickOzonsellerButton(el, 'update');
        $('#ozonseller-promo-info').html('<div class="align-center gray" style="padding-top: 100px;">\n' +
            '<span>Выберите акцию из списка для получения информации</span></div>')
        $.post('?plugin=ozonseller&module=promos&action=refreshPromos', {'post': true}, function (r) {
            if (r.status == 'ok') {
                $('#ozonseller-promos-list').html(r.data);
            } else {
                dialogError(r.errors);
            }
            clickOzonsellerButton(el, 'update', false, r.status != 'ok');
        });
        return false;
    });

    /**
     *   Получение информации об акции
     */
    $('#ozonseller-import-tab-promos').on('click', 'li.promo-info>a', function () {
        window.scrollTo(0, 0);
        $(this).closest('ul').find('li').removeClass('selected');
        $(this).closest('li').addClass('selected');
        $('#ozonseller-promo-info').html('<i class="icon16 loading" style="margin: 25px;"></i>');
        $.post('?plugin=ozonseller&module=promos&action=getPromoInfo', {'promo_id': $(this).attr('promo-id')}, function (r) {
            if (r.status == 'ok') {
                $('#ozonseller-promo-info').html(r.data);
            } else {
                dialogError(r.errors);
            }
        });
        return false;
    });

    /**
     *   Загрузка части товаров в акциях
     */
    $('#ozonseller-import-tab-promos').on('click', '.ozonseller-promo-product-part', function () {
        var el = $(this);
        var offset = $(el).attr('offset');
        var type = $(el).attr('mode');
        var span_count = $(el).closest('td').find('span.promo-count');
        var span_total = $(el).closest('td').find('span.promo-total');
        var count = parseInt($(span_count).html());
        var loading = $(el).closest('span').find('i');
        var promo_id = $('#ozonseller-promo-id').val();
        $(span_count).hide();
        $(span_total).hide();
        $(loading).show();
        $.post('?plugin=ozonseller&module=promos&action=getPartList', {
            'promo_id': promo_id,
            'type': type,
            'offset': offset
        }, function (r) {
            if (r.status == 'ok') {
                $('#ozonseller-promo-' + type).append(r.data.products);
                var update_count = count + parseInt(r.data.count);
                $(span_count).html(update_count);
                $(el).attr('offset', update_count);
                if (update_count >= parseInt(r.data.total)) {
                    $(el).hide();
                }
            } else {
                dialogError(r.errors);
            }
            $(loading).hide();
            $(span_count).show();
            $(span_total).show();
        });
        return false;
    });

    /**
     *   Добавление/удаление товаров в акции Озон
     */
    $('#ozonseller-import-tab-promos').on('click', '.ozonseller-promo-product-action', function () {
        var el = $(this);
        var mode = $(el).attr('mode');
        var rest = $(el).attr('rest');
        var promo_id = $('#ozonseller-promo-id').val();
        var ids = [];
        $('#ozonseller-promo-' + mode).find('input:checkbox:checked').each(function (){
            ids.push($(this).val());
        });
        clickOzonsellerButton(el, rest);
        $.post('?plugin=ozonseller&module=promos&action=runPromoProducts', {
            'mode': mode,
            'ids': ids,
            'source': $(el).closest('td').find('select[name="source"]').val(),
            'set': $(el).closest('td').find('select[name="set"]').val(),
            'promo_id': promo_id
        }, function(r){
            if (r.status == 'ok') {
                setTimeout(function () {
                    $('#ozonseller-promos-list').find('a[promo-id="' + promo_id + '"]').trigger('click');
                }, 500);
            } else {
                dialogError(r.errors);
            }
            clickOzonsellerButton(el, rest, false, r.status != 'ok');
        });
        return false;
    });

    /**
     *   Сохранение настроек акции
     */
    $('#ozonseller-import-tab-promos').on('click', '#ozonseller-promo-settings-save', function () {
        var el = $(this);
        var form = $(el).closest('form');
        var promo_id = $('#ozonseller-promo-id').val();
        clickOzonsellerButton(el, 'disk');
        $.post('?plugin=ozonseller&module=promos&action=savePromoSettings', form.serialize(), function (r) {
            if (r.status == 'ok') {
                $(el).closest('div.value').find('div.delete').show();
                $('#ozonseller-promo-settings-edit').hide();
                $('#ozonseller-promo-settings-view').html(r.data).show();
                $('#ozonseller-promo-button-add').removeClass('disabled');
                $('#ozonseller-promos-list').find('a[promo-id="'+promo_id+'"]').find('i.status-gray').removeClass('status-gray').addClass('status-green');
            } else {
                dialogError(r.errors);
            }
            clickOzonsellerButton(el, 'disk', false, r.status !== 'ok');
        });
        return false;
    });

    /**
     *   Удаление настроек акции
     */
    $('#ozonseller-import-tab-promos').on('click', '#ozonseller-promo-settings-delete', function () {
        var el = $(this);
        var form = $(el).closest('form');
        var promo_id = $('#ozonseller-promo-id').val();
        clickOzonsellerButton(el, 'trash');
        $.post('?plugin=ozonseller&module=promos&action=deletePromoSettings', form.serialize(), function (r) {
            if (r.status == 'ok') {
                $(el).closest('div').hide();
                $('#ozonseller-promo-settings-edit').hide();
                $('#ozonseller-promo-settings-view').html(r.data).show();
                $('#ozonseller-promo-button-add').addClass('disabled');
                $('#ozonseller-promos-list').find('a[promo-id="'+promo_id+'"]').find('i.status-green').removeClass('status-green').addClass('status-gray');
            } else {
                dialogError(r.errors);
            }
            clickOzonsellerButton(el, 'trash', false, r.status !== 'ok');
        });
        return false;
    });


    /**
     *  Просмотр характеристик категории по типам
     */
    $('#ozonseller-category').on('click', 'a.ozonseller-type', function () {
        if ($(this).closest('li').hasClass('selected')) {
            return false;
        }
        var target = $(this).closest('.ozonseller-category-property').find('div.content');
        $(target).empty().html('<i class="icon16 loading"</i>');
        $(this).closest('ul').find('li').removeClass('selected');
        var li = $(this).closest('li');
        var type_id = $(this).attr('type_id');
        var category_id = $('#ozonseller-category-id').val();
        $.post('?plugin=ozonseller&action=getCategoryFeaturesByTypeId', {
            'type_id': type_id,
            'category_id': category_id
        }, function (r) {
            if (r.status == 'ok') {
                $(target).empty().html(r.data);
                $(li).addClass('selected');
            } else {
                dialogError(r.errors);
            }
        });
        return false;
    });

    /**
     *   Ссылка Добавить тип
     */
    $('#ozonseller-category').on('click', '#ozonseller-add-type', function () {
        var type_id = $('#ozonseller-new-type').val();
        if (type_id == 0) {
            return false;
        }
        var type_name = $('#ozonseller-new-type').find('option[value="' + type_id + '"]').html();
        if ($('#ozonseller-list-types').find('li[type_id="' + type_id + '"]').length) {
            $('#ozonseller-div-type-attention').show(100);
            setTimeout(function () {
                $('#ozonseller-div-type-attention').hide(100);
            }, 2000);
        } else {
            $('#ozonseller-no-type').hide();
            $('#ozonseller-yes-type').show();
            var li = '<li type_id="' + type_id + '"><a type_id="' + type_id + '" href="#" class="ozonseller-type"><i class="icon16 ss pt box"></i>' + type_name + '</i></li>';
            $('ul#ozonseller-list-types').append($(li));
            $(li).find('a').trigger('click');
            $('#ozonseller-list-types').find('a[type_id="' + type_id + '"]').trigger('click');
            $('#ozonseller-dictionaries-update').show();
        }
        return false;
    });

    /**
     *   Кнопка Обновить справочники
     */
    $('#ozonseller-category').on('click', '.ozonseller-dictionaries-update', function () {
        var el = $(this);
        var url = '?plugin=ozonseller&action=updateDictionaries';
        clickOzonsellerButton(el, 'view-table');
        $(el).closest('div').addClass('disabled');
        $.post(url, {'category_id': $(el).attr('category-id')}, function (data) {
            if (data.error !== undefined) {
                dialogError(data.error);
                $(el).closest('div').removeClass('disabled');
                clickOzonsellerButton(el, 'view-table', false, true);
            } else {
                var step = setInterval(function () {
                    $.wa.errorHandler = function (xhr) {
                        return !((xhr.status >= 500) || (xhr.status == 0));
                    };
                    var processId = data.processId;
                    $.post(url, {'processId': processId}, function (r) {
                        if (r.ready == true) {
                            clearInterval(step);
                            $(el).closest('div').removeClass('disabled');
                            clickOzonsellerButton(el, 'view-table', false);
                        }
                        return true;
                    }, 'json');
                }, 3000);
            }
        }, 'json');
        return false;
    });

    $('#ozonseller-category').on('click', '.prm-cross', function () {
        $(this).parent().hide();
        return false;
    });

    $('#ozonseller-category').on('click', '.ozonseller-category-del', function () {
        $(this).hide();
        $(this).closest('div').find('div.ozonseller-category-del-buttons').show();
        return false;
    });

    $('#ozonseller-category').on('click', '.ozonseller-category-cancel', function () {
        $(this).closest('div.ozonseller-category-del-buttons').hide();
        $(this).closest('div.block').find('a.ozonseller-category-del').show();
        return false;
    });

    $('#ozonseller-category').on('click', '.ozonseller-category-delete', function () {
        var el = $(this);
        var category_id = $(el).attr('category-id');
        var type_id = $(el).attr('type-id');
        $.post('?plugin=ozonseller&action=removeCategoryType', {
            'category_id': category_id,
            'type_id': type_id
        }, function (r) {
            if (r.status == 'ok') {
                if (type_id) {
                    $('#ozonseller-list-types').find('li[type_id="' + type_id + '"]').remove();
                    $(el).closest('.left250px').empty();
                } else {
                    $('#ozonseller-categories').find('li[ozon-id="' + category_id + '"]').remove();
                    $('#ozonseller-category').find('a.ozonseller-category-settings-close').trigger('click');
                }
            } else {
                dialogError(r.errors);
            }
        });
        return false;
    });

    /**
     *  Выбор select'a с характеристикой магазина в окне настройки типа товаров для катгеории
     */
    $('#ozonseller-category').on('change', '.ozonseller-select-shop-features', function () {
        var el = $(this);
        var value = $(el).val();
        var div = $(el).closest('div.ozonseller-type-feature-row').find('div.ext');
        var string = $(div).find('input.string');
        var select = $(div).find('select.params');
        var rich = $(div).find('select.rich');
        var dims = $(div).find('.dims');
        var matches = $(el).closest('div').find('div.ozonseller-matches');
        var need_match = $(el).attr('option');
        if (value == 'string') {
            $(string).attr('disabled', false).show();
            $(select).attr('disabled', true).val('').hide();
            $(rich).attr('disabled', true).val('').hide();
            $(dims).remove();
            $(matches).hide();
        } else if (value == 'params') {
            $(string).attr('disabled', true).val('').hide();
            $(rich).attr('disabled', true).val('').hide();
            $(select).attr('disabled', false).show();
            $(dims).remove();
            $(matches).hide();
        } else if (value == 'rich') {
            $(string).attr('disabled', true).val('').hide();
            $(select).attr('disabled', true).val('').hide();
            $(rich).attr('disabled', false).show();
            $(dims).remove();
            $(matches).hide();
        } else {
            $(dims).remove();
            $(string).attr('disabled', true).val('').hide();
            $(select).attr('disabled', true).val('').hide();
            $(rich).attr('disabled', true).val('').hide();
            if ($(el).find('option:selected').attr('is-dim') == '1') {
                var of_type = $(el).closest('div.ozonseller-type-feature-row').find('.ozonseller-icon24.string');
                $.post('?plugin=ozonseller&action=getDimsSelect', {
                    'feature_id': value,
                    'ozon_feature_id': $(el).closest('div.ozonseller-type-feature-row').attr('ozon-feature-id'),
                    'is_string': of_type.length
                }, function (r) {
                    $(div).append(r.data);
                });
            }
            if (value == '0') {
                $(matches).hide();
            } else if (need_match) {
                var match_count = $(matches).find('span.ozonseller-matches-count');
                $(match_count).html('<i class="icon16 loading"></i>');
                $.post('?plugin=ozonseller&action=getCountMatches', {
                    'ozon_feature_id': need_match,
                    'feature_id': value
                }, function (r) {
                    if (r.status == 'ok') {
                        $(match_count).html(r.data);
                    } else {
                        dialogError(r.errors);
                    }
                });
                $(matches).show();
            }
        }
    });

    /**
     *   Ссылка сопоставления значений характеристик
     */
    $('#ozonseller-category').on('click', '.ozonseller-matches-set', function () {
        var loading = $(this).closest('div').find('i.loading:first');
        $(loading).show();
        var fselect = $(this).closest('div.ozonseller-type-feature-cell').find('select.ozonseller-select-shop-features');
        var ozon_category_id = $(this).closest('form').find('input[name="category_id"]').val();
        var ozon_id = $(fselect).attr('option');
        var feature_id = $(fselect).val();
        $.post('?plugin=ozonseller&action=getDialogMatches', {
            'ozon_feature_id': ozon_id,
            'feature_id': feature_id,
            'ozon_category_id': ozon_category_id
        }, function (r) {
            if (r.status == 'ok') {
                $(r.data).waDialog({
                    'height': '550px',
                    'width': '400px',
                    'onClose': function (f) {
                        $(this).remove();
                    },
                    'esc': true,
                });
            } else {
                dialogError(r.errors);
            }
            $(loading).hide();
        });
        return false;
    });

    /**
     *   Кнопка Сбросить сопоставления товаров
     */
    $('#ozonseller-import-tab-import').on('click', '#ozonseller-clear-products', function () {
        var icon = $(this).closest('div').find('i');
        $(icon).show();
        var form = $(this).closest('form');
        $.post('?plugin=ozonseller&action=removeProductComparsion', form.serialize(), function (r) {
            if (r.status == 'ok') {
                $('#ozonseller-total-publics').html(r.data);
            } else {
                dialogError(r.errors);
            }
            $(icon).hide();
        });
        return false;
    });
    $('#ozonseller-import-tab-import').on('change', '#ozonseller-clear-import', function () {
        var value = $(this).val();
        if (value == 'set_in' || value == 'set_out') {
            $('#ozonseller-clear-import-set').show();
        } else {
            $('#ozonseller-clear-import-set').hide();
        }
    });

    /**
     *   Кнопка Получить информацию из Ozon
     */
    $('#ozonseller-import-tab-import').on('click', '#ozonseller-ozon-info', function () {
        var el = $(this);
        var form = $(el).closest('form');
        var file = $(form).find('input#ozonseller-import-file');
        var total = $(form).find('span#ozonseller-import-ozon-total');
        var news = $(form).find('span#ozonseller-import-ozon-new');
        var nonexist = $(form).find('span#ozonseller-import-ozon-non-exist');
        var itime = $(form).find('span#ozonseller-import-time');
        var buttons = $(this).closest('div#buttons');
        var stat = $(form).find('div#ozonseller-import-stats');
        var itype = $(form).find('#ozonseller-import-type').closest('div.field');
//        clickOzonsellerButton($(this), 'sync');
        $(total).html(0);
        $(news).html(0);
        $(itime).html(0);
        $(nonexist).html(0);
        $(file).val('');
        var tmp = goProgressBar(
            '?plugin=ozonseller&action=import',
            form.serialize(),
            $('#ozonseller-gradusnik-import'),
            5000,
            ['ozonseller-icon-yes', 'ozonseller-icon-exist', 'ozonseller-icon-non-exist'],
            [$(el)],
            'sync'
        );
        return false;
    });

    /**
     *   Ручная публикация очереди
     */
    $('#ozonseller-import-tab-waits').on('click', '#ozonseller-public-waits', function () {
        $.post('?plugin=ozonseller&action=getWaitsPbar', function (r) {
            if (r.status == 'ok') {
                $('#ozonseller-public-waits-pbar').html(r.data);
            } else {
                dialogError(r.errors);
                return false;
            }
        });
        var els = $(this).closest('div.block').find('a');
        var buttons = $(this).closest('div#buttons');
        $.post('?plugin=ozonseller&action=getWaitsPbar', function (r) {
            if (r.status == 'ok') {
                $('#ozonseller-public-waits-pbar').html(r.data);
            } else {
                dialogError(r.errors);
                return false;
            }
        });
        var tmp = goProgressBar(
            '?plugin=ozonseller&action=publicWaits',
            [],
            $('#ozonseller-public-waits-pbar'),
            5000,
            ['ozonseller-icon-yes', 'ozonseller-icon-non-exist'],
            [$(this), $('#ozonseller-remove-waits')],
            'merge'
        );
        $(this).closest('div').addClass('disabled');
        return false;
    });

    $('#ozonseller-import-tab-settings').on('change', '.ozonseller-settings-markup-type', function () {
        var el = $(this);
        var div = $(el).closest('div.value');
        if ($(el).val() == '0') {
            $(div).find('select.ozonseller-settings-markup-key').hide();
        } else {
            $(div).find('select.ozonseller-settings-markup-key').show();
        }
    });

    $('#ozonseller-import-tab-settings').on('change', '.ozonseller-settings-exclude-type', function () {
        var el = $(this);
        var div = $(el).closest('div.value');
        if ($(el).val() == 'ozonseller-adv-params') {
            $(div).find('select.ozonseller-settings-exclude-key').show();
        } else {
            $(div).find('select.ozonseller-settings-exclude-key').hide();
        }
    });

    $('#ozonseller-import-tab-settings').on('change', '.ozonseller-settings-dimensions-type', function () {
        var el = $(this);
        var div = $(el).closest('div.value');
        if ($(el).val() == 'adv-params') {
            $(div).find('div.ozonseller-dimensions-fields').show();
        } else {
            $(div).find('div.ozonseller-dimensions-fields').hide();
        }
    });

    $('#ozonseller-main-div').on('click', '.ozonseller-button', function () {
        if ($(this).hasClass('disabled')) {
            return false;
        }
        $(this).find('a').trigger('click');
    });

    $('#ozonseller-import-tab-logs').on('click', 'span.row-name', function () {
        var tr = $(this).closest('div.ozonseller-log');
        var target = $(tr).find('div.ozonseller-log-data');
        if ($(tr).hasClass('selected')) {
            $(target).hide('fast');
            $(tr).removeClass('selected');
            return;
        }
        $('#ozonseller-logs').find('div.ozonseller-log-data').hide();
        $('#ozonseller-logs').find('div.ozonseller-log').removeClass('selected');
        $(tr).addClass('selected');
        if ($(target).attr('loading') == '0') {
            $(target).html('<i class="icon16 loading"></i>');
            $.post('?plugin=ozonseller&action=getProductLogs', {'product_id': $(tr).attr('product-id')}, function (r) {
                if (r.status == 'ok') {
                    $(target).html(r.data);
                    $(target).attr('loading', 1);
                } else {
                    dialogError(r.errors);
                }
            });
        }
        $(target).show('fast');
    });

    $('.ozonseller-refresh-logs').on('click', function () {
        var el = $(this);
        var mode = $(this).attr('mode');
        clickOzonsellerButton($(el), mode);
        $.post('?plugin=ozonseller&action=refreshLogs', {'mode': mode}, function (r) {
            if (r.status == 'ok') {
                $('#ozonseller-logs').closest('div').html(r.data);
            } else {
                dialogError(r.errors);
            }
            clickOzonsellerButton($(el), mode, false, r.status != 'ok');
        });
        return false;
    });

    /**
     *  Диалог с информацией об ошибках
     * @param errors
     */
    var dialogError = function (errors, buttons = true) {
        $.post('?plugin=ozonseller&action=dialogError', {
            'errors': errors,
            'buttons': buttons
        }, function (data) {
            $(data).waDialog({
                'height': '150px',
                'width': '450px',
                'onClose': function (f) {
                    $(this).remove();
                },
                'esc': true,
            });
            return false;
        });
    }

    /**
     *   "Засеривание" элементов
     */
    var disableElements = function (el, enable = false) {
        if (enable) {
            $(el).find('input').attr('disabled', false);
            $(el).find('select').attr('disabled', false);
            $(el).find('a').css('pointer-events', 'auto').css('color', '');
        } else {
            $(el).find('input').attr('disabled', true);
            $(el).find('select').attr('disabled', true);
            $(el).find('a').css('pointer-events', 'none').css('color', '#888');
        }
    }

    /**
     *   Скрытие/показ настроек категории
     * @param show
     */
    var showCategorySettings = function (show = true) {
        if (show) {
            $('.ozonseller-categories').hide();
            $('#ozonseller-category').show();
        } else {
            $('.ozonseller-categories').show();
            $('#ozonseller-category').empty().hide();
        }
    }

    var showCategoriesSelect = function (show = true) {
        if (show) {
            $('#ozonseller-a-add-category').hide();
            $('#ozonseller-new-category').show();
        } else {
            $('#ozonseller-new-category').hide();
            $('#ozonseller-a-add-category').show();
        }
    }

    var clickOzonsellerButton = function (el, rest_class, run = true, errors = false) {
        var div = $(el).closest('div');
        var loading = $(div).find('i.loading');
        var rest = $(div).find('i.' + rest_class);
        var yes = $(div).find('i.yes');
        if (run) {
            $(loading).show();
            $(rest).hide();
        } else {
            $(loading).hide();
            if (!errors && $(yes).length) {
                $(yes).show();
                setTimeout(function () {
                    $('#ozonseller-div-type-attention').hide(100);
                    $(yes).hide();
                    $(rest).show();
                }, 2000);
            } else {
                $(rest).show();
            }
        }
    }

    var saveSettings = function (el) {
        clickOzonsellerButton(el, 'disk');
        var form = $(el).closest('form');
        var type_settings = $(form).find('input[name="type"]').val();
        var errors = false;
        $.post('?plugin=ozonseller&action=settingsSave', form.serialize(), function (r) {
            if (r.status != 'ok') {
                dialogError(r.errors);
                errors = true;
            }
            if (type_settings == 'prices') {
                var schema = $(form).find('#wahtmlcontrol_shop_ozonseller_schema').val();
                $('#ozonseller-import-tab-settings-orders').find('.ozonseller-settings-orders').hide();
                if (schema == 'fbo') {
                    $('#ozonseller-import-tab-settings-orders').find('.ozonseller-settings-orders.fbo').show();
                } else {
                    $('#ozonseller-import-tab-settings-orders').find('.ozonseller-settings-orders').show();
                }
            }
            clickOzonsellerButton(el, 'disk', false, errors);
            return true;
        }, 'json');
    }

    /**
     * @desc Функция для работы с градусником WA
     * @param string url  url для post-запроса к waLongActionController
     * @param array params  параметры запроса
     * @param obj  jq-элемент содержащий сам градусник
     * @param int timeout
     * @param array lis  перечень id элементов <li> которые допустимы по результатам работы waLongActionController.
     *                   Перечень идентичен значениям id элементов массива ['lis'] которые передаются в шаблон градусника
     * @param array els  массив jq-объектов которые надо засерить на время выполнения
     *
     *   От waLongActionController ожидаются данные в формате:
     *  - на этапе pre-init наличие элемента ['error'] остановит весь процесс
     *  - по завершении (ready==true)
     *      - array ['lis']
     *          [key] => [value], где key - id элемента <li>
     *      -
     *  - по завершении (ready==false)
     *
     */
    var goProgressBar = function (url, params, pbar, timeout = 5000, lis = null, els = null, rest = null) {
        var disableElements = function (els, status, rest) {
            if (status) {
                els.forEach(el => $(el).closest('div.ozonseller-button').addClass('disabled'));
                clickOzonsellerButton(els[0], rest, true);
            } else {
                els.forEach(el => $(el).closest('div.ozonseller-button').removeClass('disabled'));
                clickOzonsellerButton(els[0], rest, false);
            }
        }

        $('.pbar-start-hidden').hide();
        if (els) {
            disableElements(els, true, rest);
        }
        if (lis) {
            lis.forEach(function (li) {
                $('#value-' + li).empty();
                $('#' + li).hide();
            });
        }
        $(pbar).find('.warslab-preprocessing').show();
        $.post(url, params, function (data) {
            $(pbar).find('.warslab-preprocessing').hide();
            if (data.error !== undefined) {
                dialogError(data.error);
                if (els) {
                    disableElements(els, false, rest);
                }
                return false;
            } else {
                $(pbar).find('.warslab-progressbar').show();
                var processId = data.processId;
                var step = setInterval(function () {
                    $.wa.errorHandler = function (xhr) {
                        return !((xhr.status >= 500) || (xhr.status == 0));
                    };
                    $.post(url, {'processId': processId}, function (r) {
                        if (r.ready == true) {
                            $(pbar).find('.progressbar .progressbar-inner').animate({
                                'width': '100%'
                            });
                            clearInterval(step);
                            if (els) {
                                disableElements(els, false, rest);
                            }
                            $(pbar).find('.warslab-progressbar').hide();
                            $(pbar).find('.progressbar .progressbar-inner').animate({'width': '0%'});
                            $(pbar).find('.progressbar-description').text('');
                            if (lis) {
                                lis.forEach(function (li) {
                                    if (r['lis'] !== undefined && r['lis'][li] !== undefined) {
                                        $('#value-' + li).html(r['lis'][li]);
                                        $('#' + li).show();
                                    }
                                });
                            }
                            $(pbar).find('.warslab-pbar-report').show();
                            if (r.errors !== undefined && r.errors.length > 0) {
                                $(pbar).find('.pbar_result_error').text(r.error).show();
                            }
                        } else {
                            var progress = parseFloat(r.progress.replace(/,/, '.'));
                            $(pbar).find('.progressbar-description').text(r.progress);
                            $(pbar).find('.progressbar .progressbar-inner').animate({
                                'width': progress + '%'
                            });
                        }
                        return true;
                    }, 'json');
                }, timeout);
            }
        }, 'json');
        return false;
    }

    if ($('#ozonseller-ozon-categories-select').length) {
        $('#ozonseller-ozon-categories-select').select2({'width': '400px', 'margin-bottom': '5px'});
    }
})
;