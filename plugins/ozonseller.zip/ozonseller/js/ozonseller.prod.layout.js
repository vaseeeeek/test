$(function () {
    $('body').on('wa_custom_mass_action', '#js-products-page-content',function (event, action, params) {
        if (action.id !== 'ozonseller_public') return;
        let spinner = '<i class="fas fa-spinner wa-animation-spin speed-1000"></i>';
        let sourceIcon = '<i id="ozonseller-dialog-icon" class="ozonseller-icon16 ozon"></i>';
        let iconSpan = $('#ozonseller-dialog-icon').closest('span');
        $(iconSpan).html(spinner);
        $.post('?plugin=ozonseller&module=products&action=getDialogProducts', params, r => {
            $(iconSpan).html(sourceIcon);
            if (r.status === 'ok') {
                $.waDialog({
                    html: r.data,
                    onClose: function (f) {
                        if (ozonsellerDlgPublics.runAction !== false) return;
                        dlgPublics.unmount();
                        ozonsellerdlgPublics = undefined;
                        dlgPublics = undefined;
                        $(this).remove();
                    },
                    esc: false
                });
            } else {
                let text = '';
                if (Array.isArray(r.errors)) {
                    text = r.errors.join('; ');
                } else {
                    text = r.errors;
                }
                if (!text.length) text = 'Непредвиденная ошибка сервера';
                alert(text);
            }
        });
    });
})