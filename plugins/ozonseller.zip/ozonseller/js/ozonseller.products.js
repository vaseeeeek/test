$(document).ready(function () {
    /**
     *   Вызов диалога публикации
     */
    $('#s-product-list-toolbar').on('click', '#ozonseller_products_export', function () {
        var products = $.product_list.getSelectedProducts(true);
        if (!products.count) {
            dialogError('Выберите хотя бы один товар');
            return false;
        }
        var iloading = $(this).find('i.loading').show();
        var iozon = $(this).find('i.ozon').hide();
        $.post('?plugin=ozonseller&module=products&action=getDialogProducts', $(this).serializeArray().concat(products.serialized), function (r) {
            if (r.status == 'ok') {
                    $(r.data).waDialog({
                        height: '250px',
                        width: '700px',
                        onCancel: function (f) {
                            if (ozonsellerDlgPublics.runAction !== false) return;
                            dlgPublics.unmount();
                            ozonsellerDlgPublics = undefined;
                            dlgPublics = undefined;
                            $(this).remove();
                        },
                        esc: false,
                    });
            } else {
                dialogError(r.errors);
            }
            $(iloading).hide();
            $(iozon).show();
        });
        return false;
    });

    /**
     *   Вызов диалога FBO|FBS
     */
    $('#s-product-list-toolbar').on('click', '#ozonseller-products-organize', function () {
        var products = $.product_list.getSelectedProducts(true);
        if (!products.count) {
            dialogError('Выберите хотя бы один товар');
            return false;
        }
        var iloading = $(this).find('i.loading').show();
        var iozon = $(this).find('i.ozon').hide();
        $.post('?plugin=ozonseller&action=getDialogSchema', $(this).serializeArray().concat(products.serialized), function (r) {
            if (r.status == 'ok') {
                openWaDialog(r.data, 500, 150, true);
            } else {
                dialogError(r.errors);
            }
            $(iloading).hide();
            $(iozon).show();
        });
        return false;
    });

    $('a.ozonseller-publics').on('click', function () {
        var products = $.product_list.getSelectedProducts(true);
        if (!products.count) {
            $('.s-select-all').attr('checked', 'checked');
            products = $.product_list.getSelectedProducts(true);
            $('.s-select-all').attr('checked', false);
        }
        $.post('?plugin=ozonseller&action=filterProducts', {
            'action': $(this).attr('action'),
            'params': products.serialized
        }, function (r) {
            if (r.status == 'ok') {
                var li = $('#s-sidebar').find('li.ozonseller-li');
                if (!$(li).length) {
                    li = '<li id="ozonseller-last_hash-" class="ozonseller-li"><span class="count"></span>' +
                        '<a id="ozonseller-link" href="#/products/hash=ozonseller-last_hash">' +
                        '<i class="ozonseller-icon16 ozon icon16"></i>Результат фильтра</a></li>';
                    $('#s-sidebar').find('ul:first').append(li);
                }
                $('.ozonseller-li').attr('id', 'ozonseller-' + r.data + '-');
                $('#ozonseller-link').attr('href', '#/products/hash=ozonseller-' + r.data);
                window.location.href = "?action=products#/products/hash=ozonseller-" + r.data;
                return false;
            } else {
                dialogError(r.errors);
            }
        });
        return false;
    });

    /**
     *    Вызов диалога WA
     */
    var openWaDialog = function (content, width, height, esc = true) {
        $(content).waDialog({
            'height': height + 'px',
            'width': width + 'px',
            'onClose': function (f) {
                $(this).remove();
            },
            'esc': esc,
        });
    }

    /**
     *  Диалог с информацией об ошибках
     * @param errors
     */
    const dialogError = function (errors, buttons = true) {
        $.post('?plugin=ozonseller&action=dialogError', {
            'errors': errors,
            'buttons': buttons
        }, function (data) {
            $(data).waDialog({
                'height': '150px',
                'width': '450px',
                'onClose': function (f) {
                    $(this).remove();
                },
                'esc': true,
            });
            return false;
        });
    }
});