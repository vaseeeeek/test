$(document).ready(function () {
    /*$('#ozonseller-dialog-select-categories').select2({
        'width': '70%',
        'margin-bottom': '5px',
        placeholder: 'Выберите категорию',
        allowClear: false,
    });*/
    $('#ozonseller-dialog-select-categories').on('change', function () {
        $('#ozonseller-public-analitic').empty().html('<i class="icon16 loading"></i>');
        var form = $(this).closest('form');
        var button_public = $(form).closest('div').find('.public');
        var button_del = $(form).closest('div').find('.del');
        $('#ozonseller-publics-attention').hide();
        $.post('?plugin=ozonseller&action=checkDialogProducts', form.serialize(), function (r) {
            if (r.status == 'ok') {
                $(button_public).find('i.clock').hide();
                $(button_public).find('i.settings').css('display', 'inline-block');
                var atext = 'Проверить и поставить в очередь...';
                $(button_public).find('span.text').html(atext);
                $(button_public).find('a').attr('mode', 'check');
                $('#ozonseller-public-analitic').html(r.data.html);
                if (r.data.count && r.data.ozon_category_id) {
                    $(button_public).removeClass('disabled');
                } else {
                    $(button_public).addClass('disabled');
                }
                if (r.data.ocount) {
                    $(button_del).removeClass('disabled');
                } else {
                    $(button_del).addClass('disabled');
                }
            } else {
                alert(r.errors);
                return false;
            }
        });
    });

    $('.ozonseller-button.action.public').on('click', 'a', function () {
        var el = $(this);
        var mode = $(el).attr('mode');
        var form = $(el).closest('div.dialog-content').find('form');
        var params = $(form).serialize();
        var buttons = $(el).closest('div.dialog-buttons').find('div.ozonseller-button:not(.disabled)');
        $(buttons).addClass('disabled');
        $('#ozonseller-dialog-select-categories').attr('disabled', true);
        if (mode == "public") {
            var url = '?plugin=ozonseller&action=addWaitProducts';
            var rest_class = 'clock';
        } else {
            var url = '?plugin=ozonseller&action=validateProducts';
            var rest_class = 'settings';
        }
        clickOzonsellerButton(el, rest_class);
        if (mode == 'public') {
            $.post(url, params, function (r) {
                clickOzonsellerButton(el, 'settings', false, r.status != 'ok');
                if (r.status != "ok") {
                    alert(r.errors);
                }
                $('#message').html('');
                $('#ozonseller-publics-attention').hide();
                $(buttons).removeClass('disabled');
                $(el).attr('mode', 'check').find('span.text').html('Проверить и поставить в очередь...');
                $('#ozonseller-dialog-select-categories').attr('disabled', false);
            });
        } else {

            $.post(url, params, function (data) {
                var procId = data.processId;
                if (!procId) {
                    clickOzonsellerButton(el, rest_class, false, true);
                    alert(data.errors);
                    return false;
                }
                var step = setInterval(function () {
                    $.wa.errorHandler = function (xhr) {
                        return !((xhr.status >= 500) || (xhr.status == 0));
                    };
                    $.post(url, {
                        processId: procId
                    }, function fromstep(r) {
                        if (r.ready == true) {
                            clearInterval(step);
                            clickOzonsellerButton(el, rest_class, false, true);
                            $(buttons).removeClass('disabled');
                            if (r.errors!= undefined && r.errors.length) {
                                alert('В процессе работы возникли ошибки. Подробности см. в ozonseller.error.log');
                            }
                            if (r.fail!= undefined && r.fail) {
                                $('#message').html('Выявлены несоответствия у ' + r.fail + ' товаров. Подробности см.в разделе <a href="?action=importexport#/ozonseller/" target="_blank">Ошибки валидации и публикаций</a>');
                                $('#ozonseller-publics-attention').show();
                            }
                            if (r.done!= undefined && r.done) {
                                $(form).find('input[name="ids_to_public"]').val(r.done_ids);
                                $(el).find('span.text').html('Поставить товары в очередь (' + r.done + ')');
                                $(el).find('i.settings').hide();
                                $(el).find('i.clock').css('display', 'inline-block');
                                $(el).attr('mode', 'public');
                            } else {
                                $(el).closest('div.ozonseller-button').addClass('disabled');
                                if(r.errors==undefined && r.fail == undefined && r.done == undefined){
                                    var message = 'waLongActionController вернул пустой результат (не смог восстановить данные после завершения основного процесса (runner))' +
                                        'Вам необходимо обратиться к вашему системному администратору для выяснения причин. Так же вы можете заказать платную диагностику в Webasyst ' +
                                        ' для выявления причин происходящего. Один из вариантов - у вас постоянно очищается кеш фреймворка, в результате чего waLongActionController ' +
                                        'не может передавать данные между процессами. ' +
                                        ' Это не ошибка плагина и к плагину не имеет никакого отношения, поэтому обращаться в поддержку плагина с этим вопросом бессмысленно. Вам будет дан ответ' +
                                        ' приведенный выше';
                                    console.log(message);
                                    alert('Некорретная работа штатных инструментов фреймворка. Подробнее см. в консоли браузера');
                                }
                            }
                            $('#ozonseller-dialog-select-categories').attr('disabled', false);
                        }
                    }, 'json');
                }, 5000);
            }, 'json');
        }
        return false;
    });

    var clickOzonsellerButton = function (el, rest_class, run = true, errors = false) {
        var div = $(el).closest('div');
        var loading = $(div).find('i.loading');
        var rest = $(div).find('i.' + rest_class);
        var yes = $(div).find('i.yes');
        if (run) {
            $(loading).show();
            $(rest).hide();
        } else {
            $(loading).hide();
            if (!errors && $(yes).length) {
                $(yes).show();
                setTimeout(function () {
                    $('#ozonseller-div-type-attention').hide(100);
                    $(yes).hide();
                    $(rest).show();
                }, 2000);
            } else {
                $(rest).show();
            }
        }
    }
});