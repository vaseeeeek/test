<?php

class shopOzonsellerPluginExportCli extends shopOzonsellerPluginOldCli
{
    const LOG_INFO = 'автоматической публикации товаров в Ozon';
    public function execute()
    {
        parent::execute();
    }
}