<?php

class shopOzonsellerPluginPromoCli extends shopOzonsellerPluginOldCli
{
    const LOG_INFO = 'актуализации акций Ozon';
    public function execute()
    {
        parent::execute();
    }
}