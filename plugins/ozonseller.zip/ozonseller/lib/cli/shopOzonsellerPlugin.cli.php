<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginCli extends waCliController
{
    const ANNOUNCEMENT_CACHE_KEY = 'OZONSELLER_CLI_%s';
    const ANNOUNCEMENT_CACHE_TTL = 345600;
    const ANNOUNCEMENT_COUNT_MAX = 5;

    public $task;
    protected $account_id;
    protected $accounts;
    protected $runErrors = false;

    public function run($params = null)
    {
        try {
            shopOzonsellerPluginHelper::validatePlugin($this);
        } catch (waException $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            return;
        }
        if (!shopOzonsellerPluginHelper::checkPhpVersion()) return;
        parent::run($params);
    }

    protected function updateProductsCategoryInfo($account_id)
    {
        $run = true;
        $offset = 0;
        $uproducts = $ucategories = $old_categories = [];
        $model = new shopOzonsellerPluginProductModel();
        try {
            $socket = new shopOzonsellerPluginOzonApi($account_id);
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage());
            return;
        }
        while ($run = true) {
            $query = <<<SQL
select sku_id, ozon_product_id, ozon_category_id from shop_ozonseller_product where account_id=$account_id and ozon_product_id>0 order by sku_id limit 1000 offset $offset
SQL;
            if (!$products = $model->query($query)->fetchAll('ozon_product_id')) break;
            $response = $socket->getOzonProductInfoList([], array_keys($products));
            $offset += 1000;
            if (!isset($response['items'])) break;
            foreach ($response['items'] as $item) {
                if (!isset($products[$item['id']])) continue;
                if ($products[$item['id']]['ozon_category_id'] != $item['category_id']) {
                    $uproducts[] = ['ozon_product_id' => $item['id'], 'ozon_category_id' => $item['category_id']];
                    if (!in_array($item['category_id'], $ucategories)) $ucategories[] = $item['category_id'];
                    if (!in_array($products[$item['id']]['ozon_category_id'], $old_categories)) $old_categories[] = $products[$item['id']]['ozon_category_id'];
                }
            }
        }
        if ($uproducts) {
            foreach ($ucategories as $category_id) {
                $category_products = array_filter($uproducts, function ($item) use ($category_id) {
                    return $item['ozon_category_id'] == $category_id;
                });
                $model->updateByField('ozon_product_id', array_column($category_products, 'ozon_product_id'), ['ozon_category_id' => $category_id]);
            }
        }
        if ($old_categories) {
            foreach ((new shopOzonsellerPluginOzonCategoryModel())->getById($old_categories) as $cat) {
                $this->setLog($account_id, sprintf(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_REMOVED, $cat['name']), '', null, true);
            }
        }
    }

    public function execute()
    {
        $params = waRequest::param();
        foreach (['task'] as $field) {
            unset($params[$field]);
        }
        if (!$this->accounts || (isset($params['account']) && !isset($this->accounts[$params['account']]))) {
            $message = $params['account'] ? sprintf(shopOzonsellerPluginTextHelper::ERROR_ACCOUNT_DISABLED, ifset($this->accounts[$params['account']]['name'], 'undefined')) : shopOzonsellerPluginTextHelper::ERROR_NO_ACCOUNTS_ENABLED;
            $this->setLog((int)$params['account'], $message);
            return false;
        }
        if (!$this->task) {
            shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_UNKNOWN_TASK, waRequest::param('task')));
            return false;
        }
        shopOzonsellerPluginHelper::setLog($this->getPreMessage() . sprintf(shopOzonsellerPluginTextHelper::TEXT_CRON_LOG_START, $this->task->getCronLogInfo()), '', null, false);
        if (ifset($params['account'])) $this->accounts = [(int)$params['account'] => $this->accounts[$params['account']]];
        unset($params['account']);
        try {
            $this->task->setAccounts($this->accounts);
            $this->task->run($params);
        } catch (Exception|Error|Throwable $e) {
            $this->setLog($this->task->account_id ?: 0, $e->getMessage(), 'error', $e, true);
        }
    }

    public function preExecute()
    {
        $this->accounts = shopOzonsellerPluginHelper::preIntData((new shopOzonsellerPluginAccountModel())->getAll('id'));
        if ($task_id = waRequest::param('task')) {
            $this->task = $this->getTask($task_id);
        }
    }

    public function getTasksMap()
    {
        $tasks_map = [];
        $task_files = glob(wa()->getAppPath('plugins/ozonseller/lib/cli/tasks/shopOzonsellerPlugin*.task.php'));
        foreach ($task_files as $tfile) {
            $afile = explode('/', $tfile);
            $file = array_pop($afile);
            $file = str_replace('.task.php', 'Task', $file);
            if (class_exists($file)) {
                try {
                    $task = new $file();
                    $tasks_map[$task->getCommand()] = [
                        'task' => $task,
                        'command' => $task->getCommand(),
                        'description' => $task->getDescription(),
                    ];
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                }
            }
        }
        return $tasks_map;
    }

    public function getTask($task_id, $isObj = true)
    {
        $tasks_map = $this->getTasksMap();
        if (isset($tasks_map[$task_id])) {
            if ($isObj) return $tasks_map[$task_id]['task'];
            else return $tasks_map[$task_id];
        } else return false;
    }

    public function getTaskData($task_id)
    {
        if (!$task = $this->getTask($task_id)) return false;
        return [
            'command' => $task->getCommand(),
            'params' => $task->getParams(),
            'description' => $task->getDescription(),
            'examples' => $task->getExamples(),
            'sort' => $task->getSort()
        ];
    }

    public function afterExecute()
    {
        if ($this->runErrors) {
            shopOzonsellerPluginHelper::setLog($this->getPreMessage() . shopOzonsellerPluginTextHelper::ERROR_CLI_RUN, '', null, false);
        } else {
            $cache = new waSerializeCache($this->getCacheKey(), self::ANNOUNCEMENT_CACHE_TTL, 'shop');
            $cache->set(0);
        }
        shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::TEXT_CRON_LOG_END, $this->task->getCronLogInfo()), '', null, false);
    }

    protected function setLog(int $account_id, string $message, string $type = '', $data = null, bool $announcment = false)
    {
        $source = true;
        $preMessage = $this->getPreMessage($account_id);
        if ($data) {
            if (is_object($data)) {
                $source = $data;
                $data = null;
            }
        }
        shopOzonsellerPluginHelper::setLog($preMessage . $message, $type, $data, $source);
        if ($announcment) $this->setAnnouncement();
    }

    private function getCacheKey()
    {
        $params = waRequest::param();
        $params_str = $params['task'] . '_';
        unset($params['task']);
        foreach ($params as $key => $value) {
            $params_str .= $key . '_' . $value . '_';
        }
        if ($params_str) $params_str = substr($params_str, 0, strlen($params_str) - 1);
        return sprintf(self::ANNOUNCEMENT_CACHE_KEY, strtoupper($params_str));
    }

    protected function setAnnouncement()
    {
        $params = waRequest::param();
        unset($params['task']);
        $params_msg = '-task ' . ($this->task ? $this->task->getCommand() : $this->getCommand());
        foreach ($params as $key => $value) {
            $params_msg .= ' -' . $key . ' ' . $value;
        }
        $cache = new waSerializeCache($this->getCacheKey(), self::ANNOUNCEMENT_CACHE_TTL, 'shop');
        if ($cache->isCached()) {
            $count = $cache->get() + 1;
        } else $count = 1;
        if ($count >= self::ANNOUNCEMENT_COUNT_MAX) {
            shopOzonsellerPluginHelper::setAnnouncement(sprintf(shopOzonsellerPluginTextHelper::ERROR_ANNOUNCEMENT_CLI_MESSAGE, $params_msg));
            $count = 0;
        }
        try {
            $cache->set($count);
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
        }
        $this->runErrors = true;
    }

    private function getPreMessage($account_id = null)
    {
        $params = waRequest::param();
        $preMessage = sprintf(shopOzonsellerPluginTextHelper::TEXT_CRON, ($this->task ? $this->task->getCommand() : $this->getCommand()));
        $excludeParams = ['task'];
        foreach ($params as $param => $value) {
            if (in_array($param, $excludeParams)) continue;
            $preMessage .= ' -' . $param . ' ' . $value;
        }
        if ($account_id) $preMessage .= ' (' . $this->accounts[$account_id]['name'] . ')';
        $preMessage .= PHP_EOL;
        return $preMessage;
    }

    protected function setAccounts(array $accounts)
    {
        $this->accounts = $accounts;
    }

    public function inPlaceOf(): string
    {
        return '';
    }
}