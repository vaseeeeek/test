<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
interface shopOzonsellerPluginCliTaskInterface
{
    public function getCommand(): string;

    public function run($params = null);

    public function getDescription(): array;

    public function getParams(): array;

    public function getExamples(): array;

    public function getCronLogInfo(): string;

    public function inPlaceOf(): string;

    public function getSort(): int;
}