<?php

class shopOzonsellerPluginMatchCli extends shopOzonsellerPluginOldCli
{
    const LOG_INFO = 'сопоставление товаров Ozon с товарами Shop-Script';
    public function execute()
    {
        parent::execute();
    }
}