<?php

class shopOzonsellerPluginUpdateCli extends shopOzonsellerPluginOldCli
{
    const LOG_INFO = 'обновления цены/остатков';

    public function execute()
    {
        parent::execute();
    }
}