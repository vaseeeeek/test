<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginServiceCli extends shopOzonsellerPluginOldCli
{
    const LOG_INFO = 'обновления справочников Ozon';
    public function execute()
    {
        parent::execute();
    }
}