<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2022 waResearchLab
 */

class shopOzonsellerPluginImagesUpdateCli extends shopOzonsellerPluginOldCli
{
    const LOG_INFO = 'обновления изображений';
    public function execute()
    {
        parent::execute();
    }
}