<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginServiceTask extends shopOzonsellerPluginCli implements shopOzonsellerPluginCliTaskInterface
{

    public function run($params = null)
    {
        if (!$account_id = array_key_first($this->accounts)) return;
        $this->account_id = $account_id;

        $category_preparator = new shopOzonsellerPluginCategoryPreparator();
        try {
            $categories = $category_preparator->getOzonCategoryTree($account_id, true);
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
        }
        if ($categories) {
            foreach ($categories as $category) {
                try {
                    $category_preparator->addCategory($category);
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    continue;
                }
            }
            $category_preparator->postUpdate();
        } else {
            shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_EMPTY_LIST, 'error');
        }

        $model_ozon_feature_values = new shopOzonsellerPluginOzonFeatureValuesModel();
        $model_ozon_feature_values->setAccountId($account_id);
        try {
            $model_ozon_feature_values->hardUpdateFeaturesValues(array_column($this->accounts, 'id'));
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
        }
    }

    public function getCommand(): string
    {
        return 'service';
    }

    public function getDescription(): array
    {
        $html = <<<HTML
<span>
    OZON периодически обновляет справочники. Для корректной работы плагина нужны актуальные версии справочников.<br>
    Рекомендуемая частота: не чаще 1 раза в 2-3 дня
</span>
HTML;
        return [
            'title' => _wp('Актуализация справочников'),
            'description' => $html
        ];
    }

    public function inPlaceOf(): string
    {
        return 'shopOzonsellerPluginService';
    }

    public function getCronLogInfo(): string
    {
        return _wp('Актуализация справочников');
    }

    public function getParams(): array
    {
        return [];
    }

    public function getExamples(): array
    {
        return [
            [
                'command' => '',
                'description' => _wp('Актуализация всех справочников в настроенных категориях Ozon')
            ]
        ];
    }

    public function getSort(): int
    {
        return 80;
    }
}