<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginUpgradeTask extends shopOzonsellerPluginCli implements shopOzonsellerPluginCliTaskInterface
{

    public function run($params = null)
    {
        $model = new shopOzonsellerPluginProductModel();
        foreach ($this->accounts as $account) {
            $this->account_id = $account['id'];
            if (wa()->getPlugin('ozonseller')->getSettings('upgrade', $account['id']) == '1') {
                $offer_ids = null;
                $set_id = waRequest::param('set');
                if ($set_id) {
                    $offer_ids = (new shopOzonsellerPluginProductModel())->getOfferIdsBySet($account['id'], $set_id);
                }
                try {
                    $preparator = new shopOzonsellerPluginPreparator($account['id'], shopOzonsellerPluginPreparator::MODE_PUBLIC);
                    $preparator->upgradePublics($offer_ids);
                } catch (Exception $e) {
                    $this->setLog($account['id'], $e->getMessage(), 'error', $e, true);
                    $this->setLog($account['id'], shopOzonsellerPluginTextHelper::CLI_UPGRADE_ERRORS);
                }
            }
            // Проверка статусов товаров
/*            try {
                $socket = new shopOzonsellerPluginOzonApi($account['id']);
            } catch (waException $e) {
                $this->setLog($account['id'], $e->getMessage(), 'error');
                continue;
            }
            $model->updateByField('account_id', $account['id'], ['state' => '']);
            try {
                $flag = true;
                $counter = 0;
                $last_id = '';
                while ($flag) {
                    $data = $socket->getOzonProductsList($last_id, 1000, ['visibility' => 'ARCHIVED']);
                    if (!isset($data['items'])) {
                        shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::ERROR_ESTABLISH_CONNECTION_SERVER);
                        break;
                    }
                    if (!$data['items']) break;
                    $counter += count($data['items']);
                    if ($data['total'] <= $counter) {
                        $flag = false;
                    } else {
                        $last_id = $data['last_id'];
                    }
                    $uParams = ['account_id' => $account['id'], 'offer_id' => array_column($data['items'], 'offer_id')];
                    $model->updateByField($uParams, ['state' => 'ARCHIVED']);
                }
            } catch (Exception $e) {
                $this->setLog($account['id'], $e->getMessage(), 'error');
            }*/
        }
    }

    public function getCommand(): string
    {
        return 'upgrade';
    }

    public function getDescription(): array
    {
        $html = <<<HTML
<span>
    Обновленные товары снимутся с продажи и отправятся на модерацию.<br>
    Рекомендуемая частота: не чаще 1 раза в сутки
</span>
HTML;
        return [
            'title' => _wp('Актуализация описаний и характеристик товаров'),
            'description' => $html
        ];
    }

    public function inPlaceOf(): string
    {
        return 'shopOzonsellerPluginUpgrade';
    }

    public function getCronLogInfo(): string
    {
        return _wp('Актуализация описаний и характеристик товаров');
    }

    public function getParams(): array
    {
        return [
            [
                'param' => 'account X',
                'description' => _wp('где Х - id аккаунта Ozon. Если параметр не указан будут обработаны все доступные аккаунты Ozon')
            ],
            [
                'param' => 'set SET_ID',
                'description' => _wp('где SET_ID - идентификатор списка в Shop-Script. Если параметр присутствует, то будут обновлены описания/характеристики только тех товаров, которые находятся в списке с указанным идентификатором')
            ]
        ];
    }

    public function getExamples(): array
    {
        return [
            [
                'command' => '',
                'description' => _wp('Актуализация описаний/характеристик для всех опубликованных товаров во всех аккаунтах Ozon')
            ],
            [
                'command' => '-account 1',
                'description' => _wp('Актуализация описаний/характеристик товаров опубликованных от аккаунта с id 1')
            ],
            [
                'command' => '-account 2 -set update_in_ozon',
                'description' => _wp('Актуализация описаний/характеристик товаров из списка с идентификатором update_in_ozon опубликованных от аккаунта с id 2 ')
            ]
        ];
    }

    public function getSort(): int
    {
        return 40;
    }
}