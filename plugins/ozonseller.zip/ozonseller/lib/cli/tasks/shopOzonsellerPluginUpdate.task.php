<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginUpdateTask extends shopOzonsellerPluginCli implements shopOzonsellerPluginCliTaskInterface
{
    public function run($params = null)
    {
        $errors = [];
        $mode = ifset($params['mode']);
        $model_ozon_product = new shopOzonsellerPluginProductModel();
        $model_sku = new shopProductSkusModel();
        foreach ($this->accounts as $account_id => $account) {
            $this->account_id = $account_id;
            $settings = wa('shop')->getPlugin('ozonseller')->getSettings(null, $account_id);
            try {
                $socket = new shopOzonsellerPluginOzonApi($account_id);
            } catch (Exception $e) {
                $this->setLog($account_id, $e->getMessage());
                return;
            }

            try {
                $preparator = new shopOzonsellerPluginPreparator($account_id);
            } catch (Exception $e) {
                $this->setLog($account_id, $e->getMessage());
                return;
            }

            // Проверка статусов отправленных на модерацию товаров
            if ($check_publics = $model_ozon_product->getCheckPublics($account_id)) {
                $preparator->checkPublicsState($check_publics);
            }
            $this->updateProductsCategoryInfo($account_id);

            if (!$mode || $mode == 'price') {
                // Обновление цен
                if ($total = $model_ozon_product->countByField('account_id', $account_id)) {
                    for ($i = 0; $i <= $total; $i += $settings['part_size_price']) {
                        $publics = $model_ozon_product->getPublicsForUpdatePrice($account_id, null, $i, $settings['part_size_price']);
                        $sku_ids = array_keys($publics);
                        $skus = $model_sku->getById($sku_ids);
                        $items = [];
                        foreach ($skus as $sku) {
                            $sku['currency'] = $publics[$sku['id']]['currency'];
                            $sku['ozon_category_id'] = $publics[$sku['id']]['ozon_category_id'];
                            $sku['ozon_product_id'] = (int)$publics[$sku['id']]['ozon_product_id'];
                            $prices = $preparator->getPricesBySku($sku);
                            $item = array_merge(['offer_id' => $preparator->getOfferId($sku['product_id'], $sku['id'], $sku),], $prices, ['product_id' => $sku['ozon_product_id']]);
                            $items[] = $item;
                        }
                        if ($items) {
                            try {
                                if ($result = $socket->updatePriceLists($items)) {
                                    $errors = $errors + shopOzonsellerPlugin::preparePQResult('price', $result);
                                }
                            } catch (Exception $e) {
                                $this->setLog($account_id, $e->getMessage(), 'error', $e, true);
                            }
                        }
                    }
                }
            }

            if (!$mode || $mode == 'quantity') {
                //  Обновление остатков
                if ($settings['schema'] != 'fbo') {
                    if ($total = $model_ozon_product->countByField('account_id', $account_id)) {
                        $diff = intval($total / ($total * count($settings['stock_ids']) / 100));
                        for ($i = 0; $i <= $total; $i += $diff) {
                            if ($publics = $model_ozon_product->getPublicsForUpdateStocks($account_id, null, $i, $diff)) {
                                $items = $preparator->getQuantityByPublics($publics);
                                if ($items) {
                                    try {
                                        usleep(800000);
                                        if ($result = $socket->updateProductsStocks($items)) {
                                            $errors = $errors + shopOzonsellerPlugin::preparePQResult('quantity', $result);
                                        }
                                    } catch (Exception $e) {
                                        $this->setLog($account_id, $e->getMessage(), 'error', $e, true);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if ($errors) {
                $model_log = new shopOzonsellerPluginFailLogModel();
                $publics = $model_ozon_product->getDataForFailLog($account_id, array_keys($errors));
                foreach ($publics as $public) {
                    $public['errors'] = $errors[$public['offer_id']];
                    $model_log->updateLog($account_id, $public);
                }
                shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::CLI_PRICE_QUANTITY_ERRORS, $this->accounts[$account_id]['name']));
            }
        }
    }

    public function getCommand(): string
    {
        return 'update';
    }

    public function getDescription(): array
    {
        $html = <<<HTML
<span>
    Команда без параметров обновляет цены и остатки для всех активных аккаунтов Ozon<br>
    Рекомендуемая частота: не чаще 1 раза в час
</span>
HTML;
        return [
            'title' => _wp('Актуализация цен и/или остатков'),
            'description' => $html
        ];
    }

    public function getCronLogInfo(): string
    {
        return _wp('Обновление цен/остатков');
    }

    public function inPlaceOf(): string
    {
        return 'shopOzonsellerPluginUpdate';
    }

    public function getParams(): array
    {
        return [
            [
                'param' => 'account X',
                'description' => _wp('где Х - id аккаунта Ozon. Если параметр не указан будут обработаны все доступные аккаунты Ozon')
            ],
            [
                'param' => 'mode price|quantity',
                'description' => _wp('Параметр может принимать одно из значений: price (обновление только цен) или quantity (обновление только остатков)')
            ]
        ];
    }

    public function getExamples(): array
    {
        return [
            [
                'command' => '',
                'description' => 'Обновление цени и остатков для всех доступных аккаунтов Ozon'
            ],
            [
                'command' => '-account 2 -mode price',
                'description' => 'Обновление только цен для аккаунта Ozon c id 2'
            ],
            [
                'command' => '-mode quantity',
                'description' => 'Обновление остатков для всех доступных аккаунтов Ozon'
            ]
        ];
    }

    public function getSort(): int
    {
        return 10;
    }
}