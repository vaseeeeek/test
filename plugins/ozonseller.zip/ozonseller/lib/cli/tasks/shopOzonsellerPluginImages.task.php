<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginImagesTask extends shopOzonsellerPluginCli implements shopOzonsellerPluginCliTaskInterface
{
    public function run($params = null)
    {
        $model = new shopOzonsellerPluginProductModel();
        foreach ($this->accounts as $account) {
            $this->account_id = $account['id'];
            $publics = [];
            if (!isset($params['set'])) {
                $publics = $model->getAll();
            } else {
                if ($params['set']) {
                    $set_id = $params['set'];
                    if ($set = (new shopSetModel())->getById($set_id)) {
                        $query = <<<SQL
select op.* from shop_ozonseller_product op join shop_set_products sp on op.product_id = sp.product_id 
            where op.account_id={$account['id']} and sp.set_id="$set_id"
SQL;
                        $publics = $model->query($query)->fetchAll();
                    } else {
                        $this->setLog($account['id'], sprintf(shopOzonsellerPluginTextHelper::ERROR_SET_NOT_FOUND, $params['set']));
                    }
                } else {
                    $this->setLog($account['id'], sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'set'));
                }
            }
            if ($publics) {
                try {
                    $preparator = new shopOzonsellerPluginPreparator($account['id']);
                    $socket = new shopOzonsellerPluginOzonApi($account['id']);
                    $model_sku = new shopProductSkusModel();
                    foreach ($publics as $public) {
                        $product = new shopProduct($public['product_id']);
                        if (!$product->getId()) continue;
                        if (!$sku = $model_sku->getById($public['sku_id'])) continue;
                        try {
                            if (!$images = $preparator->getProductImages($product, $sku)) {
                                $this->setLog($account['id'], shopOzonsellerPluginTextHelper::FAIL_IMAGES . ' (' . $public['product_id'] . ')');
                                continue;
                            }
                        } catch (Exception $e) {
                            $this->setLog($account['id'], $e->getMessage(), '', $e);
                            continue;
                        }
                        if (!$socket->updateImages($public['ozon_product_id'], $images)) {
                            $this->setLog($account['id'], shopOzonsellerPluginTextHelper::ERROR_IMAGES_UPDATE . '(id: ' . $public['product_id'] . ')');
                        }
                    }
                } catch (Exception $e) {
                    $this->setLog($account['id'], $e->getMessage(), 'error', $e, true);
                }
            }
        }
    }

    public function getCommand(): string
    {
        return 'images';
    }

    public function getDescription(): array
    {
        $html = <<<HTML
<span>
    Команда используется в случае если вам необходимо обновить только изображения товаров, не затрагивая описания и характеристики.<br>
    Если URL изображения не изменился, то Ozon не будет повторно загружать изображение. <br>
    Рекомендуемая частота: не чаще 1 раза в сутки
</span>
HTML;
        return [
            'title' => _wp('Обновление только изображений у товаров'),
            'description' => $html
        ];
    }

    public function inPlaceOf(): string
    {
        return 'shopOzonsellerPluginImagesUpdate';
    }

    public function getCronLogInfo(): string
    {
        return _w('Обновление изображений у товаров');
    }

    public function getParams(): array
    {
        return [
            [
                'param' => 'account X',
                'description' => _wp('где Х - id аккаунта Ozon. Если параметр не указан будут обработаны все доступные аккаунты Ozon')
            ],
            [
                'param' => 'set SET_ID',
                'description' => _wp('где SET_ID - идентификатор списка в котором находятся товары для которых необходимо обновить изображения')
            ]
        ];
    }

    public function getExamples(): array
    {
        return [
            [
                'command' => '-account 3',
                'description' => _wp('Обновит изображения для всех товаров опубликованных от аккаунта Ozon с id 3')
            ],
            [
                'command' => '-set update_images',
                'description' => 'Обновит изображения всех товаров находящихся в списке с идентификатором update_images для всех аккаунтов Ozon'
            ]
        ];
    }

    public function getSort(): int
    {
        return 50;
    }
}