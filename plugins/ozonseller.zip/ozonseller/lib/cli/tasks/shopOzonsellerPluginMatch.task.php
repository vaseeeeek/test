<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginMatchTask extends shopOzonsellerPluginCli implements shopOzonsellerPluginCliTaskInterface
{
    public function run($params = null)
    {
        $new = $exist = $non_exist = $current_page = 0;
        $field = ifset($params['field']);
        if (!$field || !in_array($field, ['id', 'sku', 'name', 'product_id'])) {
            shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_CLI_MATCH_FIELD, $field));
            return;
        }
        $importer = new shopOzonsellerPluginProductsActions();
        foreach ($this->accounts as $account) {
            $this->account_id = $account['id'];
            try {
                $socket = new shopOzonsellerPluginOzonApi($account['id']);
            } catch (Exception $e) {
                $this->setLog($account['id'], $e->getMessage(), 'error');
                continue;
            }
            $flag = true;
            $bad_offer_ids = $bad_publics = [];
            $counter = 0;
            $last_id = '';
            while ($flag) {
                $data = $socket->getOzonProductsList($last_id, 1000);
                if (!isset($data['items'])) {
                    shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::ERROR_ESTABLISH_CONNECTION_SERVER);
                    $flag = false;
                }
                $counter += count($data['items']);
                if ($result = $importer->importOzonProducts($account['id'], $data['items'], $field)) {
                    foreach ($result as $key => $value) {
                        if (wa_is_int($value)) $$key += $value;
                    }
                    if ($data['total'] <= $counter) {
                        $flag = false;
                    } else {
                        $last_id = $data['last_id'];
                    }
                    if ($result['non_exist_data']) $bad_offer_ids = array_merge($bad_offer_ids, $result['non_exist_data']);
                } else {
                    $this->setLog($account['id'], shopOzonsellerPluginTextHelper::ERROR_ESTABLISH_CONNECTION_SERVER, '', null, true);
                    $flag = false;
                }
            }
            if ($bad_offer_ids) {
                foreach (array_chunk($bad_offer_ids, 1000) as $part) {
                    try {
                        if ($data = $socket->getOzonProductInfoList($part)) {
                            foreach ($data['items'] as $item) {
                                $bad_publics[] = [
                                    'id' => $item['id'],
                                    'offer_id' => $item['offer_id'],
                                    'name' => $item['name']
                                ];
                            }
                        }
                    } catch (Exception $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    }
                }
            }
            if ($bad_publics) {
                shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::TEXT_NO_MATCHING_PRODUCTS, $account['name'], count($bad_publics)), 'import', $bad_publics, false);
            }
            $log_message = $non_exist ? sprintf(shopOzonsellerPluginTextHelper::CLI_MATСH_LOG, $non_exist) : '';
            shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::CLI_MATCH_END, $account['name'], $new, $non_exist, $log_message), '', null, false);
        }
    }

    public function getCommand(): string
    {
        return 'match';
    }

    public function getDescription(): array
    {
        $html = <<<HTML
<span>Рекомендуемая частота: не чаще 1-2 раз день</span>
HTML;
        return [
            'title' => _wp('Автоматическое сопоставление товаров Ozon с товарами Shop-Script'),
            'description' => $html
        ];
    }

    public function inPlaceOf(): string
    {
        return 'shopOzonsellerPluginMatch';
    }

    public function getCronLogInfo(): string
    {
        return _wp('Автоматическое сопоставление товаров');
    }

    public function getParams(): array
    {
        return [
            [
                'param' => 'field id|sku|name|product_id',
                'description' => _wp('Параметр может принимать одно из значений: id - id артикула, sku - код артикула, name - название артикула, product_id - id товара')
            ],
            [
                'param' => 'account X',
                'description' => _wp('где X - id аккаунта Ozon. Если параметр не указан будут обработаны все доступные аккаунты Ozon')
            ]
        ];
    }

    public function getExamples(): array
    {
        return [
            [
                'command' => '-account 7 -field id',
                'description' => 'автоматическое сопоставление товаров для аккаунта Ozon с id 7 по id артикула'
            ],
            [
                'command' => '-field sku',
                'description' => 'автоматическое сопоставление товаров для всех активных аккаунтов Ozon по коду артикула'
            ]
        ];
    }
    public function getSort(): int
    {
        return 70;
    }
}