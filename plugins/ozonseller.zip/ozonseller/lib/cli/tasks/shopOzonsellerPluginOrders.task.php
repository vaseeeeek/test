<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginOrdersTask extends shopOzonsellerPluginCli implements shopOzonsellerPluginCliTaskInterface
{
    public function run($params = null)
    {
        foreach ($this->accounts as $account) {
            $this->account_id = $account['id'];
            $settings = wa()->getPlugin('ozonseller')->getSettings(null, $account['id']);
            if (!$settings['contact_id']) continue;
            try {
                $checker = new shopOzonsellerPluginOrders($account['id']);
            } catch (Exception $e) {
                $this->setLog($account['id'], $e->getMessage(), 'error', null, true);
                continue;
            }
            if (time() - strtotime($settings['order_date']) > $settings['order_period']) {
                $since_date = date('Y-m-d\T', time() - $settings['order_period']) . '00:00:00Z';
            } else {
                $since_date = date('Y-m-d\TH:i:s\Z', strtotime($settings['order_date']));
            }
            try {
                $socket = new shopOzonsellerPluginOzonApi($account['id']);
            } catch (Exception $e) {
                $this->setLog($account['id'], $e->getMessage(), 'error', null, true);
                return;
            }
            // Отправления по FBS
            if ($settings['schema'] != 'fbo') {
                try {
                    if ($orders = $socket->getOrderList('fbs', ['filter' => ['since' => $since_date, 'to' => date('Y-m-d\TH:i:s\Z')]])) {
                        $checker->processingOrders('fbs', $orders);
                    }
                } catch (waException $e) {
                    $this->setLog($account['id'], $e->getMessage(), '', null, true);
                }
            }
            // Отправления по FBO
            if ($settings['schema'] != 'fbs') {
                try {
                    if ($orders = $socket->getOrderList('fbo', ['filter' => ['since' => $since_date]])) {
                        $checker->processingOrders('fbo', $orders);
                    }
                } catch (waException $e) {
                    $this->setLog($account['id'], $e->getMessage(), '', null, true);
                }
            }
        }
    }

    public function getCommand(): string
    {
        return 'orders';
    }

    public function getDescription(): array
    {
        $html = <<<HTML
<span>Рекомендуемая частота: не чаще 1 раза в 10 минут</span>
HTML;
        return [
            'title' => _wp('Получение заказов и обновление статусов'),
            'description' => $html
        ];
    }

    public function inPlaceOf(): string
    {
        return 'shopOzonsellerPluginOrderCheck';
    }

    public function getCronLogInfo(): string
    {
        return _wp('Синхронизация заказов');
    }

    public function getParams(): array
    {
        return [
            [
                'param' => 'account X',
                'description' => _wp('где Х - id аккаунта Ozon. Если параметр не указан будут обработаны все доступные аккаунты Ozon')
            ]
        ];
    }

    public function getExamples(): array
    {
        return [
            [
                'command' => '',
                'description' => _wp('Синхронизация заказов для всех доступных аккаунтов Ozon')
            ],
            [
                'command' => '-account 3',
                'description' => _wp('Синхронизация заказов для аккаунта Ozon с id 3')
            ]
        ];
    }

    public function getSort(): int
    {
        return 20;
    }
}