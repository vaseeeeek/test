<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginPromoTask extends shopOzonsellerPluginCli implements shopOzonsellerPluginCliTaskInterface
{
    public function run($params = null)
    {
        $mode = ifset($params['mode']);
        $model_promo = new shopOzonsellerPluginPromoModel();
        foreach ($this->accounts as $account) {
            $this->account_id = $account['id'];
            $promoController = new shopOzonsellerPluginPromosActions($account['id']);
            $ozon_promos = $promoController->getPromos($account['id']);
            $promos = $model_promo->getByField('account_id', $account['id'], 'promo_id');
            if (!$mode || $mode === 'remove') {
                foreach ($ozon_promos as $ozon_promo) {
                    if (isset($promos[$ozon_promo['id']])) continue;
                    try {
                        $promoProducts = $promoController->getAllProducts('products', $ozon_promo['id']);
                        if (!$promoProducts) continue;
                        $promoController->promoDelProducts($account['id'], array_column($promoProducts, 'id'), ['source' => 'all', 'promo_id' => $ozon_promo['id']]);
                    } catch (Exception $e) {}
                }
            }
            if (!$mode || $mode === 'add') {
                foreach ($promos as $p) {
                    if (!isset($ozon_promos[$p['promo_id']])) continue;
                    $promo = $promoController->getPromos($account['id'], true, $p['promo_id']);
                    $params = [
                        'source' => 'selected',
                        'promo_id' => $promo['id'],
                    ];
                    if ($promo['settings']['auto']) {
                        try {
                            if ($candidates = $promoController->getAllProducts('candidates', $promo['id'])) {
                                $params['ids'] = array_column($candidates, 'id');
                                $promoController->promoAddProducts($account['id'], $candidates, [], $params);
                            }
                        } catch (Exception $e) {
                            $this->setLog($account['id'], $e->getMessage(), 'error', $e, true);
                        }
                    }
                }
            }
            $model_promo->deleteOldPromos($account['id'], array_column($ozon_promos, 'id'));
        }
    }

    public function getCommand(): string
    {
        return 'promo';
    }

    public function getDescription(): array
    {
        $html = <<<HTML
<span>Рекомендуемая частота: не чаще 1 раза в сутки</span>
HTML;
        return [
            'title' => _wp('Добавление/удаление товаров в/из акции Ozon'),
            'description' => $html
        ];
    }

    public function inPlaceOf(): string
    {
        return 'shopOzonsellerPluginPromo';
    }

    public function getCronLogInfo(): string
    {
        return _wp('Актуализация акций Ozon');
    }

    public function getParams(): array
    {
        return [
            [
                'param' => 'account X',
                'description' => _wp('где Х - id аккаунта Ozon. Если параметр не указан будут обработаны все доступные аккаунты Ozon')
            ],
            [
                'param' => 'mode add|remove',
                'description' => _wp('Режим работы. Может принимать одно из значений: add (добавление товаров в акции) или remove (удаление автоматичесмки добавленных товаров в акции)')
            ]
        ];
    }

    public function getExamples(): array
    {
        return [
            [
                'command' => '',
                'description' => 'Добавление товаров во "включенные" акции и удаление автоматически добавленных Ozon товаров из "выключенных" акций'
            ],
            [
                'command' => '-account 1 -mode add',
                'description' => 'Добавление товаров во "включенные" акции Ozon для аккаунта с id 1'
            ],
            [
                'command' => '-mode remove',
                'description' => 'Удаление всех автоматически добавленных Ozon товаров из "выключенных" в плагине акций'
            ]
        ];
    }

    public function getSort(): int
    {
        return 60;
    }
}