<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginExportTask extends shopOzonsellerPluginCli implements shopOzonsellerPluginCliTaskInterface
{

    public function run($params = null)
    {
        $mode = ifset($params['mode']);
        foreach ($this->accounts as $account_id => $account) {
            $this->account_id = $account_id;
            try {
                $preparator = new shopOzonsellerPluginPreparator($account_id, shopOzonsellerPluginPreparator::MODE_PUBLIC);
            } catch (Exception $e) {
                $this->setLog($account_id, $e->getMessage(), 'error', $e, true);
                return;
            }

            if ((!$mode || $mode == 'sku') && wa()->getPlugin('ozonseller')->getSettings('all_skus', $account_id)) {
                if ($new_skus = (new shopOzonsellerPluginProductModel())->getUnpublishedSkus($account_id)) {
                    foreach ($new_skus as $new_sku) {
                        try {
                            $preparator->importProduct($new_sku['product_id'], $new_sku['ozon_category_id'], $new_sku['sku_id']);
                        } catch (waException $e) {
                            $this->setLog($account_id, $e->getMessage(), 'error', $e, true);
                        }
                    }
                }
            }

            if (!$mode || $mode == 'product') {
                $model_wait_product = new shopOzonsellerPluginWaitProductModel();
                foreach ($model_wait_product->getByField('account_id', $account_id, true) as $data) {
                    try {
                        $result = $preparator->importProduct($data['product_id'], $data['ozon_category_id']);
                        if ($result['status'] == 'ok') {
                            $model_wait_product->deleteByField(array_merge(['account_id' => $account_id], $data));
                        }
                    } catch (waException $e) {
                        $this->setLog($account_id, $e->getMessage(), 'error', $e, true);
                    }
                }
            }

            if (!$mode || $mode == 'category') {
                $model_wait_category = new shopOzonsellerPluginWaitCategoryModel();
                $new_products = $model_wait_category->getNewProducts($account_id);
                foreach ($new_products as $new_product) {
                    try {
                        $preparator->importProduct($new_product['product_id'], $new_product['ozon_category_id']);
                    } catch (waException $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    }
                }
            }
        }
    }

    public function getCommand(): string
    {
        return 'export';
    }

    public function getDescription(): array
    {
        $html = <<<HTML
<span>
    Команда без параметра публикует поставленные в очередь на публикацию товары, новые товары появившиеся в категориях и новые артикулы у ранее опубликованных товаров<br>
    Параметр <code>-mode</code>, может принимать одно из значений:<br>
    <code>product</code> — публикация товаров поставленных в очередь на публикацию вручную<br>
    <code>sku</code> — публикация новых артикулов у товаров которые ранее уже были опубликованы<br>
    <code>category</code> — публикация новых товаров категорий в соответствии с ее настройками<br>
    Рекомендуемая частота: по необходимости, но не чаще 2 раз в сутки
</span>
HTML;
        return [
            'title' => _wp('Автоматическая публикация товаров в Ozon'),
            'description' => $html
        ];
    }

    public function inPlaceOf(): string
    {
        return 'shopOzonsellerPluginExport';
    }

    public function getCronLogInfo(): string
    {
        return _wp('Автоматическая публикация товаров в Ozon');
    }

    public function getParams(): array
    {
        $description = <<<HTML
Параметр -mode, может принимать одно из значений:
product — публикация товаров поставленных в очередь на публикацию вручную
sku — публикация новых артикулов у товаров которые ранее уже были опубликованы
category — публикация новых товаров категорий в соответствии с ее настройками
HTML;

        return [
            [
                'param' => 'account X',
                'description' => _wp('где Х - id аккаунта Ozon. Если параметр не указан будут обработаны все доступные аккаунты Ozon')
            ],
            [
                'param' => 'mode sku|product|category',
                'description' => _wp($description)
            ]
        ];
    }

    public function getExamples(): array
    {
        return [
            [
                'command' => '',
                'description' => _wp('Публикация товаров из очереди и новые товары категорий')
            ],
            [
                'command' => '-mode product',
                'description' => 'Публикация товаров поставленных в очередь всех аккаунтов Ozon'
            ],
            [
                'command' => '-mode sku',
                'description' => 'Публикация новых артикулов товаров которые ранее были опубликованы для всех аккаунтов Ozon'
            ],
            [
                'command' => '-account 4 -mode category',
                'description' => 'Публикация новых товаров категорий для аккаунта Ozon с id 4'
            ]
        ];
    }

    public function getSort(): int
    {
        return 30;
    }
}