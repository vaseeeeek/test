<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginOldCli extends waCliController
{
    const LOG_INFO = 'undefined';
    const WARNING = <<<HTML
Используется устаревшая команда cron для %s! Необходимо перенастроить задание cron!
Подробнее см. в системных настройках плагина
HTML;
    public function execute()
    {
        $message = sprintf(self::WARNING,  static::LOG_INFO);
        shopOzonsellerPluginHelper::setLog($message, 'error');
        shopOzonsellerPluginHelper::setAnnouncement($message);
    }
}