<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginUpgradeCli extends shopOzonsellerPluginOldCli
{
    public const LOG_INFO = 'актуализации описаний и характеристик товаров';
    public function execute()
    {
        parent::execute();
    }
}