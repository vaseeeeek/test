<?php

class shopOzonsellerPluginOrderCheckCli extends shopOzonsellerPluginOldCli
{
    const LOG_INFO = 'синхронизации заказов';
    public function execute()
    {
        parent::execute();
    }
}