<?php
return array(
    'php' => array(
        'version' => '>=7.4',
        'strict' => true,
    ),
    'app.shop' => array(
        'version' => '>=7.0',
        'strict' => true,
    ),
    'app.installer' => array(
        'version' => '>=2.7.0',
        'strict' => true,
    )
);