<?php
$settings_config = array(
    'upgrade' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_UPGRADE,
        'description' => shopOzonsellerPluginTextHelper::SETTING_UPGRADE_DESCRIPTION,
        'control_type' => waHtmlControl::SELECT,
        'options' => array(
            array('title' => shopOzonsellerPluginTextHelper::TEXT_ALLOW, 'value' => '1'),
            array('title' => shopOzonsellerPluginTextHelper::TEXT_ALLOW_HAND, 'value' => '2'),
            array('title' => shopOzonsellerPluginTextHelper::TEXT_BAN, 'value' => '0'),
        ),
        'value' => '1',
        'subject' => 'system'
    ),
    'json_query' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_JSON_QUERY,
        'description' => shopOzonsellerPluginTextHelper::SETTING_JSON_QUERY_DESCRIPTION,
        'control_type' => waHtmlControl::CHECKBOX,
        'value' => '0',
        'subject' => 'system'
    ),
    'debug' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_DEBUG,
        'control_type' => waHtmlControl::RADIOGROUP,
        'options' => array(
            array(
                'title' => shopOzonsellerPluginTextHelper::SETTING_DEBUG_MIN,
                'value' => '0'
            ),
            array(
                'title' => shopOzonsellerPluginTextHelper::SETTING_DEBUG_AVRG,
                'value' => '1'
            ),
            array(
                'title' => shopOzonsellerPluginTextHelper::SETTING_DEBUG_FULL,
                'value' => '2'
            ),
        ),
        'value' => '0',
        'subject' => 'system'
    ),
    'product_commisions' => array(
        'title' => shopOzonsellerPluginTextHelper::TEXT_COMMISSIONS,
        'description' => shopOzonsellerPluginTextHelper::TEXT_COMMISSIONS_DESCRIPTION,
        'control_type' => waHtmlControl::CHECKBOX,
        'value' => '0',
        'subject' => 'system'
    ),
    'offer_id' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_OFFER_ID,
        'description' => shopOzonsellerPluginTextHelper::SETTING_OFFER_ID_DESCRIPTION,
        'control_type' => waHtmlControl::SELECT,
        'options' => array(
            'id' => shopOzonsellerPluginTextHelper::TEXT_OPTION_ID,
            'product_id' => shopOzonsellerPluginTextHelper::TEXT_OPTION_PRODUCT_ID,
            'sku' => shopOzonsellerPluginTextHelper::TEXT_OPTION_SKU_CODE,
            'name' => shopOzonsellerPluginTextHelper::TEXT_OPTION_SKU_NAME,
        ),
        'value' => 'id',
        'subject' => 'general',
    ),
    'all_skus' => array(
        'title' => 'Выгружать артикулы товара',
        'description' => '',
        'control_type' => waHtmlControl::SELECT,
        'options' => array(
            '0' => 'Только основной артикул',
            '1' => 'Все артикулы'
        ),
        'value' => '0',
        'subject' => 'general',
    ),
    'name' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_NAME,
        'description' => 'По правилам Ozon название должно формироваться по схеме: тип + бренд или производитель + серия (если есть) + модель + артикул производителя (если есть)',
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [
                ['value' => 'name', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_NAME],
                ['value' => 'name_sku', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_NAME_PRODUCT_SKU],
                ['value' => 'name_sku_bracket', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_NAME_PRODUCT_SKU_BRACKET],
                ['value' => 'sku', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_NAME_SKU],
                ['value' => 'title_og', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_TITLE_OG]
                /*['value' => 'auto', 'title' => shopOzonsellerPluginTextHelper::TEXT_USE_AUTO_NAME]*/
            ],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_BY_ADVANCED_PARAMS,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS
                ],
                'features' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'types' => ['text', 'varchar']
                ],
            ]
        ],
        'value' => array('type' => 'name', 'key' => ''),
        'subject' => 'general',
    ),
    'description' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_DESCRIPTION,
        'description' => 'Описание в Ozon не должно превышать 3000 знаков',
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [
                ['value' => 'description', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_DESCRIPTION],
                ['value' => 'summary', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_SUMMARY],
                ['value' => 'description_og', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_DESCRIPTION_OG]
            ],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_BY_ADVANCED_PARAMS,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS
                ],
                'blocks' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_SITE_BLOCKS_USE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_SITE_BLOCKS
                ],
                'features' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'types' => ['text', 'varchar']
                ],
            ]
        ],
        'value' => array('type' => 'description', 'key' => ''),
        'subject' => 'general'
    ),
    'br_replace' => array(
        'title' => 'Переводы строк',
        'description' => 'Укажите через запятую, какие закрывающие теги (или другие наборы символов) заменять на перевод строки (тег < br >) в описании товара при экспорте в Ozon',
        'control_type' => waHtmlControl::INPUT,
        'value' => '</p>,</h1>',
        'subject' => 'general'
    ),
    'empty_description' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_EMPTY_DESCRIPTION,
        'description' => '',
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [
                ['value' => '0', 'title' => shopOzonsellerPluginTextHelper::TEXT_SKIP_PUBLIC_PRODUCT],
                ['value' => 'summary', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_SUMMARY]
            ],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS_USE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS
                ],
                'blocks' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_SITE_BLOCKS_USE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_SITE_BLOCKS
                ],
            ]
        ],
        'value' => array('type' => '', 'key' => ''),
        'subject' => 'general',
    ),
    'image_source' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_IMAGE_SOURCE,
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'variants' => [
                'product_image' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_IMAGES,
                ],
                'sku_image' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_SKU_IMAGE,
                    'description' => shopOzonsellerPluginTextHelper::TEXT_SKU_IMAGE_DESCRIPTION
                ],
                'sku_image_overall' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_SKU_IMAGE_OVERALL,
                    'description' => shopOzonsellerPluginTextHelper::TEXT_SKU_IMAGE_OVERALL_DESCRIPTION
                ],
                'image_og' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PRODUCT_IMAGE_OG,
                ],
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS_USE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS
                ],
                'features' => [
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'title' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'main_list' => true
                ]
            ]
        ],
        'value' => array('type' => 'product_image', 'key' => 'main'),
        'class' => 'ozonseller-image-source',
        'subject' => 'general',
    ),
    'vat' => array(
        'title' => 'НДС',
        'description' => 'Выбранны в данной настройке налог будет применяться к тем товарам, у которых налог не заполнен',
        'control_type' => waHtmlControl::SELECT,
        'options' => array(
            '0' => 'Без НДС',
            '0.1' => 'НДС 10%',
            '0.2' => 'НДС 20%'
        ),
        'value' => '0',
        'subject' => 'general'
    ),
    'dimensions' => array(
        'title' => 'Габариты товаров',
        'description' => 'Выберите как определять габариты товаров: <a href="?action=settings#/shipping/" target="_blank">из настроек магазина</a> или с использованием дополнительных параметров',
        'control_type' => waHtmlControl::CUSTOM . ' shopOzonsellerPlugin::settingsDimensions',
        'value' => [
            'type' => 'shop',
            'unit' => 'm',
            'height' => '',
            'width' => '',
            'length' => '',
        ],
        'subject' => 'general_features'
    ),
    'barcode' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_BARCODE,
        'description' => shopOzonsellerPluginTextHelper::SETTING_BARCODE_DESCRIPTION,
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [['value' => '0', 'title' => shopOzonsellerPluginTextHelper::TEXT_DONT_USE]],
            'variants' => [
                'features' => [
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'title' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'main_list' => true
                ],
                'plugin_scanbarcode' => [
                    'group' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_FIELDS,
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_FIELDS,
                    'main_list' => true
                ]
            ]
        ],
        'value' => '0',
        'subject' => 'general_features',
    ),
    'soft_fail' => array(
        'title' => 'Незаполненные характеристики',
        'description' => 'Выберите, как поступать с товаром у которого не заполнены (или заполнены с ошибками) значения необязательных для публикации в Ozon характеристик',
        'control_type' => waHtmlControl::SELECT,
        'options' => array(
            ['title' => 'Публиковать как есть', 'value' => '1'],
            ['title' => 'Не публиковать, заносить в ошибки ', 'value' => '0'],
        ),
        'value' => '1',
        'subject' => 'general_features'
    ),
    'error_set' => array(
        'title' => 'Помещать товары которые не удалось опубликовать в список',
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [['value' => '0', 'title' => shopOzonsellerPluginTextHelper::TEXT_DONT_USE]],
            'variants' => [
                'sets' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_SETS,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_SETS,
                    'main_list' => true
                ]
            ]
        ],
        'value' => '0',
        'subject' => 'general_features'
    ),
    'skip_upgrade' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_SKIP_UPGRADE,
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [['value' => '0', 'title' => shopOzonsellerPluginTextHelper::TEXT_DONT_USE]],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_BY_ADVANCED_PARAMS,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS,
                ],
                'sets' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_IN_SET,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_SETS,
                ],
                'features' => [
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'title' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'main_list' => true,
                    'ftype' => shopFeatureModel::TYPE_BOOLEAN
                ],
            ]
        ],
        'value' => array('type' => '0', 'key' => ''),
        'subject' => 'general_features'
    ),
    'exclude' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_EXCLUDE,
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [['value' => '0', 'title' => shopOzonsellerPluginTextHelper::TEXT_DONT_USE]],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_BY_ADVANCED_PARAMS,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS,
                ],
                'sets' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_IN_SET,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_SETS,
                ],
                'features' => [
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'title' => shopOzonsellerPluginTextHelper::TEXT_ALLTYPE_FEATURES,
                    'main_list' => true,
                    'ftype' => shopFeatureModel::TYPE_BOOLEAN
                ],
            ]
        ],
        'value' => array('type' => '0', 'key' => ''),
        'subject' => 'general_features'
    ),
    'header_price' => array(
        'control_type' => waHtmlControl::HELP,
        'class' => 'ozonseller-setting-header',
        'value' => shopOzonsellerPluginTextHelper::TEXT_PRICES_MARKUPS,
        'subject' => 'prices'
    ),
    'price' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_PRICE,
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [
                ['value' => 'price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE],
                ['value' => 'compare_price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE_COMPARE],
                ['value' => 'purchase_price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE_PURCHASE],
            ],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_BY_ADVANCED_PARAMS,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS
                ],
                'plugin_price' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICE
                ],
                'plugin_pricetype' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICETYPE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICETYPE
                ]
            ]
        ],
        'value' => array('type' => 'price', 'key' => ''),
        'subject' => 'prices',
    ),
    'old_price' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_OLD_PRICE,
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [
                ['value' => '0', 'title' => shopOzonsellerPluginTextHelper::TEXT_DONT_USE],
                ['value' => 'price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE],
                ['value' => 'compare_price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE_COMPARE],
                ['value' => 'purchase_price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE_PURCHASE],
            ],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_BY_ADVANCED_PARAMS,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS
                ],
                'plugin_price' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICE
                ],
                'plugin_pricetype' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICETYPE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICETYPE
                ]
            ]
        ],
        'value' => array('type' => '0', 'key' => ''),
        'subject' => 'prices',
    ),
    'premium_price' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_PREMIUM_PRICE,
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [
                ['value' => '0', 'title' => shopOzonsellerPluginTextHelper::TEXT_DONT_USE],
                ['value' => 'price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE],
                ['value' => 'compare_price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE_COMPARE],
                ['value' => 'purchase_price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE_PURCHASE],
            ],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_BY_ADVANCED_PARAMS,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS
                ],
                'plugin_price' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICE
                ],
                'plugin_pricetype' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICETYPE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICETYPE
                ]
            ]
        ],
        'value' => array('type' => '0', 'key' => ''),
        'subject' => 'prices',
    ),
    'min_price' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_MIN_PRICE,
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [
                ['value' => '0', 'title' => shopOzonsellerPluginTextHelper::TEXT_DONT_USE],
                ['value' => 'price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE],
                ['value' => 'compare_price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE_COMPARE],
                ['value' => 'purchase_price', 'title' => shopOzonsellerPluginTextHelper::TEXT_PRICE_PURCHASE],
            ],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_BY_ADVANCED_PARAMS,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS
                ],
                'plugin_price' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICE
                ],
                'plugin_pricetype' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICETYPE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_PRICETYPE
                ]
            ]
        ],
        'value' => array('type' => '0', 'key' => ''),
        'subject' => 'prices',
    ),
    'markup_product' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_MARKUP_PRODUCT,
        'description' => 'Для товаров у которых установлено значение выбранного дополнительного параметра настройки наценок категории будут проигнорированы и будет использована индивидуальная наценка',
        'control_type' => 'OzonsellerUniversalCombiSelect',
        'source' => [
            'null_els' => [
                ['value' => '0', 'title' => shopOzonsellerPluginTextHelper::TEXT_NO_INDIVIDUAL_MARKUPS],
            ],
            'variants' => [
                'params' => [
                    'title' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS_USE,
                    'group' => shopOzonsellerPluginTextHelper::TEXT_ADVANCED_PARAMS
                ],
            ]
        ],
        'value' => array('type' => '0', 'key' => ''),
        'subject' => 'prices'
    ),
    'header_space' => array(
        'control_type' => waHtmlControl::HELP,
        'class' => 'ozonseller-setting-header',
        'subject' => 'prices'
    ),
    'header_quantity' => array(
        'control_type' => waHtmlControl::HELP,
        'class' => 'ozonseller-setting-header',
        'value' => shopOzonsellerPluginTextHelper::TEXT_SCHEMA_STOCKS,
        'subject' => 'prices'
    ),
    'schema' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_SCHEMA,
        'control_type' => waHtmlControl::SELECT,
        'options' => [
            ['value' => 'fbo', 'title' => shopOzonsellerPluginTextHelper::SETTING_SCHEMA_FBO],
            ['value' => 'fbs', 'title' => shopOzonsellerPluginTextHelper::SETTING_SCHEMA_FBS],
            ['value' => 'free', 'title' => shopOzonsellerPluginTextHelper::SETTING_SCHEMA_FREE]
        ],
        'value' => 'fbo',
        'subject' => 'prices'
    ),
    'stock_ids' => array(
        'control_type' => 'ozonStocks',
        'value' => array(),
        'subject' => 'prices_extend'
    ),
    'sync_additionals' => array(
        'value' => ['order' => '0', 'import' => '0'],
        'subject' => 'prices_extend'
    ),
    'contact_id' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_CONTACT_ID,
        'description' => shopOzonsellerPluginTextHelper::SETTING_CONTACT_ID_DESCRIPTION,
        'value' => null,
        'control_type' => 'orderContact',
        'subject' => 'orders',
    ),
    'order_date' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_ORDER_DATE,
        'description' => shopOzonsellerPluginTextHelper::SETTING_ORDER_DATE_DESCRIPTION,
        'value' => date('Y-m-d'),
        'control_type' => waHtmlControl::INPUT,
        'field_type' => 'date',
        'subject' => 'orders'
    ),
    'order_comment' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_ORDER_COMMENT,
        'description' => shopOzonsellerPluginTextHelper::SETTING_ORDER_COMMENT_DESCRIPTION,
        'value' => '0',
        'control_type' => waHtmlControl::CHECKBOX,
        'subject' => 'orders'
    ),
    'order_collect' => array(
        'value' => '1',
        'control_type' => 'orderCollect',
        'subject' => 'orders',
        'title' => shopOzonsellerPluginTextHelper::SETTING_ORDER_COLLECT
    ),
    'order_collect_weight_restriction' => array(
        'value' => '0',
        'title' => shopOzonsellerPluginTextHelper::SETTING_ORDER_COLLECT_RESTRICTION,
        'description' => shopOzonsellerPluginTextHelper::SETTING_ORDER_COLLECT_RESTRICTION_DESCRIPTION,
        'control_type' => waHtmlControl::INPUT,
        'field_type' => 'number',
        'class' => 'short',
        'subject' => 'orders'
    ),
    'order_period' => array(
        'value' => 7776000,
        'subject' => 'orders_extend'
    ),
    'order_params' => array(
        'control_type' => 'orderParams',
        'custom_control_wrapper' => '<div>%s%s%s</div>',
        'value' => ['fbo' => array('stock_id' => 0, 'shipping' => 0, 'payment' => 0), 'fbs' => array()],
        'subject' => 'orders_extend'
    ),
    'ozon_order_status' => array(
        'control_type' => 'orderStatuses',
        'value' => include(wa()->getAppPath('plugins/ozonseller/lib/config/data/ozon_order_statuses.php')),
        'custom_control_wrapper' => '<div>%s%s%s</div>',
        'subject' => 'orders_extend',
    ),
    'shop_orders' => array(
        'title' => shopOzonsellerPluginTextHelper::SETTING_SHOP_ORDERS,
        'description' => shopOzonsellerPluginTextHelper::SETTING_SHOP_ORDERS_DESCRIPTION,
        'value' => ['awaiting_deliver', 'acceptance_in_progress', 'awaiting_approve', 'awaiting_packaging', 'arbitration', 'cancelled', 'client_arbitration', 'delivering', 'driver_pickup', 'delivered', 'not_accepted'],
        'control_type' => waHtmlControl::GROUPBOX,
        'options' => shopOzonsellerPlugin::getOzonOrderStatuses(true)
    ),
    'calculation' => array('value' => '0', 'subject' => 'prices_extend'),
    'cron_last_start' => array('value' => ''),
    'cron_add' => array('value' => ''),
    'cron_skip' => array('value' => ''),
    'cron_update' => array('value' => ''),
    'cron_errors' => array('value' => ''),
    'cron_last_end' => array('value' => ''),

// каждый элемент - ['time' => int, 'task_id' => int]
    'last_docs' => array('value' => array()),
    'empty_ids' => array('value' => array('product_id' => 0, 'sku_id' => 0)),
    'unique_category_features' => ['value' => []],
    'null_quantity' => ['value' => [], 'subject' => 'prices_extend'],  // Признак Снять с продажи
    'null_product_quantity' => ['value' => 300, 'subject' => 'prices_extend'],
    'weight_code' => array('value' => 'weight'),
    'price_markups' => array('value' => array('price' => '1', 'old_price' => '1', 'premium_price' => '1', 'min_price' => '1'), 'subject' => 'prices_extend'),
    'longop_part' => array('value' => 50),
    'rfbs_customer_email' => array('value' => ''),
    'curl_verify' => array('value' => '1'),
    'order_by_stocks' => array('value' => 0),
    'part_size_price' => array('value' => 1000),
    'part_size_quantity' => array('value' => 500),
    'null_bad_categories' => array('value' => 0),
    'shipping_rate_id' => (array('value' => ''))
);
//TODO
/*if (isset($this->settings['image_source']['type'])) {
    $settings_config['images']['disabled'] = $this->settings['image_source']['type'] !== 'product';
}*/
return $settings_config;