<?php
return array(
    'name' => 'Ozon: Интеграция',
    'img' => 'img/ozonseller.png',
    'version' => '2023.10.1',
    'vendor' => '834834',
    'importexport' => true,
    'custom_settings' => true,
    'handlers' =>
        array(
            'backend_prod' => 'handlerBackendProd',
            'backend_product' => 'handlerBackendProduct',
            'backend_products' => 'handlerBackendProducts',
            'backend_category_dialog' => 'handlerBackendCategoryDialog',
            'backend_order_print' => 'handlerBackendOrderPrint',
//            'backend_set_dialog' => 'handlerBackendCategoryDialog',
            'products_collection' => 'handlerProductsCollection',
            'product_delete' => 'handlerProductDelete',
            'product_mass_update' => 'handlerProductMassUpdate',
            'category_save' => 'handlerCategorySave',
            'category_delete' => 'handlerCategoryDelete',
            'ole_plugin' => 'handlerOlePlugin',
//            'set_save' => 'handlerCategorySave',
//            'set_delete' => 'handlerCategoryDelete',
            'routing' => 'handlerRouting',
/* UI2 */
            'backend_prod_mass_actions' => 'handlerBackendProdMassActions',
            'backend_prod_layout' => 'handlerBackendProdLayout',
/* EOFUI2 */
            '*' => array(
                array(
                    'event_app_id' => 'shop',
                    'event' => 'order_action.*',
                    'class' => 'shopOzonsellerPluginOrders',
                    'method' => 'handlerOrderActions',
                ),
                array(
                    'event_app_id' => 'shop',
                    'event' => 'orders_collection',
                    'class' => 'shopOzonsellerPluginOrders',
                    'method' => 'handlerOrdersCollection',
                ),
                array(
                    'event_app_id' => 'shop',
                    'event' => 'orders_collection.filter',
                    'class' => 'shopOzonsellerPluginOrders',
                    'method' => 'handlerOrdersCollectionFilter',
                ),
                array(
                    'event_app_id' => 'shop',
                    'event' => 'orders_collection.prepared',
                    'class' => 'shopOzonsellerPluginOrders',
                    'method' => 'handlerOrdersCollectionPrepared',
                ),
                array(
                    'event_app_id' => 'shop',
                    'event' => 'backend_order',
                    'class' => 'shopOzonsellerPluginOrders',
                    'method' => 'handlerBackendOrder',
                ),
                array(
                    'event_app_id' => 'shop',
                    'event' => 'backend_orders',
                    'class' => 'shopOzonsellerPluginOrders',
                    'method' => 'handlerBackendOrders',
                ),
                array(
                    'event_app_id' => 'shop',
                    'event' => 'controller_before.shopBackendAutocompleteController',
                    'class' => 'shopOzonsellerPluginOrders',
                    'method' => 'handlerOrderAutocomplete',
                ),
                array(
                    'event_app_id' => 'shop',
                    'event' => 'controller_before.shopWorkflowPrepareController',
                    'class' => 'shopOzonsellerPluginOrders',
                    'method' => 'handlerWorkflowPrepare',
                )
            ),
        ),
);
