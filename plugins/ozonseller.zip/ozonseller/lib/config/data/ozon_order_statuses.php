<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2022 waResearchLab
 */
return array(
    'fbo' => array(
        'acceptance_in_progress' => '0',
        'awaiting_approve' => '0',
        'awaiting_packaging' => '0',
        'awaiting_deliver' => '0',
        'arbitration' => '0',
        'cancelled' => '0',
        'cancelled_after_ship' => '0',
        'client_arbitration' => '0',
        'delivering' => '0',
        'driver_pickup' => '0',
        'delivered' => '0',
        'not_accepted' => '0'
    ),
    'fbs' => array()
);