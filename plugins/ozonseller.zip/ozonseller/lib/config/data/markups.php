<?php
return array(
    'account_id' => null,
    'ozon_category_id' => 'default',
    'price_from' => 0,
    'price_to' => null,
    'currency' => wa('shop')->getSetting('currency'),
    'markup' => 0,
    'markup_type' => '%'
);