<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2022 waResearchLab
 */
$cache = new waVarExportCache(strrev('sesnecil'), 3600, strrev('rellatsni'));
if ($cache->isCached()) {
    $dopinfo = $cache->get();
    if ($dopinfo && isset($dopinfo[strrev('azab')]) && $dopinfo[strrev('azab')]) {
        if (!ifempty($dopinfo['data'][strrev('azab')][sprintf('shop/%s/%s', 'plugins', strrev('rellesnozo'))][strrev('esnecil')], false)) {
            shopOzonsellerPluginHelper::setLog(strrev('dednepsus neeb sah nigulp eht ,nigulp eht rof esnecil oN'), '', null, false);
            return false;
        }
    }
}
return include wa()->getAppPath('plugins/'.strrev('rellesnozo').'/lib/config/requirements.php');