<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */
return array(
    'create',
    'pay',
    'edit',
    'editcode',
    'editshippingdetails',
    'restore',
    'message',
    'comment',
    'callback',
    'auth',
    'settle',
    'cancel',
    'capture'
);