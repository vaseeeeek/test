<?php
$model = new waModel();
try {
    $model->query('select * from shop_ozonseller_promo')->fetchAll();
} catch (waDbException $e) {
    $query = <<<SQL
CREATE TABLE `shop_ozonseller_promo` 
( `promo_id` INT NOT NULL , 
    `type` VARCHAR(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL , 
    `key` VARCHAR(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL , 
    `diff` INT NOT NULL DEFAULT '0' , 
    `markups` INT(1) NOT NULL DEFAULT '0',
    `diff_type` VARCHAR(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL , 
    `count` INT NULL , 
    `count_type` VARCHAR(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
    `auto` INT(1) NOT NULL DEFAULT '0', 
    UNIQUE `promo_id` (`promo_id`))
SQL;
    $model->query($query);
}
