<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2022 waResearchLab
 */

$model = new waAppSettingsModel();
if (!$old_setting = $model->getByField(['app_id' => 'shop.ozonseller', 'name' => 'images'])) {
    return;
}
$setting = [
    'type' => 'sku_image',
    'key' => $old_setting['value']
];
try {
    $model->set('shop.ozonseller', 'image_source', json_encode($setting));
    $model->del('shop.ozonseller', 'images');
} catch (Exception $e) {
    waLog::log($e->getMessage(), shopOzonsellerPluginTextHelper::FILE_LOG_ERROR);
}
$model = new waModel();
$query = <<<SQL
alter table shop_ozonseller_category_features modify value varchar(256) null;
SQL;
try {
    $model->query($query);
} catch (waDbException $e) {
    waLog::log($e->getMessage(), shopOzonsellerPluginTextHelper::FILE_LOG_ERROR);
}
