<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
foreach (['1690233546', '1690233557', '1692615741'] as $mo) {
    try {
        waFiles::delete(wa()->getAppPath('plugins/ozonseller/lib/updates/' . $mo . '.php'));
    } catch (waException $e) {
    }
}