<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */
$model = new waModel();
try {
    $model->query('select offer_id from shop_ozonseller_product');
} catch (waDbException $e) {
    $query = <<<SQL
ALTER TABLE `shop_ozonseller_product` ADD `offer_id` VARCHAR(128) NULL AFTER `task_id`, ADD UNIQUE `offer_id` (`offer_id`);
SQL;
    $model->query($query);
    $upd_query = <<<SQL
update shop_ozonseller_product set offer_id = sku_id
SQL;
    $model->query($upd_query);
    $query = <<<SQL
ALTER TABLE `shop_ozonseller_product` CHANGE `offer_id` `offer_id` VARCHAR(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;
SQL;
    $model->query($query);
}