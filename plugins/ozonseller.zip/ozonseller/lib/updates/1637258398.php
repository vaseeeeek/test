<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */
$model = new waModel();
$query = <<<SQL
ALTER TABLE `shop_ozonseller_ozon_feature_values` DROP `info`, DROP `picture`;
SQL;
try {
    $model->query($query);
} catch (waDbException $e) {
}