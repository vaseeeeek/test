<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */
$model = new waModel();

try {
    $model->query('select state from shop_ozonseller_product')->fetchAll();
} catch (waDbException $e) {
    $query = <<<SQL
ALTER TABLE `shop_ozonseller_product` ADD `state` VARCHAR(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL AFTER `checksum`;
SQL;
    $model->exec($query);
}
