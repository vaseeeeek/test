<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2022 waResearchLab
 */
$model = new waModel();
$query = <<<SQL
SELECT ext from shop_ozonseller_category_features 
SQL;
try {
    $model->query($query);
} catch (waDbException $e) {
    $model->query('alter table shop_ozonseller_category_features add ext varchar(16) null');
}
