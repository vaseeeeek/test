<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2022 waResearchLab
 */
$model = new waAppSettingsModel();
if ($setting = $model->get('shop.ozonseller', 'ozon_order_status')) {
    $setting = json_decode($setting, true);
    if (!isset($setting['fbo']['cancelled_after_ship'])) {
        $tmp = ['fbo' => [], 'fbs' => $setting['fbs']];
        foreach ($setting['fbo'] as $k => $v) {
            $tmp['fbo'][$k] = $v;
            if ($k == 'cancelled') {
                $tmp['fbo']['cancelled_after_ship'] = '0';
            }
        }
        $model->set('shop.ozonseller', 'ozon_order_status', json_encode($tmp));
    }
}