<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */
$model = new waModel();
try {
    $model->query('TRUNCATE TABLE shop_ozonseller_ozon_feature_values');
} catch (waDbException $e) {
    waLog::log($e->getMessage());
}