<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */
$base_path = wa()->getAppPath('plugins/ozonseller/');
$files = [
    'templates/actions/backend/docActions.html',
];
foreach ($files as $file) {
    try {
        waFiles::delete($file);
    } catch (waException $e) {
    }
}