<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
$model = new waModel();
try {
    $model->query('select to_del from shop_ozonseller_ozon_category limit 1');
} catch (waDbException $e) {
    $query = <<<SQL
alter table shop_ozonseller_ozon_category add to_del tinyint default 0 null
SQL;
    $model->query($query);
}
