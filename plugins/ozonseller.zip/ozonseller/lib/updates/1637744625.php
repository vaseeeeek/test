<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */
$file = wa()->getAppPath('plugins/ozonseller/lib/cli/shopOzonsellerPluginCheckModerating.cli.php');
if (file_exists($file)) {
    try {
        waFiles::delete($file);
    } catch (waException $e) {
        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
    }
}