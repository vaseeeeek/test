<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2022 waResearchLab
 */
$model = new waAppSettingsModel();
$old_settings = ['order_stock_id', 'order_stock_id_fbo'];
$settings = $model->getByField('app_id', 'shop.ozonseller', 'name');
$check = false;
foreach ($old_settings as $old_setting) {
    if (isset($settings[$old_setting])) {
        $check = true;
    }
}
if ($check) {
    if (!isset($settings['order_params'])) {
        $settings['order_params'] = array(['fbo' => array('stock_id' => 0, 'shipping' => 0, 'payment' => 0), 'fbs' => array()]);
    }
    foreach ($old_settings as $os) {
        switch ($os) {
            case 'order_stock_id':
                foreach (json_decode($settings['stock_ids']['value'], true) as $ostock_id => $stock_id) {
                    $settings['order_params']['fbs'][$ostock_id] = [
                        'stock_id' => $stock_id == 'count' ? 0 : $stock_id,
                        'shipping' => 0,
                        'payment' => 0
                    ];
                }
                break;
            case 'order_stock_id_fbo':
                $settings['order_params']['fbo']['stock_id'] = $settings[$os];
                break;
        }
    }
    foreach ($old_settings as $old_setting) {
        $model->del('shop.ozonseller', $old_setting);
    }
    $model->set('shop.ozonseller', 'order_params', json_encode($settings['order_params']));
}