<?php
$model = new waAppSettingsModel();
$settings = $model->where('app_id="shop.ozonseller" and name in ("unique_category_features", "null_quantity")')->fetchAll();
foreach ($settings as $setting) {
    $value = json_decode($setting['value']);
    if (!$value && !is_array($value)) {
        try {
            $model->insert(['app_id' => 'shop.ozonseller', 'name' => $setting['name'], 'value' => json_encode([])], 1);
        } catch (Exception $e) {
            continue;
        }
    }
}