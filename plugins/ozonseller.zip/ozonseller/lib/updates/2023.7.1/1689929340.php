<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
$model = new waModel();
$queries = [
    'alter table shop_ozonseller_product drop key offer_id',
    'alter table shop_ozonseller_product add constraint offer_id unique (offer_id, account_id)',
    'alter table shop_ozonseller_product drop key sku_id',
    'alter table shop_ozonseller_product add constraint sku_id unique (sku_id, account_id)',
    'alter table shop_ozonseller_product drop key task_id',
    'alter table shop_ozonseller_product add constraint task_id unique (task_id, account_id)'
];
foreach ($queries as $query) {
    try {
        $model->query($query);
    } catch (waDbException $e) {
        waLog::log($e->getMessage());
    }
}