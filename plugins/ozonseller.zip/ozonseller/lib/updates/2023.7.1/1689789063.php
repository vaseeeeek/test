<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

$files = [
    'lib/actions/backend/shopOzonsellerPluginBackendSetup.action.php',
    'lib/actions/backend/shopOzonsellerPluginBackendSetupOld.action.php'
];
$path = wa()->getAppPath('plugins/ozonseller/');
foreach ($files as $file) {
    try {
        waFiles::delete($path . $file, true);
    } catch (waException $e) {
        waLog::log($e->getMessage());
    }
}