<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
$model = new waModel();
$query = <<<SQL
SELECT ext from shop_ozonseller_category_features 
SQL;
try {
    $model->query($query);
} catch (waDbException $e) {
    $model->query('alter table shop_ozonseller_category_features add ext varchar(16) null');
}

$field = $model->query('SHOW COLUMNS FROM shop_ozonseller_ozon_feature_values like "category_id"')->fetchAll();
if ($field  && ($field[0]['Type'] !== 'int' || $field[0]['Null'] !== 'NO' || $field[0]['Default'] !== "0")) {
    $model->query('truncate table shop_ozonseller_ozon_feature_values');
    $query = <<<SQL
alter table shop_ozonseller_ozon_feature_values modify category_id int default 0 not null;
SQL;
    try {
        $model->query($query);
    } catch (waDbException $e) {
    }
    try {
        (new waAppSettingsModel())->updateByField(['app_id' => 'shop.ole', 'name' => 'oz_order_number'], 0);
    } catch (Exception $e) {
    }
}