<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
$model = new waModel();
$model_settings = new waAppSettingsModel();

$schema_file = wa()->getAppPath('plugins/ozonseller/lib/config/db.php', 'shop');
if (!file_exists($schema_file) && is_readable($schema_file)) {
    throw new waException('Отсутствует файл db.php');
}
$tables = include($schema_file);
if (!$table = ifset($tables['shop_ozonseller_account'])) throw new waException('Некорректная схема БД (account)');
try {
    $model->query('select * from shop_ozonseller_account limit 1');
} catch (waDbException $e) {
    $model->createSchema(['shop_ozonseller_account' => $table]);
    $params = ['app_id' => 'shop.ozonseller', 'name' => ['client_id', 'token']];
    $account = $model_settings->getByField($params, 'name');
    if ($account) {
        $query = <<<SQL
INSERT INTO shop_ozonseller_account (client_id, token, status, name) VALUE ({$account['client_id']['value']}, "{$account['token']['value']}", 1, "Ozon Account")
SQL;
        $model->query($query);
        $model_settings->deleteByField($params);
    }
}

if (!$table = ifset($tables['shop_ozonseller_account_settings'])) throw new waException('Некорректная схема БД (settings)');
try {
    $model->query('select * from shop_ozonseller_account_settings limit 1');
} catch (waDbException $e) {
    $model->createSchema(['shop_ozonseller_account_settings' => $table]);
    $query = <<<SQL
select id from shop_ozonseller_account limit 1
SQL;
    if ($account_id = $model->query($query)->fetchField('id')) {
        $source_settings = include(wa()->getAppPath('plugins/ozonseller/lib/config/settings.php'));
        $settings = $model_settings->getByField(['app_id' => 'shop.ozonseller'], 'name');
        unset($settings['reimages']);
        $model_settings->set('shop.ozonseller', 'shop_orders', json_encode(array_values(json_decode($settings['shop_orders']['value'], true))));
        $exclude_settings = ['update_time', 'client_id', 'token'];
        $del_settings = [];
        foreach ($settings as $name => $value) {
            if (in_array($name, $exclude_settings) || !isset($source_settings[$name]['subject'])) continue;
            $del_settings[] = $name;
            $query = <<<SQL
INSERT INTO shop_ozonseller_account_settings (account_id, name, value) VALUE ($account_id, "$name", s:value)
SQL;
            try {
                $model->query($query, ['value' => $value['value']]);
            } catch (waDbException $e) {
                waLog::log($e->getMessage(), 'ozonseller.metaupdate.error.log');
            }
        }
        if ($del_settings) $model_settings->deleteByField(['app_id' => 'shop.ozonseller', 'name' => $del_settings]);
        $query = <<<SQL
select distinct order_id from shop_order_params where name="ozon_posting_number"
SQL;
        if ($order_ids = $model->query($query)->fetchAll(null, true)) {
            $orders_data = [];
            foreach ($order_ids as $order_id) {
                $orders_data[] = sprintf('%s, "%s", "%s"', $order_id, 'ozon_account_id', $account_id);
            }
            if ($orders_data) {
                $values = implode('), (', $orders_data);
                $query = <<<SQL
            INSERT INTO shop_order_params (order_id, name, value) VALUES ($values) 
ON DUPLICATE KEY UPDATE order_id=VALUES(order_id), name=VALUES(name), value=VALUES(value)
SQL;
                $model->query($query);
            }
        }
        $ptables = [
            'shop_ozonseller_category_features',
            'shop_ozonseller_category_markups',
            'shop_ozonseller_fail_log',
            'shop_ozonseller_product',
            'shop_ozonseller_promo',
            'shop_ozonseller_wait_category',
            'shop_ozonseller_wait_product'
        ];
        foreach ($ptables as $ptable) {
            $query = <<<SQL
select account_id from $ptable limit 1
SQL;
            try {
                $model->query($query)->fetchAll();
            } catch (waDbException $e) {
                try {
                    $query = <<<SQL
alter table $ptable add account_id int null;
SQL;
                    $model->query($query);
                    $query = <<<SQL
update $ptable set account_id=$account_id
SQL;
                    $model->query($query);
                    switch ($ptable) {
                        case 'shop_ozonseller_category_markups':
                            $query = <<<SQL
alter table shop_ozonseller_category_markups drop key `UNIQUE`;
SQL;
                            $model->query($query);
                            $query = <<<SQL
alter table shop_ozonseller_category_markups
    add constraint `UNIQUE`
        unique (account_id, ozon_category_id, price_from);
SQL;
                            $model->query($query);
                            break;
                        case 'shop_ozonseller_promo':
                            $query = <<<SQL
alter table shop_ozonseller_promo drop key promo_id
SQL;
                            $model->query($query);
                            $query = <<<SQL
alter table shop_ozonseller_promo add constraint promo_id unique (account_id, promo_id)
SQL;
                            $model->query($query);
                            break;
                        case 'shop_ozonseller_category_features':
                            $query = <<<SQL
alter table shop_ozonseller_category_features drop key `UNIQUE`
SQL;
                            $model->query($query);
                            $query = <<<SQL
alter table shop_ozonseller_category_features
    add constraint `UNIQUE`
        unique (account_id, ozon_category_id, type_id, ozon_feature_id)
SQL;
                            $model->query($query);
                            break;
                        case 'shop_ozonseller_wait_category':
                            $query = <<<SQL
alter table shop_ozonseller_wait_category drop key `UNIQUE`
SQL;
                            $model->query($query);
                            $query = <<<SQL
alter table shop_ozonseller_wait_category add constraint `UNIQUE` unique (account_id, category_id, ozon_category_id)
SQL;
                            $model->query($query);
                            break;
                    }
                    $query = <<<SQL
alter table $ptable modify account_id int not null first;
SQL;
                    $model->query($query);
                } catch (waDbException $e) {
                    waLog::log($e->getMessage(), 'ozonseller.metaupdate.error.log');
                }
            }
        }
    }
}

foreach ($tables as $table => $fields) {
    foreach ($fields as $field => $db_Schema) {
        $query = <<<SQL
select $field from $table limit 1
SQL;
        try {
            $model->query($query);
        } catch (waDbException $e) {
            $model->addColumn($field, $tables, null, $table);
        }
    }
}
wa('installer');
installerHelper::flushCache();
wa('shop');