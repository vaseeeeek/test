<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
$model_settings = new waAppSettingsModel();
$source = include(wa()->getAppPath('plugins/ozonseller/lib/config/settings.php'));
$settings = $model_settings->get('shop.ozonseller');
foreach ($settings as $key => $value) {
    if (isset($source[$key]['control_type']) && in_array($source[$key]['control_type'], [waHtmlControl::INPUT, waHtmlControl::TEXTAREA])) continue;
    $json = json_decode($value, true);
    if (is_array($json)) {
        $settings[$key] = $json;
    }
}
$path = wa()->getConfigPath('shop') . '/plugins/ozonseller/backupSettings.php';
try {
    if (!file_exists($path)) waFiles::create($path);
    waUtils::varExportToFile($settings, $path);
} catch (Exception $e) {
    waLog::log($e->getMessage());
}