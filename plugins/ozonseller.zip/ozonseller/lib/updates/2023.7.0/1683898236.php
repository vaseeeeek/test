<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
$model = new waAppSettingsModel();
$setDim = $model->get('shop.ozonseller', 'dimensions');
if (!$setDim || !is_array($setDim)) {
    $setDim = [
        'type' => 'shop',
        'unit' => 'm',
        'height' => '',
        'width' => '',
        'length' => ''
    ];
} else {
    foreach (['type', 'unit', 'height', 'width', 'length'] as $field) {
        if (!isset($setDim[$field])) $setDim[$field] = '';
    }
}
$model->set('shop.ozonseller', 'dimensions', json_encode($setDim));
/*$shop_orders = $model->get('shop.ozonseller', 'shop_orders');
if (!is_array($shop_orders)) $shop_orders = [];
$model->set('shop.ozonseller', 'shop_orders', json_encode(array_values($shop_orders)));*/