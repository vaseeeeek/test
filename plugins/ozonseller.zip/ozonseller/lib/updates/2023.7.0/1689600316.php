<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
$files = [
    'js/vendors/vue/vue.min.js',
    'lib/actions/backend/shopOzonsellerPluginBackendHandDelete.action.php',
    'lib/config/install.php',
    'templates/actions/backend/dialogs/categoryDialog.html',
    'templates/actions/backend/dialogs/include.dialog.info.html',
    'templates/actions/backend/logs/',
    'templates/actions/backend/ozon-category/',
    'templates/actions/backend/setup/promos/include.promo.products.html',
    'templates/actions/backend/setup/promos/include.promo.view.settings.html',
    'templates/actions/backend/setup/promos/include.promos.list.html',
    'templates/actions/backend/setup/promos/promo.info.html',
    'templates/actions/backend/setup/import-category.html',
    'templates/actions/backend/setup/import-import.html',
    'templates/actions/backend/setup/import.logs.html',
    'templates/actions/backend/setup/import-promos.html',
    'templates/actions/backend/setup/import-settings.html',
    'templates/actions/backend/setup/import-settings-orders.html',
    'templates/actions/backend/setup/import-settings-prices.html',
    'templates/actions/backend/setup/import-waits.html',
    'templates/actions/backend/setup/include.cron.info.html',
    'templates/actions/backend/setup/include.waits.html',
    'templates/actions/backend/setup/limits.info.html',
    'templates/actions/backend/BackendHandDelete.html',
    'templates/actions/backend/BackendSetup.html',
    'templates/actions/backend/block_gradusnik.html',
    'templates/actions/backend/handler.backend.order.html',
    'templates/actions/backend/handler.backend.orders.html',
    'templates/actions/backend/settings/include.settings.cron.tr.html'
];
$path = wa()->getAppPath('plugins/ozonseller/');
foreach ($files as $file) {
    try {
        waFiles::delete($path . $file, true);
    } catch (waException $e) {
        waLog::log($e->getMessage());
    }
}