<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
$path = wa()->getAppPath('plugins/ozonseller/', 'shop');
$files_to_delete = [
    'lib/cli/shopOzonsellerPluginTest.cli.php'
];