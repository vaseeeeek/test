<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

$model = new waAppSettingsModel();
$params = ['app_id' => 'shop.ozonseller', 'name' => 'br_replace'];
$setting = $model->getByField($params);
$setting = explode(',', $setting['value']);
foreach (['<ul>', '</ul>', '<li>', '</li>'] as $el) {
    $k = array_search($el, $setting);
    if ($k !== false) {
        unset($setting[$k]);
    }
}
$setting = implode(',', $setting);
try {
    $model->updateByField($params, ['value' => $setting]);
} catch (Exception $e) {
    waLog::log($e->getMessage());
}