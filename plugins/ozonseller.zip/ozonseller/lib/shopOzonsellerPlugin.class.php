<?php

class shopOzonsellerPlugin extends shopPlugin
{
    const UI2_VERSION = '10.0.2';

    public function saveSettings($settings = [], $account_id = null)
    {
        $source_settings = $this->getOriginalSettings();
        if ($account_id) {
            $model = new shopOzonsellerPluginAccountSettingsModel();
            foreach ($settings as $name => $value) {
                if (isset($source_settings[$name]['subject'])) {
                    $value = is_array($value) ? json_encode($value) : $value;
                    $model->insert(['account_id' => $account_id, 'name' => $name, 'value' => $value], 1);
                }
            }
        } else {
            $model = new waAppSettingsModel();
            foreach ($settings as $name => $value) {
                if (!isset($source_settings[$name]['subject'])) {
                    $model->set('shop.ozonseller', $name, is_array($value) ? json_encode($value) : $value);
                }
            }
        }
    }

    public function getSettings($name = null, $account_id = null)
    {
        $source_settings = $this->getOriginalSettings();
        if (!$account_id && !$name) {
            return (new waAppSettingsModel())->get('shop.ozonseller');
        }
        if ((!$account_id && $name && isset($source_settings[$name]['subject']))) {
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_SETTINGS_NO_ACCOUNT);
        }
        $settings = array_merge(parent::getSettings(null), (new shopOzonsellerPluginAccountSettingsModel())->getSettings(null, $account_id));
        foreach ($settings as $key => $value) {
            if (isset($source_settings[$key]['subject']) && is_array(ifset($source_settings[$key]['value']))) {
                if (is_string($value)) $settings[$key] = json_decode($value, true);
            } elseif (wa_is_int($value)) $settings[$key] = (int)$value;
        }
        if ($name) return ifset($settings[$name]);
        else return $settings;
    }

    public function getAllAccountsSettings()
    {
        $settings = [];
        foreach ((new shopOzonsellerPluginAccountModel())->getAll('id') as $account) {
            $settings[$account['id']] = $this->getSettings(null, $account['id']);
        }
        return $settings;
    }

    public function handlerBackendProd($params)
    {
        $product_id = $params['product']['id'];
        $count = (new shopOzonsellerPluginProductModel())->countByField('product_id', $params['product']['id']);
        $url_back = wa()->getUrl();
        $li = <<<HTML
<li>
    <a href="{$url_back}products/$product_id/ozonseller/">
        <span>Ozon</span>
        <span class="count badge light-gray" style="color: var(--white);">$count</span>
    </a>
</li>
HTML;

        return [
            'sidebar_item' => $li
        ];
    }

    public function handlerBackendProduct($product)
    {
        $publics = (new shopOzonsellerPluginProductModel())->countByField('product_id', $product['id']);
        $product_id = $product['id'];
        $new_editor = false;
        $view = wa()->getView();
        $template = $this->path . '/templates/actions/backend/handlers/handler.backend.product.html';
        $view->assign(compact('publics', 'product_id', 'new_editor'));
        return array(
            'toolbar_section' => $view->fetch($template),
        );
    }

    public function handlerBackendProducts()
    {
        $this->addCss('css/ozonseller_old.css');
        $this->addCss('css/ozonseller.icons16.css');
        $path = wa()->getAppStaticUrl('shop', true) . 'plugins/ozonseller/js/ozonseller.products.js';
        $li_organize = '';
        $li_export = <<<HTML
<li>
<a id="ozonseller_products_export" href="#"><i class="ozonseller-icon16 ozon icon16"></i><i class="icon16 loading" style="display: none"></i>Ozon</a>
</li> 
<script src="$path" type="text/javascript"></script>
HTML;
        $li_viewmode = <<<HTML
<li class="list-view-mode list-view-mode-skus"><a class="ozonseller-publics" action="1" href="#" title="Опубликованные в Ozon товары из представленных на экране"><i class="ozonseller-icon16 ozon-tb"></i></a></li>
<li class="list-view-mode list-view-mode-skus"><a class="ozonseller-publics" action="2" href="#" title="Не прошедшие предварительную модерацию в Ozon из представленных на экране"><i class="ozonseller-icon16 ozon-tb-bw"></i></a></li>
<li class="list-view-mode list-view-mode-skus"><a class="ozonseller-publics" action="0" href="#" title="Неопубликованные в Ozon товары из представленных на экране"><i class="ozonseller-icon16 ozon-no-tb"></i></a></li>
HTML;
        return array(
            'toolbar_export_li' => $li_export,
            'viewmode_li' => $li_viewmode,
            'toolbar_organize_li' => $li_organize
        );
    }

    public function handlerBackendCategoryDialog($category)
    {
        if ($category['type']) return null;
        if (!$accounts = (new shopOzonsellerPluginAccountModel())->getAllAccounts(true)) return;
        $model = new shopOzonsellerPluginWaitCategoryModel();
        $isDebug = shopOzonsellerPluginHelper::isDebug();
        $model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        $accSettings = [];
        $subcats = 0;
        foreach ($accounts as $account) {
            $model_ozon_category->setAccountId($account['id']);
            $subcats = $model->getSubcategoryParam($account['id'], $category['id']);
            $accSettings[$account['id']] = [
                'items' => array_values($model->getByCategoryId($account['id'], $category['id'])),
                'subcategories' => $subcats,
                'ozon_categories' => array_values($model_ozon_category->getAssociatedCategoriesFilled())
            ];
        }
        $view = wa()->getView();
        $template = $this->path . '/templates/actions/backend/dialogs/categoryDialog.vue';
        $view->assign([
            'accounts' => json_encode($accounts),
            'accSettings' => json_encode($accSettings),
            'isDebug' => $isDebug,
            'subcats' => $subcats
        ]);
        return $view->fetch($template);
    }

    public function handlerBackendProdMassActions(&$params)
    {
        if (version_compare(wa()->getVersion('shop'), self::UI2_VERSION, '>=')) {
            $params['actions']['export']['actions'][] = [
                'id' => 'ozonseller_public',
                'name' => 'Ozon',
                'icon' => '<i id="ozonseller-dialog-icon" class="ozonseller-icon16 ozon"></i>',
                'pinned' => true,
                'custom_handler' => 'checkPublics'
            ];
        }
    }

    public function handlerBackendProdLayout(&$params)
    {
        if (version_compare(wa()->getVersion('shop'), self::UI2_VERSION, '>=')) {
            $this->addJs('js/ozonseller.prod.layout.js');
            $this->addCss('css/ozonseller.css');
            $this->addCss('css/ozonseller.icons16.css');
        }
    }

    public function handlerCategoryDelete($category)
    {
        $model = new shopOzonsellerPluginWaitCategoryModel();
        $model->deleteByField('category_id', $category['id']);
    }

    public function handlerCategorySave($category)
    {
        $params = waRequest::post('ozonseller');
        $subcategories = ifset($params['subcategories'], 0);
        $model = new shopOzonsellerPluginWaitCategoryModel();
        $model->deleteByField('category_id', $category['id']);
        if (!isset($params['ozon_category_ids'])) return;
        foreach ($params['ozon_category_ids'] as $account_id => $ozon_ids) {
            foreach ($ozon_ids as $ozon_id) {
                $data = [
                    'account_id' => $account_id,
                    'category_id' => $category['id'],
                    'subcategories' => $subcategories,
                    'ozon_category_id' => $ozon_id
                ];
                try {
                    $model->insert($data, 1);
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error', $params);
                }
            }
        }
    }

    public function handlerProductDelete($params)
    {
        $query = <<<SQL
select account_id,ozon_product_id from shop_ozonseller_product where product_id in (i:ids)
SQL;
        $publics = (new shopOzonsellerPluginProductModel())->query($query, ['ids' => $params['ids']])->fetchAll('account_id', 2);
        foreach ($publics as $account_id => $ozon_product_ids) {
            try {
                (new shopOzonsellerPluginOzonApi($account_id))->archiveProducts($ozon_product_ids);
            } catch (Exception $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            }
        }
        (new shopOzonsellerPluginProductModel())->deleteByField('product_id', $params['ids']);
    }

    public function handlerRouting($route = [])
    {
        if (wa()->getEnv() === 'backend') {
            return ['products/<id>/ozonseller/?' => 'backend/viewInfo'];
        }
    }

    public function handlerBackendOrderPrint($order)
    {
        if (!isset($order['params']['ozon_posting_number'])) return;
        $posting_number = $order['params']['ozon_posting_number'];
        $date = wa_date('j F Y, H:i', $order['params']['ozon_shipment_date']);
        $html = <<<HTML
<div id="ozonseller-order-info">
    <div class="field-group">
        <div class="field">
            <div class="name" style="text-align: right; width: 180px;">Номер отправления Ozon</div>
            <div class="value" style="margin-left: 200px;"><strong>$posting_number</strong></div>
        </div>
        <div class="field">
            <div class="name" style="text-align: right; width: 180px;">Дата отгрузки</div>
            <div class="value" style="margin-left: 200px;"><strong>$date</strong></div>
        </div>
    </div>
</div>
<script>
    $(function () {
        $('#s-order-items').before($('#ozonseller-order-info'));
    });
</script>
HTML;
        return ['info_section' => $html];
    }

    /**
     * Функция обработчик хука products_collection
     */
    public function handlerProductsCollection($params)
    {
        $this->product_collection = $params['collection'];
        $hash = $this->product_collection->getHash();
        if (strpos($hash[0], 'ozonseller-') !== 0) {
            return null;
        }
        $hash_key = preg_replace('/^ozonseller\-/', '', $hash[0]);
        if (!$pids = wa()->getStorage()->get('shop/ozonseller/' . $hash_key)) {
            $this->product_collection->addTitle(shopOzonsellerPluginTextHelper::TEXT_FILTER_RESULT_NOT_FOUND);
            $this->product_collection->addWhere("p.id = 'id/ot'");
            return true;
        }
        $product_ids = $pids['pids'] ? $pids['pids'] : [0];
        $this->product_collection->addWhere("p.id IN (" . implode(',', $product_ids) . ")");
        $this->product_collection->addTitle($pids['title']);
        return true;
    }

    public function handlerProductMassUpdate($params)
    {
        // TODO FIX
        /*        $model_product = new shopOzonsellerPluginProductModel();
                if (!$sku_changed = array_keys($params['sku_changes'])) return;
                if (!$publics = $model_product->getPublicsForUpdatePrice($sku_changed)) {
                    return;
                }
                try {
                    $preparator = new shopOzonsellerPluginPreparator();
                    $socket = new shopOzonsellerPluginOzonApi();
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage());
                    return;
                }
                $items = $errors = [];
                foreach ($params['sku_changed'] as $sku) {
                    $sku['currency'] = $publics[$sku['id']]['currency'];
                    $sku['ozon_category_id'] = $publics[$sku['id']]['ozon_category_id'];
                    $sku['ozon_product_id'] = (int)$publics[$sku['id']]['ozon_product_id'];
                    $prices = $preparator->getPricesBySku($sku);
                    $item = array_merge(['offer_id' => (string)$sku['id']], $prices, ['product_id' => $sku['ozon_product_id']]);
                    $items[] = $item;
                }
                try {
                    if ($items) {
                        $result = $socket->updatePriceLists($items);
                        $errors = self::preparePQResult('price', $result);
                    }
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                }
                if ($this->getSettings('schema') != 'fbo') {
                    if ($params['stocks_changed_sku_ids']) {
                        if ($publics = $model_product->getByField('sku_id', $params['stocks_changed_sku_ids'], 'sku_id')) {
                            $items = $preparator->getQuantityByPublics($publics);
                            if ($items) {
                                try {
                                    $result = $socket->updateProductsStocks($items);
                                    $errors = array_merge($errors, shopOzonsellerPlugin::preparePQResult('quantity', $result));
                                } catch (Exception $e) {
                                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                                }
                            }
                        }
                    }
                }
                if ($errors) {
                    $model_log = new shopOzonsellerPluginFailLogModel();
                    $publics = (new shopOzonsellerPluginProductModel())->getDataForFailLog(array_keys($errors));
                    foreach ($publics as $public) {
                        $public['errors'] = $errors[$public['sku_id']];
                        $model_log->updateLog($public);
                    }
                    shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::CLI_PRICE_QUANTITY_ERRORS);
                }*/
    }

    public function handlerOlePlugin()
    {
        $title = shopOzonsellerPluginTextHelper::TEXT_OZON_POSTING_NUMBER;
        $before = <<<JS
() => {
    $('#order-list').find('tr').each((idx, tr) => {
        if (!$(tr).find('td.s-ozonseller-order-td').length) {
            $('td', tr).eq(4).after('<td class="s-ozonseller-order-td"></td>');
        }
    });
}
JS;

        $table = <<<JS
(order, row) => {
    if (!order.params || !order.params.ozon_posting_number) return;
    if (row.find('td.s-ozonseller-order-td').length) {
       $(row).find('td.s-ozonseller-order-td').html('<div class="s-ozonseller-order"  title="$title"><i class="icon16 ozonseller-icon16 ozon"></i> '+ order.params.ozon_posting_number + '</div>');                 
    }
}
JS;
        $split = <<<JS
(order, details) => {
    if (!order.params || !order.params.ozon_posting_number) return;
    if (details.length && !details.find('div.s-ozonseller-order').length) {
        details.append('<div class="s-ozonseller-order split" title="$title"><i class="icon16 ozonseller-icon16 ozon"></i> '+ order.params.ozon_posting_number + '</div>');            
    }
} 
JS;
        return [
            'table' => ['orders' => $table, 'before' => $before],
            'split' => ['orders' => $split]
        ];
    }

    public static function getAdvancedParams()
    {
        $query = 'select distinct name from shop_product_params order by name';
        return (new shopProductParamsModel())->query($query)->fetchAll(null, 1);
    }

    public static function getSiteBlocks()
    {
        wa('site');
        return array_keys((new siteBlockModel())->getAll('id'));
    }

    public static function getPaymentsShippingsMethods($type, $is_options = true)
    {
        $methods = (new shopPluginModel())->getByField('type', $type, 'id');
        if (!$is_options) return $methods;
        $options = [['title' => shopOzonsellerPluginTextHelper::TEXT_DONT_USE, 'value' => '0']];
        foreach ($methods as $method_id => $method) {
            $options[] = ['value' => $method_id, 'title' => $method['name']];
        }
        return $options;
    }

    public static function preparePQResult($type, $result)
    {
        $errors = [];
        $true_errors = [
            'SKU_STOCK_NOT_CHANGE',
            'NOT_FOUND_ERROR',
            'PRICE_IS_NOT_SENT',
            'SOURCE_TYPE_NOT_FOUND',
            'NOTICE'
        ];
        foreach ($result as $item) {
            if (!$item['updated']) {
                foreach ($item['errors'] as $error) {
                    $error['message'] = isset(shopOzonsellerPluginTextHelper::OZON_ERRORS[strtoupper($error['code'])]) ? shopOzonsellerPluginTextHelper::OZON_ERRORS[strtoupper($error['code'])] : $error['message'];
                    if (!in_array($error['code'], $true_errors)) {
                        try {
                            $const = constant('shopOzonsellerPluginTextHelper::TEXT_UPDATE_' . strtoupper($type));
                        } catch (Error $e) {
                            shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_UNKNOWN_CONSTANT, $type), 'error');
                            $const = strtoupper($type);
                        }
                        $errors[$item['offer_id']][] = $const . ': ' . $error['code'] . ' (' . $error['message'] . ')';
                    }
                }
            }
        }
        return $errors;
    }

    public static function getOzonStocks($account_id)
    {
        $cache = new waSerializeCache('ozonseller_ozon_stocks_' . $account_id, 600);
        if ($cache->isCached()) {
            $stocks_ozon = $cache->get();
        } else {
            $stocks_ozon = (new shopOzonsellerPluginOzonApi($account_id))->getOzonStocks();
        }
        return $stocks_ozon ?: [];
    }

    public static function getOzonOrderStatuses($is_options = false)
    {
        $statuses = [
            'awaiting_deliver' => shopOzonsellerPluginTextHelper::OZON_ORDER_AWAITING_DELIVER,
            'acceptance_in_progress' => shopOzonsellerPluginTextHelper::OZON_ORDER_ACCEPTANCE_IN_PROGRESS,
            'awaiting_approve' => shopOzonsellerPluginTextHelper::OZON_ORDER_AWAITING_APPROVE,
            'awaiting_packaging' => shopOzonsellerPluginTextHelper::OZON_ORDER_AWAITING_PACKAGING,
            'arbitration' => shopOzonsellerPluginTextHelper::OZON_ORDER_ARBITRATION,
            'cancelled' => shopOzonsellerPluginTextHelper::OZON_ORDER_CANCELLED,
            'cancelled_after_ship' => shopOzonsellerPluginTextHelper::OZON_ORDER_CANCELLED_AFTER_SHIP,
            'client_arbitration' => shopOzonsellerPluginTextHelper::OZON_ORDER_CLIENT_ARBITRATION,
            'delivering' => shopOzonsellerPluginTextHelper::OZON_ORDER_DELIVERING,
            'driver_pickup' => shopOzonsellerPluginTextHelper::OZON_ORDER_DRIVER_PICKUP,
            'delivered' => shopOzonsellerPluginTextHelper::OZON_ORDER_DELIVERED,
            'not_accepted' => shopOzonsellerPluginTextHelper::OZON_ORDER_NOT_ACCEPTED,
        ];
        if ($is_options) {
            foreach ($statuses as $status => $title) {
                $options[] = ['title' => $title, 'value' => $status];
            }
        }
        return $is_options ? $options : $statuses;
    }
    public function getOriginalSettings()
    {
        return $this->getSettingsConfig();
    }
}