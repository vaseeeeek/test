<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginAccountModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_account';

    public function getAllAccounts($only_enabled = false, $key = null)
    {
        $accounts = $this->select('*')->order('id');
        if ($only_enabled) $accounts->where('status=1');
        // if (!waLicensing::check('shop/plugins/ozonseller')->isPremium()) {
        //     $accounts->where('id=(select min(id) from shop_ozonseller_account)');
        // }
        return shopOzonsellerPluginHelper::preIntData($accounts->fetchAll($key));
    }

    public function deleteById($value)
    {
        parent::deleteById($value);
        $params = ['account_id' => $value];
        (new shopOzonsellerPluginAccountSettingsModel())->deleteByField($params);
        (new shopOzonsellerPluginCategoryFeaturesModel())->deleteByField($params);
        (new shopOzonsellerPluginCategoryMarkupsModel())->deleteByField($params);
        (new shopOzonsellerPluginFailLogModel())->deleteByField($params);
        (new shopOzonsellerPluginPromoModel())->deleteByField($params);
        (new shopOzonsellerPluginWaitCategoryModel())->deleteByField($params);
        (new shopOzonsellerPluginWaitProductModel())->deleteByField($params);
        (new shopOzonsellerPluginProductModel())->deleteByField($params);
    }

    public function getAllAccountsWithSettings($settings_type = null)
    {
        $accounts = $this->getAllAccounts();
        foreach ($accounts as &$account) {
            if ($settings_type) {
                $account['settings'] = shopOzonsellerPluginHelper::getAccountSettingsType($account['id'], $settings_type);
            } else {
                $account['settings'] = wa()->getPlugin('ozonseller')->getSettings(null, $account['id']);
            }
        }
        return shopOzonsellerPluginHelper::preIntData($accounts);
    }

    public function chekAppOzonAccount($client_id, $token)
    {
        $response = false;
        foreach (['client_id', 'token'] as $field) {
            if ($data = $this->getByField($field, $$field)) $response = $data['id'];
            break;
        }
        return $response;
    }

    public function insert($data, $type = 0)
    {
        // if (!waLicensing::check('shop/plugins/ozonseller')->isPremium()) {
        //     if ($this->countAll()) {
        //         return false;
        //     }
        // }
        return parent::insert($data, $type);
    }
}