<?php

class shopOzonsellerPluginProductModel extends shopOzonsellerPluginModel
{
    const OZON_STATUSES = [
        'moderating' => shopOzonsellerPluginTextHelper::TEXT_OZON_STATUS_MODERATING,
        'processed' => shopOzonsellerPluginTextHelper::TEXT_OZON_STATUS_PROCESSED,
        'failed_moderation' => shopOzonsellerPluginTextHelper::TEXT_OZON_STATUS_FAILED_MODERATION,
        'failed_validation' => shopOzonsellerPluginTextHelper::TEXT_OZON_STATUS_FAILED_VALIDATION,
        'failed' => shopOzonsellerPluginTextHelper::TEXT_OZON_STATUS_FAILED
    ];

    const OZON_TRUE_PUBLIC = [
        'processed'
    ];

    protected $table = 'shop_ozonseller_product';
    protected $id = ['account_id', 'sku_id'];

    public function getAllProductIds($account_id = null)
    {
        $query = <<<SQL
select product_id from shop_ozonseller_product
SQL;
        if ($account_id) $query.= ' where account_id=i:account_id';
        if (!$product_ids = $this->query($query, ['account_id' => $account_id])->fetchAll(null, true)) $product_ids = [0];
        return $product_ids;
    }

    /**
     *  Возвращает перечень товаров находящихся на модерации в Ozon
     */
    public function getCheckPublics($account_id, $product_ids = null)
    {
        $where = 'account_id=i:account_id and (state="moderating" or task_id is not null)';
        if ($product_ids) {
            $where .= ' and product_id in(i:product_ids)';
        }
        return $this->where($where, ['account_id' => $account_id, 'product_ids' => $product_ids])->fetchAll('product_id', 2);
    }

    public function getAllPublics($account_id = null)
    {
        return $this->select('*')->where($account_id ? ('account_id=' . (int)$account_id) : '')->fetchAll('product_id', 2);
    }

    public function getPublicsForUpdatePrice($account_id, $sku_ids = null, $offset = null, $limit = null)
    {
        if ($limit === null) {
            $limit = wa()->getPlugin('ozonseller')->getSettings('part_size_price');
        }
        $where = ' WHERE account_id=i:account_id';
        if ($sku_ids) {
            $where = ' and op.sku_id IN(i:sku_ids) ';
        }
        $query = <<<SQL
select op.product_id, op.sku_id, op.ozon_category_id, op.ozon_product_id, sp.currency from shop_ozonseller_product op
join shop_product sp on op.product_id = sp.id $where 
SQL;
        if ($offset !== null) {
            $query .= <<<SQL
order by op.sku_id limit $limit offset $offset
SQL;
        }
        return $this->query($query, ['account_id' => $account_id, 'sku_ids' => $sku_ids])->fetchAll('sku_id');
    }

    public function getPublicsForUpdateStocks($account_id, $sku_ids = null, $offset = null, $limit = null)
    {
        if ($limit === null) {
            $limit = wa()->getPlugin('ozonseller')->getSettings('part_size_quantity');
        }
        $sku_where = $sku_ids ? 'and op.sku_id in (i:sku_ids)' : '';
        $publics = [];
        if (wa()->getPlugin('ozonseller')->getSettings('schema', $account_id) != 'fbo') {
            $query = <<<SQL
select op.* from shop_ozonseller_product op
    join shop_product sp on op.product_id=sp.id
    join (select * from shop_ozonseller_category_features socf where socf.ozon_feature_id=0 and socf.value='1') cf
    on cf.type_id=sp.type_id and cf.ozon_category_id=op.ozon_category_id where op.account_id=$account_id $sku_where
union
select op.* from shop_ozonseller_product op where account_id=$account_id and op.fbs=1 $sku_where
order by sku_id
SQL;
            if ($offset !== null) {
                $query .= <<<SQL
 limit $limit offset $offset
SQL;
            }
            $publics = $this->query($query, ['sku_ids' => $sku_ids])->fetchAll();
        }
        return $publics;
    }

    public function getPublicsByCategoryId($account_id, $ozon_category_id, $product_type_id = null)
    {
        if ($product_type_id) {
            $query = <<<SQL
select * from shop_ozonseller_product op join shop_product sp on sp.id=op.product_id where op.ozon_category_id=i:ozon_category_id and sp.type_id=i:type_id and account_id=i:account_id
SQL;
        } else {
            $query = <<<SQL
select * from shop_ozonseller_product where ozon_category_id=i:ozon_category_id and account_id=i:account_id
SQL;
        }
        return $this->query($query, ['account_id' => $account_id, 'ozon_category_id' => $ozon_category_id, 'type_id' => $product_type_id])->fetchAll();
    }

    public function getPublicForUpdate($ozon_category_id = null, $type_id = null)
    {
        $setting = wa('shop')->getPlugin('ozonseller')->getSettings('exclude');
        $key = ifset($setting['key']);
        switch ($setting['type']) {
            case 'params':
                $query = <<<SQL
select sop.sku_id, sop.product_id from shop_ozonsellep_product sop where sop.task_id is null and sop.product_id not in
(select spp.product_id from shop_product_params where name=$key)
SQL;
                break;
            case 'sets':
                $query = <<<SQL
select sop.sku_id, sop.product_id from shop_ozonsellep_product sop where sop.task_id is null and sop.product_id not in
(select ssp.product_id from shop_set_products where ssp.set_id=$key)
SQL;
                break;
            case '0':
            default:
                $query = <<<SQL
select sop.sku_id, sop.product_id from shop_ozonsellep_product sop where sop.task_id is null
SQL;
        }
        $publics = $this->query($query)->fetchAll('product_id', 2);
        return $publics;
    }

    public function getUnpublishedSkus($account_id)
    {
        if (!$data = $this->getAllPublics()) {
            return [];
        }
        $product_ids = array_keys($data);
        $query = <<<SQL
select product_id,id from shop_product_skus where product_id in (i:product_ids) and available=1
SQL;
        $product_skus = $this->query($query, ['account_id'=> $account_id, 'product_ids' => $product_ids])->fetchAll('product_id', 2);
        if (!$product_skus) return [];
        $new_publics = [];
        foreach ($product_skus as $product_id => $skus) {
            if (!$new_skus = array_diff($skus, array_column($data[$product_id], 'sku_id'))) {
                continue;
            }
            foreach ($new_skus as $sku_id) {
                $new_publics[] = [
                    'product_id' => $product_id,
                    'sku_id' => $sku_id,
                    'ozon_category_id' => $data[$product_id][0]['ozon_category_id']
                ];
            }
        }
        return $new_publics;
    }

    public function countPublic($account_ids, $ozon_category_id = null, $product_ids = null)
    {
        $query = 'select distinct product_id from shop_ozonseller_product where %s';
        $where = $params = [];
        if ($ozon_category_id) {
            $where[] = 'ozon_category_id in (i:ozon_category_id)';
            $params['ozon_category_id'] = $ozon_category_id;
        }
        if ($product_ids !== null) {
            $where[] = 'product_id in (i:product_ids)';
            $params['product_ids'] = $product_ids;
        }
        if ($account_ids) {
            $where[] = 'account_id in (i:account_ids)';
            $params['account_ids'] = is_array($account_ids) ?: [$account_ids];
        }
        if ($where) {
            $where = implode(' and ', $where);
        } else {
            $where = '1';
        }
        $query = sprintf($query, $where);
        $result = $this->query($query, $params)->count();
        return $result;
    }

    public function getDataForFailLog($account_id, $offer_ids)
    {
        $query = <<<SQL
SELECT product_id, sku_id, ozon_category_id, offer_id FROM $this->table where account_id=i:account_id and offer_id in (s:offer_ids)
SQL;
        return $this->query($query, ['account_id' => $account_id, 'offer_ids' => $offer_ids])->fetchAll('offer_id');

    }

    public function getDistinctPublicIds($field, $where = '')
    {
        if (!$this->fieldExists($field)) {
            return [];
        }
        if ($where) $where = ' where ' . $where;
        $query = 'select distinct ' . $this->escape($field) . ' from ' . $this->table . $where;
        return $this->query($query)->fetchAll(null, true);
    }

    public function getNullQuantityFeatureValues($feature_id, $product_ids, $offer_ids = null)
    {
        $data = ['product' => [], 'skus' => []];
        if (!$feature_id || !$product_ids) return $data;
        $query = <<<SQL
SELECT * from shop_product_features WHERE feature_id=$feature_id AND product_id IN (i:product_ids) AND feature_value_id=1 AND sku_id IS NULL
SQL;
        $data['product'] = $this->query($query, ['product_ids' => $product_ids])->fetchAll();
        if ($offer_ids) {
            $query = <<<SQL
SELECT spf.*, sop.offer_id from shop_product_features spf JOIN shop_ozonseller_product sop ON spf.sku_id=sop.sku_id
    WHERE spf.feature_id=$feature_id AND spf.product_id IN (i:product_ids) AND spf.feature_value_id=1 AND sop.offer_id IN (s:offer_ids) IS NULL
SQL;
            $data['skus'] = $this->query($query . ' IS NOT NULL', ['product_ids' => $product_ids, 'offer_ids' => $offer_ids])->fetchAll();
        }
        return $data;
    }

    public function getOzonProductIds($account_id, $product_ids)
    {
        if (!is_array($product_ids)) {
            $product_ids = [$product_ids];
        }
        $query = <<<SQL
select ozon_product_id from $this->table where account_id=$account_id and product_id in (i:product_ids)
SQL;
        return $this->query($query, ['product_ids' => $product_ids])->fetchAll(null, true);
    }

    public function getSkusByOfferIds($account_id, $offer_ids, $field_key = 'offer_id')
    {
        if (!$offer_ids) return [];
        $query = <<<SQL
SELECT sps.*, sop.offer_id, sp.currency FROM shop_product_skus sps JOIN shop_ozonseller_product sop ON sps.id=sop.sku_id JOIN shop_product sp ON sps.product_id=sp.id where sps.id IN (SELECT sku_id FROM $this->table WHERE sop.account_id=$account_id and offer_id IN (s:offer_ids))
SQL;
        return $this->query($query, ['offer_ids' => $offer_ids])->fetchAll($field_key);
    }

    public function getOfferIdsBySet($account_id, $set_id) {
        $query = <<<SQL
select offer_id from $this->table op join shop_set_products ssp on op.product_id = ssp.product_id where op.account_id=$account_id and ssp.set_id="$set_id"
SQL;
        return $this->query($query)->fetchAll(null, true);
    }

    public function getPromoData($account_id, $ozon_product_ids)
    {
        $query = <<<SQL
select sps.id, sps.id sku_id, sps.product_id, sps.price, sps.compare_price, sps.purchase_price, sp.currency, op.ozon_category_id, op.ozon_product_id
from shop_product_skus sps 
    join shop_ozonseller_product op on sps.id=op.sku_id
    join shop_product sp on sps.product_id=sp.id
where op.account_id=$account_id and op.ozon_product_id in (i:ids)
SQL;
        return $this->query($query, ['ids' => $ozon_product_ids])->fetchAll();
    }

    public function deleteLostTasks($account_id, $offer_ids)
    {
        $query = <<<SQL
delete from $this->table where account_id=$account_id and offer_id in (i:ids) and task_id is not null
SQL;
        $this->query($query, ['ids' => $offer_ids]);
    }
}