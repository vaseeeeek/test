<?php

class shopOzonsellerPluginFailLogModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_fail_log';

    public function getSummaryInfo()
    {
        $query = <<<SQL
select distinct fl.datetime, fl.product_id, sp.name, oc.name as category_name from
(select max(datetime) as datetime, product_id from shop_ozonseller_fail_log group by product_id) fl
    join shop_product sp on fl.product_id=sp.id
    join shop_ozonseller_fail_log fl1 on sp.id = fl1.product_id and fl.datetime=fl1.datetime
    join shop_ozonseller_ozon_category oc on fl1.ozon_category_id=oc.id order by fl.datetime desc
SQL;
        $logs = $this->query($query)->fetchAll('product_id');
        foreach ($logs as &$log) {
            $log['items'] = [];
        }
        return $logs;
    }

    public function getInfoByProductId($product_id)
    {
        $query = <<<SQL
select * from shop_ozonseller_fail_log where product_id=(i:product_id) order by datetime desc;
SQL;
        return $this->query($query, ['product_id' => $product_id])->fetchAll();
    }

    public function updateLog($account_id, $data)
    {
        if (!$product_id = $data['product_id']) {
            return false;
        }
        if (!$ozon_category_id = $data['ozon_category_id']) {
            return false;
        }
        if (!$sku_id = $data['sku_id']) {
            return false;
        }
        $this->deleteByField(['account_id' => $account_id, 'product_id' => $product_id, 'sku_id' => $sku_id, 'ozon_category_id' => $ozon_category_id]);
        $errors = [];
        foreach ($data['errors'] as $error) {
            $params = [
                'account_id' => $account_id,
                'product_id' => $product_id,
                'sku_id' => $sku_id,
                'ozon_category_id' => $ozon_category_id,
                'message' => $error,
                'datetime' => date('Y-m-d H:i:s')
            ];
            $errors[] = $params;
        }
        if ($errors) {
            $this->multipleInsert($errors);
        }
    }
}