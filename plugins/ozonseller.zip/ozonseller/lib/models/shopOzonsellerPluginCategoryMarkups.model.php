<?php


class shopOzonsellerPluginCategoryMarkupsModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_category_markups';
    protected $id = ['account_id', 'ozon_category_id', 'price_from'];

    public function getAllMarkups($account_id)
    {
        $query = <<<SQL
select * from shop_ozonseller_category_markups where account_id=$account_id order by price_from
SQL;
        return $this->query($query)->fetchAll('ozon_category_id', 2);
    }

    public function getByOzonId($account_id, $category_id, $sort = 'ASC')
    {
        $sort = strtoupper($sort) == 'ASC' ? 'ASC' : 'DESC';
        $query = <<<SQL
 select * from shop_ozonseller_category_markups where ozon_category_id=? and account_id=$account_id order by price_from $sort
SQL;
        return $this->query($query, $category_id)->fetchAll();
    }
}