<?php

class shopOzonsellerPluginOzonCategoryModel extends shopCategoryModel
{
    const
        BOOL_FALSE = ['NO', 'НЕТ', '-', '0'],
        BOOL_TRUE = ['YES', 'ДА', '1'],
        CACHE_FEATURE_KEY = 'ozonseller_features_%s',
        CACHE_FEATURE_VALUE_KEY = 'ozonseller_feature_values_%s_%s_%s',
        CACHE_TTL = 86400,
        OZON_DESCRIPTION_ATTRIBUTE = 4191,
        OZON_LIMIT = 5000,
        REAL_VALUE_TYPES = ['String', 'multiline', 'Integer', 'Decimal', 'Boolean', 'URL', 'ImageURL'],
        RICH_CONTENT_ID = 11254,
        VIDEO_COMPLEX_ID = 100001,
        VIDEO_FEATURES = [21841, 21837, 21845];


    /**
     *   Для следующих характеристик значения разные для разных категорий несмотря на одинаковый dictionary_id
     *   8229 - Тип товара, 9461 - Коммерческий тип,
     */
    const UNIQUE_CATEGORY_FEATURE_VALUES = [8229, 9461];

    /**
     *   (цитата)
     *      Мы еще не изменили параметры обязательности данного параметра в методе [https://api-seller.ozon.ru/v3/category/attribute]
     *      В данный момент главное изображение необходимо прописывать в primary_image. Все остальные изображение так же прописываются в массиве images.
     *   (конец цитаты)
     *   4194 - Изображение (главное), 4195 - Изображения, 4180 - Название, 4497 - Вес с упаковкой, 4191 - Описание (Аннотация)
     */
    const EXCLUDE_OZON_FEATURES = [4194, 4195, 4180, 4497, self::OZON_DESCRIPTION_ATTRIBUTE];


    protected $table = 'shop_ozonseller_ozon_category';
    private $account_id = null;

    /**
     *   Возвращает полную информацию по категории Ozon: категория, характеристики, наценки, привязанные типы товаров (в т.ч. незаполненные)
     * @param int $ozon_category_id
     * @return array
     * @throws waException
     */
    public function getCategoryFullData($ozon_category_id, $account_id)
    {
        $this->account_id = $account_id;
        if (!$category = $this->select('id, name, status')->where('id=? and status>0', $ozon_category_id)->fetchAssoc()) {
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_NOT_FOUND, $ozon_category_id), 704);
        }
        $this->setAccountId($account_id);
        $model_category_features = new shopOzonsellerPluginCategoryFeaturesModel();
        $category['ozon_features'] = $this->getFeaturesByCategoryId($ozon_category_id);
        $category['markups'] = (new shopOzonsellerPluginCategoryMarkupsModel())->getByOzonId($account_id, $ozon_category_id, 'desc');
        $query = <<<SQL
select distinct type_id from {$model_category_features->getTableName()} where account_id=$account_id and ozon_category_id=?
SQL;

        $category['types'] = array_keys($model_category_features->query($query, $ozon_category_id)->fetchAll('type_id'));
        return shopOzonsellerPluginHelper::preIntData($category);
    }

    public function getFeaturesByCategoryId($ozon_category_id, $required_only = false)
    {
        $key = sprintf(self::CACHE_FEATURE_KEY, $ozon_category_id);
        $cache = new waSerializeCache($key, self::CACHE_TTL);
        if ($cache->isCached()) {
            $features = $cache->get();
        } else {
            $features = [];
            $socket = new shopOzonsellerPluginOzonApi($this->account_id);
            try {
                $ozon_features = $socket->getCategoryFeatures($ozon_category_id);
            } catch (Exception $e) {
                if ($e->getCode() == '3' && strpos($e->getMessage(), 'category not found') !== false) {
                    $bad_category = $this->getById($ozon_category_id);
                    shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_NOT_EXIST, is_array($bad_category['name']) ? $bad_category['name'] : 'undefined', $ozon_category_id, ''), 'error');
                    $new_category_ids = $this->getAnalogCategoryOzon($ozon_category_id);
                    if ($new_category_ids) {
                        $new_category_id = array_shift($new_category_ids);
                        $this->moveToOzonCategory($ozon_category_id, $new_category_id);
                        if (!$new_category = $this->getById($new_category_id)) {
                            $cats = $this->socket->getCategoryTree($new_category_id);
                            if ($new_category = $cats[0]) {
                                $this->add($new_category);
                            }
                        }
                        $message_ext = sprintf(shopOzonsellerPluginTextHelper::TEXT_PRODUCT_MOVE, $new_category['name'], $new_category_id);
                        $message_ext .= ' ' . shopOzonsellerPluginTextHelper::TEXT_CATEGORY_NOT_EXIST_WARNING;
                    } else {
                        if (wa()->getPlugin('ozonseller')->getSettings('null_bad_categories')) {
                            $this->moveToOzonCategory($ozon_category_id, 0);
                            $message_ext = shopOzonsellerPluginTextHelper::TEXT_CATEGORY_NOT_EXIST_NULL;
                        } else {
                            $message_ext = shopOzonsellerPluginTextHelper::TEXT_CATEGORY_NOT_EXIST_HAND;
                        }
                    }
                    $message = sprintf(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_NOT_EXIST, $bad_category['name'], $ozon_category_id, $message_ext);
                    throw new waException($message, 744);
                }
            }
            foreach ($ozon_features as $of) {
                if (in_array($of['id'], self::EXCLUDE_OZON_FEATURES)) continue;
                $features[$of['id']] = $of;
            }
            $cache->set($features);
        }
        if ($required_only) {
            $features = array_filter($features, function ($f) {
                return $f['is_required'] ? true : false;
            });
        }
        if (!$features) {
            $cache->delete();
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_OZON_FEATURES_EMPTY, $ozon_category_id));
        }
        return $features;
    }

    public function getFeatureValues($ozon_category_id, $feature_id, $dictionary_id = null, $assoc = true)
    {
        if ($dictionary_id === null) {
            if (!$dictionary_id = $this->getDictionaryId($ozon_category_id, $feature_id)) return [];
        }
        $values = (new shopOzonsellerPluginOzonFeatureValuesModel())->getFeatureValues($ozon_category_id, $feature_id, $dictionary_id);
        if ($assoc) {
            $data = [];
            foreach ($values as $v) {
                $data[$v['id']] = $v['value'];
                $values = $data;
            }
        }
        return $values;
    }

    public function getDictionaryId($ozon_category_id, $ozon_feature_id)
    {
        $features = $this->getFeaturesByCategoryId($ozon_category_id);
        return ifset($features[$ozon_feature_id]['dictionary_id']);
    }

    /**
     *  Возвращает полную информацию по полностью сопоставленным категориям
     */
    public function getFullFilledCategories($account_id)
    {
        $this->account_id = $account_id;
        if (!$category_ids = $this->getAssociatedCategoriesFilled()) {
            return false;
        }
        $default_markups = (new shopOzonsellerPluginCategoryMarkupsModel())->getByOzonId($account_id,'default', 'desc');
        $model_type_feature = new shopOzonsellerPluginCategoryFeaturesModel();
        $categories = [];
        foreach (array_keys($category_ids) as $category_id) {
            $category = $this->getCategoryFullData($category_id, $account_id);
            $type_ids = $this->getFilledTypeIds($account_id, $category_id);
            $types = [];
            foreach ($category['types'] as $key => $type_id) {
                if (!in_array($type_id, $type_ids)) {
                    continue;
                }
                $types[$type_id] = $model_type_feature->getByField(['ozon_category_id' => $category_id, 'type_id' => $type_id, 'account_id' => $account_id], 'ozon_feature_id');
            }
            $category['types'] = $types;
            if (!$category['markups']) $category['markups'] = $default_markups;
            $categories[$category_id] = $category;
        }
        return $categories;
    }

    /**
     *   Возвращает перечень всех сопоставленных категорий (вне зависимости от того заполнены настройки или нет)
     * @return array
     */
    public function getAssociatedCategoriesAll($account_id)
    {
        $model = new shopOzonsellerPluginCategoryFeaturesModel();
        $query = <<<SQL
select * from {$this->table} where id in(select distinct ozon_category_id from {$model->getTableName()} where account_id=$account_id) order by name;
SQL;
        return $this->query($query)->fetchAll('id');
    }

    /**
     *   Возвращает перечень категорий в которых полностью сопоставлены обязательные характеристики хотя бы для одного типа товаров
     * @return array
     */
    public function getAssociatedCategoriesFilled()
    {
        if (!$this->account_id) throw new waException(shopOzonsellerPluginTextHelper::ERROR_NO_ACCOUNT_ID);
        $model_category_features = new shopOzonsellerPluginCategoryFeaturesModel();
        $categories = [];
        $all_cats = $this->getRequiredFeatureIds();
        $query = <<<SQL
select * from shop_ozonseller_category_features where feature_id<>"0" and ozon_category_id=? and ozon_feature_id in(?) and account_id={$this->account_id}
SQL;
        foreach ($all_cats as $category_id => $requirements) {
            $filled = false;
            if (!$requirements) {
                shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_FEATURES_REQUIRED, $category_id), 'error');
                continue;
            }
            $category_data = $model_category_features->query($query, $category_id, $requirements)->fetchAll('type_id', 2);
            foreach ($category_data as $type_id => $data) {
                if (count($data) == count($requirements)) {
                    $filled = true;
                    break;
                }
            }
            if (!$filled) {
                unset($all_cats[$category_id]);
            }
        }
        if ($all_cats) {
            $categories = $this->getById(array_keys($all_cats));
        }
        return shopOzonsellerPluginHelper::sortArray($categories, 'name', 'asc', true);
    }

    /**
     *  Возвращает перечень ids типов товаров у которых сопоставлены все обязательные характеристики Ozon для указанной категории Ozon
     * @param mixed $ozon_category_id
     * @return array
     */
    public function getFilledTypeIds($account_id, $ozon_category_ids = null)
    {
        $type_ids = [];
        if ($ozon_category_ids && !is_array($ozon_category_ids)) {
            $ozon_category_ids = [$ozon_category_ids];
        } elseif (!$ozon_category_ids) {
            $query = <<<SQL
select distinct ozon_category_id from shop_ozonseller_category_features where account_id=i:account_id
SQL;
            $ozon_category_ids = $this->query($query, ['account_id' => $account_id])->fetchAll(null, true);
        }

        foreach ($ozon_category_ids as $id) {
            try {
                $ozon_feature_ids = $this->getRequiredFeatureIds($id);
            } catch (Exception $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error', ['ozon_category_id' => $id]);
                continue;
            }
            if (!$ozon_feature_ids) {
                shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_FEATURES_NOT_FOUND, $id) . ' ' . shopOzonsellerPluginTextHelper::TEXT_CHECK_CATEGORY_SETTINGS, 'error');
                continue;
            }
            $query = <<<SQL
select * from shop_ozonseller_category_features where feature_id<>'0' and ozon_feature_id IN (i:ozon_feature_ids) and ozon_category_id=i:ozon_category_id and account_id=i:account_id
SQL;
            $type_features = $this->query($query, ['ozon_feature_ids' => $ozon_feature_ids, 'ozon_category_id' => $id, 'account_id' => $account_id])->fetchAll('type_id', 2);
            foreach ($type_features as $type_id => $features) {
                if (count($features) === count($ozon_feature_ids)) {
                    $type_ids[] = $type_id;
                }
            }
        }
        return $type_ids;
    }

    /**
     *   Возвращает перечень id обязательных характеристик Ozon для указанной категории
     * @param null $ozon_category_id
     * @return array|mixed|null
     */
    protected
    function getRequiredFeatureIds($ozon_category_id = null)
    {
        if (!$ozon_category_id) {
            $ozon_category_ids = $this->query('select distinct ozon_category_id from shop_ozonseller_category_features')->fetchAll(null, true);
        } else {
            $ozon_category_ids = [$ozon_category_id];
        }
        $requireds = [];
        foreach ($ozon_category_ids as $oc_id) {
            try {
                $requireds[$oc_id] = array_keys($this->getFeaturesByCategoryId($oc_id, true));
            } catch (waException $e) {
                continue;
            }
        }
        return $ozon_category_id ? ifset($requireds[$ozon_category_id], []) : $requireds;
    }

    private function getAnalogCategoryOzon($bad_category_id)
    {
        if (!$publics = (new shopOzonsellerPluginProductModel())->getPublicsByCategoryId($this->account_id, $bad_category_id)) {
            //TODO
            throw new waException();
        }
        if (!$this->socket) {
            $this->socket = new shopOzonsellerPluginOzonApi($this->account_id);
        }
        if (!$result = $this->socket->getOzonProductInfoList(array_column($publics, 'offer_id'))) return $result;
        $category_ids = array_unique(array_column($result['items'], 'category_id'));
        $position = array_search($bad_category_id, $category_ids);
        if ($position !== false) {
            unset($category_ids[$position]);
        }
        return $category_ids;
    }

    private function moveToOzonCategory($bad_category_id, $new_categopry_id)
    {
        $classes = [
            'CategoryFeatures',
            'CategoryMarkups',
            'Product',
            'WaitCategory',
            'WaitProduct'
        ];
        foreach ($classes as $part_name) {
            $className = 'shopOzonsellerPlugin' . $part_name . 'Model';
            $model = new $className();
            try {
                if ($new_categopry_id) {
                    $model->updateByField('ozon_category_id', $bad_category_id, ['ozon_category_id' => $new_categopry_id]);
                } else {
                    $model->deleteByField('ozon_category_id', $bad_category_id, ['ozon_category_id' => $new_categopry_id]);
                }
            } catch (Exception $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            }
        }
        if ($new_categopry_id) {
            $this->deleteById($bad_category_id);
        }
    }

    public function add($data, $parent_id = null, $before_id = null, $check = false)
    {
        $category = [
            'id' => $data['category_id'],
            'name' => $data['title'],
            'parent_id' => $parent_id,
            'status' => $data['children'] ? 0 : 1,
            'to_del' => 0
        ];
        if ($this->getById($category['id'])) {
            $this->updateById($category['id'], $category);
            $id = $category['id'];
        } else {
            $id = $this->_add($category, $parent_id);
            if ($check) {
                shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::MESSAGE_NEW_CATEGORY, $category['name']));
            }
        }
        if ($id && isset($data['children']) && is_array($data['children'])) {
            foreach ($data['children'] as $subcategory) {
                $this->add($subcategory, $category['id'], null, $check);
            }
        }
    }

    public function setAccountId($account_id)
    {
        $this->account_id = $account_id;
    }
}