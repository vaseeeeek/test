<?php

class shopOzonsellerPluginModel extends waModel
{

    public static $account_id;

    public function __construct($type = null, $writable = false)
    {
        parent::__construct($type, $writable);
        if (!self::$account_id) {
            self::$account_id = waRequest::post('account_id') ?: waRequest::get('account_id');
        }
    }

    /**
     * @param array $data
     * @param null $mode
     * @return bool|object|resource
     * @throws waException
     */
    public function multipleInsert($data, $mode = null)
    {
        if ($mode === null || ($mode !== 'IGNORE' && !is_array($mode)))
            return parent::multipleInsert($data);

        $data = $this->_prepareMultipleInsertData($data);
        if (!$data || empty($data['fields']) || empty($data['values'])) return true;

        $sql = 'INSERT' . ($mode === 'IGNORE' ? ' IGNORE' : '');

        $sql .= ' INTO `' . $this->getTableName() .
            '` (' . implode(',', $data['fields']) .
            ') VALUES ('
            . implode('),(', $data['values']) .
            ')';

        if (is_array($mode)) {
            $values = [];
            foreach ($mode as $field => $value) {
                if (is_numeric($field) && isset($this->fields[$value])) {
                    $escaped_field = $this->escapeField($value);
                    $values[] = "$escaped_field=VALUES($escaped_field)";
                } elseif (isset($this->fields[$field]))
                    $values[] = $this->escapeField($field) . "=$value";
            }
            if ($values)
                $sql .= ' ON DUPLICATE KEY UPDATE ' . implode(',', $values);
        }

        return $this->query($sql);
    }

    /**
     * @param array $data
     * @return array|null
     * @throws waException
     */
    protected function _prepareMultipleInsertData(array $data): ?array
    {
        if (!$data) return null;

        $values = array();
        $fields = array();
        if (isset($data[0])) {
            foreach ($data as $row) {
                $row_values = array();
                foreach ($row as $field => $value) {
                    if (isset($this->fields[$field])) {
                        $row_values[$this->escapeField($field)] = $this->getFieldValue($field, $value);
                    }
                }
                if (!$fields) {
                    $fields = array_keys($row_values);
                }
                $values[] = implode(',', $row_values);
            }
        } else {
            $multi_field = false;
            $row_values = array();
            foreach ($data as $field => $value) {
                if (isset($this->fields[$field])) {
                    if (is_array($value) && !$multi_field) {
                        $multi_field = $field;
                        $row_values[$this->escapeField($field)] = '';
                    } else {
                        $row_values[$this->escapeField($field)] = $this->getFieldValue($field, $value);
                    }
                }
            }
            $fields = array_keys($row_values);
            if ($multi_field) {
                foreach ($data[$multi_field] as $v) {
                    $row_values[$this->escapeField($multi_field)] = $this->getFieldValue($multi_field, $v);
                    $values[] = implode(',', $row_values);
                }
            } else {
                $values[] = implode(',', $row_values);
            }
        }

        return ['fields' => $fields, 'values' => $values];
    }

    public function setAccountId($account_id)
    {
        self::$account_id = $account_id;
    }
}