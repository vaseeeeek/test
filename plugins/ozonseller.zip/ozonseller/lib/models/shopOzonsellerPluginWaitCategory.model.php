<?php

class shopOzonsellerPluginWaitCategoryModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_wait_category';
    protected $id = ['account_id', 'category_id', 'ozon_category_id'];

    public function getNewProducts($account_id, $category_id = null)
    {
        $new_products = [];
        $model_category = new shopCategoryModel();
        $model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        if ($category_id) {
            $data = $this->getByField(['account_id' => $account_id, 'category_id' => $category_id], true);
        } else {
            $data = $this->getByField('account_id', $account_id, true);
        }
        $public_ids = $this->query('select distinct product_id from shop_ozonseller_product where account_id=?', $account_id)->fetchAll(null, true);
        $query = <<<SQL
select sp.id, sp.type_id from shop_product sp JOIN shop_category_products scp on sp.id=scp.product_id 
    where scp.category_id in (i:category_ids);
SQL;
        foreach ($data as $item) {
            $category_ids = [$item['category_id']];
            if ($item['subcategories']) {
                $subcats = $model_category->getSubcategories($item['category_id']);
                $category_ids = array_merge($category_ids, array_column($subcats, 'id'));
            }
            $products = $this->query($query, ['category_ids' => $category_ids])->fetchAll('id');
            $new_product_ids = array_diff(array_keys($products), $public_ids);
            foreach ($new_product_ids as $new_product_id) {
                $type_ids = $model_ozon_category->getFilledTypeIds($account_id, $item['ozon_category_id']);
                if (in_array($products[$new_product_id]['type_id'], $type_ids)) {
                    $new_products[] = [
                        'product_id' => $new_product_id,
                        'ozon_category_id' => $item['ozon_category_id']
                    ];
                    continue;
                }
            }
        }
        return $new_products;
    }

    public function getByCategoryId($account_id, $category_id)
    {
        $query = <<<SQL
select oc.name,oc.id,wc.subcategories from shop_ozonseller_wait_category as wc join shop_ozonseller_ozon_category oc on wc.ozon_category_id=oc.id where wc.account_id=$account_id and wc.category_id=?
SQL;
        return $this->query($query, [$category_id])->fetchAll('id');
    }

    public function getSubcategoryParam($account_id, $category_id)
    {
        $data = $this->getByField(['account_id' => $account_id, 'category_id' => $category_id]);
        return ifset($data['subcategories'], 0);
    }
}