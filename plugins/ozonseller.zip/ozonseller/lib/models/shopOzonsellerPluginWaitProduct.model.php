<?php

class shopOzonsellerPluginWaitProductModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_wait_product';
    protected $id = 'product_id';
}