<?php

class shopOzonsellerPluginCategoryFeaturesModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_category_features';
    protected $id = ['account_id', 'ozon_category_id', 'type_id', 'ozon_feature_id'];

    public function getOzonCategoryFeaturesByTypes($account_id, $category_id, $type_id)
    {
        $data = [];
        return $this->where('account_id=? and ozon_category_id=? and type_id=?', $account_id, $category_id, $type_id)->fetchAll('ozon_feature_id');
    }

    public function copyFullCategorySettings($source_id, $target_id, $category_id)
    {
        if ((new shopOzonsellerPluginAccountModel())->countByField(['id' => [$source_id, $target_id]]) != 2) {
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_ACCOUNT_IDS);
        }
        if ($this->getByField(['account_id' => $target_id, 'ozon_category_id' => $category_id])) {
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_ACCOUNT_SETTINGS_EXIST, $target_id));
        }
        if (!$data = $this->getByField(['account_id' => $source_id, 'ozon_category_id' => $category_id], true)) return [];
        foreach ($data as &$datum) {
            $datum['account_id'] = $target_id;
        }
        unset($datum);
        $this->multipleInsert($data, 'IGNORE');
    }
}