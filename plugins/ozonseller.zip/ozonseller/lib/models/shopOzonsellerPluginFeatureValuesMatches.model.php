<?php

class shopOzonsellerPluginFeatureValuesMatchesModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_feature_values_matches';
    protected $id = ['ozon_feature_id', 'ozon_value_id', 'feature_id', 'value_id'];

    public function getAllMatches()
    {
        $features = [];
        $ozon_feature_ids = $this->query('select distinct ozon_feature_id from ' . $this->table)->fetchAll(null, 1);
        foreach ($ozon_feature_ids as $ozon_feature_id) {
            $query = <<<SQL
select * from {$this->table} where ozon_feature_id=?
SQL;
            $features[$ozon_feature_id] = $this->query($query, $ozon_feature_id)->fetchAll('feature_id', 2);
        }
        return $features;
    }

    public function getMatchesByOzonFeatureId($ozon_feature_id)
    {
        $matches = $this->getAllMatches();
        return ifset($matches[$ozon_feature_id], []);
    }
}