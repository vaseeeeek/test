<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginAccountSettingsModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_account_settings';

    public function getSettings($name, $account_id)
    {
        if (!$account_id || (!wa_is_int($account_id) && $account_id !== 'all')) return [];
        if (wa_is_int($account_id)) {
            $where_field = $name ? ' AND name="{$name}" ' : '';
            $query = <<<SQL
select name, value from {$this->table} where account_id=$account_id $where_field order by name
SQL;
            $settings = $this->query($query)->fetchAll('name', true);
            $acc_data = $this->query('select client_id, token, status from shop_ozonseller_account where id=?', $account_id)->fetchAssoc();
            return array_merge($settings, $acc_data);
        } else {

        }
    }
}