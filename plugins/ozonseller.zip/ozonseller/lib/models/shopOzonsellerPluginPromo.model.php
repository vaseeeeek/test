<?php

class shopOzonsellerPluginPromoModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_promo';
    protected $id = ['account_id', 'promo_id'];

    public function deleteOldPromos($account_id, $promo_ids)
    {
        if (!$promo_ids) return;
        $query = <<<SQL
DELETE from $this->table WHERE account_id=$account_id and promo_id not in (i:ids)
SQL;
        try {
            $this->query($query, ['ids' => $promo_ids]);
        } catch (waDbException $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
        }
    }
}