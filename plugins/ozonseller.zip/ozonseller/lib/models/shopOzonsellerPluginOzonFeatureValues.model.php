<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginOzonFeatureValuesModel extends shopOzonsellerPluginModel
{
    protected $table = 'shop_ozonseller_ozon_feature_values';
    private $socket = false;
    public $unique_category_features;
    const LIMIT_VALUES = 5000;

    public function __construct($type = null, $writable = false)
    {
        parent::__construct($type, $writable);

        /**
         *  Характеристики, для которых значения уникальны для каждой категории
         *  8229 - Тип
         */
        $this->unique_category_features = array_merge(['8229'], (array)wa()->getPlugin('ozonseller')->getSettings('unique_category_features'));
    }

    public function getFeatureValues($ozon_category_id, $ozon_feature_id, $dictionary_id)
    {
        $params = [
            'category_id' => $ozon_category_id,
            'dictionary_id' => $dictionary_id
        ];
        if (!in_array($ozon_feature_id, $this->unique_category_features)) {
            $params['category_id'] = 0;
        }
        $count_values = $this->countByField($params);
        if ($count_values > self::LIMIT_VALUES) {
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_BIG_DATA, $count_values), 5000);
        }
        if (!$values = $this->getByField($params, true)) {
            $response = $this->getFeatureValuesFromOzon($ozon_category_id, $ozon_feature_id, 0);
            if (isset($response['result'])) {
                $values = $response['result'];
                foreach ($values as &$value) {
                    $value['value'] = trim($value['value']);
                    $value = array_merge($params, $value);
                }
                try {
                    $this->multipleInsert($values);
                } catch (waException $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                }
                if ($response['has_next']) {
                    // Чтобы не падать по памяти просто не будем показывать списки значений более 5000 позиций
                    throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_BIG_DATA, shopOzonsellerPluginTextHelper::TEXT_MORE . ' ' . self::LIMIT_VALUES));
                }
            } else {
                throw new waException($response['error']['message'], $response['error']['code']);
            }
        }
        return shopOzonsellerPluginHelper::sortArray($values, 'value');
    }

    /**
     * //TODO надо отказаться и использовать аналог из preparator
     * @param $feature_id
     * @param $category_id
     * @param $value
     * @return false|mixed|null
     * @throws waException
     * @deprecated
     */
    public function checkValue($feature_id, $category_id, $value)
    {
        if (!$dictionary_id = (new shopOzonsellerPluginOzonCategoryModel())->getDictionaryId($category_id, $feature_id)) {
            return false;
        }
        $params = [
            'category_id' => $category_id,
            'dictionary_id' => $dictionary_id,
            'value' => trim($value)
        ];
        if (!in_array($feature_id, $this->unique_category_features)) {
            unset($params['category_id']);
        }
        $variants = [
            $value,
            strtoupper($value),
            strtolower($value),
            ucfirst(strtolower($value))
        ];
        foreach ($variants as $variant) {
            if ($v = ifset($this->getByField($params)['id'])) {
                break;
            }
        }
        return $v;
    }

    public function hardUpdateFeaturesValues()
    {
        if (wa()->getEnv() != 'cli') return false;
        $model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        $filled_categories = $needle_features = [];
        $items = $this->query('select ozon_category_id, ozon_feature_id from shop_ozonseller_category_features')->fetchAll();
        foreach ($items as $item) {
            if (!isset($filled_categories[$item['ozon_category_id']])) {
                if ($data = $model_ozon_category->getFeaturesByCategoryId($item['ozon_category_id'])) {
                    $filled_categories[$item['ozon_category_id']]['ozon_features'] = $data;
                }
            }
        }
        foreach ($filled_categories as $fc_id => $fc) {
            foreach ($fc['ozon_features'] as $feature_id => $feature) {
                if (ifempty($feature['dictionary_id'])) {
                    $el = [
                        'category_id' => $fc_id,
                        'feature_id' => $feature_id
                    ];
                    if (in_array($feature_id, $this->unique_category_features)) {
                        $needle_features[$feature['dictionary_id']]['unique'][] = $el;
                    } elseif (!isset($needle_features[$feature['dictionary_id']]['overall'])) {
                        $needle_features[$feature['dictionary_id']]['overall'] = $el;
                    }
                }
            }
        }

        foreach ($needle_features as $dictionary_id => $types) {
            foreach ($types as $type => $items) {
                if ($type == 'overall') {
                    $items = [$items];
                }
                foreach ($items as $item) {
                    $params = [
                        'category_id' => $item['category_id'],
                        'dictionary_id' => $dictionary_id
                    ];
                    if (!in_array($item['feature_id'], $this->unique_category_features)) {
                        $params['category_id'] = 0;
                    }
                    $has_next = true;
                    $last_value_id = 0;
                    while ($has_next) {
                        $new_values = [];
                        $response = $this->getFeatureValuesFromOzon($item['category_id'], $item['feature_id'], $last_value_id);
                        $exist_values = $this->getByField(array_merge($params, ['id' => array_column($response['result'], 'id')]), 'id');
                        if (isset($response['result'])) {
                            foreach ($response['result'] as $value) {
                                if (!isset($exist_values[$value['id']])) {
                                    $value['value'] = trim($value['value']);
                                    $new_value = array_merge($params, $value);
                                    foreach ($new_value as $field => $v) {
                                        if (!isset($this->fields[$field])) {
                                            unset($new_value[$field]);
                                        }
                                    }
                                    $new_values[] = $new_value;
                                }
                            }
                            if ($new_values) {
                                try {
                                    $this->multipleInsert($new_values);
                                } catch (waException $e) {
                                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                                }
                            }
                            if ($has_next = ifset($response['has_next'])) {
                                $last_value_id = array_pop($response['result'])['id'];
                            }
                        } else {
                            $has_next = false;
                        }
                    }
                }
            }
        }
        return true;
    }

    public function getAllFeatureValues($ozon_category_id, $ozon_feature_id, $dictionary_id)
    {
        $cache_key = $ozon_feature_id . '_' . $dictionary_id . '_' . $ozon_category_id;
        $cache = new waSerializeCache($cache_key, 600);
        if ($cache->isCached()) {
            $data = $cache->get();
        } else {
            if (!in_array($ozon_feature_id, $this->unique_category_features)) $ozon_category_id = 0;
            $query = <<<SQL
SELECT id, value FROM $this->table WHERE dictionary_id=$dictionary_id AND category_id = $ozon_category_id 
SQL;
            if ($data = $this->query($query)->fetchAll('id', true)) $cache->set($data);
        }
        return $data;
    }

    public function getFeatureValuesFromOzon($ozon_category_id, $ozon_feature_id, $last_value_id, $limit = self::LIMIT_VALUES)
    {
        if (!$this->socket) {
            $this->socket = new shopOzonsellerPluginOzonApi(parent::$account_id);
        }
        $response = $this->socket->getFeatureValues($ozon_category_id, $ozon_feature_id, $last_value_id, $limit);
        if (isset($response['result'])) {
            return $response;
        } else {
            throw new waException($response['error']['message'], $response['error']['code']);
        }
    }

    public function searchDictionaryValue($category_id, $dictionary_id, $value)
    {
        if (!in_array($category_id, $this->unique_category_features)) {
            $category_id = 0;
        }
        $query = <<<SQL
SELECT id , value text FROM $this->table 
WHERE dictionary_id=$dictionary_id AND value LIKE "%$value%" AND category_id=$category_id
SQL;
        return $this->query($query)->fetchAll();
    }

}