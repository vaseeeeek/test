<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginOrderModel extends shopOrderModel
{
    public function countOrdersByOzonParams($params, $dates = [])
    {
        $query = 'SELECT count(*) total' . $this->generateQuery($params, $dates);
        return $this->query($query)->fetchField('total');
    }

    public function getOrderIdsByOzonParams($params, $dates = [])
    {
        $query = 'SELECT id' . $this->generateQuery($params, $dates);
        return $this->query($query)->fetchAll(null, true);
    }

    public static function countOrdersByStatusDate(array $ozon_statuses, $shop_statuses = [], $date = null)
    {
        if (!$ozon_statuses) $ozon_statuses = ['awaiting_deliver'];
        $query = <<<SQL
SELECT count(*) total
FROM shop_order so
        JOIN shop_order_params sop1 ON sop1.order_id = so.id
        JOIN shop_order_params sop2 ON sop2.order_id = so.id
        JOIN shop_order_params sop3 ON sop3.order_id = so.id
WHERE 
      sop1.name = 'ozon_order_status' AND sop1.value IN(s:ozon_statuses)AND 
      sop2.name='ozon_schema' AND sop2.value='fbs'
SQL;
        if ($date) {
            if (wa_is_int($date)) {
                $date = date('Y-m-d 00:00:00', $date);
            }
            $date_to = date('Y-m-d 00:00:00', strtotime($date) + 86400);
            $query .= <<<SQL
AND sop3.name='ozon_shipment_date' AND sop3.value>="$date" 
AND sop3.name='ozon_shipment_date' AND sop3.value<"$date_to"
SQL;
        }
        if ($shop_statuses) {
            $query .= '  AND so.state_id IN(s:shop_statuses)';
        }
        return (new shopOrderModel())->query($query, ['ozon_statuses' => $ozon_statuses, 'shop_statuses' => $shop_statuses])->fetchField('total');
    }

    protected function generateQuery($params, $dates)
    {
        $query = ' FROM shop_order so ';
        for ($i = 1; $i <= count($params); $i++) {
            $query .= 'JOIN shop_order_params sop' . $i . ' ON sop' . $i . '.order_id = so.id ';
        }
        if ($dates) {
            for ($i = count($params) + 1; $i <= count($params) + count($dates); $i++) {
                $query .= 'JOIN shop_order_params sop' . $i . ' ON sop' . $i . '.order_id = so.id ';
            }
        }
        $query .= ' WHERE ';
        $i = 0;
        foreach ($params as $name => $value) {
            $i++;
            if ($i > 1) $query .= ' AND ';
            $query .= 'sop' . $i . '.name="' . $name . '" AND sop' . $i . '.value="' . $value . '"';
        }
        if ($dates) {
            $i = count($params) + 1;
            foreach ($dates as $name => $value) {
                $value = date('Y-m-d ', strtotime($value)) . '00:00:00';
                $query .= ' AND sop' . $i . '.name="' . $name . '" AND sop' . $i . '.value>"' . $value . '"';
                $value = date('Y-m-d ', strtotime($value) + 86400) . '00:00:00';
                $query .= ' AND sop' . $i . '.name="' . $name . '" AND sop' . $i . '.value<"' . $value . '"';
                $i++;
            }
        }
        return $query;
    }
}