<?php

class shopOzonsellerPluginMigrateActions extends shopOzonsellerPluginJsonActions
{
    const MATCH_VALUES = [
        'sku_code' => 'sku',
        'all' => ['type' => 'product_image', 'key' => 'all'],
        'one' => ['type' => 'sku_image', 'key' => 0],
        '$name ($sku)' => ['type' => 'name_sku_bracket', 'key' => ''],
        '$name, $sku' => ['type' => 'name_sku', 'key' => ''],
        '$name' => ['type' => 'name', 'key' => '']
    ];

    const MATCH_TYPE_VALUES = [
        'ozonInputProductFeature' => 'feature_id',
        'ozonInputProductFeatureDimension' => 'feature_id',
        'ozonInputSku' => 'sku',
        'ozonInputProduct' => 'product'
    ];
    private $appSettings;
    private $sourceSettings;
    private $model_ozon_category;
    private $model_ozon_category_features;
    private $model_feature;
    private $warnings = [];

    public function goMigrateAction()
    {
        $data = waRequest::post();
        $this->checkRequiredFields($data, ['categories', 'ozon_categories']);
        if ($this->errors) return;
        $migratedSettings = null;
        $account_id = $this->checkAppAccount();
        if ($this->errors) return;
        $plugin = wa()->getPlugin('ozonseller');
        if (!$this->model_ozon_category_features) $this->model_ozon_category_features = new shopOzonsellerPluginCategoryFeaturesModel();
        if (!$account_id) {
            if (!$data['name']) {
                $this->setError(_wp('Укажите название для аккаунта Ozon'));
                return;
            }
            $accData = [
                'name' => $data['name'],
                'status' => 0,
                'client_id' => $this->appSettings['clientId'],
                'token' => $this->appSettings['apiKey']
            ];
            try {
                $account_id = (new shopOzonsellerPluginAccountModel())->insert($accData);
                $markups = include(wa()->getAppPath('plugins/ozonseller/lib/config/data/markups.php'));
                $markups['account_id'] = $account_id;
                (new shopOzonsellerPluginCategoryMarkupsModel())->insert($markups);
            } catch (Exception $e) {
                $this->setError($e->getMessage());
                return;
            }
            $settings = $plugin->getSettings(null, $account_id);
            $migratedSettings = $this->prepareAppSystemSettings();
            $migratedSettings = array_merge($settings, $migratedSettings);
        }

        $categoryFeatures = [];
        foreach ($data['ozon_categories'] as $ozon_category_id => $item) {
            if (!$this->checkOzonCategoryExist($ozon_category_id)) {
                $this->warnings[] = sprintf(_wp('Не удалось найти категорию Ozon %s (%s). Категория пропущена', $item['name'], $ozon_category_id));
                continue;
            }
            foreach ($item['types'] as $type_id => $datum) {
                if (!$datum['checked'] || $datum['exist']) continue;
                try {
                    if ($newData = $this->getOzonCategorySettings($account_id, $ozon_category_id, $type_id)) {
                        $categoryFeatures = array_merge($categoryFeatures, $newData);
                    } else {
                        $this->warnings[] = sprintf(_wp('Не найдены настройки для категории Ozon <strong>%s</strong>. Категория пропущена'), $item['name']);
                    }
                } catch (waException $e) {
                    $this->warnings[] = sprintf($e->getMessage(), $datum['name'], $item['name']);
                }
            }
        }

        if ($migratedSettings) {
            try {
                $plugin->saveSettings($migratedSettings, $account_id);
            } catch (waException $e) {
                $this->setError($e->getMessage());
                return;
            }
        }

        if ($categoryFeatures) {
            foreach ($categoryFeatures as $categoryFeature) {
                try {
                    $this->model_ozon_category_features->insert($categoryFeature, 1);
                } catch (Exception $e) {
                    $this->warnings[] = $e->getMessage();
                }
            }
        }

        if ($data['categories']) {
            $model_wait_categories = new shopOzonsellerPluginWaitCategoryModel();
            $query = <<<SQL
select category_id, wa_category_id from ozon_category_wa_category
SQL;
            $appCategories = $model_wait_categories->query($query)->fetchAll('wa_category_id', true);
            foreach ($data['categories'] as $category) {
                if ($category['checked'] && isset($appCategories[$category['id']])) {
                    $catData = [
                        'account_id' => $account_id,
                        'category_id' => $category['id'],
                        'ozon_category_id' => $appCategories[$category['id']],
                        'subcategories' => 0
                    ];
                    try {
                        $model_wait_categories->insert($catData, 1);
                    } catch (Exception $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    }
                }
            }
        }
        $plugin_config = $plugin->getOriginalSettings();
        $offer_id = $plugin->getSettings('offer_id', $account_id);
        try {
            $appOrders = $this->getAppOrdersInfo();
        } catch (Exception $e) {
            $appOrders = false;
        }

        $this->response = [
            'accounts' => (new shopOzonsellerPluginAccountModel())->getAllAccountsWithSettings('system'),
            'appData' => [
                'account_id' => $account_id,
                'offer_id' => $offer_id,
                'offer_id_name' => ifset($plugin_config['offer_id']['options'][$offer_id], 'undefined'),
                'orders' => $appOrders,
                'warnings' => $this->warnings
            ]
        ];
    }

    public function preMigrateAction()
    {
        $apps = wa()->getApps();
        if (!isset($apps['ozon'])) {
            $this->setError(_wp('Приложение Интеграция с Ozon не найдено'));
            return;
        }
        $account_name = '';
        if ($account_id = $this->checkAppAccount()) {
            $account_name = (new waModel())->query('select name from shop_ozonseller_account where id=?', $account_id)->fetchField('name');
        }
        if ($this->errors) return;
        try {
            $appData = $this->prepareData($account_id);
            $query = <<<SQL
select distinct oc.wa_category_id as id, sc.name, sc.type as checked from ozon_category_wa_category oc join shop_category sc on oc.wa_category_id=sc.id
SQL;
            $appData['categories'] = (new waModel)->query($query)->fetchAll();
        } catch (waDbException $e) {
            $this->setError($e->getMessage());
            return;
        }

        $this->response = array_merge(['account_id' => $account_id, 'name' => $account_name], $appData);
    }

    public function orderMigrateAction()
    {
        $appOrders = $this->getModelData('ozonOrderModel', null, 'all');
        if (!$appOrders) return;
    }

    private function prepareData($account_id, $run = false)
    {
        $model_categories = new shopOzonsellerPluginOzonCategoryModel();
        $appData = $pluginData = [
            'ozon_categories' => []
        ];
        $query = <<<SQL
select category_id as ozon_category_id, wa_category_id as category_id from ozon_category_wa_category
SQL;
        $data = $model_categories->query($query)->fetchAll('ozon_category_id', 2);
        $ozon_categories = $model_categories->getById(array_keys($data));
        foreach ($data as $ozon_category_id => $category_ids) {
            $query = <<<SQL
select distinct sp.type_id from shop_product sp join shop_category_products scp on sp.id=scp.product_id where scp.category_id in (?)
SQL;
            if ($type_ids = $model_categories->query($query, $category_ids)->fetchAll(null, true)) {
                $query = <<<SQL
select id, name from shop_type where id in (i:type_ids)
SQL;
                $types = [];
                $typesData = $model_categories->query($query, ['type_ids' => $type_ids])->fetchAll('id');
                foreach ($type_ids as $type_id) {
                    $types[$type_id] = ['id' => $type_id, 'name' => ifset($typesData[$type_id]['name'], 'undefined'), 'exist' => 0, 'checked' => 0];
                }
                $appData['ozon_categories'][$ozon_category_id] = [
                    'id' => $ozon_category_id,
                    'name' => ifset($ozon_categories[$ozon_category_id]['name'], 'undefined'),
                    'types' => $types,
                    'checked' => 0
                ];
            }
        }
        if (!$appData['ozon_categories']) throw new waException(_wp('Не удалось получить настройки ни для одной категории Ozon в приложении Интеграция с Ozon'));
        if ($account_id) {
            $ozon_categories = $model_categories->getAssociatedCategoriesAll($account_id);
            foreach ($ozon_categories as $ozon_category_id => $ozon_category) {
                try {
                    $data = $model_categories->getCategoryFullData($ozon_category_id, $account_id);
                } catch (waException $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    continue;
                }
                foreach ($data['types'] as $type_id) {
                    if (isset($appData['ozon_categories'][$ozon_category_id]['types'][$type_id])) {
                        $appData['ozon_categories'][$ozon_category_id]['types'][$type_id]['exist'] = 1;
                    }
                }
            }
        }
        return $appData;
    }

    private function prepareAppSystemSettings()
    {
        $settings = [];
        $appSettings = $this->getModelData('ozonProductRuleModel', ['ozon_attribute_id' => null, 'ozon_category_id' => null], 'field', true);
        foreach ($appSettings as $appSetting) {
            $type_value = isset(self::MATCH_TYPE_VALUES[$appSetting['input_type']]) ? self::MATCH_TYPE_VALUES[$appSetting['input_type']] : null;
            $value = $appSetting['input_name'];
            switch ($appSetting['output_type']) {
                case 'ozonOutputWidth':
                case 'ozonOutputHeight':
                case 'ozonOutputDepth':
                case 'ozonOutputWeight':
                case 'ozonOutputPartImageSize':
                case 'ozonOutputPartSku':
                case 'ozonOutputPartName':
                    break;
                case 'ozonOutputVat':
                    switch ($value) {
                        case '10':
                            $value = 0.1;
                            break;
                        case '20':
                            $value = 0.2;
                        case '0':
                            break;
                        default:
                            $value = false;
                            $this->setSettingWarning('vat', $value);
                    }
                    if ($value !== false) $settings['vat'] = $value;
                    break;
                case 'ozonOutputNameTemplate':
                    if (isset(self::MATCH_VALUES[$value])) {
                        $settings['name'] = self::MATCH_VALUES[$value];
                    } else $this->setSettingWarning('name', $value);
                    break;
                case 'ozonOutputPartImageType':
                    if (isset(self::MATCH_VALUES[$value])) {
                        $settings['image_source'] = self::MATCH_VALUES[$value];
                    } else $this->setSettingWarning('image_source', $value);
                    break;
                case 'ozonOutputBarcode':
                    if ($type_value !== 'feature_id' || !$feature_id = $this->getFeatureIdByCode($value, 0)) {
                        $this->setSettingWarning('barcode', $value);
                        break;
                    }
                    $settings['barcode'] = $feature_id;
                    break;
                case 'ozonOutputOfferId':
                    $value = $this->checkValue($value);
                    if (in_array($value, ['id', 'product_id', 'sku', 'name'])) {
                        $settings['offer_id'] = $value;
                    } else $this->setSettingWarning('offer_id', $value);
                    break;
                case 'ozonOutputOldPrice':
                case 'ozonOutputPrice':
                case 'ozonOutputSyncPrice':
                    $set_id = 'price';
                    if (strpos($appSetting['output_type'], 'OldPrice') !== false) $set_id = 'old_price';
                    elseif (strpos($appSetting['output_type'], 'SyncPrice') !== false) $set_id = 'premium_price';
                    if ($type_value !== 'sku' || !in_array($value, ['price', 'compare_price', 'purchase_price'])) {
                        $this->setSettingWarning($set_id, $value);
                        break;
                    }
                    $settings[$set_id] = ['type' => $value, 'key' => null];
                    break;
            }
        }
        return $settings;
    }

    public function getOzonCategorySettings($account_id, $ozon_category_id, $type_id)
    {
        if (!$this->checkOzonCategoryExist($ozon_category_id)) return false;
        //  Проверить настроена ли для этого аккаунта эта категория с таким типом
        if (!$this->model_ozon_category_features) $this->model_ozon_category_features = new shopOzonsellerPluginCategoryFeaturesModel();
        if ($this->model_ozon_category_features->countByField(compact('account_id', 'ozon_category_id', 'type_id'))) {
            throw new waException(_wp('Для этого аккаунта тип товара %s уже настроен для категории Озон %s '));
        }
        //  Собрать и проверить настройки приложения Озон
        $appSettings = $this->getModelData('ozonProductRuleModel', ['ozon_category_id' => $ozon_category_id], 'field', true);
        if (!$appSettings) return false;

        // Сконвертировать в нужный формат
        $rows = [];
        foreach ($appSettings as $appSetting) {
            if (!$appSetting['ozon_attribute_id']) continue;
            if ($appSetting['ozon_attribute_id'] == shopOzonsellerPluginOzonCategoryModel::OZON_DESCRIPTION_ATTRIBUTE) continue;
            $row = [
                'account_id' => $account_id,
                'ozon_category_id' => $ozon_category_id,
                'type_id' => $type_id,
                'ozon_feature_id' => $appSetting['ozon_attribute_id'],
                'feature_id' => 0,
                'value' => null,
                'ext' => null
            ];
            switch ($appSetting['input_type']) {
                case 'ozonInputDictionary':
                case 'ozonInputFixedValue':
                    $row['feature_id'] = 'string';
                    $row['value'] = $appSetting['input_title'];
                    break;
                case 'ozonInputProduct':
                    switch ($appSetting['input_name']) {
                        case 'id':
                            $row['feature_id'] = 'string';
                            $row['value'] = '{$product_id}';
                            break;
                        case 'name':
                            $row['feature_id'] = 'string';
                            $row['value'] = '{$product_name}';
                            break;
                    }
                    break;
                case 'ozonInputSku':
                    switch ($appSetting['input_name']) {
                        case 'id':
                            $row['feature_id'] = 'string';
                            $row['value'] = '{$sku_id}';
                            break;
                        case 'name':
                            $row['feature_id'] = 'string';
                            $row['value'] = '{$sku_name}';
                            break;
                        case 'sku':
                            $row['feature_id'] = 'string';
                            $row['value'] = '{$sku_sku}';
                            break;
                    }
                    break;
                case 'ozonInputSkuOnlyName':
                    $row['feature_id'] = 'string';
                    $row['value'] = '{$sku_name}';
                    break;
                case 'ozonInputProductFeature':
                case 'ozonInputProductFeatureDimension':
                    if ($feature_id = $this->getFeatureIdByCode($appSetting['input_name'], $type_id)) {
                        $row['feature_id'] = $feature_id;
                    }
                    break;
            }
            $rows[] = $row;
        }
        return $rows;
    }

    private function checkAppAccount()
    {
        $client_id = $this->getAppSettings('clientId');
        $token = $this->getAppSettings('apiKey');
        if (!$client_id || !$token) {
            $this->setError(_wp('В приложении Интеграция с Ozon не заполнены данные аккаунта'));
            return false;
        }
        $model_account = new shopOzonsellerPluginAccountModel();
        if (!$account_id = $model_account->chekAppOzonAccount($client_id, $token)) {
            if ($model_account->countAll()) {
                if (!shopOzonsellerPluginHelper::checkLicense(true)) {
                    $message = <<<HTML
Данные настроенного аккаунта в плагине отличаются от данных аккаунта в приложении Интеграция с Ozon. Импорт настроек в текущий аккаунт плагина невозможен.
Для импорта настроек в новый аккаунт Ozon необходимо приобрести Премиум лицензию плагина Ozon: Интеграция
HTML;
                    $this->setError($message);
                }
                $account_id = 0;
            }
        }
        return $account_id;
    }

    private function getAppSettings($set_id = null)
    {
        if (!$this->appSettings) {
            $ozonSettings = (new waAppSettingsModel())->get('ozon');
            foreach ($ozonSettings as $name => $value) {
                if (!wa_is_int($value) && is_string($value)) $value = json_decode($value, true);
                if ($value) $ozonSettings[$name] = $value;
            }
            $this->appSettings = $ozonSettings;
        }
        if ($set_id) return ifset($this->appSettings[$set_id]);
        else return $this->appSettings;
    }

    private function getModelData($modelName, $params = null, $type = 'field', $key = null)
    {
        $apps = wa()->getApps();
        if (!isset($apps['ozon'])) return [];
        wa('ozon');
        $data = [];
        $model = new $modelName();
        switch ($type) {
            case 'id':
                $data = $model->getById($key);
                break;
            case 'all':
                $data = $model->getAll($key);
                break;
            case 'count':
                $data = (int) $model->countByField($params);
                break;
            default:
                $data = $model->getByField($params, $key);
                break;
        }
        wa('shop');
        return $data;
    }

    private function checkOzonCategoryExist($ozon_category_id)
    {
        if (!$this->model_ozon_category) {
            $this->model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        }
        return $this->model_ozon_category->countByField('id', $ozon_category_id) == 1 ? true : false;
    }

    private function getFeatureIdByCode($code, $type_id)
    {
        if (!$this->model_feature) $this->model_feature = new shopFeatureModel();
        $type_ids = [0];
        if ($type_id) $type_ids[] = $type_id;
        $query = <<<SQL
select sf.* from shop_feature sf join shop_type_features stf on sf.id = stf.feature_id
where sf.code=s:code and stf.type_id in (i:type_ids)
SQL;
        $feature = $this->model_feature->query($query, ['code' => $code, 'type_ids' => $type_ids])->fetchAssoc();
        return ifset($feature['id']);
    }

    public function getAppOrdersInfo()
    {
        $statuses = [];
        foreach (shopOzonsellerPlugin::getOzonOrderStatuses() as $status_id => $title) {
            $statuses[$status_id] = $this->getModelData('ozonOrderModel', ['ozon_state' => $status_id], 'count');
        }
        return $statuses;
    }

    private function setSettingWarning($set_id, $value)
    {
        if (!$this->sourceSettings) $this->sourceSettings = wa()->getPlugin('ozonseller')->getOriginalSettings();
        $name = ifset($this->sourceSettings[$set_id]['title'], $set_id);
        $this->warnings[] = sprintf(_wp('Не удалось сопоставить значение настройки %s (%s). Установите значение вручную'), $name, $value);
    }

    private function checkValue($value)
    {
        return isset(self::MATCH_VALUES[$value]) ? self::MATCH_VALUES[$value] : $value;
    }
}