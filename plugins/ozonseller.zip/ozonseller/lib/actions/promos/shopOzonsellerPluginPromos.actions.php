<?php

class shopOzonsellerPluginPromosActions extends shopOzonsellerPluginJsonActions
{
    protected $socket;

    public function runPromoProductsAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['promo_id', 'source', 'mode', 'account_id']);
        switch ($post['source']) {
            case 'all':
                break;
            case 'selected':
                if (!ifempty($post['ids'])) {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_LIST_PRODUCTS);
                }
                break;
            case'set':
                if (!ifempty($post['set'])) {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_SET_NOT_CHANGED);
                }
                break;
            default:
                $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'source'));
        }
        if (!in_array($post['mode'], ['candidates', 'products'])) $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'mode'));
        if ($this->errors) return;
        $candidates = $products = [];
        foreach (['candidates', 'products'] as $type) {
            if ($post['mode'] == 'products' && $type == 'candidates') continue;
            try {
                $$type = $this->getAllProducts($type, $post['promo_id']);
            } catch (Exception $e) {
                $this->setError($e->getMessage());
                return;
            }
        }
        if ($post['mode'] == 'products') {
            $this->promoDelProducts($post['account_id'], array_column($products, 'id'), $post);
        } else {
            $this->promoAddProducts($post['account_id'], $candidates, $products, $post);
        }
        try {
            $data = $this->getPromoProducts('products', $post['promo_id']);
            $products = $this->prepareOzonProducts($data['products']);
            $this->response['products'] = ['items' => array_values($products), 'total' => $data['total']];
        } catch (Exception $e) {
            $this->setError($e->getMessage());
        }
    }

    public function promoAddProducts($account_id, $candidates, $products, $params)
    {
        $model = new shopOzonsellerPluginProductModel();
        $promo = $this->getPromos($account_id, true, $params['promo_id']);
        $add_ids = [];
        switch ($params['source']) {
            case 'all':
                $add_ids = array_diff(array_column($candidates, 'id'), array_column($products, 'id'));
                break;
            case 'selected':
                $add_ids = $params['ids'];
                break;
            case'set':
                if (!$product_ids = (new shopSetProductsModel())->getByField('set_id', $params['set'], 'product_id')) return;
                $public_ids = $model->getOzonProductIds(array_keys($product_ids));
                $add_ids = array_intersect(array_column($candidates, 'id'), $public_ids);
                break;
            default:
                $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'source'));
        }
        if (!$add_ids) return;
        try {
            $preparator = new shopOzonsellerPluginPreparator($account_id, shopOzonsellerPluginPreparator::MODE_CHECK);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        foreach (array_chunk($add_ids, 1000) as $part_ids) {
            try {
                if ($data = $preparator->preparePromoData($part_ids, $promo)) {
                    $result = $this->socket->setPromoProducts($params['promo_id'], 'add', $data);
                    if ($result['rejected']) {
                        $this->response['errors'][] = shopOzonsellerPluginTextHelper::ERROR_PROMO_ADD_PRODUCTS;
                        $this->prepareRejectedProducts($account_id, $promo, $result['rejected']);
                    }
                }
            } catch (Exception $e) {
                $this->setError($e->getMessage());
                continue;
            }
        }
    }

    public function promoDelProducts($account_id, $promo_product_ids, $params)
    {
        $del_ids = [];
        switch ($params['source']) {
            case 'all':
                $del_ids = $promo_product_ids;
                break;
            case 'selected':
                $del_ids = $params['ids'];
                break;
            case'set':
                if (!$product_ids = (new shopSetProductsModel())->getByField(['account_id' => $account_id, 'set_id' => $params['set']], 'product_id')) return;
                $public_ids = (new shopOzonsellerPluginProductModel())->getOzonProductIds($account_id, array_keys($product_ids));
                $del_ids = array_intersect($promo_product_ids, $public_ids);
                break;
            default:
                $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'source'));
        }
        if (!$del_ids) return;
        foreach (array_chunk($del_ids, 1000) as $ids) {
            try {
                $result = $this->socket->setPromoProducts($params['promo_id'], 'delete', $ids);
            } catch (waException $e) {
                $this->setError($e->getMessage());
            }
            if ($result && $result['rejected']) {
                $this->response['errors'][] = shopOzonsellerPluginTextHelper::ERROR_PROMO_DEL_PRODUCTS;
                $promo = $this->getPromos(true, $params['promo_id']);
                $this->prepareRejectedProducts($account_id, $promo, $result['rejected']);
            }
        }
    }

    private function prepareRejectedProducts($account_id, $promo, $rejected)
    {
        $publics = (new shopOzonsellerPluginProductModel())->getPromoData(array_column($rejected, 'product_id'));
        foreach ($publics as $public) {
            $idx = array_search($public['ozon_product_id'], array_column($rejected, 'product_id'));
            if ($idx === false) continue;
            $log_params = [
                'status' => 'fail',
                'product_id' => $public['product_id'],
                'sku_id' => $public['sku_id'],
                'ozon_category_id' => $public['ozon_category_id'],
                'errors' => [sprintf(shopOzonsellerPluginTextHelper::TEXT_PROMO_REJECTED, $promo['title'], $rejected[$idx]['reason'])]
            ];
            (new shopOzonsellerPluginFailLogModel())->updateLog($account_id, $log_params);
        }
    }

    public function refreshPromosAction()
    {
        try {
            $promos = $this->getPromos(false);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $this->response = array_values($promos);
    }

    public function getPromoInfoAction()
    {
        if (!$account_id = waRequest::post('account_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));
            return;
        }
        if (!$promo_id = waRequest::post('promo_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'promo_id'));
            return;
        }
        if (!$promo = $this->getPromos($account_id,true, $promo_id)) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_PROMO_INFO);
            return;
        }
        $promo['setMode'] = 'view';
        try {
            $data = $this->getPromoProducts('candidates', $promo_id);
            $candidates = $this->prepareOzonProducts($data['products']);
            $candidates_total = $data['total'];
            $data = $this->getPromoProducts('products', $promo_id);
            $products = $this->prepareOzonProducts($data['products']);
            $products_total = $data['total'];
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $this->response = [
            'promo' => $promo,
            'candidates' => ['items' => array_values($candidates), 'total' => (int)$candidates_total],
            'products' => ['items' => array_values($products), 'total' => (int)$products_total]
        ];
    }

    public function savePromoSettingsAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['promo', 'promo_id', 'account_id']);
        if ($this->errors) return;
        if (!$promo = $this->getPromos($post['account_id'],true, $post['promo_id'])) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_PROMO_INFO);
            return;
        }
        $promo_fields = ['type', 'diff_type'];
        if ($promo['action_type'] == 'STOCK_DISCOUNT') {
            $promo_fields = array_merge($promo_fields, ['count', 'count_type']);
        }
        $this->checkRequiredFields($post['promo'], $promo_fields);
        if (!in_array($post['promo']['type'], ['price', 'compare_price', 'purchase_price']) && !$post['promo']['key']) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, shopOzonsellerPluginTextHelper::SETTING_PROMO_PRICE));
            return;
        }
        if ($this->errors) return;
        $params = $post['promo'];
        $params['promo_id'] = $post['promo_id'];
        if (!isset($params['auto'])) $params['auto'] = 0;
        try {
            (new shopOzonsellerPluginPromoModel())->insert($params, 1);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
/*        $promo = $this->getPromos(true, $promo['id']);
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/promos/include.promo.view.settings.html');
        $view->assign(compact('promo'));
        $this->response = $view->fetch($template);*/
    }

    public function deletePromoSettingsAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['promo_id', 'account_id']);
        if (!$promo = $this->getPromos(true, $post['promo_id'])) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_PROMO_INFO);
        }
        try {
            (new shopOzonsellerPluginPromoModel())->deleteById(['account_id' => $post['account_id'], 'promo_id' => $post['promo_id']]);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
        }
    }

    public function getPromoProducts($type, $promo_id, $offset = 0, $limit = 100)
    {
        $products = [];
        $promo_products = $this->socket->getPromoProducts($type, $promo_id, $offset, $limit);
        if ($promo_products['products']) {
            $ozon_product_ids = array_column($promo_products['products'], 'id');
            $ozon_products = $this->socket->getOzonProductInfoList(null, $ozon_product_ids);
            foreach ($ozon_products['items'] as $op) {
                $products[$op['id']] = $op;
            }
        }
        return ['products' => $products, 'total' => $promo_products['total']];
    }

    public function getAllProducts($type, $promo_id, $part_size = 1000)
    {
        $products = [];
        $flag = true;
        $offset = 0;
        while ($flag) {
            $data = $this->getPromoProducts($type, $promo_id, $offset, $part_size);
            if ($data['products']) {
                $products = array_merge($products, $data['products']);
            } else {
                $flag = false;
            }
            if (count($products) >= $data['total']) $flag = false;
            $offset += count($data['products']);
        }
        return $products;
    }

    public function prepareOzonProducts($ozon_products)
    {
        if (!$ozon_products) return [];
        if ($ozon_ids = array_column($ozon_products, 'id')) {
            $offers = (new shopOzonsellerPluginProductModel())->getByField('ozon_product_id', $ozon_ids, 'ozon_product_id');
            foreach ($offers as $ozon_id => $offer) {
                $ozon_products[$ozon_id]['ss_product_id'] = $offer['product_id'];
            }
        }
        return $ozon_products;
    }

    public function getPromos($account_id, $with_cache = true, $promo_id = false)
    {
        if ($this->errors) return;
        $cache = new waSerializeCache('ozonseller_promos_' . $account_id, 86400);
        if ($with_cache && $cache->isCached()) {
            $promos = $cache->get();
        } else {
            $promos = [];
            if ($data = $this->socket->getPromos()) {
                $data = shopOzonsellerPluginHelper::sortArray($data, 'date_start');
                foreach ($data as $item) {
                    $promos[$item['id']] = $item;
                }
                $cache->set($promos);
            }
        }
        if ($promos) {
            $settings = (new shopOzonsellerPluginPromoModel())->getByField(['account_id' => $account_id, 'promo_id' => array_column($promos, 'id')], 'promo_id');
            $original_settings = include(wa()->getAppPath('plugins/ozonseller/lib/config/settings.php'));
            $setting = $original_settings['price'];
            foreach ($settings as $id => $promo_settings) {
                if (isset($promos[$id])) {
                    if (in_array($promo_settings['type'], ['price', 'compare_price', 'purchase_price'])) {
                        $idx = array_search($promo_settings['type'], array_column($setting['source']['null_els'], 'value'));
                        $promo_settings['type_name'] = $setting['source']['null_els'][$idx]['title'];
                    } else {
                        $promo_settings['type_name'] = $setting['source']['variants'][$promo_settings['type']]['title'];
                    }
                    $promos[$id]['settings'] = $promo_settings;
                }
            }
        }
        if ($promo_id) {
            /*            if (isset($promos[$promo_id])) {
                            $promos[$promo_id]['settings'] = (new shopOzonsellerPluginPromoModel())->getById($promo_id);
                            if ($promos[$promo_id]['settings']) {
                                $original_settings = include(wa()->getAppPath('plugins/ozonseller/lib/config/settings.php'));
                                $setting = $original_settings['price'];
                                if (in_array($promos[$promo_id]['settings']['type'], ['price', 'compare_price', 'purchase_price'])) {
                                    $idx = array_search($promos[$promo_id]['settings']['type'], array_column($setting['source']['null_els'], 'value'));
                                    $promos[$promo_id]['settings']['type_name'] = $setting['source']['null_els'][$idx]['title'];
                                } else {
                                    $promos[$promo_id]['settings']['type_name'] = $setting['source']['variants'][$promos[$promo_id]['settings']['type']]['title'];
                                }
                            }
                        }*/
            return ifset($promos[$promo_id]);
        } else {
            return $promos;
        }
    }

    public function getPartListAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'promo_id', 'type', 'offset']);
        if ($this->errors) return;
        try {
            $data = $this->getPromoProducts($post['type'], $post['promo_id'], $post['offset']);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
        }
        try {
            $products = $this->prepareOzonProducts($data['products']);
            $this->response = array_values($products);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
        }
    }

    public function __construct($account_id = null)
    {
        if (!$account_id) {
            $account_id = waRequest::post('account_id') ?: waRequest::get('account_id');
        }
        try {
            $this->socket = new shopOzonsellerPluginOzonApi($account_id);
        } catch (Exception $e) {
            if (waRequest::post()) {
                $this->setError($e->getMessage());
                return;
            } else {
                throw new waException($e->getMessage(), $e->getCode());
            }
        }
    }
}