<?php


class shopOzonsellerPluginBackendSettingsSaveController extends waJsonController
{
    public function execute()
    {
        $post = waRequest::post();
        if (!$account_id = ifset($post['account_id'])) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));
            return;
        }
        if (!$type = ifset($post['type'])) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'type'));
            return;
        }
        unset($post['type']);
        if (!$data = ifset($post['settings'])) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'settings'));
            return;
        }
        $settings = wa()->getPlugin('ozonseller')->getSettings(null, $account_id);
        switch ($type) {
            case 'general':
                //Проверка правильности заполнения
                foreach (['name', 'description', 'empty_description', 'exclude', 'image_source'] as $setting) {
                    if (isset($data[$setting]) && $data[$setting]) {
                        if (in_array($data[$setting]['type'], ['blocks', 'sets', 'params', 'features', 'sku_image', 'product_image']) && (!isset($data[$setting]['key']) || $data[$setting]['key'] == '')) {
                            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_FALSE_SETTINGS, constant('shopOzonsellerPluginTextHelper::SETTING_' . strtoupper($setting))));
                        }
                    }
                }
                //Проверка других обязательных настроек
                foreach (['image_size'] as $setting) {
                    if (isset($data[$setting])) {
                        if (is_array($data[$setting])) {
                            if (!$data[$setting]['type']) $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_FALSE_SETTINGS, constant('shopOzonsellerPluginTextHelper::SETTING_' . strtoupper($setting))));
                        } else {
                            if (!$data[$setting]) $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_FALSE_SETTINGS, constant('shopOzonsellerPluginTextHelper::SETTING_' . strtoupper($setting))));
                        }
                    }
                }

                if (isset($data['quantity']) && $data['quantity'] == 'stock_ids' && !isset($data['stock_ids'])) {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_FALSE_SETTINGS_STOCKS);
                }
                if (isset($data['dimensions']) && $data['dimensions']['type'] == 'adv-params') {
                    $tmp = [];
                    foreach (['length', 'height', 'width', 'unit'] as $field) {
                        if (!isset($data['dimensions'][$field]) || in_array($data['dimensions'][$field], $tmp)) {
                            $this->setError(shopOzonsellerPluginTextHelper::ERROR_FALSE_SETTINGS_DIMENSIONS);
                            break;
                        }
                        $tmp[] = $data['dimensions'][$field];
                    }
                }
                break;
            case 'prices':
                if (!isset($data['calculation'])) $data['calculation'] = '0';
                if (!isset($data['sync_additionals']['order'])) $data['sync_additionals']['order'] = '0';
                $settings['stock_ids'] = $settings['sync_additionals'] = [];
                foreach (['markup_product', 'price', 'old_price', 'premium_price'] as $setting) {
                    if (isset($data[$setting]) && $data[$setting]) {
                        if (in_array($data[$setting]['type'], ['blocks', 'sets', 'params', 'features', 'plugin_price']) && !$data[$setting]['key']) {
                            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_FALSE_SETTINGS, constant('shopOzonsellerPluginTextHelper::SETTING_' . strtoupper($setting))));
                        }
                    }
                }
                if ($data['schema'] == 'fbo') {
                    unset($data['stock_ids']);
                } else {
                    $check = false;
                    foreach (ifset($data['stock_ids'], []) as $ozon_stock_id => $shop_stock_id) {
                        if ($shop_stock_id) {
                            $check = true;
                            break;
                        }
                    }
                    if (!$check) {
                        $this->setError(shopOzonsellerPluginTextHelper::ERROR_FALSE_SETTINGS_STOCKS);
                    }
                }
                break;
            case 'orders':
                if (!isset($data['order_comment'])) $data['order_comment'] = '0';
                if (isset($data['shop_orders'])) {
                    (new waAppSettingsModel())->set('shop.ozonseller', 'shop_orders', json_encode($data['shop_orders']));
                    unset($data['shop_orders']);
                }
                break;
            case 'system':
                foreach (['debug', 'json_query', 'product_commisions', 'upgrade', 'reimages'] as $field) {
                    if (!isset($data[$field])) $data[$field] = 0;
                }
                break;
            default:
                $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'type'));
        }
        if ($this->errors) return;

        try {
            wa()->getPlugin('ozonseller')->saveSettings($data, $account_id);
        } catch (waException $e) {
            $this->setError($e->getMessage());
        }
        $this->response = shopOzonsellerPluginHelper::getAccountSettingsType($account_id, $type, $type === 'system');
        switch ($type) {
            case 'prices':
                $this->response['ozonStocks'] = wa()->getPlugin('ozonseller')->getOzonStocks($account_id);
                break;
        }
    }
}