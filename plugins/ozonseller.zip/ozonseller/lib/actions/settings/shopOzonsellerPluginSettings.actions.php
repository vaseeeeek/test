<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginSettingsActions extends shopOzonsellerPluginJsonActions
{
    public function saveAccountAction()
    {
        if (!$account = waRequest::post('account')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account'));
            return;
        }
        $this->checkRequiredFields($account, ['name', 'client_id', 'token']);
        if ($this->errors) return;
        $model = new shopOzonsellerPluginAccountModel();
        try {
            if ($account['id']) $model->updateById($account['id'], $account);
            else {
                $account['id'] = $model->insert($account);
                if ($account['id'] === false) {
                    $this->setError(_wp('Для создания нескольких аккаунтов Ozon необходимо приобрести Пермиум лицензию'));
                    return;
                }
                $markups = include(wa()->getAppPath('plugins/ozonseller/lib/config/data/markups.php'));
                $markups['account_id'] = $account['id'];
                (new shopOzonsellerPluginCategoryMarkupsModel())->insert($markups);
            }
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $account['settings'] = shopOzonsellerPluginHelper::getAccountSettingsType($account['id'], 'general');
        $this->response = $account;
    }

    public function deleteAccountAction()
    {
        if (!$account_id = waRequest::post('account_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));
            return;
        }
        try {
            (new shopOzonsellerPluginAccountModel())->deleteById($account_id);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
        }
    }
}