<?php


class shopOzonsellerPluginSettingsAction extends waViewAction
{
    public function execute()
    {
        $plugin = wa('shop')->getPlugin('ozonseller');
        $model = new shopOzonsellerPluginAccountModel();
        $accounts = $model->getAllAccountsWithSettings('system');
        $tasks = [];
        $cliController = new shopOzonsellerPluginCli();
        $tasks_map = $cliController->getTasksMap();
        foreach ($tasks_map as $task_id => $datum) {
            if ($task = $cliController->getTaskData($task_id)) $tasks[] = $task;
        }

        $apps = wa()->getApps();
        $newUi = wa()->whichUI() !== '1.3';
        $view = wa()->getView();
        $file = $newUi ? 'actionButton.vue' : 'actionButton_old.vue';
        $actionButton = $view->fetch(wa()->getAppPath('plugins/ozonseller/templates/actions/' . $file));
        $cronInfo = shopOzonsellerPluginHelper::getVueComponent('cronInfo');
        $bar = [
            'max' => null,
            'value' => 0,
            'width' => '70%',
            'height' => '2em',
            'doneText' => 'Процесс успешно завершен',
            'errorText' => 'В процессе работы возникли ошибки',
            'prerunText' => 'Получаем информацию о товарах в Ozon...',
            'runText' => 'Идёт проверка и сопоставление товаров...',
            'state' => 'wait',
            'small' => false,
            'time' => true,
            'result' => [],
            'lis' => [
                ['icon' => 'fas fa-check-double', 'text' => 'Успешно сопоставлено: ', 'el' => 'new', 'empty' => true],
                ['icon' => 'fas fa-clipboard-list', 'text' => 'Ранее сопоставленных: ', 'el' => 'exist', 'empty' => true],
                ['icon' => 'far fa-question-circle', 'text' => 'Не удалось сопоставить: ', 'el' => 'nonexist', 'empty' => true]
            ]
        ];
        if (wa()->whichUI() === '1.3') {
            $bar['lis'] = [
                ['icon' => 'icon16 status-green', 'text' => 'Успешно сопоставлено: ', 'el' => 'new', 'empty' => true],
                ['icon' => 'icon16 status-yellow', 'text' => 'Ранее сопоставленных: ', 'el' => 'exist', 'empty' => true],
                ['icon' => 'icon16 status-red', 'text' => 'Не удалось сопоставить: ', 'el' => 'nonexist', 'empty' => true]
            ];
        }
        $this->view->assign([
            'tasks' => json_encode(shopOzonsellerPluginHelper::sortArray($tasks, 'sort')),
            'version' => str_replace('.', '_', $plugin->getVersion()),
            'is_cloud' => json_encode(wa()->appExists('hosting')),
            'wa_app_url' => json_encode(wa()->getAppUrl('shop')),
            'wa_path' => json_encode(wa()->getConfig()->getRootPath()),
            'wa_url' => json_encode(wa()->getRootUrl()),
            'accounts' => json_encode($accounts),
            'newUi' => json_encode($newUi),
            'is_debug' => shopOzonsellerPluginHelper::isDebug(),
            'actionButton' => json_encode($actionButton, 256),
            'cronInfo' => json_encode($cronInfo, 256),
            'appOzon' => json_encode(isset($apps['ozon'])),
//            'orderStates' => json_encode(shopOzonsellerPlugin::getOzonOrderStatuses()),
            'orderStates' => json_encode((new shopOzonsellerPluginMigrateActions())->getAppOrdersInfo()),
            'gradusnik' => json_encode(shopOzonsellerPluginHelper::getVueComponent('gradusnik'), 256),
            'bar' => json_encode($bar)
        ]);
    }
}