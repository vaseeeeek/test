<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginProductsActions extends shopOzonsellerPluginJsonActions
{
    const PRODUCT_CACHE_KEY_TEMPLATE = 'product_info_%s_%s';

    public function updateProductAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'mode', 'sku_id']);
        if ($this->errors) return;
        try {
            $socket = new shopOzonsellerPluginOzonApi($post['account_id']);
            $preparator = new shopOzonsellerPluginPreparator($post['account_id']);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        if (!$sku = (new shopProductSkusModel())->getById($post['sku_id'])) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'sku_id'));
            return;
        }
        $public = (new shopOzonsellerPluginProductModel())->getByField(['account_id' => $post['account_id'], 'sku_id' => $sku['id']]);
        if (in_array($post['mode'], ['upgrade', 'imgUpdate']) && !$public) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_PUBLIC_NOT_FOUND);
            return;
        }
        $product = (new shopProductModel())->getById($sku['product_id']);
        switch ($post['mode']) {
            case 'price':
                $sku['currency'] = $product['currency'];
                $sku['ozon_category_id'] = $public['ozon_category_id'];
                $sku['ozon_product_id'] = (int)$public['ozon_product_id'];
                $prices = $preparator->getPricesBySku($sku);
                $item = array_merge(['offer_id' => $preparator->getOfferId($product['id'], $sku['id'], $sku)], $prices, ['product_id' => $sku['ozon_product_id']]);
                try {
                    if ($item) {
                        $result = $socket->updatePriceLists([$item]);
                        if ($error = shopOzonsellerPlugin::preparePQResult($post['mode'], $result)) {
                            foreach ($error as $product_id => $errors) {
                                foreach ($errors as $er) {
                                    $this->setError($er);
                                }
                            }
                        }
                    }
                } catch (Exception $e) {
                    $this->setError($e->getMessage());
                    return;
                }
                break;
            case 'quantity':
                $items = $preparator->getQuantityByPublics([$public]);
                if ($items) {
                    try {
                        $result = $socket->updateProductsStocks($items);
                        if ($error = shopOzonsellerPlugin::preparePQResult($post['mode'], $result)) {
                            foreach ($error as $product_id => $errors) {
                                foreach ($errors as $er) {
                                    $this->setError($er);
                                }
                            }
                        }
                    } catch (Exception $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    }
                }
                break;
            case 'description':
                //TODO
                break;
            case 'upgrade':
                if (!wa()->getPlugin('ozonseller')->getSettings('upgrade', $post['account_id'])) {
                    $this->setError(shopOzonsellerPluginTextHelper::CLI_UPGRADE_BAN);
                    break;
                }
                $preparator = new shopOzonsellerPluginPreparator($post['account_id'], shopOzonsellerPluginPreparator::MODE_PUBLIC);
                try {
                    $result = $preparator->importProduct($product['id'], $public['ozon_category_id'], $sku['id']);
                } catch (waException $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                }
                if ($result['status'] != 'ok') {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_PUBLIC_ATTRIBUTE);
                }
                break;
            case 'public':
                if (!$data = (new shopOzonsellerPluginProductModel())->getByField(['account_id' => $post['account_id'], 'product_id' => $sku['product_id']])) {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_PUBLICS_NOT_FOUND);
                    return;
                }
                $preparator = new shopOzonsellerPluginPreparator($post['account_id'], shopOzonsellerPluginPreparator::MODE_PUBLIC);
                try {
                    $preparator->importProduct($sku['product_id'], $data['ozon_category_id'], $post['sku_id']);
                } catch (waException $e) {
                    $this->setError($e->getMessage());
                }
                break;
            case 'unmatch':
                try {
                    (new shopOzonsellerPluginProductModel())->deleteByField(['account_id' => $post['account_id'], 'sku_id' => $sku['id']]);
                } catch (Exception $e) {
                    $this->setError($e->getMessage());
                    return;
                }
                break;
            case 'imgUpdate':
                $product = new shopProduct($sku['product_id']);
                if (!$product->getId()) {
                    $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_PRODUCT_NOT_FOUND, $sku['product_id']));
                    break;
                }
                if (!$images = $preparator->getProductImages($product, $sku)) {
                    $this->setError(shopOzonsellerPluginTextHelper::FAIL_IMAGES);
                    break;
                }
                if (!$socket->updateImages($public['ozon_product_id'], $images)) {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_IMAGES_UPDATE);
                }
                break;
            default:
                $this->setError(shopOzonsellerPluginTextHelper::ERROR_UNEXPECTED_MODE);
        }
        if (!$this->errors && in_array($post['mode'], ['public', 'unmatch'])) {
            $data = $this->getInfoByProductId($post['account_id'], $sku['product_id'], false);
            $this->response = ['publics' => $data['publics'], 'unpublics' => $data['unpublics']];
        }
    }

    public function getProductOzonInfoAction()
    {
        if (!$product_id = waRequest::post('product_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'product_id'));
            return;
        }
        $model_account = new shopOzonsellerPluginAccountModel();
        $accounts = $model_account->getAllAccounts(false, 'id');
        foreach ($accounts as &$account) {
            $data = $this->getInfoByProductId($account['id'], $product_id);
            $account['publics'] = ifset($data['publics'], []);
            $account['unpublics'] = ifset($data['unpublics'], []);
            $account['errors'] = ifset($data['errors'], []);
        }
        unset($account);
        $actionButton = shopOzonsellerPluginHelper::getVueComponent('actionButton');
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/product/product.old.vue');
        $view = wa()->getView();
        $view->assign([
            'accounts' => json_encode($accounts),
            'account_id' => json_encode((int)$model_account->select('min(id) as id')->fetchField('id')),
            'product_id' => json_encode($product_id),
            'is_debug' => shopOzonsellerPluginHelper::isDebug(),
            'newUi' => json_encode(wa()->whichUI('shop') === '1.3'),
            'actionButton' => json_encode($actionButton, 256),
            'accountsMenu' => json_encode(shopOzonsellerPluginHelper::getVueComponent('accountsMenu'), 256)
        ]);
        $this->response = $view->fetch($template);
    }

    public function getInfoByProductId($account_id, $product_id, $check_cache = true)
    {
        $publics = $unpublics = [];
        $skus = (new shopProductSkusModel())->getByField('product_id', $product_id, 'id');
        if ($current_publics = (new shopOzonsellerPluginProductModel())->getByField(['account_id' => $account_id, 'product_id' => $product_id], true)) {
            $cache = new waSerializeCache(sprintf(self::PRODUCT_CACHE_KEY_TEMPLATE, $account_id, $product_id), 60 * 15);
            if ($check_cache && $cache->isCached()) {
                $publics = $cache->get();
            } else {
                try {
                    $socket = new shopOzonsellerPluginOzonApi($account_id);
                } catch (waException $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                }
                $publics = [];
                if (!wa()->getPlugin('ozonseller')->getSettings('product_commisions', $account_id)) {
                    try {
                        $publics = $socket->getOzonProductInfoList(array_column($current_publics, 'offer_id'));
                        $publics = $publics['items'];
                    } catch (waException $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    }
                } else {
                    foreach (array_column($current_publics, 'offer_id') as $offer_id) {
                        try {
                            $item = $socket->getOzonProductInfo($offer_id);
                            $publics[] = $item;
                        } catch (waException $e) {
                            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                        }
                    }
                }
                foreach ($publics as &$item) {
                    $public = ifset($current_publics[array_search($item['offer_id'], array_column($current_publics, 'offer_id'))], []);
                    $sku = ifset($skus[$public['sku_id']], []);
                    $item = $this->prepareOzonData($item, $sku, $sku);
                }
                unset($item);
                if ($check_publics = (new shopOzonsellerPluginProductModel())->getCheckPublics($account_id, [$product_id])) {
                    if ($check_ozon_publics = (new shopOzonsellerPluginPreparator($account_id))->checkPublicsState($check_publics)) {
                        $lost_tasks = array_diff(array_column($check_publics[$product_id], 'offer_id'), array_column($check_ozon_publics[$product_id], 'offer_id'));
                    } else {
                        $lost_tasks = array_column($check_publics[$product_id], 'offer_id');
                    }
                    if ($check_ozon_publics) {
                        foreach ($check_ozon_publics[$product_id] as $item) {
                            if ($publics && array_search($item['offer_id'], array_column($publics, 'offer_id')) !== false) continue;
                            $cp_idx = array_search($item['offer_id'], array_column($current_publics, 'offer_id'));
                            if ($cp_idx === false || !isset($skus[$current_publics[$cp_idx]['sku_id']])) continue;
                            $sku = $skus[$current_publics[$cp_idx]['sku_id']];
                            $product = new shopProduct($sku['product_id']);
                            if (!$currency = $product['currency']) $currency = 'RUB';
                            $publics[] = [
                                'sku_id' => $sku['id'],
                                'shop_sku' => $sku['sku'],
                                'name' => shopOzonsellerPluginTextHelper::TEXT_NAME_NOT_DEFINED,
                                'status' => $item['status'],
                                'state_name' => shopOzonsellerPluginTextHelper::TEXT_STATE_FAILED,
                                'error_message' => implode('; ', array_column($item['errors'], 'message')),
                                'price' => shopOzonsellerPluginTextHelper::TEXT_PRICE_NOT_SET,
                                'shop_price' => waCurrency::format('%0i{n}', $sku['price'], $currency, 'ru_RU'),
                                'category_name' => (new shopOzonsellerPluginOzonCategoryModel())->getById($current_publics[$cp_idx]['ozon_category_id'])['name']
                            ];
                        }
                    }
                    if ($lost_tasks) {
                        (new shopOzonsellerPluginProductModel())->deleteLostTasks($account_id, $lost_tasks);
                        foreach ($lost_tasks as $task) {
                            $key = array_search($task, array_column($publics, 'offer_id'));
                            if ($key !== false) unset($publics[$key]);
                        }
                    }
                }
                if ($publics) {
                    $cache->set($publics);
                }
            }
        }
        if ($publics) {
            foreach (array_diff(array_keys($skus), array_column($publics, 'sku_id')) as $sku_id) {
                $unpublics[] = $skus[$sku_id];
            }
        }
        $errors = (new shopOzonsellerPluginFailLogModel())->getByField(['account_id' => $account_id, 'product_id' => $product_id], true);
        return compact('publics', 'unpublics', 'errors');
    }

    public function importOzonProducts($account_id, $items, $field)
    {
        $exist = $non_exist = $new = 0;
        if (!$items) return compact('exist', 'non_exist', 'new');
        $products = $needle = $offer_ids = $non_exist_data = [];
        foreach ($items as $item) {
            $products[$item['offer_id']] = [
                'sku_id' => $item['offer_id'],
                'ozon_product_id' => $item['product_id']
            ];
        }
        unset($item);
        $query = <<<SQL
SELECT id, product_id, sku, name from shop_product_skus where $field IN (?)
SQL;
        if ($products) {
            $product_ids = (new shopProductSkusModel())->query($query, [array_keys($products)])->fetchAll($field);
            $new_items = array_intersect(array_keys($product_ids), array_keys($products));
            $exist_items = (new shopOzonsellerPluginProductModel())->getByField(['account_id' => $account_id, 'offer_id' => array_keys($products)], 'offer_id');
            $exist += count($exist_items);
            if ($delta = count($products) - count($product_ids)) {
                $non_exist_ids = array_values(array_diff(array_keys($products), array_keys($product_ids)));
                $non_exist_data = array_merge($non_exist_data, $non_exist_ids);
            }
            $non_exist += $delta;
            foreach ($new_items as $offer_id) {
                if (!isset($exist_items[$offer_id])) {
                    $needle[] = ['sku_id' => $products[$offer_id]['sku_id'], 'offer_id' => $offer_id];
                    $offer_ids[] = (string)$offer_id;
                }
            }
        }

        $new_products = [];
        if ($needle) {
            try {
                $full_data = (new shopOzonsellerPluginOzonApi($account_id))->getOzonProductInfoList($offer_ids);
            } catch (waException $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                return false;
            }
            if (!ifset($full_data['items'], [])) {
                return false;
            }
            foreach ($full_data['items'] as $item) {
                if (isset($product_ids[$item['offer_id']])) {
                    $new_products[] = [
                        'account_id' => $account_id,
                        'product_id' => $product_ids[$item['offer_id']]['product_id'],
                        'offer_id' => $item['offer_id'],
                        'sku_id' => $product_ids[$item['offer_id']]['id'],
                        'ozon_category_id' => $item['category_id'],
                        'ozon_product_id' => $item['id'],
                        'task_id' => null,
                        'edit_datetime' => null,
                        'checksum' => null,
                        'state' => $item['state'],
                        'fbs' => 1
                    ];
                    $new += 1;
                }
            }
        }
        $model = new shopOzonsellerPluginProductModel();
        foreach ($new_products as $datum) {
            try {
                $model->insert($datum, 1);
            } catch (Exception $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error', $datum);
            }
        }
        return compact('new', 'exist', 'non_exist', 'non_exist_data');
    }

    private function prepareOzonData($item, $sku, $public = null)
    {
        $product = new shopProduct($sku['product_id']);
        if (!$currency = $product['currency']) $currency = 'RUB';
        $item['state_name'] = $item['status']['state_name'];
        $item['category_name'] = (new shopOzonsellerPluginOzonCategoryModel())->getById($item['category_id'])['name'];
        $item['sku_id'] = $sku['id'];
        $item['price'] = waCurrency::format('%0i{n}', $item['price'], 'RUB', 'ru_RU');
        $item['shop_sku'] = $sku['sku'];
        $item['shop_price'] = waCurrency::format('%0i{n}', $sku['price'], $currency, 'ru_RU');
        return $item;
    }

    public function getDialogProductsAction()
    {
        $post = waRequest::post();
        if (isset($post['hash']) && $post['hash']) {
            $typeProductIds = 'hash';
            $product_ids = $post['hash'];
            /*}*/
        } elseif (isset($post['product_id']) && $post['product_id']) {
            $typeProductIds = 'ids';
            if (!$product_ids = implode(',', $post['product_id'])) {
                $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_LIST_PRODUCTS_PUBLIC);
            }
        } elseif (isset($post['products_hash'])) {
            $typeProductIds = 'hash';
            $product_ids = $post['products_hash'];
        } else {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'product_id'));
            return;
        }
        $typeProductIds === 'category' ? $is_category = true : $is_category = false;
        if (!$accounts = (new shopOzonsellerPluginAccountModel())->getAllAccounts(true)) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_NO_ACCOUNTS_ENABLED);
            return;
        }
        $model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        $accSettings = $counts = [];
        $flag = false;
        foreach ($accounts as $account) {
            $model_ozon_category->setAccountId($account['id']);
            try {
                $cnts = $this->countPublicsByCollection($account['id'], $typeProductIds, $product_ids);
                if ($cnts === null) {
                    $accSettings[$account['id']]['count'] = null;
                    $accSettings[$account['id']]['categories'] = null;
                    continue;
                }
                $accSettings[$account['id']]['categories'] = array_values($model_ozon_category->getAssociatedCategoriesFilled());
                $accSettings[$account['id']]['count'] = $cnts['ocount'];
                if (count($accSettings[$account['id']]['categories'])) $flag = true;
            } catch (Exception $e) {
                $accSettings[$account['id']]['categories'] = null;
                $accSettings[$account['id']]['count'] = null;
            }
        }
        if (!$flag) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_NO_FILLED_CATEGORY);
            return;
        }
        $newUi = wa()->whichUI('shop') !== '1.3';
        $is_debug = shopOzonsellerPluginHelper::isDebug();
        $actionButton = shopOzonsellerPluginHelper::getVueComponent('actionButton');

        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/') . ($newUi ? 'dialogPublics.html' : 'dialogPublics_old.html');
        $view->assign(compact('is_debug'));
        $view->assign([
            'accounts' => json_encode($accounts),
            'accSettings' => json_encode($accSettings),
            'product_ids' => json_encode($product_ids),
            'typeProductIds' => json_encode($typeProductIds),
            'newUi' => json_encode($newUi),
            'actionButton' => json_encode($actionButton, 256)
        ]);
        $this->response = $view->fetch($template);
    }

    public function checkDialogProductsAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['ozon_category_id', 'product_ids', 'type_ids', 'account_id']);
        if ($this->errors) return;

        $counts = $this->countPublicsByCollection($post['account_id'], $post['type_ids'], $post['product_ids'], ifempty($post['ozon_category_id']));
        if ($this->errors) return;
        $this->response = [
            'go' => $counts['count'],
            'ocount' => $counts['ocount'],
        ];
    }

    public function countPublicsByCollection($account_id, $type_ids, $product_ids, $ozon_category_id = null)
    {
        $model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        $model_ozon_product = new shopOzonsellerPluginProductModel();
        try {
            $collection = (new shopOzonsellerPluginHelper())->getCollectionProducts($type_ids, $product_ids);
        } catch (waException $e) {
            $this->setError($e->getMessage());
            return null;
        }
        if (!$type_ids = $model_ozon_category->getFilledTypeIds($account_id, $ozon_category_id)) {
//            $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_TYPE_FILLED);
            return null;
        }
        $product_ids = array_keys($collection->getProducts('id', 0, $collection->count()));
        if (!$public_product_ids = $model_ozon_product->getAllProductIds($account_id)) $public_product_ids = [0];
        $collection = new shopProductsCollection($product_ids);
        $collection->addWhere('p.type_id in(' . implode(',', $type_ids) . ') and p.id not in(' . implode(',', $public_product_ids) . ')');
        $count = $collection->count();
        $ocount = $model_ozon_product->countPublic($account_id, $ozon_category_id, $product_ids);

        $ocount = $ocount < 0 ? 0 : $ocount;
        return compact('count', 'ocount');
    }

    public function addWaitProductsAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['type_ids', 'product_ids', 'ozon_category_id', 'ids_to_public', 'account_id']);
        if ($this->errors) return;
        try {
            $collection = (new shopOzonsellerPluginHelper())->getCollectionProducts($post['type_ids'], $post['product_ids']);
        } catch (waException $e) {
            $this->setError($e->getMessage());
            return;
        }

        if (!$type_ids = (new shopOzonsellerPluginOzonCategoryModel())->getFilledTypeIds($post['account_id'], $post['ozon_category_id'])) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_TYPE_FILLED);
            return;
        }
        $product_ids = (new shopOzonsellerPluginProductModel())->getAllProductIds($post['account_id']);
        $collection->addWhere('type_id in(' . implode(',', $type_ids) . ') and p.id not in(' . implode(',', $product_ids) . ')');
        $collection->addWhere('p.id in (' . $post['ids_to_public'] . ')');
        if (!$collection->count()) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_LIST_PRODUCTS);
            return;
        }

        $products = $collection->getProducts('id,sku_id', 0, $collection->count());
        $this->model_wait = new shopOzonsellerPluginWaitProductModel();
        $all_skus = wa()->getPlugin('ozonseller')->getSettings('all_skus', $post['account_id']);
        $errors = false;
        foreach ($products as $product_id => $p) {
            $data = [
                'account_id' => $post['account_id'],
                'product_id' => $p['id'],
                'ozon_category_id' => $post['ozon_category_id']
            ];
            if ($all_skus) {
                $product = new shopProduct($product_id);
                $skus = $product->getSkus();
                foreach ($skus as $sku) {
                    $data['sku_id'] = $sku['id'];
                    try {
                        $this->addWaitProduct($data);
                    } catch (Exception $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                        $errors = true;
                    }
                }
            } else {
                $data['sku_id'] = $p['sku_id'];
                try {
                    $this->addWaitProduct($data);
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    $errors = true;
                }
            }
        }
        if ($errors) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_OPERATION_FAILED);
        }
    }

    private function addWaitProduct($data)
    {
        $this->model_wait->insert($data, 1);
    }

    public function getWaitProductsAction()
    {
        $wait_products = $ozon_category_ids = [];
        if ($wait_publics_data = (new shopOzonsellerPluginWaitProductModel())->getAll('product_id')) {
            $wait_product_data = (new shopProductModel())->getById(array_keys($wait_publics_data));
            $ozon_category_ids = array_column($wait_publics_data, 'ozon_category_id');
        }
        if ($ozon_category_ids) {
            $ozon_categories = (new shopOzonsellerPluginOzonCategoryModel())->getById($ozon_category_ids);
        }
        foreach ($wait_publics_data as $product_id => $item) {
            $wait_products[] = [
                'id' => $product_id,
                'name' => ifset($wait_product_data[$product_id]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE),
                'ozon_category' => ifset($ozon_categories[$item['ozon_category_id']]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE)
            ];
        }
        $this->response = $wait_products;
    }

    public function postExecute()
    {
        if ($this->errors) {
            $this->errors = implode('; ', $this->errors);
        }
        parent::postExecute();
    }
}