<?php

class shopOzonsellerPluginBackendDialogErrorAction extends waViewAction
{
    public function execute()
    {
        $post = waRequest::post();
        if (!isset($post['errors'])) {
            $errors[] = shopOzonsellerPluginTextHelper::ERROR_UNKNOWN;
        } else {
            $errors = $post['errors'];
        }
        $this->view->assign('errors', $errors);
        $this->view->assign('buttons', waRequest::post('buttons'));
    }
}