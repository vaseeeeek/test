<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginBackendViewInfoAction extends waViewAction
{
    public function execute()
    {
        $product_id = waRequest::param('id', 0, waRequest::TYPE_INT);
        $product = new shopProduct($product_id);
        $model_account = new shopOzonsellerPluginAccountModel();
        $accounts = $model_account->getAllAccounts(false, 'id');
        foreach ($accounts as &$account) {
            $data = (new shopOzonsellerPluginProductsActions())->getInfoByProductId($account['id'], $product_id);
            $account['publics'] = $data['publics'];
            $account['unpublics'] = $data['unpublics'];
            $account['errors'] = (new shopOzonsellerPluginFailLogModel())->getByField(['account_id' => $account['id'], 'product_id' => $product_id], true);
        }
        $actionButton = shopOzonsellerPluginHelper::getVueComponent('actionButton');
        $accountsMenu = shopOzonsellerPluginHelper::getVueComponent('accountsMenu');
        $is_debug = shopOzonsellerPluginHelper::isDebug();

        $this->setTemplate(wa()->getAppPath('plugins/ozonseller/templates/actions/backend/product/product.vue'));
        $this->view->assign([
            'account_id' => json_encode((int)$model_account->select('min(id) as id')->fetchField('id')),
            'accounts' => json_encode($accounts),
            'product_id' => $product_id,
            'actionButton' => json_encode($actionButton, 256),
            'accountsMenu' => json_encode($accountsMenu, 256),
            'is_debug' => $is_debug
        ]);
        $this->setLayout(new shopBackendProductsEditSectionLayout([
            'product' => $product,
            'content_id' => 'ozonseller',
        ]));
    }
}