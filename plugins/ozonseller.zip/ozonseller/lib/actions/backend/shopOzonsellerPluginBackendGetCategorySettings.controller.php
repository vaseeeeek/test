<?php

class shopOzonsellerPluginBackendGetCategorySettingsController extends waJsonController
{
    public function execute()
    {
        if (!$account_id = waRequest::post('account_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));
            return;
        }
        if (!$category_id = waRequest::post('category_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'category_id'));
            return;
        }
        $model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        try {
            $category = $model_ozon_category->getCategoryFullData($category_id, $account_id);
            if (isset($category['markups']) && is_array($category['markups'])) {
                $category['markups'] = shopOzonsellerPluginHelper::sortArray($category['markups'], 'price_from');
            }
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $types = $category['types'];
        unset($category['types']);
        if ($types) {
            foreach ($types as $type_id) {
                $category['types'][$type_id]['features'] = $this->getFeaturesByTypeId($type_id);
                $category['types'][$type_id]['values'] = $this->validateTypeFeatureValues($category['ozon_features'], (new shopOzonsellerPluginCategoryFeaturesModel())->getOzonCategoryFeaturesByTypes($account_id, $category_id, $type_id), $category_id, $type_id);
                $category['types'][$type_id]['count'] = (new shopOzonsellerPluginProductModel())->countPublic($category_id);
                $category['ozon_features'] = array_values($category['ozon_features']);
                if ($diff = array_diff(array_column($category['ozon_features'], 'id'), array_keys($category['types'][$type_id]['values']))) {
                    foreach ($diff as $of_id) {
                        $category['types'][$type_id]['values'][$of_id] = [
                            'ozon_category_id' => $category_id,
                            'type_id' => $type_id,
                            'ozon_feature_id' => $of_id,
                            'feature_id' => '0',
                            'value' => null,
                            'ext' => null,
                            'account_id' => $account_id
                        ];
                    }
                }
            }
        } else $category['types'] = false;
        $category['count'] = (new shopOzonsellerPluginProductModel())->countPublic($category_id);
        if ($newAccountId = waRequest::post('new_account')) {
            try {
                $category = (new shopOzonsellerPluginCategoryFeaturesModel())->copyFullCategorySettings($account_id, $newAccountId, $category_id);
            } catch (waException $e) {
                $this->setError($e->getMessage());
            }
        }
        $this->response = $category;
    }

    public function validateTypeFeatureValues($features, $values, $ozon_category_id, $type_id)
    {
        $template = null;
        foreach ($features as $feature_id => $feature) {
            if (!isset($values[$feature_id])) {
                if (!$template) {
                    $template = (new shopOzonsellerPluginCategoryFeaturesModel())->getEmptyRow();
                    $template['ozon_category_id'] = $ozon_category_id;
                    $template['type_id'] = $type_id;
                }
                $values[$feature_id] = array_merge($template, ['ozon_feature_id' => $feature_id]);
            }
        }
        return $values;
    }

    public function getFeaturesByTypeId($type_id)
    {
        $type_features = (new shopOzonsellerPluginHelper())->getFeaturesType($type_id);
        foreach ($type_features[$type_id] as $key => $tf) {
            if (array_search($tf['id'], array_column($type_features[0], 'id')) !== false) {
                unset($type_features[$type_id][$key]);
            }
        }
        return $type_features;
    }
}