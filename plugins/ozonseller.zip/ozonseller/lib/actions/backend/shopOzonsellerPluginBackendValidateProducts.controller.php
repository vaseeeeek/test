<?php

class shopOzonsellerPluginBackendValidateProductsController extends waLongActionController
{

    protected function preInit()
    {
        $post = waRequest::post();
        $errors = [];
        foreach (['type_ids', 'product_ids', 'ozon_category_id', 'account_id'] as $field) {
            if (!ifempty($post[$field])) {
                $errors[] = sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, $field);
            }
        }
        if ($errors) {
            echo json_encode(array('errors' => $errors, 'processId' => false));
            return false;
        }
        $collection = (new shopOzonsellerPluginHelper())->getCollectionProducts($post['type_ids'], $post['product_ids']);
        $model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        if (!$type_ids = $model_ozon_category->getFilledTypeIds($post['account_id'], $post['ozon_category_id'])) {
            $errors[] = (shopOzonsellerPluginTextHelper::ERROR_EMPTY_TYPE_FILLED);
            echo json_encode(array('errors' => $errors, 'processId' => false));
            return false;
        }
        if (!$public_product_ids = (new shopOzonsellerPluginProductModel())->getAllProductIds($post['account_id'])) $public_product_ids = [0];
        $collection->addWhere('p.type_id in(' . implode(',', $type_ids) . ') and p.id not in(' . implode(',', $public_product_ids) . ')');
        if (!$count = $collection->count()) {
            $errors[] = shopOzonsellerPluginTextHelper::ERROR_EMPTY_LIST_PRODUCTS;
            echo json_encode(array('errors' => $errors, 'processId' => false));
            return false;
        }
        $this->data['total'] = $count;
        $this->data['product_ids'] = array_keys($collection->getProducts('id', 0, $count));
        $this->data['ozon_category_id'] = $post['ozon_category_id'];
        $this->data['account_id'] = $post['account_id'];
        return true;
    }

    protected function init()
    {
        $params = [
            'done' => 0,
            'fail' => 0,
            'count' => 0,
            'done_ids' => [],
            'errors' => [],
            'total' => count($this->data['product_ids']),
            'part_size' => wa()->getPlugin('ozonseller')->getSettings('longop_part')
        ];
        $this->data = array_merge($this->data, $params);
        return true;
    }

    protected function step()
    {
        $product_ids = array_slice($this->data['product_ids'], $this->data['count'], $this->data['part_size']);
        try {
            $preparator = new shopOzonsellerPluginPreparator($this->data['account_id']);
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            $this->data['errors'][] = $e->getMessage();
            $this->data['count'] = count($this->data['product_ids']);
            return;
        }
        foreach ($product_ids as $product_id) {
            try {
                $result = $preparator->validateProductData($product_id, $this->data['ozon_category_id']);
                if ($result) {
                    $this->data['done_ids'][] = $product_id;
                    $this->data['done']++;
                } else {
                    $this->data['fail']++;
                }
            } catch (waException $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                $this->data['errors'][] = $e->getMessage();
                $this->data['fail']++;
            }
            $this->data['count'] += 1;
        }
    }

    protected function info()
    {
        $response = array(
            'processId' => $this->processId,
            'ready' => $this->isDone(),
            'done' => $this->data['done'],
            'fail' => $this->data['fail'],
            'errors' => $this->data['errors'],
            'done_ids' => $this->data['done'] ? implode(',', $this->data['done_ids']) : '',
            'total' => $this->data['total']
        );
        echo json_encode($response);
    }

    protected function isDone()
    {
        return $this->data['count'] >= $this->data['total'];
    }

    protected function finish($filename)
    {
        $this->info();
        return true;
    }

    public function execute()
    {
        try {
            parent::execute();
        } catch (waException $e) {
            echo json_encode(['exception' => $e->getMessage()]);
        }
    }
}