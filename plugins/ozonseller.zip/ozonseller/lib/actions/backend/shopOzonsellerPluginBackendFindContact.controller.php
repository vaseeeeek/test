<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginBackendFindContactController extends waController
{
    public function run($params = null)
    {
        $name = waRequest::get('term');
        $query = <<<SQL
select id as value, name as label FROM wa_contact WHERE name LIKE "%$name%" LIMIT 10
SQL;
        echo json_encode((new waContactModel())->query($query)->fetchAll());
    }
}