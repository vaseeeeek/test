<?php

class shopOzonsellerPluginBackendRefreshOzonCategoryController extends waLongActionController
{
    protected function preInit()
    {
        $errors = [];
        if (!$account_id = waRequest::post('account_id')) {
            $errors[] = sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id');
            echo json_encode(array('error' => $errors, 'processId' => false));
            return false;
        }
        try {
            $preparator = new shopOzonsellerPluginCategoryPreparator();
            $categories = $preparator->getOzonCategoryTree($account_id, true);
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            $errors[] = $e->getMessage();
            echo json_encode(array('error' => $errors, 'processId' => false));
            return false;
        }
        if (!$categories) {
            $errors[] = shopOzonsellerPluginTextHelper::ERROR_CATEGORY_EMPTY_LIST;
            echo json_encode(array('error' => $errors, 'processId' => false));
            return false;
        }
        $this->data['ozon_categories'] = $categories;
        $this->data['total'] = count($categories);
        $this->data['count'] = $this->data['done'] = 0;
        return true;
    }

    protected function init()
    {

    }

    protected function step()
    {
        $category = $this->data['ozon_categories'][$this->data['count']];
        try {
            (new shopOzonsellerPluginCategoryPreparator())->addCategory($category);
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
        }
        $this->data['count'] += 1;
    }

    protected function info()
    {
        $response = array(
            'processId' => $this->processId,
            'ready' => $this->isDone(),
            'total' => $this->data['total'],
            'done' => $this->data['count']
        );
        echo json_encode($response);
    }

    protected function isDone()
    {
        return $this->data['count'] >= $this->data['total'];
    }

    protected function finish($filename)
    {
        (new shopOzonsellerPluginCategoryPreparator())->postUpdate();
        $this->info();
        return true;
    }
}