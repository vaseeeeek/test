<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginBackendServicesController extends waJsonController
{
    public function execute()
    {
        if (!$mode = waRequest::post('mode')) {
            $this->errors = sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'mode');
            return;
        }
        $account_id = waRequest::post('account_id');
        if (!$account_id && !in_array($mode, ['addIndividualCategory', 'truncateFvalues', 'stocksInfo', 'restore', 'esnecil'])) {
            $this->errors = sprintf(_wp('Выберите аккаунт Ozon'));
            return;
        }
        switch ($mode) {
            case 'cleanSetting':
                if (!$name = waRequest::post('value')) {
                    $this->errors = sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'name');
                    return;
                }
                $plugin = wa()->getPlugin('ozonseller');
                $settings = $plugin->getSettings(null, $account_id);
                $original = include(wa()->getAppPath('plugins/ozonseller/lib/config/settings.php'));
                $settings[$name] = ifset($original[$name]);
                $plugin->saveSettings($settings, $account_id);

                break;
            case 'setSetting':
                foreach (['setting', 'value'] as $field) {
                    $$field = waRequest::post($field);
                    if ($$field == null) {
                        $this->errors = sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, $field);
                        return;
                    }
                }
                $plugin = wa()->getPlugin('ozonseller');
                $settings = $plugin->getSettings(null, $account_id);
                $original = include(wa()->getAppPath('plugins/ozonseller/lib/config/settings.php'));
                if (!is_string(ifset($original[$setting]['value'])) && !is_int(ifset($original[$setting]['value']))) {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_SETTING_SET_TYPE);
                    return;
                }
                $settings[$setting] = $value;
                $plugin->saveSettings($settings, $account_id);
                break;
            case 'viewSettings':
                $this->response = $this->getHtml(null, wa()->getPlugin('ozonseller')->getSettings(null, $account_id));
                break;
            case 'addIndividualCategory':
                $ozon_feature_id = waRequest::post('value');
                if (!wa_is_int($ozon_feature_id)) {
                    $this->errors = sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'category id');
                    return;
                }
                $plugin = wa()->getPlugin('ozonseller');
                $settings = $plugin->getSettings();
                $settings['unique_category_features'][] = $ozon_feature_id;
                $plugin->saveSettings($settings);
                break;
            case 'publicInfo':
                $offer_id = waRequest::post('value');
                if (!$offer_id) {
                    $this->errors = sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'offer id');
                    return;
                }
                if (!$public = (new shopOzonsellerPluginProductModel())->getByField(['account_id' => $account_id, 'offer_id' => $offer_id])) {
                    $this->errors = shopOzonsellerPluginTextHelper::ERROR_PUBLIC_NOT_FOUND;
                    return;
                }
                $this->response = $this->getHtml(null, $public);
                break;
            case 'publicData':
                $ozon_sku = waRequest::post('value');
                if (!$public = (new shopOzonsellerPluginProductModel())->getByField(['account_id' => $account_id, 'offer_id' => $ozon_sku])) {
                    $this->errors = shopOzonsellerPluginTextHelper::ERROR_PUBLIC_NOT_FOUND;
                    return;
                }
                if (!$sku = (new shopProductSkusModel())->getById($public['sku_id'])) {
                    $this->errors = sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'sku id');
                    return;
                }
                try {
                    $preparator = new shopOzonsellerPluginPreparator($account_id);
                } catch (Exception $e) {
                    $this->errors = $e->getMessage();
                    break;
                }
                $product = new shopProduct($public['product_id']);
                try {
                    $data = $preparator->getSourceData($product, $sku, $public['ozon_category_id']);
                } catch (Exception $e) {
                    $this->errors = $e->getMessage();
                    return;
                }
                $data['quantity'] = $preparator->getQuantityByPublics([$public]);
                $this->response = $this->getHtml(null, $data);
                break;
            case 'resetMarkups':
                $model = new shopOzonsellerPluginCategoryMarkupsModel();
                try {
                    $model->deleteByField(['account_id' => $account_id, 'ozon_category_id' => 'default']);
                    $markups = include(wa()->getAppPath('plugins/ozonseller/lib/config/data/markups.php'));
                    $markups['account_id'] = $account_id;
                    $model->insert($markups);
                } catch (waException $e) {
                    $this->errors = $e->getMessage();
                    return;
                }
                break;
            case 'truncateFvalues':
                $model = new shopOzonsellerPluginOzonFeatureValuesModel();
                try {
                    $model->truncate();
                } catch (Exception $e) {
                    $this->errors = $e->getMessage();
                }
                break;
            case 'stocksInfo':
                if (!$product_id = waRequest::post('value')) {
                    $this->errors = sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'product_id');
                    return;
                }
                $product = (new shopProductModel())->getById($product_id);
                $data = [
                    'product_id' => $product_id,
                    'shop_product' => (new shopProductModel())->select('id, sku_id, count, sku_type, sku_count, status')->where('id=?', $product_id)->fetchAll(),
                    'shop_product_skus' => (new shopProductSkusModel())->select('id, product_id,count,available,status')->where('product_id=?', $product_id)->fetchAll(),
                    'shop_product_stocks' => (new shopProductStocksModel())->getByField('product_id', $product_id, true),
                    'shopProductStocksModel::getBySkuId()' => (new shopProductStocksModel())->getBySkuId([$product['sku_id']]),
                    'shop_stock' => (new shopStockModel())->getAll()
                ];
                $this->response = $this->getHtml(null, $data);
                break;
            case 'deleteOzonCategory':
                try {
                    (new shopOzonsellerPluginBackendActions())->removeCategoryTypeAction();
                } catch (Exception $e) {
                    $this->errors = $e->getMessage();
                }
                break;
            case 'moveProducts':
                $post = waRequest::post();
                foreach (['old_category_id', 'new_category_id'] as $name) {
                    if (!ifempty($post[$name])) {
                        $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, $name));
                    }
                }
                if ($this->errors) return;
                $model = new shopOzonsellerPluginProductModel();
                if ($count = $model->countByField(['account_id' => $account_id, 'ozon_category_id' => $post['old_category_id']])) {
                    try {
                        $model->updateByField(['account_id' => $account_id, 'ozon_category_id' => $post['old_category_id']], ['ozon_category_id' => $post['new_category_id']]);
                    } catch (Exception $e) {
                        $this->setError($e->getMessage());
                        return;
                    }
                }
                (new shopOzonsellerPluginOzonCategoryModel())->deleteById($post['old_category_id']);
                (new shopOzonsellerPluginCategoryFeaturesModel())->deleteByField('ozon_category_id', $post['old_category_id']);
                wa()->getConfig()->clearCache();
                $this->response = $this->getHtml(sprintf(shopOzonsellerPluginTextHelper::TEXT_MOVE_PRODUCTS_SUCESSFULL, $count));
                break;
            case 'syncOrders':
                try {
                    $checker = new shopOzonsellerPluginOrders($account_id);
                    $socket = new shopOzonsellerPluginOzonApi($account_id);
                } catch (Exception $e) {
                    $this->setError($e->getMessage());
                    break;
                }
                $settings = wa()->getPlugin('ozonseller')->getSettings(null, $account_id);
                if (time() - strtotime($settings['order_date']) > $settings['order_period']) {
                    $since_date = date('Y-m-d\T', time() - $settings['order_period']) . '00:00:00Z';
                } else {
                    $since_date = date('Y-m-d\TH:i:s\Z', strtotime($settings['order_date']));
                }
                if ($settings['schema'] != 'fbo') {
                    try {
                        if ($orders = $socket->getOrderList('fbs', ['filter' => ['since' => $since_date, 'to' => date('Y-m-d\TH:i:s\Z')]])) {
                            $checker->processingOrders('fbs', $orders);
                        }
                    } catch (waException $e) {
                        $this->setError($e->getMessage());
                    }
                }
                // Отправления по FBO
                if ($settings['schema'] != 'fbs') {
                    try {
                        if ($orders = $socket->getOrderList('fbo', ['filter' => ['since' => $since_date]])) {
                            $checker->processingOrders('fbo', $orders);
                        }
                    } catch (waException $e) {
                        $this->setError($e->getMessage());
                    }
                }
                break;
            case 'esnecil':
                $tmp = include (wa()->getAppPath('plugins/ozonseller/lib/config/data/requirements.php'));
                break;
            case 'restore':
                if (!file_exists(wa()->getConfigPath('shop') . '/plugins/ozonseller/backupSettings.php')) {
                    $this->getHtml(_wp('Не удалось найти файл с сохраненными настройками. Восстановление невозможно'));
                    return;
                } elseif (!$settings = include (wa()->getConfigPath('shop') . '/plugins/ozonseller/backupSettings.php')) {
                    $this->getHtml(_wp('Не удалось получить настройки. Восстановление невозможно'));
                    return;
                }
                if (!$account = (new shopOzonsellerPluginAccountModel())->getById(1)) {
                    $message = _wp('Не удалось получить аккаунт с id 1. Восстановление настроек невозможно');
                    $this->getHtml($message);
                    return;
                }
                $tables_witn_account_id = [
                    'shop_ozonseller_category_features',
                    'shop_ozonseller_category_markups',
                    'shop_ozonseller_fail_log',
                    'shop_ozonseller_product',
                    'shop_ozonseller_promo',
                    'shop_ozonseller_wait_category',
                    'shop_ozonseller_wait_product'
                ];
                $model = new waAppSettingsModel();
                foreach (['shop_ozonseller_account', 'shop_ozonseller_account_settings'] as $table) {
                    try {
                        $model->query('drop table ' . $table);
                    } catch (waDbException $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    }
                }
                foreach ($tables_witn_account_id as $table) {
                    $query = <<<SQL
delete from $table where account_id > 1
SQL;
                    try {
                        $model->query($query);
                    } catch (waDbException $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    }
                    $query = <<<SQL
alter table $table drop column account_id;
SQL;
                    try {
                        $model->query($query);
                    } catch (waDbException $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    }
                }
                $model->deleteByField('app_id', 'shop.ozonseller');
                foreach ($settings as $name => $setting) {
                    if (is_array($setting)) $setting = json_encode($setting);
                    $model->set('shop.ozonseller', $name, $setting);
                }


                $message = <<<HTML
Настройки успешно восстановлены. <strong>Не очищая кеш фреймворка</strong> вручную удалите каталог с плагином и на его место скопируйте версию 2023.5.х<br>
после чего очистите кеш фреймворка
HTML;
                $this->getHtml($message);
                break;
            default:
                $this->errors = sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'mode');
                return;
        }
        if (!$this->response) {
            $this->response = $this->getHtml();
        }
    }

    private function getHtml($message = null, $data = null)
    {
        if (!$message) $message = 'SUCESSFUL <br>';
        $result = $message . '<br>';
        if ($data) {
            $view = wa()->getView();
            $view->assign('data', $data);
            $result .= $view->fetch('string:{wa_dumpc($data)}');
        }
        return $result;
    }
}