<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginBackendPublicWaitsController extends waLongActionController
{
    protected function preInit()
    {
        $errors = [];
        if (!$waits = (new shopOzonsellerPluginWaitProductModel())->getAll()) {
            $errors[] = shopOzonsellerPluginTextHelper::ERROR_EMPTY_WAIT_LIST;
            echo json_encode(array('errors' => $errors, 'processId' => false));
            return false;
        }
        if (!$accounts = (new shopOzonsellerPluginAccountModel())->getAllAccounts(true, 'id')) {
            $errors[] = shopOzonsellerPluginTextHelper::ERROR_NO_ACCOUNTS_ENABLED;
            echo json_encode(array('errors' => $errors, 'processId' => false));
            return false;
        }
        $this->data['waits'] = $waits;
        $this->data['total'] = count($waits);
        $this->accounts = $accounts;
        return true;
    }

    protected function init()
    {
        $data = [
            'total' => count($this->data['waits']),
            'count' => 0,
            'done' => 0,
            'errors' => 0
        ];
        $this->data = array_merge($this->data, $data);
    }

    protected function step()
    {
        $d = $this->data['waits'][$this->data['count']];
        $preparator = new shopOzonsellerPluginPreparator($d['account_id'], shopOzonsellerPluginPreparator::MODE_PUBLIC);
        try {
            $result = $preparator->importProduct($d['product_id'], $d['ozon_category_id']);
            if ($result === false || $result['errors']) {
                $this->data['errors'] += 1;
            } else {
                (new shopOzonsellerPluginWaitProductModel())->deleteByField(['account_id' => $d['account_id'], 'product_id' => $d['product_id']]);
                $this->data['done']++;
            }
            $this->data['count']++;
            (new shopOzonsellerPluginFailLogModel())->updateLog($d['account_id'],$result);
        } catch (waException $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            $this->data['errors'] += 1;
        }
    }

    protected function isDone()
    {
        return $this->data['count'] >= $this->data['total'];
    }

    protected function info()
    {
        $response = array(
            'processId' => $this->processId,
            'ready' => $this->isDone(),
            'total' => $this->data['total'],
            'done' => $this->data['count'],
            'lis' => [
                'done' => $this->data['done'],
                'fail' => $this->data['errors']
            ],
        );
        echo json_encode($response);
    }

    protected function finish($filename)
    {
        $this->info();
        return true;
    }
}