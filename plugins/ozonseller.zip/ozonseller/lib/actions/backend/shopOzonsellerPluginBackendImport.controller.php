<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginBackendImportController extends waLongActionController
{

    protected function preInit()
    {
        if (!$account_id = waRequest::post('account_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));
            return;
        }
        try {
            new shopOzonsellerPluginOzonApi($account_id);
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            $this->setError($e->getMessage());
            return false;
        }
        $this->data['field'] = waRequest::post('field');
        if (!$this->data['field'] || !in_array($this->data['field'], ['id', 'name', 'sku', 'product_id'])) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'field'));
            return false;
        }
        $this->data['account_id'] = $account_id;
        return true;
    }

    protected function init()
    {
        try {
            $ozon = new shopOzonsellerPluginOzonApi($this->data['account_id']);
            $info = $ozon->getOzonProductsList();
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            $this->setError($e->getMessage());
            return false;
        }
        $this->data['limit'] = 500;
        $this->data['total'] = ifset($info['total'], 0);
        $this->data['count'] = $this->data['connect_error'] = $this->data['new'] = $this->data['exist'] = $this->data['non_exist'] = 0;
        $this->data['non_exist_data'] = [];
        $this->data['last_id'] = '';
        $this->data['products'] = $this->data['errors'] = [];
        $this->data['settings'] = wa()->getPlugin('ozonseller')->getSettings(null, $this->data['account_id']);
        if (!$this->data['total']) return false;
        return true;
    }

    protected function step()
    {
        try {
            $ozon = new shopOzonsellerPluginOzonApi($this->data['account_id']);
            $data = $ozon->getOzonProductsList($this->data['last_id'], $this->data['limit']);
            if ($this->data['settings']['debug'] == 2) {
                shopOzonsellerPluginHelper::setLog('$ozon->getOzonProductsList', 'debug', $data);
            }
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            $this->data['connect_error'] += 1;
        }
        if (ifset($data['items'], [])) {
            $result = (new shopOzonsellerPluginProductsActions())->importOzonProducts($this->data['account_id'], $data['items'], $this->data['field']);
            if(is_array($result)){
                foreach ($result as $field => $value){
                    $this->data[$field] += $value;
                }
            }
            $this->data['last_id'] = $data['last_id'];
        } else {
            $this->data['connect_error'] += 1;
        }

        $this->data['products'] = [];
        $this->data['count'] += count($data['items']);
    }

    protected function isDone()
    {
        if ($this->data['connect_error'] >= 5) {
            $this->data['errors'][] = shopOzonsellerPluginTextHelper::ERROR_ESTABLISH_CONNECTION_SERVER;
        }
        return (($this->data['count'] >= $this->data['total']) || ($this->data['connect_error'] >= 5));
    }

    protected function finish($filename)
    {
        if ($this->data['non_exist_data']) {
            foreach ($this->data['non_exist_data'] as &$el) {
                $el = (string)$el;
            }
            $socket = new shopOzonsellerPluginOzonApi($this->data['account_id']);
            $bad_publics = [];
            foreach (array_chunk($this->data['non_exist_data'], 1000) as $part) {
                try {
                    $data = $socket->getOzonProductInfoList($part);
                    foreach ($data['items'] as $item) {
                        $bad_publics[] = [
                            'id' => $item['id'],
                            'offer_id' => $item['offer_id'],
                            'name' => $item['name']
                        ];
                    }
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                }
            }
            if ($bad_publics) {
                if ($account = (new shopOzonsellerPluginAccountModel())->getById($this->data['account_id'])) {
                    shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::TEXT_NO_MATCHING_PRODUCTS, $account['name'], count($this->data['non_exist_data'])), 'import', $bad_publics);
                }
            }
        }
        $this->info();
    }

    protected function info()
    {
        $response = array(
            'processId' => $this->processId,
            'done' => $this->data['count'],
            'ready' => $this->isDone(),
            'total' => $this->data['total'],
            'errors' => $this->data['errors'],
            'lis' => [
                'new' => $this->data['new'],
                'exist' => $this->data['exist'],
                'nonexist' => $this->data['non_exist']
            ],
        );
        echo json_encode($response);
    }

    private function setError($message)
    {
        echo json_encode(array('error' => $message));
    }
}