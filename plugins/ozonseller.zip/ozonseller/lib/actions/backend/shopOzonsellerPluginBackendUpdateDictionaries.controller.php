<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginBackendUpdateDictionariesController extends waLongActionController
{
    protected function preInit()
    {
        if (!$category_id = waRequest::post('category_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'category_id'));
            return false;
        }
        if (!$account_id = waRequest::post('account_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));
            return false;
        }

        $this->data['category_id'] = $category_id;
        $this->data['account_id'] = $account_id;
        try {
            $features = (new shopOzonsellerPluginOzonCategoryModel())->getFeaturesByCategoryId($category_id);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return false;
        }
        foreach ($features as $feature_id => $feature) {
            if (!$feature['dictionary_id']) continue;
            $this->data['features'][] = ['id' => $feature_id, 'dictionary_id' => $feature['dictionary_id']];
            $cache_key = $feature_id . '_' . $feature['dictionary_id'] . '_' . $category_id;
            (new waSerializeCache($cache_key, 600))->delete();
        }
        return true;
    }

    protected function init()
    {
        $this->data['total'] = count($this->data['features']);
        $this->data['current'] = 0;
        $this->data['done'] = 0;
        $this->data['fail'] = false;
        $this->data['page'] = 0;
        $this->data['errors'] = [];
        $this->data['connect_error'] = 0;
        $max_execution_time = ini_get('max_execution_time') - 10;
        $this->data['execution_time'] = $max_execution_time >= 10 ? $max_execution_time : 10;
//        $this->data['execution_time'] = 10000000;
        $this->data['last_value_id'] = 0;
        $this->data['values_new'] = [];
    }

    protected function step()
    {
        $model_ozon_feature_values = new shopOzonsellerPluginOzonFeatureValuesModel();
        $model_ozon_feature_values->setAccountId($this->data['account_id']);
        $go = true;
        $stime = time();
        while ($go) {
            $feature = $this->data['features'][$this->data['current']];
            $next = true;
            while ($next) {
                try {
                    $response = $model_ozon_feature_values->getFeatureValuesFromOzon($this->data['category_id'], $feature['id'], $this->data['last_value_id']);
//                    $values_exist = $model_ozon_feature_values->getByField(['dictionary_id' => $feature['dictionary_id'], 'id' => array_column($response['result'], 'id')], 'id');
                    foreach ($response['result'] as $item) {
  //                      if (!isset($values_exist[$item['id']])) {
                            $this->data['values_new'][] = [
                                'id' => $item['id'],
                                'dictionary_id' => $feature['dictionary_id'],
                                'value' => trim($item['value']),
                                'info' => trim($item['info']),
                                'picture' => trim($item['picture']),
                                'category_id' => in_array($feature['id'], $model_ozon_feature_values->unique_category_features) ? $this->data['category_id'] : null
                            ];
//                        }
                    }
                    if ($this->data['values_new']) {
                        $model_ozon_feature_values->multipleInsert($this->data['values_new'], ['value']);
                    }
                    $this->data['last_value_id'] = array_pop($response['result'])['id'];
                    $this->data['values_new'] = [];
                    $next = $response['has_next'] && ((time() - $stime) < $this->data['execution_time']);
                } catch (waException $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    $next = false;
                }
            }
            $this->data['current'] += 1;
            $this->data['last_value_id'] = 0;
            $this->data['values_new'] = [];
            $go = ((time() - $stime) < $this->data['execution_time']) && ($this->data['current'] < $this->data['total']);
        }
    }

    protected function isDone()
    {
        if ($this->data['connect_error'] >= 5) {
            $this->data['errors'][] = shopOzonsellerPluginTextHelper::ERROR_ESTABLISH_CONNECTION_SERVER;
        }
        return (($this->data['current'] >= $this->data['total']) || ($this->data['connect_error'] >= 5));
    }

    protected function finish($filename)
    {
        $this->info();
    }

    protected function info()
    {
        $response = array(
            'processId' => $this->processId,
            'progress' => 0.0,
            'ready' => $this->isDone(),
            'total' => $this->data['total'],
            'errors' => $this->data['errors'],
        );
        $response['progress'] = ($this->data ['current'] / $this->data['total']) * 100;
        $response['progress'] = sprintf('%0.3f%%', $response['progress']);
        echo json_encode($response);
    }

    private function setError($message)
    {
        echo json_encode(array('error' => $message));
    }
}