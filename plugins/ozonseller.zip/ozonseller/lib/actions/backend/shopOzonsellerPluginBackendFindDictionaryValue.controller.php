<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginBackendFindDictionaryValueController extends waController
{
    public function run($params = null)
    {
        $get = waRequest::get();
        try {
            $response = (new shopOzonsellerPluginOzonFeatureValuesModel())->searchDictionaryValue($get['category_id'], $get['dictionary_id'], $get['term']);
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            $response = [];
        }
        $response = shopOzonsellerPluginHelper::sortArray($response, 'text');
        echo json_encode(['results' => $response]);
    }
}