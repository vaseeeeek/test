<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginBackendRepairMeta7Controller extends waController
{
    public function execute()
    {
        $result = '';
        $tables = [
            'shop_ozonseller_category_features',
            'shop_ozonseller_category_markups',
            'shop_ozonseller_fail_log',
            'shop_ozonseller_product',
            'shop_ozonseller_promo',
            'shop_ozonseller_wait_category',
            'shop_ozonseller_wait_product'
        ];
        if(!$account_id = waRequest::get('account_id')) {
            print_r(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));
            return;
        }
        $model = new waModel();
        foreach ($tables as $table) {
            try {
                $model->query('select account_id from ' . $table . ' limit 1');
            } catch (waDbException $e) {
                continue;
            }
            if ($data = $model->query('select * from  ' . $table . ' where account_id=0')->fetchAll()) {
                try {
                    $model->query('update ignore ' . $table . ' set account_id=i:account_id where account_id=0', ['account_id' => $account_id]);
                    $model->query('delete from ' . $table . ' where account_id=0');
                } catch (waDbException $e) {
                    $result .= sprintf('При обновлении таблицы %s произошли ошибки: ') . $e->getMessage() . '<br>';
                }
                $result .= sprintf('В таблице %s обновлено %s записей', $table, count($data)) . '<br>';
            } else {
                $result .= _wp(sprintf('В таблице %s отсутствуют записи требующие исправления', $table)) . '<br>';
            }
        }
        $result .= 'Восстановление данных завершено';
        print_r($result);
    }
}