<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginBackendHandMadeAction extends waViewAction
{
    public function execute()
    {
        $this->setLayout(new shopBackendLayout());
        $this->setTemplate(wa()->getAppPath('plugins/ozonseller/templates/actions/backend/BackendHandMade.html'));
        $sets = (new shopSetModel())->getByField('type', '0', true);
        $accounts = (new shopOzonsellerPluginAccountModel())->getAllAccounts();
        if ($restore = waRequest::get('restore')) {
            if (!file_exists(wa()->getConfigPath('shop') . '/plugins/ozonseller/backupSettings.php')) $restore = false;
        }
        $extend = waRequest::get('extend');
        $this->view->assign(compact('sets', 'accounts', 'restore', 'extend'));
    }
}