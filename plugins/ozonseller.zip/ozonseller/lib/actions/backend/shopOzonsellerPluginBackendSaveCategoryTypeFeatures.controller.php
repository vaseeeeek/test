<?php


class shopOzonsellerPluginBackendSaveCategoryTypeFeaturesController extends waJsonController
{
    private $required_empty = 0;

    public function execute()
    {
        $post = waRequest::post();
        foreach (['account_id', 'features', 'category_id', 'type_id'] as $field) {
            if (!ifset($post[$field])) {
                $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, $field));
            }
        }
        if ($this->errors) return;
        $model_category_features = new shopOzonsellerPluginCategoryFeaturesModel();
        $ozon_features = (new shopOzonsellerPluginOzonCategoryModel())->getFeaturesByCategoryId($post['category_id']);
        foreach ($ozon_features as &$feature){
            if(isset($feature['child']) && is_array($feature['child'])){
                foreach ($feature['child'] as $key => $cf){
                    $ozon_features[$cf['id']] = $cf;
                    unset($feature['child'][$key]);
                }
            }
        }
        $model_category_features->deleteByField(['account_id' => $post['account_id'], 'ozon_category_id' => $post['category_id'], 'type_id' => $post['type_id']]);

        $schema_data = ifset($post['features'][0]['value']);
        if($schema_data === null){
            if (wa()->getPlugin('ozonseller')->getSettings('schema', $post['account_id']) == 'fbo'){
                $schema_data = 0;
            } else {
                $schema_data = 1;
            }
        }
        $model_category_features->insert([
            'account_id' => $post['account_id'],
            'ozon_category_id' => $post['category_id'],
            'type_id' => $post['type_id'],
            'ozon_feature_id' => 0,
            'feature_id' => 0,
            'value' => $schema_data
        ]);
        unset($post['features'][0]);

        foreach ($post['features'] as $of_id => $data) {
            if ($ozon_features[$of_id]['is_required'] && (!$data['feature_id'] || (!wa_is_int($data['feature_id']) && !$data['value']))) {
                $this->required_empty++;
            }
            try {
                $model_category_features->insert([
                    'account_id' => $post['account_id'],
                    'ozon_category_id' => $post['category_id'],
                    'type_id' => $post['type_id'],
                    'ozon_feature_id' => $of_id,
                    'feature_id' => $data['feature_id'],
                    'value' => ifset($data['value']),
                    'ext' => ifset($data['ext'])
                ]);
            } catch (Exception $e) {
                $this->setError($e->getMessage());
            }
        }

        if ($this->required_empty) {
            $icon = wa()->whichUI() === '1.3' ? '<i class="icon16 exclamation"></i> ' : '<i class="fas fa-exclamation-circle"></i> ';
            $this->response['attention'] = $icon . sprintf(shopOzonsellerPluginTextHelper::MESSAGE_EMPTY_REQUIRED_FEATURES, $this->required_empty);
        }
    }
}