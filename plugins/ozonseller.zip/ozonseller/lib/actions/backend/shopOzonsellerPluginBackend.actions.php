<?php

class shopOzonsellerPluginBackendActions extends shopOzonsellerPluginJsonActions
{
    public function getCategoryFeaturesByTypeIdAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'category_id', 'type_id']);
        if ($this->errors) return;
        try {
            $ozon_features = (new shopOzonsellerPluginOzonCategoryModel())->getFeaturesByCategoryId($post['category_id']);
            $controller = new shopOzonsellerPluginBackendGetCategorySettingsController();
            $features = $controller->getFeaturesByTypeId($post['type_id']);
            $values = $controller->validateTypeFeatureValues($ozon_features, (new shopOzonsellerPluginCategoryFeaturesModel())->getOzonCategoryFeaturesByTypes($post['account_id'], $post['category_id'], $post['type_id']), $post['category_id'], $post['type_id']);
            if (!isset($values[0])) {
                $values[0] = [
                    'ext' => null,
                    'feature_id' => 0,
                    'ozon_category_id' => $post['category_id'],
                    'ozon_feature_id' => 0,
                    'type_id' => $post['type_id'],
                    'value' => 0
                ];
            }
            $count = (new shopOzonsellerPluginProductModel())->countPublic($post['account_id'], $post['category_id']);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $this->response = compact('features', 'values', 'count');
    }

    public function removeCategoryTypeAction()
    {
        if (!$category_id = waRequest::post('category_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'category_id'));
            return;
        }
        if (!$account_id = waRequest::post('account_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));
            return;
        }
        $type_id = waRequest::post('type_id');
        $model_category_features = new shopOzonsellerPluginCategoryFeaturesModel();
        $params = ['account_id' => $account_id, 'ozon_category_id' => $category_id];
        if ($type_id) $params['type_id'] = $type_id;
        $model_category_features->deleteByField($params);
        unset($params['type_id']);
        if (!$type_id) {
            (new shopOzonsellerPluginCategoryMarkupsModel())->deleteByField($params);
            (new shopOzonsellerPluginCategoryFeaturesModel())->deleteByField($params);
            (new shopOzonsellerPluginWaitCategoryModel())->deleteByField($params);
            (new shopOzonsellerPluginWaitProductModel())->deleteByField($params);
            (new shopOzonsellerPluginFailLogModel())->deleteByField($params);
        }
        $publics = (new shopOzonsellerPluginProductModel())->getPublicsByCategoryId($account_id, $category_id, $type_id);
        try {
            $preparator = new shopOzonsellerPluginPreparator($account_id, shopOzonsellerPluginPreparator::MODE_CHECK);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $ozon_product_ids = [];
        foreach ($publics as $public) {
            $ozon_product_ids[] = (int)$public['ozon_product_id'];
        }
        if ($ozon_product_ids) {
            try {
                $preparator->archivePublic($ozon_product_ids);
            } catch (Exception $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            }
        }
    }

    public function saveMarkupsAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'ozon_category_id']);
        if ($this->errors) return;
        if ($post['ozon_category_id'] == 'default' && !$post['markups']) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'markups'));
            return;
        }
        $model = new shopOzonsellerPluginCategoryMarkupsModel();
        try {
            $model->deleteByField(['account_id' => $post['account_id'], 'ozon_category_id' => $post['ozon_category_id']]);
            if ($post['markups']) {
                $markups = [];
                foreach ($post['markups'] as $markup) {
                    $mitem = [
                        'account_id' => $post['account_id'],
                        'ozon_category_id' => $post['ozon_category_id'],
                        'price_from' => $markup['price_from'],
                        'currency' => $markup['currency'],
                        'markup' => $markup['markup'],
                        'markup_type' => $markup['markup_type']
                    ];
                    $markups[] = $mitem;
                }
                $model->multipleInsert($markups);
            }
        } catch (waException $e) {
            $this->setError($e->getMessage());
        }
        $this->response = $model->getByOzonId($post['account_id'], $post['ozon_category_id']);
    }

    public function addMarkupAction()
    {
        $count = waRequest::post('count');
        if (!wa_is_int($count)) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'count'));
            return;
        }
        if (!$ozon_category_id = waRequest::post('ozon_category_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'ozon_category_id'));
            return;
        }
        $currencies = array_keys((new shopCurrencyModel())->getCurrencies());
        $markup = ['price_from' => 0, 'currency' => '', 'markup' => 0, 'markup_type' => '%'];
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/ozon-category/include.category.markup.edit.tr.html');
        $view->assign(compact('count', 'currencies', 'markup', 'ozon_category_id'));
        $this->response = $view->fetch($template);
    }

    public function getOzonFeatureValuesAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'category_id', 'feature_id']);
        if ($this->errors) return;
        $model = new shopOzonsellerPluginOzonCategoryModel();
        $model->setAccountId($post['account_id']);
        try {
            $values = $model->getFeatureValues($post['category_id'], $post['feature_id']);
        } catch (waException $e) {
                        if ($e->getCode() == 5000) {
            $this->response = shopOzonsellerPluginTextHelper::ERROR_BIG_DATA;
                        } else {
                            $this->setError($e->getMessage());
                        }
                        return;
        }
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/categories/feature.values.html');
        $view->assign('values', $values);
        $this->response = $view->fetch($template);
    }

    public function getDialogMatchesAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'ozon_feature_id', 'feature_id', 'ozon_category_id']);
        if ($this->errors) return;
        $model_categories = new shopOzonsellerPluginOzonCategoryModel();
        $model_categories->setAccountId($post['account_id']);
        try {
            $ovalues = $model_categories->getFeatureValues($post['ozon_category_id'], $post['ozon_feature_id']);
        } catch (waException $e) {
            if ($e->getCode() == 5000) {
                $this->getDialogBigMatch($post);
                return;
            } else {
                $this->setError($e->getMessage());
            }
            return;
        }
        $model_feature = new shopFeatureModel();
        $feature = $model_feature->getById($post['feature_id']);
        $fvalues = $model_feature->getValues([$feature]);
        $values = $fvalues[0]['values'];
        asort($values);
        $ozon_feature_id = $post['ozon_feature_id'];
        $feature_id = $post['feature_id'];
        $umatches = (new shopOzonsellerPluginFeatureValuesMatchesModel())->getByField(['ozon_feature_id' => $post['ozon_feature_id'], 'feature_id' => $post['feature_id']], true);
        try {
            $preparator = new shopOzonsellerPluginPreparator($post['account_id'], 'check');
            $prematches = $preparator->prematchFeatureValues($post['ozon_category_id'], $feature_id, $ozon_feature_id);
        } catch (waException $e) {
            $this->setError($e->getMessage());
            return;
        }
        $matches = [];
        foreach ($values as $key => $value) {
            $is_match = false;
            $tmp = $idx = array_search($key, array_column($umatches, 'value_id'));
            if ($idx === false) {
                $idx = ifset($prematches[$key], false);
            } else {
                $idx = $umatches[$idx]['ozon_value_id'];
                $is_match = true;
            }
            $matches[] = [
                'ozon_value_id' => $idx,
                'ozon_value' => $idx === false ? false : $ovalues[$idx],
                'value_id' => $key,
                'value' => $value,
                'default' => isset($prematches[$key]) && isset($ovalues[$prematches[$key]]) ? $ovalues[$prematches[$key]] : shopOzonsellerPluginTextHelper::TEXT_NO_MATCHES,
                'is_match' => $is_match
            ];
        }
        try {
            $ovalues = (new shopOzonsellerPluginOzonCategoryModel())->getFeatureValues($post['ozon_category_id'], $post['ozon_feature_id'], null, false);
        } catch (waException $e) {
            $this->setError($e->getMessage());
            return;
        }
        $view = wa()->getView();
        $tmpltFile = wa()->whichUI() === '1.3' ? 'dialogMatches_old.html' : 'dialogMatches.html';
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/') . $tmpltFile;
        $view->assign(compact('ovalues', 'feature_id', 'ozon_feature_id', 'matches'));
        $this->response = $view->fetch($template);
    }

    private function getDialogBigMatch($data)
    {
        $model_feature = new shopFeatureModel();
        $feature_id = $data['feature_id'];
        $ozon_feature_id = $data['ozon_feature_id'];
        $ozon_category_id = $data['ozon_category_id'];
        $account_id = $data['account_id'];
        $feature = $model_feature->getById($feature_id);
        $fvalues = $model_feature->getValues([$feature]);
        $values = $fvalues[0]['values'];
        asort($values);
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/dialogMatchesBig.html');
        $view->assign(compact('values', 'feature_id', 'ozon_feature_id', 'ozon_category_id', 'account_id'));
        $this->response = $view->fetch($template);
    }

    public function getBigMatchAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['ozon_category_id', 'ozon_feature_id', 'feature_id', 'value', 'value_id', 'account_id']);
        if ($this->errors) return;
        $is_match = $match = $ovalue = false;
        $ozon_category_id = $post['ozon_category_id'];
        $ozon_feature_id = $post['ozon_feature_id'];
        if (!$dictionary_id = (new shopOzonsellerPluginOzonCategoryModel())->getDictionaryId($ozon_category_id, $ozon_feature_id)) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_FAIL_DICTIONARY_ID);
            return;
        }
        $params = [
            'ozon_feature_id' => $ozon_feature_id,
            'feature_id' => $post['feature_id'],
            'value_id' => $post['value_id']
        ];
        if ($match = (new shopOzonsellerPluginFeatureValuesMatchesModel())->getByField($params)) {
            $ozon_value = (new shopOzonsellerPluginOzonFeatureValuesModel())->getByField(['dictionary_id' => $dictionary_id, 'id' => $match['ozon_value_id']]);
            $is_match = true;
            $ovalue = $ozon_value['value'];
        } else {
            try {
                $preparator = new shopOzonsellerPluginPreparator($post['account_id']);
            } catch (Exception $e) {
                $this->setError($e->getMessage());
                return;
            }
            $ovalues = (new shopOzonsellerPluginOzonFeatureValuesModel())->getAllFeatureValues($ozon_category_id, $ozon_feature_id, $dictionary_id);
            $idx = $preparator->checkValueOptions($post['value'], $ovalues);
            if ($idx !== false) {
                $ovalue = $ovalues[$idx];
            }
            unset($ovalues);
        }
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/include.bigmatch.html');
        $view->assign(compact('ovalue', 'ozon_category_id', 'ozon_feature_id', 'dictionary_id', 'is_match', 'match'));
        $this->response = $view->fetch($template);
    }

    public function setBigmatchAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['ozon_feature_id', 'feature_id', 'value_id', 'ozon_value_id']);
        if ($this->errors) {
            $this->errors = implode(', ', $this->errors);
            return;
        }
        $model = new shopOzonsellerPluginFeatureValuesMatchesModel();
        $params = [
            'ozon_feature_id' => $post['ozon_feature_id'],
            'feature_id' => $post['feature_id'],
            'value_id' => $post['value_id'],
        ];
        $model->deleteByField($params);
        $params['ozon_value_id'] = $post['ozon_value_id'];
        try {
            $model->insert($params, 1);
        } catch (Exception $e) {
            $this->errors = $e->getMessage();
        }
    }

    public function delBigMatchAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['ozon_feature_id', 'feature_id', 'value_id', 'match_ozon_id']);
        if ($this->errors) {
            $this->errors = implode(', ', $this->errors);
            return;
        }
        $params = [
            'ozon_feature_id' => $post['ozon_feature_id'],
            'feature_id' => $post['feature_id'],
            'value_id' => $post['value_id'],
            'ozon_value_id' => $post['match_ozon_id']
        ];
        try {
            (new shopOzonsellerPluginFeatureValuesMatchesModel())->deleteByField($params);
        } catch (Exception $e) {
            $this->errors = $e->getMessage();
        }
    }

    public function getCountMatchesAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['ozon_feature_id', 'feature_id']);
        if ($this->errors) return;
        $this->response = (new shopOzonsellerPluginFeatureValuesMatchesModel())->countByField(['ozon_feature_id' => $post['ozon_feature_id'], 'feature_id' => $post['feature_id']]);
    }

    public function reloadMeatchesByFeaturesAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['ozon_feature_id', 'feature_id']);
        if ($this->errors) return;
        $matches = [];
        $allMatches = (new shopOzonsellerPluginFeatureValuesMatchesModel())->getMatchesByOzonFeatureId($post['ozon_feature_id']);
        if (isset($allMatches[$post['feature_id']])) $matches = $allMatches[$post['feature_id']];
        $this->response = $matches;
    }

    public function saveMatchAction()
    {
        $post = waRequest::post();
        $data = $post;
        $this->checkRequiredFields($post, ['ozon_feature_id', 'ozon_value_id', 'feature_id', 'value_id']);
        if ($this->errors) return;
        unset($post['ozon_value_id']);
        $model = new shopOzonsellerPluginFeatureValuesMatchesModel();
        if ($match = $model->getByField($post)) {
            //$values = (new shopOzonsellerPluginOzonFeatureModel())->getValuesByFeatureId($post['ozon_feature_id']);
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_MATCH_EXIST);
        } else {
            try {
                $model->insert($data, 1);
            } catch (Exception $e) {
                $this->setError($e->getMessage());
                return;
            }
        }
    }

    public function deleteMatchAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['ozon_feature_id', 'ozon_value_id', 'feature_id', 'value_id']);
        if ($this->errors) return;
        try {
            (new shopOzonsellerPluginFeatureValuesMatchesModel())->deleteByField($post);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
        }
    }

    public function rejectImportAction()
    {
        if (!$file = waRequest::post('file')) {
            $this->errors = (sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'file'));
            return;
        }
        try {
            waFiles::delete(wa()->getTempPath($file));
        } catch (waException $e) {
            $this->errors = $e->getMessage();
        }
    }

    public function getProductLogsAction()
    {
        if (!$product_id = waRequest::post('product_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'product_id'));
            return;
        }
        $product = new shopProduct($product_id);
        $product['skus'] = $product->getSkus();
        $records = (new shopOzonsellerPluginFailLogModel())->getInfoByProductId($product_id);
        foreach ($records as &$record) {
            $record['header'] = trim(ifset($product['skus'][$record['sku_id']]['name'], '') . ' ' . ifset($product['skus'][$record['sku_id']]['sku'], ''));
        }
        $this->response = $records;
    }

    public function filterProductsAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['params']);
        if ($this->errors) return;
        $data = [];
        if (count($post['params']) > 1) {
            foreach ($post['params'] as $param) {
                $data['product_id'][] = $param['value'];
            }
        } else {
            if ($post['params'][0]['name'] == 'product_id[]') {
                $data['product_id'][] = $post['params'][0]['value'];
            } else {
                $data[$post['params'][0]['name']] = $post['params'][0]['value'];
            }
        }
        if (isset($data['hash']) && $data['hash']) {
            if ($data['hash'] == 'category') {
                $type_ids = 'category';
                $product_ids = '';
            } else {
                $type_ids = 'hash';
                $product_ids = $data['hash'];
            }
        } elseif (isset($data['product_id']) && $data['product_id']) {
            $type_ids = 'ids';
            if (!$product_ids = implode(',', $data['product_id'])) {
                $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_LIST_PRODUCTS);
            }
        } else {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'product_id'));
            return;
        }
        if ($this->errors) return;
        $collection = (new shopOzonsellerPluginHelper())->getCollectionProducts($type_ids, $product_ids);
        $publics_where = $post['action'] == 2 ? 'task_id is not null' : '';
        if (!$public_ids = (new shopOzonsellerPluginProductModel())->getDistinctPublicIds('product_id', $publics_where)) {
            $public_ids = [0];
        }
        $where = 'p.id ' . sprintf($post['action'] ? 'IN (%s)' : 'NOT IN (%s)', implode(',', $public_ids));
        $collection->addWhere($where);
        $product_ids = array_keys($collection->getProducts('id', 0, $collection->count()));

        $user = wa()->getUser();
        $os_hash = $user['id'] . '_' . time();
        wa()->getStorage()->set('shop/ozonseller/' . $os_hash, array(
            'pids' => $product_ids,
            'title' => $post['action'] ? ($post['action'] == 1 ? shopOzonsellerPluginTextHelper::TEXT_PRODUCT_PUBLIC : shopOzonsellerPluginTextHelper::TEXT_PRODUCT_PUBLIC_MODERATION) : shopOzonsellerPluginTextHelper::TEXT_PRODUCT_PUBLIC_NO
        ));
        $this->response = $os_hash;
    }

    public function getWaitsPbarAction()
    {
        $pbar = [
            'color' => 'blue',
            'is_small' => true,
            'width' => '70%',
            'processing_text' => shopOzonsellerPluginTextHelper::TEXT_PBAR_PROGRESS_WAITS,
            'done_text' => '<br><br>',/*shopOzonsellerPluginTextHelper::TEXT_PBAR_DONE_WAITS,*/
            'done_error_text' => shopOzonsellerPluginTextHelper::TEXT_PBAR_DONE_ERRORS_WAITS,
            'lis' => [
                [
                    'icon' => 'status-green',
                    'text' => shopOzonsellerPluginTextHelper::TEXT_PBAR_ICON_YES_WAITS,
                    'id' => 'ozonseller-icon-yes'
                ],
                [
                    'icon' => 'status-red',
                    'text' => shopOzonsellerPluginTextHelper::TEXT_PBAR_ICON_FAIL_WAITS,
                    'id' => 'ozonseller-icon-non-exist'
                ],
            ]
        ];
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/block_gradusnik.html');
        $view->assign(compact('pbar'));
        $this->response = $view->fetch($template);
    }

    public function getDimsSelectAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['feature_id', 'ozon_feature_id']);
        if ($this->errors) return;
        $feature_id = $post['feature_id'];
        $ozon_feature_id = $post['ozon_feature_id'];
        if (!$feature = (new shopFeatureModel())->getById($feature_id)) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_FEATURE_SHOP_NOT_FOUND, $feature_id));
            return;
        }
        $units = shopOzonsellerPluginHelper::getDimensionUnits();
        $ftype = explode('.', $feature['type']);
        if (!isset($units[$ftype[1]])) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_UNKNOWN);
            return;
        }
        $conv = shopOzonsellerPluginTextHelper::TEXT_DIM_CONVERTATION;
        $conv_no = shopOzonsellerPluginTextHelper::TEXT_DIM_CONVERTATION_NO;
        $html = <<<HTML
<select name="features[$ozon_feature_id][value]" class="dims">
        <option value="">$conv_no</option>
        <optgroup label="$conv">
HTML;
        foreach ($units[$ftype[1]]['units'] as $unit_id => $unit) {
            $unit_name = $unit['name'];
            $html .= <<<HTML
                <option value="$unit_id">$unit_name</option>
HTML;
        }
        $html .= <<<HTML
        </optgroup>
    </select>
HTML;
        if ($post['is_string']) {
            $title = shopOzonsellerPluginTextHelper::TEXT_TITLE_ABC_ICON;
            $html .= <<<HTML
        <input name="features[$ozon_feature_id][ext]" type="checkbox" value="1" class="dims" title="$title">
        <i class="ozonseller-icon24 abc dims" title="$title"></i>
HTML;

        }
        $this->response = $html;
    }

    public function getDialogSelectContactAction()
    {
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/selectContact.html');
        $this->response = $view->fetch($template);
    }

    public function getOzonCategoriesAction()
    {
        $this->response = array_values((new shopOzonsellerPluginOzonCategoryModel())->getFullTree('id,name,status,depth'));
    }

    public function removeProductComparsionAction()
    {
        $post = waRequest::post();
        if (!$account_id = waRequest::post('account_id')) $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));        if (!$post['target']) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_SELECT_PARAM);
        } elseif ($post['target'] != 'all' && !$post['set']) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_SELECT_PARAM);
        }
        if ($this->errors) return;
        $model = new shopOzonsellerPluginProductModel();
        try {
            switch ($post['target']) {
                case 'all':
                    $model->deleteByField('account_id', $account_id);
                    break;
                case 'set_in':
                case 'set_out':
                    $operator = $post['target'] == 'set_in' ? 'IN' : 'NOT IN';
                    $query = <<<SQL
delete from shop_ozonseller_product where account_id=i:account_id and product_id $operator(i:product_ids)
SQL;
                    $product_ids = (new shopSetProductsModel())->query('select product_id from shop_set_products where set_id=?', $post['set'])->fetchAll(null, true);
                    if (!$product_ids) {
                        $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_LIST_PRODUCTS);
                        break;
                    }
                    $model->query($query, ['product_ids' => $product_ids, 'account_id' => $account_id]);
                    break;
                default:
                    $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'target'));
                    break;
            }
        } catch (Exception $e) {
            $this->setError($e->getMessage());
        }
        $this->response = [
            'publics' => count($model->select('distinct product_id')->where('account_id=?', $account_id)->fetchAll()),
            'publicSkus' => $model->countByField('account_id', $account_id)
        ];
    }

    public function updateWaitsAction()
    {
        if (!$mode = waRequest::post('mode')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'mode'));
            return;
        }
        switch ($mode) {
            case 'trash':
                try {
                    (new shopOzonsellerPluginWaitProductModel())->truncate();
                } catch (Exception $e) {
                    $this->setError($e->getMessage());
                    return;
                }
            case 'update':
                $waitProducts = $waitCategories = $wait_product_data = [];
                $categories_ozon = (new shopOzonsellerPluginOzonCategoryModel())->getFullTree('id,name,status,depth');
                if ($wait_publics_data = (new shopOzonsellerPluginWaitProductModel())->getAll('product_id')) {
                    $wait_product_data = (new shopProductModel())->getById(array_keys($wait_publics_data));
                }
                foreach ($wait_publics_data as $product_id => $item) {
                    $waitProducts[] = [
                        'account_id' => $item['account_id'],
                        'id' => $product_id,
                        'name' => ifset($wait_product_data[$product_id]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE),
                        'ozon_category' => ifset($categories_ozon[$item['ozon_category_id']]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE)
                    ];
                }
                if ($waitCategories = (new shopOzonsellerPluginWaitCategoryModel())->getAll()) {
                    $category_ids = array_column($waitCategories, 'category_id');
                    $ozon_category_ids = array_column($waitCategories, 'ozon_category_id');
                    $shop_categories = (new shopCategoryModel())->getById($category_ids);
                    $ozon_categories = (new shopOzonsellerPluginOzonCategoryModel())->getById($ozon_category_ids);
                    foreach ($waitCategories as &$category) {
                        $category['name'] = ifset($shop_categories[$category['category_id']]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE);
                        $category['ozon_name'] = ifset($ozon_categories[$category['ozon_category_id']]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE);
                    }
                }

                $this->response = compact('waitProducts', 'waitCategories');
                break;
            default:
                $this->setError(shopOzonsellerPluginTextHelper::ERROR_UNEXPECTED_MODE);
        }
    }

    public function copyCategorySettingsAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['source_id', 'category_id', 'target_id']);
        if ($this->errors) return;
        try {
            (new shopOzonsellerPluginCategoryFeaturesModel())->copyFullCategorySettings($post['source_id'], $post['target_id'], $post['category_id']);
        } catch (waException $e) {
            $this->setError($e->getMessage());
        }
    }

    public function checkLimitsAction()
    {
        try {
            $socket = new shopOzonsellerPluginOzonApi();
            $data = $socket->checkLimits();
        } catch (Exception $e) {
            $this->setError = $e->getMessage();
            return;
        }
        if (!$data) {
            $this->errors = shopOzonsellerPluginTextHelper::ERROR_ESTABLISH_CONNECTION_SERVER;
            return;
        }
        $data['reset_at'] = shopOzonsellerPluginHelper::convertDateFromUtc($data['reset_at']);

        $view = wa()->getView();
        $view->assign('data', $data);
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/limits.info.html');
        $this->response = $view->fetch($template);
    }
    public function refreshLogsAction()
    {
        if (!$mode = waRequest::post('mode')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'mode'));
            return;
        }
        switch ($mode) {
            case 'trash':
                try {
                    (new shopOzonsellerPluginFailLogModel())->truncate();
                } catch (Exception $e) {
                    $this->setError($e->getMessage());
                }
            case 'update':
                if ($records = (new shopOzonsellerPluginFailLogModel())->getSummaryInfo()) $records = array_values($records);
                $this->response = $records;
                break;
            default:
                $this->setError(shopOzonsellerPluginTextHelper::ERROR_UNEXPECTED_MODE);
        }
    }

    public function closeBannerAction() {
        wa()->getResponse()->setCookie(shopOzonsellerPluginTextHelper::BANNER_COOKIES_KEY, (new DateTime())->modify('+7days')->format('Y-m-d'));
    }

    public function checkLicenseAction() {
        $license = waLicensing::check('shop/plugins/ozonseller');
        $this->response = [
            'license' => true,
            'premium' => true
        ];
    }
}