<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginSetupActions extends shopOzonsellerPluginJsonActions
{
    private $view;
    private $path;
    private $type;

    public function categoriesAction()
    {
        $plugin = wa()->getPlugin('ozonseller');
        $this->type = 'categories';
        $this->path = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/categories/');
        $accounts = (new shopOzonsellerPluginAccountModel())->getAllAccounts();
        $model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        $accSettings = [];
        foreach ($accounts as $account) {
            if ($categories = $model_ozon_category->getAssociatedCategoriesAll($account['id'])) {
                $categories = shopOzonsellerPluginHelper::sortArray($categories, 'name');
            }
            $markups = (new shopOzonsellerPluginCategoryMarkupsModel())->getAllMarkups( $account['id']);
            $accSettings[$account['id']] = [
                'categories' => $categories,
                'markups' => $markups,
                'schema' => $plugin->getSettings('schema', $account['id'])
            ];
        }
        $types = (new shopTypeModel())->getAll();
        $currencies = array_keys((new shopCurrencyModel())->getCurrencies());
        $accountsMenu = shopOzonsellerPluginHelper::getVueComponent('accountsMenu');

        $this->view->assign([
            'accounts' => json_encode($accounts),
            'accSettings' => json_encode($accSettings),
            'markups' => json_encode($markups),
            'types' => json_encode($types),
            'currencies' => json_encode($currencies),
            'ocount' => json_encode($model_ozon_category->countAll()),
            'newUi' => json_encode(wa()->whichUI('shop') !== '1.3'),
            'accountsMenu' => json_encode($accountsMenu, 256)
        ]);
    }

    public function promosAction()
    {
        if (!$account_id = waRequest::post('account_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id'));
            return;
        }
        $this->type = 'promos';
        $this->path = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/promos/');
        $accounts = (new shopOzonsellerPluginAccountModel())->getAllAccounts();
        $accSettings = [];
        $controller = new shopOzonsellerPluginPromosActions($account_id);
        foreach ($accounts as $account) {
            try {
                $accSettings[$account['id']] = array_values($controller->getPromos($account['id']));
            } catch (Exception $e) {
                $this->setError($e->getMessage());
                $accSettings[$account['id']] = [];
            }
        }
        $sets = (new shopSetModel())->getByField('type', '0', true);
        $wa_path = wa()->getConfig()->getRootPath();
        $apps = wa()->getApps(true);
        $is_cloud = isset($apps['hosting']);
        $options = $this->getCombiOptions();
        $combiControl = shopOzonsellerPluginHelper::getVueComponent('combiControl');
        $accountsMenu = shopOzonsellerPluginHelper::getVueComponent('accountsMenu');
        $cronInfo = shopOzonsellerPluginHelper::getVueComponent('cronInfo');
        $original_settings = include(wa()->getAppPath('plugins/ozonseller/lib/config/settings.php'));
        $cntrlSetting = $original_settings['price'];
        unset($cntrlSetting['title']);
        $this->view->assign([
            'accounts' => json_encode($accounts),
            'accSettings' => json_encode($accSettings),
            'sets' => json_encode($sets),
            'wa_path' => json_encode($wa_path),
            'is_cloud' => json_encode($is_cloud),
            'options' => json_encode($options),
            'combiControl' => json_encode($combiControl, 256),
            'accountsMenu' => json_encode($accountsMenu, 256),
            'cronInfo' => json_encode($cronInfo, 256),
            'cntrlSetting' => json_encode($cntrlSetting),
            'newUi' => json_encode(wa()->whichUI('shop') !== '1.3')
        ]);
    }

    public function logsAction()
    {
        $this->type = 'logs';
        $this->path = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/logs/');
        $model = new shopOzonsellerPluginFailLogModel();
        $logs = $model->getSummaryInfo();
        $accounts = (new shopOzonsellerPluginAccountModel())->getAllAccounts();
        $this->view->assign([
            'accounts' => json_encode($accounts),
            'logs' => json_encode(array_values($logs))
        ]);
    }

    public function waitAction()
    {
        $this->type = 'wait';
        $this->path = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/wait/');
        $wait_products = $wait_categories = $wait_product_data = $ozon_category_ids = [];
        if ($wait_publics_data = (new shopOzonsellerPluginWaitProductModel())->getAll('product_id')) {
            $wait_product_data = (new shopProductModel())->getById(array_keys($wait_publics_data));
            $ozon_category_ids = array_column($wait_publics_data, 'ozon_category_id');
        }
        if ($wait_categories = (new shopOzonsellerPluginWaitCategoryModel())->getAll()) {
            $category_ids = array_column($wait_categories, 'category_id');
            $shop_categories = (new shopCategoryModel())->getById($category_ids);
            $ozon_category_ids = array_merge($ozon_category_ids, array_column($wait_categories, 'ozon_category_id'));
        }
        if ($ozon_category_ids) {
            $ozon_categories = (new shopOzonsellerPluginOzonCategoryModel())->getById($ozon_category_ids);
        }
        foreach ($wait_publics_data as $product_id => $item) {
            $wait_products[] = [
                'account_id' => $item['account_id'],
                'id' => $product_id,
                'name' => ifset($wait_product_data[$product_id]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE),
                'ozon_category' => ifset($ozon_categories[$item['ozon_category_id']]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE)
            ];
        }
        foreach ($wait_categories as &$category) {
            $category['name'] = ifset($shop_categories[$category['category_id']]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE);
            $category['ozon_name'] = ifset($ozon_categories[$category['ozon_category_id']]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE);
        }
        $accounts = (new shopOzonsellerPluginAccountModel())->getAllAccounts();
        $this->view->assign([
            'waitProducts' => json_encode($wait_products),
            'waitCategories' => json_encode($wait_categories),
            'accounts' => json_encode($accounts),
            'newUi' => json_encode(wa()->whichUI('shop') !== '1.3')
        ]);
    }

    public function generalAction()
    {
        $lengths = (shopDimension::getInstance())->getDimension('length');
        $this->view->assign('lengths', json_encode($lengths));
        $this->getTemplateSettings('general');
    }

    public function pricesAction()
    {
        $ozonStocks = $this->getAllOzonStocks();
        $stocks = shopHelper::getStocks();
        $this->view->assign([
            'stocks' => json_encode($stocks),
        ]);
        $this->getTemplateSettings('prices', true, ['ozonStocks' => $ozonStocks]);
    }

    public function ordersAction()
    {
        $stocks = shopHelper::getStocks();
        $actions = [];
        $exclude_actions = shopOzonsellerPluginHelper::getConfigFile('exclude_order_actions.php');
        foreach ((new shopWorkflow())->getAllActions() as $action) {
            $action_id = $action->getId();
            if (in_array($action_id, $exclude_actions)) continue;
            $actions[] = array(
                'value' => $action_id,
                'title' => $action->getName(),
            );
        }
        $payments = shopOzonsellerPlugin::getPaymentsShippingsMethods('payment');
        $shippings = shopOzonsellerPlugin::getPaymentsShippingsMethods('shipping');
        $setting_default_order_status = include(wa()->getAppPath('plugins/ozonseller/lib/config/data/ozon_order_statuses.php'));
        $fbs_actions = $ozon_statuses = [];
        foreach ($setting_default_order_status['fbo'] as $key => $value) {
            try {
                $const = constant('shopOzonsellerPluginTextHelper::OZON_ORDER_' . strtoupper($key));
            } catch (Error $e) {
                shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_UNKNOWN_CONSTANT, $key), 'error');
                $const = strtoupper($key);
            }
            $ozon_statuses[] = ['title' => $const, 'value' => $key];
        }
        foreach (['delivered', 'delivering', 'last-mile'/*, 'cancel'*/] as $status) {
            try {
                $const = constant('shopOzonsellerPluginTextHelper::OZON_ORDER_' . strtoupper(str_replace('-', '_', $status)));
            } catch (Error $e) {
                shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_UNKNOWN_CONSTANT, $status), 'error');
                $const = $status;
            }
            $fbs_actions[] = ['value' => $status, 'title' => shopOzonsellerPluginTextHelper::TEXT_CHANGE_TO . $const];
        }
        $this->view->assign([
            'stocks' => json_encode($stocks),
            'actions' => json_encode($actions),
            'payments' => json_encode($payments),
            'shippings' => json_encode($shippings),
            'fbs_actions' => json_encode($fbs_actions),
            'ozon_statuses' => json_encode($ozon_statuses)
        ]);

        $this->getTemplateSettings('orders', true, ['ozonStocks' => $this->getAllOzonStocks()]);
    }

    private function getTemplateSettings($type, $with_options = true, $ext_settings = [])
    {
        $plugin = wa()->getPlugin('ozonseller');
        $this->type = $type;
        $this->path = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/' . $type . '/');
        if ($with_options) $options = $this->getCombiOptions();
        else $options = [];
        $accounts = (new shopOzonsellerPluginAccountModel())->getAll();
        $accSettings = [];
        foreach ($accounts as $account) {
            $accSettings[$account['id']] = shopOzonsellerPluginHelper::getAccountSettingsType($account['id'], $this->type, false);
            foreach ($ext_settings as $name => $value) {
                if (is_array($value) && isset($value[$account['id']])) $accSettings[$account['id']][$name] = $value[$account['id']];
                else $accSettings[$account['id']][$name] = $value;
            }
            switch ($type) {
                case 'prices':
                    foreach (['stock_ids', 'null_quantity'] as $field) {
                        if (!ifset($accSettings[$account['id']][$field]['value'])) {
                            foreach ($accSettings[$account['id']]['ozonStocks'] as $data) {
                                $accSettings[$account['id']][$field]['value'][$data['warehouse_id']] = 0;
                            }
                        }
                    }
                    break;
                case 'orders':
                    $accSettings[$account['id']]['schema']['value'] = $plugin->getSettings('schema', $account['id']);
                    $contact = ['id' => null, 'name' => shopOzonsellerPluginTextHelper::TEXT_DONT_CREATE_ORDERS];
                    if ($contact_id = ifset($accSettings[$account['id']]['contact_id']['value'])) {
                        try {
                            $contact = new waContact($contact_id);
                            if ($contact->getId()) $contact = ['id' => $contact_id, 'name' => $contact->getName()];
                            else throw new waException();
                        } catch (waException $e) {
                            $contact = [
                                'id' => $contact_id,
                                'name' => shopOzonsellerPluginTextHelper::ERROR_CONTACT_DELETED
                            ];
                        }
                    }
                    $accSettings[$account['id']]['contact'] = $contact;
                    foreach ($accSettings[$account['id']]['ozonStocks'] as $data) {
                        if (!ifset($accSettings[$account['id']]['order_params']['value']['fbs'][$data['warehouse_id']])) {
                            $accSettings[$account['id']]['order_params']['value']['fbs'][$data['warehouse_id']] = ['stock_id' => 0, 'payment' => 0, 'shipping' => 0];
                        }
                    }

                    foreach (['fbo', 'fbs'] as $schema) {
                        if (!isset($accSettings[$account['id']]['ozon_order_status']['value'][$schema])) {
                            $accSettings[$account['id']]['ozon_order_status']['value'][$schema] = [];
                        }
                    }
                    break;
            }
        }
        $accountsMenu = shopOzonsellerPluginHelper::getVueComponent('accountsMenu');
        $combiControl = shopOzonsellerPluginHelper::getVueComponent('combiControl');
/*        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/combiControl.vue');*/
        $this->view->assign([
            'accSettings' => json_encode($accSettings),
            'options' => json_encode($options),
            'combiControl' => json_encode($combiControl, 256),
            'accounts' => json_encode($accounts),
            'accountsMenu' => json_encode($accountsMenu, 256),
            'newUi' => json_encode(wa()->whichUI('shop') !== '1.3')
        ]);
    }

    public function importAction()
    {
        $this->type = 'import';
        $this->path = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/import/');
        $model_product = new shopProductModel();
        $model_product_skus = new shopProductSkusModel();
        $model = new shopOzonsellerPluginProductModel();
        $accounts = (new shopOzonsellerPluginAccountModel())->getAllAccounts();
        $accSettings = [];
        foreach ($accounts as $account) {
            $accSettings[$account['id']] = [
                'total' => $model_product->countAll(),
                'totalSkus' => $model_product_skus->countAll(),
                'publics' => count($model->select('distinct product_id')->where('account_id=?', $account['id'])->fetchAll()),
                'publicSkus' => $model->countByField('account_id', $account['id'])
            ];
        }
        $sets = (new shopSetModel())->where('type=0')->order('name')->fetchAll();
        $bar = [
            'max' => null,
            'value' => 0,
            'width' => '70%',
            'height' => '2em',
            'doneText' => 'Процесс успешно завершен',
            'errorText' => 'В процессе работы возникли ошибки',
            'prerunText' => 'Получаем информацию о товарах в Ozon...',
            'runText' => 'Идёт проверка и сопоставление товаров...',
            'state' => 'wait',
            'small' => false,
            'time' => true,
            'result' => [],
            'lis' => [
                ['icon' => 'fas fa-check-double', 'text' => 'Успешно сопоставлено: ', 'el' => 'new', 'empty' => true],
                ['icon' => 'fas fa-clipboard-list', 'text' => 'Ранее сопоставленных: ', 'el' => 'exist', 'empty' => true],
                ['icon' => 'far fa-question-circle', 'text' => 'Не удалось сопоставить: ', 'el' => 'nonexist', 'empty' => true]
            ]
        ];
        if (wa()->whichUI() === '1.3') {
            $bar['lis'] = [
                ['icon' => 'icon16 status-green', 'text' => 'Успешно сопоставлено: ', 'el' => 'new', 'empty' => true],
                ['icon' => 'icon16 status-yellow', 'text' => 'Ранее сопоставленных: ', 'el' => 'exist', 'empty' => true],
                ['icon' => 'icon16 status-red', 'text' => 'Не удалось сопоставить: ', 'el' => 'nonexist', 'empty' => true]
            ];
        }
        $accountsMenu = shopOzonsellerPluginHelper::getVueComponent('accountsMenu');
        $this->view->assign([
            'accSettings' => json_encode($accSettings),
            'sets' => json_encode($sets),
            'bar' => json_encode($bar),
            'accounts' => json_encode($accounts),
            'accountsMenu' => json_encode($accountsMenu, 256),
            'newUi' => json_encode(wa()->whichUI('shop') !== '1.3')
        ]);
    }

    private function getFilenamesByUi($type)
    {
        $newUi = wa()->whichUI() !== '1.3';
        return [
            'html' => $type . ($newUi ? '' : '_old') . '.vue',
            'script' => $type . '.js'
        ];
    }

    private function getCombiOptions()
    {
        $sets_options = $stocks_options = $params_options = $siteBlocks_options = $features_options = $plugin_price_options = $plugin_scanbarcode_options = $plugin_pricetype_options = null;
        foreach ((new shopSetModel())->where('type=0')->order('name')->fetchAll() as $set) {
            $sets_options[] = [
                'value' => $set['id'],
                'title' => $set['name']
            ];
        }
        foreach (shopHelper::getStocks() as $stock_id => $stock) {
            if (wa_is_int($stock_id)) {
                $stocks_options[] = ['title' => $stock['name'], 'value' => $stock['id']];
            }
        }
        foreach (shopOzonsellerPlugin::getAdvancedParams() as $param) {
            $params_options[] = ['value' => $param, 'title' => $param];
        }
        foreach (shopOzonsellerPlugin::getSiteBlocks() as $block) {
            $siteBlocks_options[] = ['value' => $block, 'title' => $block];
        }
        foreach ((new shopOzonsellerPluginHelper())->getFeaturesType(0, false) as $feature) {
            $features_options[] = ['value' => $feature['id'], 'title' => $feature['name'], 'type' => $feature['type']];
        }
        if (shopOzonsellerPluginHelper::checkInstallPlugin('price', '4.2.3')) {
            $prices = (new shopPricePluginModel())->getAll();
            foreach ($prices as $price) {
                $option = ['value' => $price['id'], 'title' => $price['name']];
                if (ifset($v['group'])) {
                    $option['group'] = $v['group'];
                }
                $plugin_price_options[] = $option;
            }
        }
        if (shopOzonsellerPluginHelper::checkInstallPlugin('scanbarcode')) {
            $option = ['value' => 'plugin_scanbarcode', 'title' => shopOzonsellerPluginTextHelper::TEXT_PLUGIN_SCANBARCODE];
            if (ifset($v['group'])) {
                $option['group'] = $v['group'];
            }
            $plugin_scanbarcode_options[] = $option;
        }
        if (shopOzonsellerPluginHelper::checkInstallPlugin('pricetype')) {
            $pricetypes = wa('shop')->getPlugin('pricetype')->getPricetypeTypes();
            foreach ($pricetypes as $price) {
                $option = ['value' => $price['id'], 'title' => $price['name']];
                if (ifset($v['group'])) {
                    $option['group'] = $v['group'];
                }
                $plugin_pricetype_options[] = $option;
            }
        }

        return [
            'product_image' => [
                ['title' => shopOzonsellerPluginTextHelper::TEXT_PHOTO_MAIN, 'value' => 'main'],
                ['title' => shopOzonsellerPluginTextHelper::TEXT_PHOTO_ALL, 'value' => 'all']
            ],
            'sku_image' => [
                ['title' => shopOzonsellerPluginTextHelper::TEXT_SKIP_PUBLIC_SKU, 'value' => '0'],
                ['title' => shopOzonsellerPluginTextHelper::TEXT_PHOTO_SKU_MAIN, 'value' => 'main'],
                ['title' => shopOzonsellerPluginTextHelper::TEXT_PHOTO_SKU_ALL, 'value' => 'all']
            ],
            'sets' => $sets_options,
            'features' => shopOzonsellerPluginHelper::sortArray($features_options, 'title'),
            'stocks' => $stocks_options,
            'params' => $params_options,
            'blocks' => $siteBlocks_options,
            'plugin_price' => $plugin_price_options,
            'plugin_scanbarcode' => $plugin_scanbarcode_options,
            'plugin_pricetype' => $plugin_pricetype_options,
            'image_og' => false,
            'sku_image_overall' => false
        ];
    }

    private function getAllOzonStocks()
    {
        $ozonStocks = [];
        foreach ((new shopOzonsellerPluginAccountModel())->getAll('id') as $account_id => $data) {
            try {
                $ozonStocks[$account_id] = shopOzonsellerPlugin::getOzonStocks($account_id);
            } catch (Exception $e) {
                $ozonStocks[$account_id] = [];
            }
        }
        return $ozonStocks;
    }

    public function preExecute()
    {
        parent::preExecute();
        $this->view = wa()->getView();
    }

    public function postExecute()
    {
        try {
            foreach ($this->getFilenamesByUi($this->type) as $key => $file) {
                $this->response[$key] = $this->view->fetch($this->path . $file);
            }
        } catch (SmartyException|waException $e) {
            $this->setError($e->getMessage());
        }
        parent::postExecute();
    }
}