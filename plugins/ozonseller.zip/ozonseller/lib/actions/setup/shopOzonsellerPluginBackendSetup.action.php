<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */

class shopOzonsellerPluginBackendSetupAction extends waViewAction
{
    public function execute()
    {
        $plugin = wa()->getPlugin('ozonseller');
        $newUi = wa()->whichUI() !== '1.3';
        $accountId = null;
        if ($accounts = (new shopOzonsellerPluginAccountModel())->getAll()) {
            $accounts = shopOzonsellerPluginHelper::preIntData($accounts);
            $accountId = $accounts[0]['id'];
        }
        $actionButton = shopOzonsellerPluginHelper::getVueComponent('actionButton');
        $gradusnik = shopOzonsellerPluginHelper::getVueComponent('gradusnik');
        $matchFeature = shopOzonsellerPluginHelper::getVueComponent('matchFeature');

        $this->setTemplate(wa()->getAppPath('plugins/ozonseller/templates/actions/backend/setup/setup.html'));
        $this->view->assign([
            'accounts' => json_encode($accounts),
            'accountId' => json_encode($accountId),
            'newUi' => json_encode($newUi),
            'actionButton' => json_encode($actionButton, 256),
            'gradusnik' => json_encode($gradusnik, 256),
            'matchFeature' => json_encode($matchFeature, 256),
            'backUrl' => json_encode(wa()->getAppUrl('shop')),
            'version' => $plugin->getVersion(),
            'is_debug' => shopOzonsellerPluginHelper::isDebug()
        ]);
    }
}