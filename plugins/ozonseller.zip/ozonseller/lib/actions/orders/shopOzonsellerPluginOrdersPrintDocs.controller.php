<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginOrdersPrintDocsController extends shopOzonsellerPluginPrintController
{
    public function execute()
    {
        $data = waRequest::get();
        $errors = [];
        foreach (['task_id', 'type'] as $field) {
            if (!isset($data[$field])) {
                $errors[] = sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, $field);
            }
        }
        if ($errors) {
            echo json_encode(['errors' => $errors]);
            return;
        }
        $this->file_name = $data['task_id'] . '_' . $data['type'] . '.pdf';
        $this->file_path = wa()->getTempPath('plugins/ozonseller/docs/' . $this->file_name);
        if (!file_exists($this->file_path)) {
            try {
                $socket = new shopOzonsellerPluginOzonApi();
                $result = $socket->printDocs($data['type'], (int)$data['task_id']);
                waFiles::write($this->file_path, $result);
            } catch (Exception $e) {
                $errors[] = $e->getMessage();
                echo json_encode(['errors' => $errors]);
                return;
            }
        }
        $this->display();
    }
}