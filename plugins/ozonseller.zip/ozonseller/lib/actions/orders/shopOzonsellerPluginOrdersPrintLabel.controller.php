<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginOrdersPrintLabelController extends shopOzonsellerPluginPrintController
{
    protected $account_id = null;
    protected $posting_number = null;
    protected $file_name = null;

    public function preExecute()
    {
        $this->account_id = waRequest::get('account_id');
        $this->posting_number = waRequest::get('posting_number');
        $this->file_name = waRequest::get('f');
    }

    public function execute()
    {
        if (!$this->account_id) {
            echo json_encode(['errors' => sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'account_id')]);
            return;
        }
        if (!$this->posting_number && !$this->file_name) {
            echo json_encode(['errors' => shopOzonsellerPluginTextHelper::ERROR_EMPTY_POSTING_NUMBER]);
            return;
        }
        if (!$this->file_name) {
            $this->file_name = 'posting_' . $this->posting_number . '.pdf';
        }
        $this->file_path = wa()->getTempPath('plugins/ozonseller/docs/' . $this->file_name);
        if (!file_exists($this->file_path)) {
            try {
                $socket = new shopOzonsellerPluginOzonApi($this->account_id);
                $result = $socket->printLabels($this->posting_number);
                waFiles::write($this->file_path, $result);
            } catch (Exception $e) {
                $errors[] = $e->getMessage();
                echo json_encode(['errors' => $errors]);
                return;
            }
        }
        /*$params = [
            'posting_number' => $this->posting_number,
            'path' => $this->file_path,
            'file_name' => $this->file_name
        ];
        wa()->event('ozonseller.posting_label', $params);*/
        $this->display();
    }
}