<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginOrdersPrintLabelsController extends waJsonController
{
    public function execute()
    {
        if (!$task_id = waRequest::post('task_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, 'task_id'));
            return;
        }
        $query = <<<SQL
SELECT value from shop_order_params WHERE name="ozon_posting_number" AND order_id IN  
    (SELECT order_id from shop_order_params where name="ozon_doc_task_id" and value=$task_id)
SQL;
        if (!$posting_numbers = (new waModel())->query($query)->fetchAll(null, true)) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_POSTING_NUMBER);
            return;
        }
        try {
            $socket = new shopOzonsellerPluginOzonApi();
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $file_path = wa()->getTempPath('plugins/ozonseller/docs/');
        $files = [];
        foreach (array_chunk($posting_numbers, 20) as $part) {
            $file_name = 'task_' . $task_id . '_' . uniqid() . '.pdf';
            $file = $file_path . $file_name;
            try {
                $result = $socket->printLabels($part);
                waFiles::write($file, $result);
                $files[] = $file_name;
            } catch (Exception $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            }
        }
        $this->response = $files;
    }
}