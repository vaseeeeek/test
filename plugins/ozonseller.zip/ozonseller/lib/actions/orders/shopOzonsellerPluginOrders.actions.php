<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginOrdersActions extends shopOzonsellerPluginJsonActions
{

    public function countOrdersByParamsAction()
    {
        $data = waRequest::post();
        $this->response = [
            'today' => self::countOrdersByStatusDate(['awaiting_deliver'], ifset($data['states'], []), time()),
            'tomorrow' => self::countOrdersByStatusDate(['awaiting_deliver'], ifset($data['states'], []), time() + 86400)
        ];
    }

    public function getPostingInfoAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'posting_number']);
        if ($this->errors) return;
        $controller = new shopOzonsellerPluginOrders();
        $params = ['with' => ['product_exemplars' => true]];
        if (!$ozonOrder = $controller->getOrderInfoFromOzon($post['account_id'], $post['posting_number'], $params)) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_OZON_ORDER_EMPTY);
            return;
        }
        $ozonProducts = [];
        foreach ($ozonOrder['products'] as $product) {
            foreach ($ozonOrder['product_exemplars']['products'] as $item) {
                $product_exemplar = null;
                if ($item['sku'] == $product['sku'] && count(ifset($item['exemplars'], []))) {
                    $product['exemplar'] = $item['exemplars'][0];
                    unset($product['exemplar']['jw_uin']);
                    break;
                }
            }
            $ozonProducts[] = $product;
        }
        if (!$ozonProducts) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_OZON_ORDER_EMPTY);
            return;
        }
        $file = wa()->whichUI('shop') === '1.3' ? 'dialogSplitOrder.old.vue' : 'dialogSplitOrder.vue';
        $this->response = [
            'products' => $ozonProducts,
            'template' => wa()->getView()->fetch(wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/' . $file))
        ];
    }

    public function splitOrderAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'posting_number', 'items']);
        if ($this->errors) return;
        $query = <<<SQL
select value from shop_order_params where name="ozon_order_id" and order_id in 
(select order_id from shop_order_params where name="ozon_posting_number" and value="{$post['posting_number']}") limit 1
SQL;
        if (!$order_id = (int)(new shopOrderParamsModel())->query($query)->fetchField('value')) {
            $this->setError(_wp('Не удалось получить номер заказа Ozon'));
            return;
        }
        try {
            $ozonOrders = null;
            $socket = new shopOzonsellerPluginOzonApi($post['account_id']);
            if ($socket->splitPosting($post['posting_number'], shopOzonsellerPluginHelper::preIntData($post['items']))) {
                $ozonOrders = $socket->getOrderList('fbs', ['filter' => ['order_id' => $order_id]]);
            }
        } catch (waException $e) {
            $this->setError($e->getMessage());
            return;
        }
        if ($ozonOrders) {
            try {
                (new shopOzonsellerPluginOrders($post['account_id']))->processingOrders('fbs', $ozonOrders);
            } catch (waException $e) {
                $this->setError($e->getMessage());
            }
        }
    }

    public function generateDocsAction()
    {
        if (!$method_id = waRequest::post('delivery_method_id')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'delivery_method_id'));
            return;
        }
        if (!$cutoff = waRequest::post('cutoff')) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'cutoff'));
            return;
        }
        $params = [
            'ozon_order_status' => 'awaiting_deliver',
            'ozon_delivery_id' => $method_id,
        ];
        $dates = ['ozon_shipment_date' => $this->getCurrentMethodShippingDate($cutoff)];
        $model_order = new shopOzonsellerPluginOrderModel();
        /*        if (!$containers_count = $model_order->countOrdersByOzonParams($params, $dates)) {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_SHIPMENT_LIST);
                    return;
                }*/
        try {
            $socket = new shopOzonsellerPluginOzonApi();
            $task_id = $socket->generateDocs((int)$method_id/*, (int)$containers_count*/);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $plugin = wa()->getPlugin('ozonseller');
        $settings = $plugin->getSettings();
        $settings['last_docs'][$method_id] = ['task_id' => $task_id, 'time' => strtotime($dates['ozon_shipment_date'])];
        $plugin->saveSettings($settings);
        $order_ids = $model_order->getOrderIdsByOzonParams($params, $dates);
        (new shopOrderParamsModel())->updateByField(['order_id' => $order_ids, 'name' => 'ozon_doc_task_id'], ['value' => $task_id]);
        $select = $this->generateDocSelect();
        $view = wa()->getView();
        $view->assign(compact('select'));
        $this->response = $view->fetch(wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/include.docActions.html'));
    }

    public function collectOrderAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'posting_number']);
        if ($this->errors) return;
        try {
            (new shopOzonsellerPluginOrders())->collectOrder($post['account_id'], $post['posting_number']);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
        }
    }

    public function cancelPostingAction()
    {
        $post = waRequest::post();
        $fields = ['posting_id', 'reason_id', 'account_id'];
        if (ifset($post['reason_id']) == 402) {
            $fields[] = 'message';
        }
        $this->checkRequiredFields($post, $fields);
        if ($this->errors) return;
        try {
            $socket = new shopOzonsellerPluginOzonApi($post['account_id']);
            $result = $socket->cancelPosting($post['posting_number'], $post['reason_id'], ifset($post['message']));
        } catch (Exception $e) {
            $this->setError($e->getMessage());
        }
    }

    public function getDialogDocsAction()
    {
        $current_actions = $this->getCurrentTemplateDocActions();
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/ozonDocs.html');
        $view->assign(compact('current_actions'));
        $this->response = $view->fetch($template);
    }

    public function getDialogTrackNumberAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'posting_number', 'order_id']);
        if ($this->errors) return;
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/dialogTrackNumber.html');
        $view->assign([
            'account_id' => $post['account_id'],
            'posting_number' => $post['posting_number'],
            'order_id' => $post['order_id']
        ]);
        $this->response = $view->fetch($template);
    }

    public function setTrackNumberAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'posting_number', 'track', 'order_id']);
        if ($this->errors) return;
        try {
            $socket = new shopOzonsellerPluginOzonApi($post['account_id']);
            $result = $socket->setTrackNumber($post['posting_number'], $post['track']);
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $model_order_params = new shopOrderParamsModel();
        $params = $model_order_params->get($post['order_id']);
        if (!isset($params['ozon_tracking_number']) || !$params['ozon_tracking_number']) {
            $params['ozon_tracking_number'] = $post['track'];
        }
        if (!isset($params['tracking_number']) || !$params['tracking_number']) {
            $params['tracking_number'] = $post['track'];
        }
        $model_order_params->set($post['order_id'], $params);
    }

    public function getDialogCancelReasonsAction()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['account_id', 'posting_number']);
        if ($this->errors) return;
        try {
            $reasons = (new shopOzonsellerPluginOzonApi($post['account_id']))->getCancelReasons();
        } catch (Exception $e) {
            $this->setError($e->getMessage());
            return;
        }
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/dialogCancelReason.html');
        $view->assign([
            'reasons' => $reasons,
            'account_id' => $post['account_id'],
            'posting_number' => $post['posting_number']
        ]);
        $this->response = $view->fetch($template);
    }

    protected function getCurrentTemplateDocActions()
    {
        $select = $this->generateDocSelect();
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/dialogs/include.docActions.html');
        $view->assign(compact('select'));
        return $view->fetch($template);
    }

    private function generateDocSelect()
    {
        $stocks = shopOzonsellerPluginOrders::getOzonStocks();
        $last_docs = wa()->getPlugin('ozonseller')->getSettings('last_docs');
        $select = [];
        $model_orders = new shopOzonsellerPluginOrderModel();
        foreach ($stocks as $stock) {
            if ($stock['is_rfbs']) continue;
            $active_stock = false;
            foreach ($stock['methods'] as $method) {
                if ($method['status'] != 'ACTIVE') continue;
                $active_stock = true;
                $params = [
                    'ozon_order_status' => 'awaiting_deliver',
                    'ozon_delivery_id' => $method['id'],
                ];
                $dates = ['ozon_shipment_date' => $this->getCurrentMethodShippingDate($method['cutoff'])];
                $orders_count = $model_orders->countOrdersByOzonParams($params, $dates);
                $params['ozon_order_status'] = 'awaiting_packaging';
                $orders_wait_count = $model_orders->countOrdersByOzonParams($params, $dates);
                $disabled =
                    (time() < ifempty($last_docs[$method['id']]['time'], 0)) ||
                    !$orders_count ||
                    (strtotime(date('Y-m-d')) < strtotime(date('Y-m-d', strtotime($dates['ozon_shipment_date']))));
                $doc_task = 0;
                $setting = ifempty($last_docs[$method['id']], ['task_id' => 0, 'time' => 0]);
                if ($setting['task_id']) {
                    if (strtotime(date('Y-m-d', $setting['time'])) == strtotime(date('Y-m-d'))) {
                        $doc_task = $last_docs[$method['id']]['task_id'];
                    }
                }

                $select[$stock['name']][$method['id']] = [
                    'id' => $method['id'],
                    'warehouse_id' => $method['warehouse_id'],
                    'name' => $method['name'],
                    'cutoff' => $method['cutoff'],
                    'disabled' => $disabled,
                    'doc_task' => $doc_task,
                    'date' => $dates['ozon_shipment_date'],
                    'orders' => $orders_count,
                    'orders_wait' => $orders_wait_count,
                    'task_order' => 0,
                ];
            }
            if (!$active_stock) {
                unset($select[$stock['name']]);
            }
        }
        return $select;
    }

    public function updateProductsMd5Action()
    {
        $post = waRequest::post();
        $this->checkRequiredFields($post, ['order_id', 'hash']);
        if ($this->errors) return;
        $value = json_encode(['hash' => $post['hash'], 'changed' => false]);
        (new shopOrderParamsModel())->insert(['order_id' => $post['order_id'], 'name' => 'ozon_products_md5', 'value' => $value], 1);
    }

    protected function getCurrentMethodShippingDate($cutoff)
    {
        $date = date('Y-m-d ') . $cutoff . ':00';
        $time = strtotime($date);
        if ($time > time()) {
            return $date;
        } else {
            return date('Y-m-d ', time() + 86400) . $cutoff . ':00';
        }
    }

    public static function countOrdersByStatusDate(array $ozon_statuses, $shop_statuses = [], $date = null)
    {
        if (!$ozon_statuses) $ozon_statuses = ['awaiting_deliver'];
        $query = <<<SQL
SELECT count(*) total
FROM shop_order so
        JOIN shop_order_params sop1 ON sop1.order_id = so.id
        JOIN shop_order_params sop2 ON sop2.order_id = so.id
        JOIN shop_order_params sop3 ON sop3.order_id = so.id
WHERE 
      sop1.name = 'ozon_order_status' AND sop1.value IN(s:ozon_statuses)AND 
      sop2.name='ozon_schema' AND sop2.value='fbs'
SQL;
        if ($date) {
            if (wa_is_int($date)) {
                $date = date('Y-m-d 00:00:00', $date);
            }
            $date_to = date('Y-m-d 00:00:00', strtotime($date) + 86400);
            $query .= <<<SQL
AND sop3.name='ozon_shipment_date' AND sop3.value>="$date" 
AND sop3.name='ozon_shipment_date' AND sop3.value<"$date_to"
SQL;
        }
        if ($shop_statuses) {
            $query .= '  AND so.state_id IN(s:shop_statuses)';
        }
        return (new shopOrderModel())->query($query, ['ozon_statuses' => $ozon_statuses, 'shop_statuses' => $shop_statuses])->fetchField('total');
    }
}