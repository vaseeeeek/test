<?php

class shopOzonsellerPluginOzonApi
{

    const
        URL_ACT_CREATE = '/v2/posting/fbs/act/create',
        URL_ARCHIVE_PRODUCT = '/v1/product/archive',
        URL_CANCEL_REASONS_LIST = '/v2/posting/fbs/cancel-reason/list',
        URL_CANCEL_POSTING = '/v2/posting/fbs/cancel',
        URL_CATEGORY_TREE = '/v2/category/tree',
        URL_CATEGORY_ATTR = '/v3/category/attribute',
        URL_FEATURE_VALUES = '/v2/category/attribute/values',
        URL_IMAGES_UPDATE = '/v1/product/pictures/import',
        URL_LIMIT_IMPORT = '/v2/product/info/limit',
        URL_POSTING_INFO_FBS = '/v3/posting/fbs/get',
        URL_POSTING_INFO_FBO = '/v2/posting/fbo/get',
        URL_PRINT_ACT = '/v2/posting/fbs/act/get-pdf',
        URL_PRINT_CONTAINER_LABEL = '/v2/posting/fbs/act/get-container-labels',
        URL_PRINT_LABEL = '/v2/posting/fbs/package-label',
        URL_PRODUCT_IMPORT = '/v2/product/import',
        URL_PRODUCT_IMPORT_INFO = '/v1/product/import/info',
        URL_PRODUCT_INFO = '/v2/product/info',
        URL_PRODUCT_INFO_STOCKS = '/v1/product/info/stocks',
        URL_PRODUCT_INFO_PRICES = '/v1/product/info/prices',
        URL_PRODUCT_LIST = '/v2/product/list',
//        URL_PRODUCT_LIST = '/v1/product/list',
        URL_PRODUCT_INFO_LIST = '/v2/product/info/list',
        URL_PRODUCT_IMPORT_PRICES = '/v1/product/import/prices',
        URL_PRODUCT_IMPORT_STOCKS = '/v1/product/import/stocks',
        URL_PRODUCT_UPDATE = '/v1/product/update',
        URL_PRODUCT_ACTIVATE = '/v1/product/activate',
        URL_PRODUCT_DEACTIVATE = '/v1/product/deactivate',
        URL_PRODUCTS_PRICES = '/v1/products/prices',
        URL_PRODUCTS_STOCKS = '/v2/products/stocks',
        URL_PRODUCT_DELETE = '/v1/product/delete',
        URL_PROMOS_ADD = '/v1/actions/products/activate',
        URL_PROMOS_CANDIDATES = '/v1/actions/candidates',
        URL_PROMOS_DELETE = '/v1/actions/products/deactivate',
        URL_PROMOS_PRODUCTS = '/v1/actions/products',
        URL_PROMOS_LIST = '/v1/actions',
//        URL_ORDER_COLLECT = '/v2/posting/fbs/ship',
        URL_ORDER_COLLECT = '/v3/posting/fbs/ship',
        URL_ORDER_INFO_FBS = '/v2/posting/fbs/get',
        URL_ORDER_INFO_FBO = '/v2/posting/fbo/get',
        URL_ORDER_LIST_FBO = '/v2/posting/fbo/list',
        URL_ORDER_LIST_FBS = '/v3/posting/fbs/list',
        URL_ORDER_INFO = '/v1/order/',
        URL_ORDER_UNFULFILLED = '/v1/order/unfulfilled',
        URL_SET_TRACK_NUMBER = '/v2/fbs/posting/tracking-number/set',
        URL_SPLIT_ORDER = '/v3/posting/fbs/ship/package',
        URL_WAREHOUSE_LIST = '/v1/warehouse/list',
        URL_WAREHOUSE_METHODS = '/v1/delivery-method/list';

    private $settings;
    private $uri;

    private $time_qnt;

    public function __construct($account_id)
    {
        shopOzonsellerPluginHelper::validatePlugin($this, 'classes/shopOzonsellerPluginOzonApi.class.php');
        $settings = wa()->getPlugin('ozonseller')->getSettings(null, $account_id);
        if (!$settings['client_id'] || !wa_is_int($settings['client_id']) || !$settings['token']) {
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_EMPTY_API_SETTINGS);
        }
        // 836 - публичный client_id Ozon для отладки
        // token: 0296d4f2-70a1-4c09-b507-904fd05567b9
        $this->uri = $settings['client_id'] == '836' ? 'https://cb-api.ozonru.me' : 'https://api-seller.ozon.ru';
        $this->settings = $settings;
        $this->time_qnt = 0;
    }

    public function exportProduct($params)
    {
        return $this->_getOzonData(self::URL_PRODUCT_IMPORT, ['items' => [$params]], waNet::METHOD_POST);
    }

    public function checkLimits()
    {
        return $this->_getOzonData(self::URL_LIMIT_IMPORT, '');
    }

    public function checkTask($task_id)
    {
        $params = ['task_id' => $task_id];
        $result = $this->_getOzonData(self::URL_PRODUCT_IMPORT_INFO, $params);
        if (isset($result['items'])) {
            return $result['items'];
        } else {
            if (isset($result['error'])) {
                $message = $result['error']['message'];
                $code = $result['code'];
            } else {
                $message = $code = 'null';
                shopOzonsellerPluginHelper::setLog('', 'error', $result);
            }
            throw new waException($message . ': ' . $code);
        }
    }

    public function getCategoryTree($category_id = null)
    {
        $params = ['category_id' => $category_id, 'language' => 'RU'];
        return $this->_getOzonData(self::URL_CATEGORY_TREE, $params);
    }

    public function getCategoryFeatures($category_ids, $type_features = 'all')
    {
        $category_id = null;
        if ($type_features && !in_array($type_features, ['required', 'optional'])) {
            $type_features = 'all';
        }
        if (!is_array($category_ids)) {
            $category_id = $category_ids;
            $category_ids = [(int)$category_ids];
        }
        $params = [
            'attribute_type' => strtoupper($type_features),
            'category_id' => $category_ids,
        ];
        $result = $this->_getOzonData(self::URL_CATEGORY_ATTR, $params, waNet::METHOD_POST, false);
        if ($result && $category_id) {
            if (isset($result['code']) && isset($result['message'])) {
                throw new waException($result['message'], $result['code']);
            } else {
                $k = array_search($category_id, array_column($result, 'category_id'));
                if ($k === false) {
                    $result = [];
                } else {
                    $result = $result[$k]['attributes'];
                }
            }
        }
        if ($result === null) $result = [];
        return $result;
    }

    public function getFeatureValues($category_id, $feature_id, $last_value_id, $limit = 5000)
    {
        $params = [
            'category_id' => $category_id,
            'attribute_id' => $feature_id,
            'last_value_id' => $last_value_id,
            'limit' => $limit
        ];
        $response = $this->_getOzonData(self::URL_FEATURE_VALUES, $params);
        return $response;
    }

    public function getFullOzonProductsList($limit = 1, $filter = []) {
        $flag = true;
        $counter = 0;
        $items = [];
        $last_id = '';
        while ($flag) {
            $data = $this->getOzonProductsList($last_id, 1000, $filter);
            if (!isset($data['items'])) {
                shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::ERROR_ESTABLISH_CONNECTION_SERVER);
                $flag = false;
            }
            $items = array_merge($items, $data['items']);
            if ($data['total'] <= $counter) {
                $flag = false;
            } else {
                $last_id = $data['last_id'];
            }
            $counter += count($data['items']);
        }
        return $items;
    }
    public function getOzonProductsList($last_id = '', $limit = 1, $filter = [])
    {
        $params = [
            'last_id' => $last_id,
            'limit' => $limit,
        ];
        if ($filter) {
            $params['filter'] = $filter;
        }
        return $this->_getOzonData(self::URL_PRODUCT_LIST, $params);
    }

    public function getOzonProductInfo($offer_id = null, $product_id = null, $sku = null)
    {
        $params = [];
        foreach (['offer_id', 'product_id', 'sku'] as $var) {
            if ($$var) {
                $params[$var] = $$var;
            }
        }
        if (!$params) {
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_EMPTY_PARAMS);
        }
        return $this->_getOzonData(self::URL_PRODUCT_INFO, $params);
    }

    public function getOzonProductInfoList($offer_id = [], $product_id = [], $sku = [])
    {
        $params = [];
        foreach (['offer_id', 'product_id', 'sku'] as $var) {
            if ($$var) {
                $params[$var] = $$var;
            }
        }
        if (!$params) {
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_EMPTY_PARAMS);
        }
        return $this->_getOzonData(self::URL_PRODUCT_INFO_LIST, $params);
    }

    public function updatePriceLists($items)
    {
        return $this->_getOzonData(self::URL_PRODUCTS_PRICES, ['prices' => $items]);
    }

    public function updateProductsStocks($items)
    {
        if ($this->time_qnt && time() - $this->time_qnt < 1) {
            sleep(1);
        }
        $data = $this->_getOzonData(self::URL_PRODUCTS_STOCKS, ['stocks' => $items]);
        $this->time_qnt = time();
        return $data;
    }

    public function getOzonStocks()
    {
        return $this->_getOzonData(self::URL_WAREHOUSE_LIST, ['language' => 'RU']);
    }

    public function cancelPosting($posing_number, $reason_id, $message = null)
    {
        $params = [
            'cancel_reason_id' => $reason_id,
            'posting_number' => $posing_number
        ];
        if ($message) {
            $params['cancel_reason_message'] = $message;
        }
        return $this->_getOzonData(self::URL_CANCEL_POSTING, $params);
    }

    public function getCancelReasons()
    {
        $cache = new waSerializeCache('ozonseller_cancel_reasons', 89400 * 7);
        if ($cache->isCached()) {
            $reasons = $cache->get();
        } else {
            $response = $this->_getOzonData(self::URL_CANCEL_REASONS_LIST, '');
            $reasons = $response;
            $cache->set($reasons);
        }
        return $reasons;
    }

    public function setTrackNumber($posting_number, $track_number)
    {
        $params = [
            'tracking_numbers' =>
                [
                    'posting_number' => $posting_number,
                    'tracking_number' => $track_number
                ]
        ];
        return $this->_getOzonData(self::URL_SET_TRACK_NUMBER, $params);
    }

    public function getOzonDeliveryMethods($filter = [])
    {
        $methods = [];
        $params = [
            'limit' => 50,
            'offset' => 0,
        ];
        if ($filter) $params['filter'] = $filter;
        while (1) {
            $data = $this->_getOzonData(self::URL_WAREHOUSE_METHODS, $params);
            if (!isset($data['result'])) break;
            foreach ($data['result'] as $info) {
                $methods[$info['warehouse_id']][$info['id']] = $info;
            }
            if (!ifset($data['has_next'], false)) break;
            $params['offset'] += $params['limit'];
        }
        return $methods;
    }

    public function getOrderList($type, $params = [], $part_only = false)
    {
        if (!in_array($type, ['fbo', 'fbs'])) {
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'type'));
        }
        $url = constant('self::URL_ORDER_LIST_' . strtoupper($type));
        $order_params = [
            'dir' => 'asc',
            'limit' => 50,
            'offset' => 0,
            'with' => [
                'analytics_data' => true,
                'financial_data' => true
            ]
        ];
        if ($type == 'fbs') {
            $order_params['with']['barcodes'] = true;
        }
        $order_params = array_merge($order_params, $params);
        $orders = [];
        while (1) {
            if (!$data = $this->_getOzonData($url, $order_params)) {
                break;
            }
            if ($type == 'fbs') {
                if (!ifset($data['postings'])) {
                    break;
                }
                $data = $data['postings'];
            }
            $orders = array_merge($orders, $data);
            $order_params['offset'] += count($data);
        }
        return $orders;
    }

    public function getPostingInfo($type, $posting_number, $params = [])
    {
        switch ($type) {
            case 'fbo':
                $url = self::URL_POSTING_INFO_FBO;
                break;
            case'fbs':
            case 'rfbs':
                $url = self::URL_POSTING_INFO_FBS;
                break;
            default:
                throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'type'));
        }
        $posting_params = array_merge($params, ['posting_number' => $posting_number]);
        return $this->_getOzonData($url, $posting_params);
    }

    public function collectPosting($posting_number, $params, $additional_data = false)
    {
        $params['posting_number'] = $posting_number;
//        $params['with'] =  $additional_data;
        return $this->_getOzonData(self::URL_ORDER_COLLECT, $params);
    }

    public function splitPosting($posting_number, $products)
    {
        foreach ($products as &$product) {
            foreach (['is_gtd_absent', 'is_rnpt_absent'] as $field) {
                $value = $product['exemplar_info'][$field];
                if (!is_bool($value)) {
                    if (wa_is_int($value)) $product['exemplar_info'][$field] = ((int)$value === 1);
                    elseif (is_string($value)) $product['exemplar_info'][$field] = $value === 'true';
                }
            }
        }
        unset($product);
        return $this->_getOzonData(self::URL_SPLIT_ORDER, ['products' => $products]);
    }

    public function generateDocs(int $delivery_method_id, int $containers_count = null)
    {
        $result = $this->_getOzonData(self::URL_ACT_CREATE, ['delivery_method_id' => $delivery_method_id /*, 'containers_count' => $containers_count*/]);
        if (isset($result['id'])) {
            return $result['id'];
        } elseif (isset($result['error'])) {
            throw new waException($result['error']['message'] . ': ' . ifset($result['code']));
        }
    }

    public function printDocs($type, $task_id)
    {
        $url = constant('shopOzonsellerPluginOzonApi::URL_PRINT_' . strtoupper($type));
        $socket = new waNet(
            ['request_format' => waNet::FORMAT_JSON, 'format' => waNet::FORMAT_RAW, 'timeout' => 30],
            ['Client-Id' => $this->settings['client_id'], 'Api-Key' => $this->settings['token']]
        );
        switch ($type) {
            case 'label':
                $params = ['posting_number' => $task_id];
                break;
            case 'act':
                $params = ['id' => $task_id];
                break;
        }
        usleep(150000);
        $result = $socket->query($this->uri . $url, $params, waNet::METHOD_POST);
        return $result;
    }

    public function printLabels($posting_numbers)
    {
        if (!is_array($posting_numbers)) {
            $posting_numbers = [$posting_numbers];
        }
        $socket = new waNet(
            ['request_format' => waNet::FORMAT_JSON, 'format' => waNet::FORMAT_RAW, 'timeout' => 30],
            ['Client-Id' => $this->settings['client_id'], 'Api-Key' => $this->settings['token']]
        );
        usleep(150000);
        $result = $socket->query($this->uri . self::URL_PRINT_LABEL, ['posting_number' => $posting_numbers], waNet::METHOD_POST);
        return $result;
    }

    public function archiveProducts($ozon_product_ids)
    {
        if (!is_array($ozon_product_ids)) {
            $ozon_product_ids = [$ozon_product_ids];
        }
        return $this->_getOzonData(self::URL_ARCHIVE_PRODUCT, ['product_id' => $ozon_product_ids]);
    }

    public function setOzonOrderStatus($posting_number, $status)
    {

    }

    public function getPromos()
    {
        $response = $this->_getOzonData(self::URL_PROMOS_LIST, [], waNet::METHOD_GET);
        return $response;
    }

    public function getPromoProducts($type, $promo_id, $offset = 0, $limit = 500)
    {
        switch ($type) {
            case 'candidates':
                $url = self::URL_PROMOS_CANDIDATES;
                break;
            case 'products':
                $url = self::URL_PROMOS_PRODUCTS;
                break;
            default:
                throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'type'));
        }
        $params = [
            'action_id' => $promo_id,
            'limit' => $limit,
            'offset' => $offset
        ];
        $response = $this->_getOzonData($url, $params);
        if (!isset($response['total'])) {
            shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::ERROR_UNEXPECTED_RESPONSE, 'error', $response);
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_UNEXPECTED_RESPONSE);
        }
        return $response;
    }

    public function setPromoProducts($promo_id, $mode, $products)
    {
        switch ($mode) {
            case 'add':
                $url = self::URL_PROMOS_ADD;
                $params = [
                    'action_id' => $promo_id,
                    'products' => $products
                ];
                break;
            case 'delete':
                $url = self::URL_PROMOS_DELETE;
                $params = [
                    'action_id' => $promo_id,
                    'product_ids' => $products
                ];
                break;
            default:
                throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'mode'));
        }
        return $this->_getOzonData($url, $params);
    }

    public function updateImages($ozon_product_id, $images)
    {
        $params = [
            'color_image' => '',
            'images' => $images,
            'images360' => [],
            'product_id' => $ozon_product_id
        ];
        $result = $this->_getOzonData(self::URL_IMAGES_UPDATE, $params);
        return isset($result['pictures']);
    }

    private function _getOzonData($url, $params = [], $method = waNet::METHOD_POST, $catch_nulled = true)
    {
        $socket = new waNet(
            ['request_format' => waNet::FORMAT_JSON, 'format' => waNet::FORMAT_JSON, 'timeout' => 30, 'verify' => $this->settings['curl_verify'] == 1],
            ['Client-Id' => $this->settings['client_id'], 'Api-Key' => $this->settings['token']]
        );
        if ($method == waNet::METHOD_GET) {
            $params['language'] = 'RU';
        }
        if ($this->settings['json_query']) {
            $filename = shopOzonsellerPluginTextHelper::JSON_DIR . trim(implode('.', explode('/', $url)) . '.json', '.');
            waFiles::write($filename, json_encode($params));
        }
        usleep(500000);
        try {
            $result = $socket->query($this->uri . $url, $params, $method);
        } catch (waException $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error', null, $e);
            if ($catch_nulled) {
                $result = null;
            } else {
                $result = $socket->getResponse();
            }
        }
        if ($this->settings['debug'] == 2) {
            $data = [
                'request' => [
                    'url' => $url,
                    'params' => $params,
                ],
                'response' => $result
            ];
            shopOzonsellerPluginHelper::setLog($url, 'debug', $data);
        } elseif ($this->settings['debug'] == 1) {
            $data = [
                'request' => [
                    'url' => $url,
                ],
                'response' => $result
            ];
            shopOzonsellerPluginHelper::setLog($url, 'debug', $data);
        }
        if (isset($result['result']) && !isset($result['has_next'])) {
            return $result['result'];
        } elseif (isset($result['result']) && isset($result['has_next'])) {
            return $result;
        } else {
            if ($result !== null) {
                shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::ERROR_UNEXPECTED_RESPONSE, 'error', ['url' => $url, 'params' => $params, 'response' => $result]);
            }
            return $result;
        }
    }
}