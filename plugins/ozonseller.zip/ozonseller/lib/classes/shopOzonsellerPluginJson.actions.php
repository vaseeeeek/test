<?php

class shopOzonsellerPluginJsonActions extends waJsonActions
{
    /**
     * @param array $data
     * @param array $fields
     */
    public function checkRequiredFields($data, $fields)
    {
        if (!is_array($fields)) {
            $fields = array($fields);
        }
        foreach ($fields as $f) {
            if (!isset($data[$f]) || !$data[$f]) {
                $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_REQUIRED_PARAMETER, $f));
            }
        }
    }

    /**
     * @param string $message
     * @param array $data
     */
    public function setError($message, $data = array())
    {
        if (wa()->getEnv() == 'cli') {
            throw new waException($message);
        }
        if ($data) {
            $this->errors[] = array($message, $data);
        } else {
            $this->errors[] = $message;
        }
    }

    public function postExecute()
    {
        parent::postExecute();
        if ($this->response) {
            $this->response = shopOzonsellerPluginHelper::preIntData($this->response);
        }
        if (isset($this->response['script'])) {
            $this->response['script'] = '<script>$(function () {' . $this->response['script'] . '});</script>';
        }
    }

    protected function execute($action)
    {
        try {
            parent::execute($action);
        } catch (waException $e) {
            $this->setError($e->getMessage());
        }
    }
}