<?php

class shopOzonsellerPluginPreparator
{
    const
        MODE_PUBLIC = 'public',
        MODE_UPDATE = 'update',
        MODE_CHECK = 'check',
        UNIT_DIMENSIONS = 'mm',
        UNIT_WEIGHT = 'g';
    const
        OZON_IMAGE_COUNT = 15,
        OZON_IMAGE_EXTENSIONS = ['jpe', 'jpeg', 'jpg', 'png'],
        OZON_IMAGE_MAX_SIZE = 10000,
        OZON_IMAGE_MIN_SIZE = 200;

    private $account_id;
    private $mode;
    private $ozon;
    private $result;
    protected $all_publics;
    protected $catalogizator;
    protected $default_markups;
    protected $dim_fields = ['length', 'width', 'height'];
    protected $dim_feature;
    protected $helper;
    protected $features;
    protected $matches;
    protected $model_fail_log;
    protected $model_ozon_category;
    protected $model_ozon_feature_values;
    protected $model_ozon_product;
    protected $model_product_og;
    protected $ozon_category_settings = [];
    protected $root_url;
    protected $shop_feature_values = [];
    protected $summary_warehouses;
    protected $settings;
    protected $taxes;
    protected $types;


    public function __construct($account_id, $mode = self::MODE_UPDATE)
    {
        shopOzonsellerPluginHelper::validatePlugin($this, 'classes/shopOzonsellerPluginPreparator.class.php');
        if (in_array($mode, [self::MODE_CHECK, self::MODE_PUBLIC, self::MODE_UPDATE])) {
            $this->mode = $mode;
        } else {
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_UNEXPECTED_MODE);
        }
        $model_feature = new shopFeatureModel();
        $this->ozon = new shopOzonsellerPluginOzonApi($account_id);
        $this->catalogizator = new shopOzonsellerPluginCategoryPreparator();
        $this->helper = new shopOzonsellerPluginHelper();
        $this->model_fail_log = new shopOzonsellerPluginFailLogModel();
        $this->model_ozon_category = new shopOzonsellerPluginOzonCategoryModel();
        $this->model_ozon_feature_values = new shopOzonsellerPluginOzonFeatureValuesModel();
        $this->model_ozon_product = new shopOzonsellerPluginProductModel();
        $this->model_product_og = new shopProductOgModel();
        $this->features = $model_feature->getAll('id');
        $this->types = (new shopTypeModel())->getAll('id');
        $this->matches = (new shopOzonsellerPluginFeatureValuesMatchesModel())->getAllMatches();
        $this->settings = wa()->getPlugin('ozonseller')->getSettings(null, $account_id);
        $this->all_publics = $this->model_ozon_product->getAllPublics($account_id);
        $this->taxes = $this->helper->getTaxesByRus();
        $this->ozon_category_settings = $this->model_ozon_category->getFullFilledCategories($account_id);
        $this->default_markups = (new shopOzonsellerPluginCategoryMarkupsModel())->getByOzonId($account_id, 'default', 'DESC');
        $this->account_id = $account_id;

        if ($mode == self::MODE_PUBLIC && !$this->ozon_category_settings) {
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_NO_FILLED_CATEGORY);
        }

        if (!$this->settings['weight_code'] || !$model_feature->getByCode($this->settings['weight_code'])) {
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::FAIL_REQUIRED_FEATURE, shopOzonsellerPluginTextHelper::TEXT_WEIGHT));
        }
        $dim_exception = sprintf(shopOzonsellerPluginTextHelper::FAIL_REQUIRED_FEATURE, shopOzonsellerPluginTextHelper::TEXT_DIMENSIONS);
        if ($this->settings['dimensions']['type'] == 'shop') {
            if ($dimensions = wa('shop')->getSetting('shipping_dimensions')) {
                $dimensions = preg_split('@\D+@', $dimensions);
                if (count($dimensions) == 1) {
                    if ($feature = $model_feature->getById($dimensions[0])) {
                        $this->dim_feature = [$feature['code']];
                    } else {
                        throw new waException($dim_exception);
                    }
                } elseif (count($dimensions) == 3) {
                    $dim_features = $model_feature->getByField('id', $dimensions, 'id');
                    if (count($dim_features) != 3) {
                        throw new waException($dim_exception);
                    }
                    foreach ($this->dim_fields as $key => $field) {
                        $this->dim_feature[$field] = $dim_features[$dimensions[$key]]['code'];
                    }
                } else {
                    throw new waException($dim_exception);
                }
            } else {
                throw new waException($dim_exception);
            }
        }
        foreach (wa()->getRouting()->getDomains() as $domain) {
            if ($this->root_url = trim(wa()->getRouting()->getUrlByRoute(['url' => ''], $domain), '/')) break;
        }
        $this->resetStatus();
    }

    public function validateProductData($product_id, $ozon_category_id)
    {
        $product = new shopProduct($product_id);
        if (!$product->getId()) {
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_PRODUCT_NOT_FOUND, $product_id));
        }
        $skus = $product->getSkus();

        if (!$this->settings['all_skus']) {
            $skus = [$product['sku_id'] => $skus[$product['sku_id']]];
        }
        foreach ($skus as $sku_id => $sku_data) {
            $this->resetStatus($product_id, $sku_id, $ozon_category_id);
            if (!$sku_data['available'] || !$this->checkExcludePublic($product, $sku_data)) {
                unset($skus[$sku_id]);
            }
        }
        if ($skus) {
            $result = true;
            foreach ($skus as $sku_id => $sku) {
                $this->resetStatus($product_id, $sku_id, $ozon_category_id);
                $data = $this->prepareProduct($product, $sku, $ozon_category_id);
                $this->prepareProductDescription($product, $sku);
                $this->model_fail_log->updateLog($this->account_id, $this->result);
            }
            $result = !$this->result['errors'];
        } else {
            $this->resetStatus($product_id, $product['sku_id'], $ozon_category_id);
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_NO_AVAILABLE_SKU, true);
            $this->model_fail_log->updateLog($this->account_id, $this->result);
            $result = false;
        }
        return $result;
    }

    public function getSourceData($product, $sku, $ozon_category_id)
    {
        $data = $this->prepareProduct($product, $sku, $ozon_category_id);
        if ($this->result['errors']) $data['errors'] = $this->result['errors'];
        return $data;
    }

    public function importProduct($product_id, $ozon_category_id, $skuId = null)
    {
        if ($this->mode != self::MODE_PUBLIC) {
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_UNEXPECTED_MODE);
        }
        if (!$product = $this->getProduct($product_id)) {
            $this->archivePublic($product_id);
            return $this->result;
        }
        $skus = (new shopProductSkusModel())->getByField(['product_id' => $product['id'], 'available' => '1'], 'id');
        if (!$this->settings['all_skus']) {
            if (isset($skus[$product['sku_id']])) {
                $skus = [$product['sku_id'] => $skus[$product['sku_id']]];
            } else {
                $skus = [];
            }
        }
        if (!$skus) {
            $this->resetStatus($product_id, $skuId ?: $product['sku_id'], $ozon_category_id);
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_NO_AVAILABLE_SKU, true);
            $this->model_fail_log->updateLog($this->account_id, $this->result);
            return $this->result;
        }
        $publics = $this->getPublicsByProductId($product_id);
        foreach ($skus as $sku_id => $sku) {
            if ($skuId && $skuId != $sku_id) continue;
            $this->resetStatus($product_id, $sku_id, $ozon_category_id);
            $this->createPublic($product, $sku, $ozon_category_id);
            unset($publics[$sku_id]);
            $this->model_fail_log->updateLog($this->account_id, $this->result);
        }
        //TODO Перепроверить и поправить
        /*        if (count($publics)) {
                    foreach ($publics as $public) {
                        $this->archivePublic($public['ozon_product_id']);
                    }
                }*/
        return $this->result;
    }

    private function createPublic($product, $sku, $ozon_category_id)
    {
        if (!$this->checkExcludePublic($product, $sku)) return;
        $this->checkPossibilityPublic($product, $ozon_category_id);
        if ($this->result['status'] != 'ok') {
            return false;
        }
        $data = $this->prepareProduct($product, $sku, $ozon_category_id);
        if ($this->result['status'] != 'ok') {
            return false;
        }
        try {
            $response = $this->ozon->exportProduct($data);
            if (isset($response['task_id'])) {
                $response = $response['task_id'];
                foreach (['price', 'old_price', 'premium_price'] as $field) {
                    unset($data[$field]);
                }
                $params = array(
                    'account_id' => $this->account_id,
                    'task_id' => $response,
                    'offer_id' => $data['offer_id'],
                    'ozon_category_id' => $ozon_category_id,
                    'product_id' => $product['id'],
                    'sku_id' => $sku['id'],
                    'edit_datetime' => $product['edit_datetime'] ? $product['edit_datetime'] : $product['create_datetime'],
                    'state' => 'moderating',
                    'fbs' => ifset($this->ozon_category_settings[$ozon_category_id]['type'][$product['type_id']][0]['value'], 1),
                    'checksum' => md5(serialize($data))
                );
                $this->model_ozon_product->insert($params, 1);
            } elseif (!$response) {
                $this->setError(shopOzonsellerPluginTextHelper::ERROR_PUBLIC_ADD, true);
            } else {
                shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::ERROR_PUBLIC_ADD, 'error', $response);
                $response = false;
            }
        } catch (Exception $e) {
            $this->result['errors'][] = $e->getMessage();
            $response = false;
        }
        return $response;
    }

    public function archivePublic($ozon_product_ids)
    {
        $result = $this->ozon->archiveProducts($ozon_product_ids);
    }

    public function getPricesBySku($sku)
    {
        $prices = [
            'price' => '0',
            'old_price' => '0',
            'premium_price' => '0',
            'min_price' => '0'
        ];
        foreach ($prices as $price_type => $value) {
            if ($price = $this->_getProductPrice($sku, $this->settings[$price_type])) {
                $params = (new shopProductParamsModel())->get($sku['product_id']);
                $prices[$price_type] = (string)$this->preparePrice($price, $sku['currency'], $sku['ozon_category_id'], $params, $price_type);
            }
        }
        foreach (['old_price'] as $type_price) {
            if ($prices[$type_price] <= $prices['price']) $prices[$type_price] = '0';
        }
        foreach (['premium_price'] as $type_price) {
            if ($prices[$type_price] >= $prices['price']) $prices[$type_price] = '0';
        }
        return $prices;
    }

    public function preparePromoData($ozon_product_ids, $promo)
    {
        $promo_data = [];
        if (!$skus = $this->model_ozon_product->getPromoData($ozon_product_ids)) {
            return $promo_data;
        }
        if ($promo['action_type'] == 'STOCK_DISCOUNT') {
            $stocks_data = $this->getQuantityByPublics($skus);
        }
        foreach ($skus as $sku) {
            if ($price = $this->_getProductPrice($sku, $promo['settings'])) {
                $price = $this->preparePrice($price, $sku['currency'], $sku['ozon_category_id'], [], 'price', $promo['settings']['markups'] == 1);
                if ($promo['settings']['diff']) {
                    switch ($promo['settings']['diff_type']) {
                        case 'piece':
                            $price += $promo['settings']['diff'];
                            break;
                        case '%':
                            $price = (int)$price + ($price * $promo['settings']['diff'] / 100);
                            break;
                    }
                }
                $item = [
                    'product_id' => (int)$sku['ozon_product_id'],
                    'action_price' => (int)$price
                ];
                if ($promo['action_type'] == 'STOCK_DISCOUNT') {
                    $count = $idx = 0;
                    /*$stocks = array_filter($stocks_data, function ($r) use ($sku) {
                        if ($r['product_id'] == $sku['ozon_product_id']) {
                            return true;
                        }
                    });
                    foreach ($stocks as $stock) {
                        $count += $stock['stock'];
                    }*/
                    while ($idx !== false) {
                        $idx = array_search($sku['ozon_product_id'], array_column($stocks_data, 'product_id'));
                        if ($idx !== false) {
                            $count += $stocks_data[$idx]['stock'];
                            unset($stocks_data[$idx]);
                            $stocks_data = array_values($stocks_data);
                        }
                    }
                    switch ($promo['settings']['count_type']) {
                        case 'piece':
                            if ($count > $promo['settings']['count']) {
                                $count = $promo['settings']['count'];
                            }
                            break;
                        case '%':
                            $new_count = $count * $promo['settings']['count'] / 100;
                            if ($count < $new_count) {
                                $count = $new_count;
                            }
                            break;
                        default:
                            $count = 0;
                    }
                    $item['stock'] = (int)$count;
                }
            } else {
                continue;
            }
            $promo_data[] = $item;
        }
        return $promo_data;
    }

    public function getQuantityByPublics($publics)
    {
        $items = $summary_warehouses = $virtual_stocks = [];
        $sku_ids = array_column($publics, 'sku_id');
        $skus = (new shopProductSkusModel())->getById($sku_ids);
        $shop_stocks = shopHelper::getStocks();
        if (!isset($this->summary_warehouses)) {
            if (count($this->settings['stock_ids']) > 1 && $this->settings['calculation']) {
                foreach ($this->settings['stock_ids'] as $wid => $sstock) {
                    if (isset($shop_stocks[$sstock]['substocks'])) {
                        foreach ($shop_stocks[$sstock]['substocks'] as $vstock_id) {
                            $summary_warehouses[$vstock_id]['total'] = ifset($summary_warehouses[$vstock_id]['total'], 0) + 1;
                        }
                    } else {
                        $summary_warehouses[$sstock]['total'] = ifset($summary_warehouses[$sstock]['total'], 0) + 1;
                    }
                }
                foreach ($summary_warehouses as $stock_id => $data) {
                    if ($data['total'] < 2) unset($summary_warehouses[$stock_id]);
                }
            }
            $this->summary_warehouses = $summary_warehouses;
        }
        unset($wid, $count, $stock_id);
        // Это нелепое условие закрывает проблему когда есть склады, но количества в shop_product_stocks нет
        if (count($shop_stocks) > 1) {
            // Если есть склады в шопе
            $data = (new shopProductStocksModel())->getBySkuId($sku_ids);
            if (count($data) != count($sku_ids)) {
                if ($empty_ids = array_diff($sku_ids, array_keys($data))) {
                    $data = $data + array_fill_keys($empty_ids, ['tmp_stock' => []]);
                }
            }
            foreach ($this->settings['stock_ids'] as $warehouse_id => $stock_id) {
                if (!$stock_id) {
                    continue;
                }

                foreach ($data as $sku_id => $stocks) {
                    switch ($stock_id) {
                        case '0':
                            $value = 0;
                            break;
                        case 'count':
                            $value = $this->calculationWarehouseCount($sku_id, $skus[$sku_id]['count'], $stock_id);
                            break;
                        default:
                            if (isset($shop_stocks[$stock_id])) {
                                if (isset($shop_stocks[$stock_id]['substocks'])) {
                                    $value = 0;
                                    foreach ($shop_stocks[$stock_id]['substocks'] as $substock_id) {
                                        if (ifset($stocks[$substock_id]['count']) === null) {
                                            $value = null;
                                            break;
                                        } else {
                                            $value += $this->calculationWarehouseCount($sku_id, $stocks[$substock_id]['count'], $substock_id);
                                        }
                                    }
                                } else {
                                    $value = ifset($stocks[$stock_id]['count']);
                                    $value = $this->calculationWarehouseCount($sku_id, $value, $stock_id);
                                }
                            } else {
                                $value = 0;
                            }
                            break;
                    }
                    if ($value === null) $value = $this->settings['null_product_quantity'];
                    $value = (int)round($value, 0, PHP_ROUND_HALF_DOWN);
                    $public = $publics[array_search($sku_id, array_column($publics, 'sku_id'))];
                    if (!$public['task_id']) {
                        $items[] = [
                            'offer_id' => $this->getOfferId($public['product_id'], $sku_id, $skus[$sku_id]),
                            'product_id' => $public['ozon_product_id'],
                            'warehouse_id' => $warehouse_id,
                            'stock' => $value >= 0 ? $value : 0
                        ];
                    }
                }
            }
        } else {
            // Если нет складов в шопе
            foreach ($this->settings['stock_ids'] as $warehouse_id => $stock_id) {
                foreach ($skus as $sku_id => $sku) {
                    switch ($stock_id) {
                        case 'count':
                        default:
                            $value = $this->calculationWarehouseCount($sku_id, $skus[$sku_id]['count'], $stock_id);
                            break;
                        case '0':
                            $value = 0;
                            break;
                    }
                    if ($value === null) $value = $this->settings['null_product_quantity'];
                    if ($value < 0) $value = 0;
                    $value = (int)round($value, 0, PHP_ROUND_HALF_DOWN);
                    $public = $publics[array_search($sku_id, array_column($publics, 'sku_id'))];
                    if (!$public['task_id']) {
                        $items[] = [
                            'offer_id' => $this->getOfferId($public['product_id'], $sku_id, $skus[$sku_id]),
                            'product_id' => $public['ozon_product_id'],
                            'warehouse_id' => $warehouse_id,
                            'stock' => $value
                        ];
                    }
                }
            }
        }
        $break_warehouses = [];
        foreach ($this->settings['null_quantity'] as $warehouse_id => $feature_id) {
            if ($feature_id) {
                $break_warehouses[$warehouse_id] = $feature_id;
            }
        }
        if ($break_warehouses && $items) {
            if ($features = (new shopFeatureModel())->getById(array_values($this->settings['null_quantity']))) {
                $fvalues = [];
                foreach ($items as &$item) {
                    if (!$feature_id = $this->settings['null_quantity'][$item['warehouse_id']]) continue;
                    if (!isset($fvalues[$feature_id])) {
                        $fvalues[$feature_id] = $this->model_ozon_product->getNullQuantityFeatureValues($feature_id, array_column($publics, 'product_id'), array_column($publics, 'offer_id'));
                    }
                    if ($fvalues[$feature_id]['skus']) {
                        if (array_search($item['offer_id'], array_column($fvalues[$feature_id]['skus'], 'offer_id')) !== false) {
                            $item['stock'] = 0;
                            continue;
                        }
                    }
                    if ($fvalues[$feature_id]['product']) {
                        $publics_idx = array_search($item['offer_id'], array_column($publics, 'offer_id'));
                        if ($publics_idx === false) continue;
                        $product_id = $publics[$publics_idx]['product_id'];
                        if (array_search($product_id, array_column($fvalues[$feature_id]['product'], 'product_id')) !== false) {
                            $item['stock'] = 0;
                        }
                    }
                }
            }
        }
        return $items;
    }

    private function calculationWarehouseCount($sku_id, $count, $stock_id)
    {
        if ($count < 0) $count = 0;
        if (!isset($this->summary_warehouses[$stock_id]) || !$this->summary_warehouses || !$count) {
            return $count;
        }
        if (!isset($this->summary_warehouses[$stock_id]['skus'][$sku_id])) {
            if ($bpart = intdiv($count, $this->summary_warehouses[$stock_id]['total'])) {
                $this->summary_warehouses[$stock_id]['skus'][$sku_id] = array_fill(0, $this->summary_warehouses[$stock_id]['total'], $bpart);
            } else {
                $this->summary_warehouses[$stock_id]['skus'][$sku_id] = array_fill(0, $count, 1);
            }
            $diff = $count - $bpart * $this->summary_warehouses[$stock_id]['total'];
            if ($bpart && $diff) {
                foreach ($this->summary_warehouses[$stock_id]['skus'][$sku_id] as $key => $part) {
                    $diff_value = $diff ? 1 : 0;
                    $this->summary_warehouses[$stock_id]['skus'][$sku_id][$key] += $diff_value;
                    $diff--;
                }
            }
        }
        if (count($this->summary_warehouses[$stock_id]['skus'][$sku_id])) {
            $value = array_shift($this->summary_warehouses[$stock_id]['skus'][$sku_id]);
        } else {
            $value = 0;
        }
        return $value;
    }

    public function checkPublic($public)
    {
        $data = $this->ozon->checkTask($public['task_id']);
        return $data;
    }

    private function prepareProduct($product, $sku, $ozon_category_id)
    {
        if (!$product->getId()) return false;

        if (!$images = $this->getProductImages($product, $sku)) {
            $this->setError(shopOzonsellerPluginTextHelper::FAIL_IMAGES);
        }

        $attributes = $this->prepareFeatures($product, $sku, $ozon_category_id);
        foreach (['weight', 'dimensions', 'barcode', 'complex_attributes'] as $field) {
            $$field = ifset($attributes[$field]);
            unset($attributes[$field]);
        }

        $attributes = array_values($attributes);

        $name = $this->prepareProductName($product, $sku);
        if ($description = $this->prepareProductDescription($product, $sku)) {
            $attributes[] = [
                'id' => shopOzonsellerPluginOzonCategoryModel::OZON_DESCRIPTION_ATTRIBUTE,
                'values' => [
                    ['value' => $description]
                ]
            ];
        }

        $prices = [
            'old_price' => (string)$this->preparePrice($this->_getProductPrice($sku, $this->settings['old_price']), $product['currency'], $ozon_category_id, $product['params'], 'old_price'),
            'premium_price' => (string)$this->preparePrice($this->_getProductPrice($sku, $this->settings['premium_price']), $product['currency'], $ozon_category_id, $product['params'], 'premium_price'),
            'price' => (string)$this->preparePrice($this->_getProductPrice($sku, $this->settings['price']), $product['currency'], $ozon_category_id, $product['params'], 'price'),
            'min_price' => (string)$this->preparePrice($this->_getProductPrice($sku, $this->settings['min_price']), $product['currency'], $ozon_category_id, $product['params'], 'min_price'),
        ];

        if (!$prices['price']) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_NULL_PRICE, true);
        }

        if ($this->result['status'] != 'ok') {
            return false;
        }

        $data = [
            'name' => $name,
            'barcode' => $barcode,
            'category_id' => (int)$ozon_category_id,
            'depth' => (int)$dimensions['length'],
            'height' => (int)$dimensions['height'],
            'width' => (int)$dimensions['width'],
            'dimension_unit' => self::UNIT_DIMENSIONS,
            'primary_image' => array_shift($images),
            'images' => array_merge([], $images),
            'offer_id' => $this->getOfferId($product['id'], $sku['id'], $sku),
            'old_price' => $prices['old_price'],
            'premium_price' => $prices['premium_price'],
            'price' => $prices['price'],
            'min_price' => $prices['min_price'],
            'vat' => isset($this->taxes[$product['tax_id']]) ? (string)($this->taxes[$product['tax_id']]['value'] / 100) : (string)$this->settings['vat'],
            'weight' => (int)$weight,
            'weight_unit' => self::UNIT_WEIGHT,
            'attributes' => $attributes,
        ];
        if (ifempty($complex_attributes)) $data['complex_attributes'] = $complex_attributes;
        foreach (['old_price'] as $type_price) {
            if ($data[$type_price] <= $data['price']) $data[$type_price] = '0';
        }
        foreach (['premium_price'] as $type_price) {
            if ($data[$type_price] >= $data['price']) $data[$type_price] = '0';
        }
        if (!$data['barcode']) unset($data['barcode']);

        if ($this->settings['debug'] == '2') {
            shopOzonsellerPluginHelper::setLog('data product_id: ' . $product['id'] . ', sku_id: ' . $sku['id'], 'debug', $data);
        }
        return $data;
    }

    private function prepareFeatures($product, $sku, $ozon_category_id)
    {
        $attributes = [];
        $this->updateOzonCategorySettings($ozon_category_id);
        $product_features = $product->getFeatures();
        $skus_features = $product->getSkuFeatures();
        $sku_features = ifset($skus_features[$sku['id']], []);

        // Вес
        $weight = $wunit = null;
        $weight_code = $this->settings['weight_code'];
        if (isset($sku_features[$weight_code])) {
            $data_weight = is_array($sku_features[$weight_code]) ? array_shift($sku_features[$weight_code]) : $sku_features[$weight_code];
            $weight = $data_weight['value'];
            $wunit = $data_weight['unit'];
        } elseif (isset($product_features[$weight_code])) {
            $data_weight = is_array($product_features[$weight_code]) ? array_shift($product_features[$weight_code]) : $product_features[$weight_code];
            $weight = $data_weight['value'];
            $wunit = $data_weight['unit'];
        } else {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::FAIL_REQUIRED_FEATURE_VALUE, shopOzonsellerPluginTextHelper::TEXT_WEIGHT), true);
        }
        if ($weight !== null && $wunit !== null) {
            if ($wunit != self::UNIT_WEIGHT) {
                $weight = $this->convertDimension($weight, 'weight', self::UNIT_WEIGHT, $wunit);
            }
            if ((int)$weight) {
                $attributes['weight'] = (int)$weight;
            } else {
                $this->setError(sprintf(shopOzonsellerPluginTextHelper::FAIL_REQUIRED_FEATURE_VALUE, shopOzonsellerPluginTextHelper::TEXT_WEIGHT), true);
            }
        }

        // Габариты
        $dimensions = [];
        if ($this->settings['dimensions']['type'] == 'shop') {
            // из настроек магазина
            $dim_value = function ($data) {
                $values = null;
                if (count($this->dim_feature) == 1) {
                    foreach ($this->dim_fields as $key => $field) {
                        $value = $data[$key]['value'];
                        if ($data[$key]['unit'] != self::UNIT_DIMENSIONS) {
                            $value = $this->convertDimension($value, 'length', self::UNIT_DIMENSIONS, $data[$key]['unit']);
                        }
                        $values[$field] = $value;
                    }
                } else {
                    $values = $data['value'];
                    if ($data['unit'] != self::UNIT_DIMENSIONS) {
                        $values = $this->convertDimension($values, 'length', self::UNIT_DIMENSIONS, $data['unit']);
                    }
                }
                return $values;
            };

            if (count($this->dim_feature) == 1) {
                if (isset($product_features[$this->dim_feature[0]])) {
                    $dimensions = $dim_value($product_features[$this->dim_feature[0]]);
                } else {
                    $dimensions = $this->dim_fields;
                }
            } else {
                foreach ($this->dim_fields as $field) {
                    if (isset($this->dim_feature[$field]) && isset($sku_features[$this->dim_feature[$field]])) {
                        $dimensions[$field] = $dim_value($sku_features[$this->dim_feature[$field]]);
                    } elseif (isset($this->dim_feature[$field]) && isset($product_features[$this->dim_feature[$field]])) {
                        $dimensions[$field] = $dim_value($product_features[$this->dim_feature[$field]]);
                    } else {
                        $dimensions[$field] = $field;
                        break;
                    }
                }
            }
        } else {
            // Если берем из доп.параметров
            foreach ($this->dim_fields as $field) {
                $value = isset($product['params'][$this->settings['dimensions'][$field]]) ? (int)$product['params'][$this->settings['dimensions'][$field]] : 0;
                if ($this->settings['dimensions']['unit'] != self::UNIT_DIMENSIONS) {
                    $value = $this->convertDimension($value, 'length', self::UNIT_DIMENSIONS, $this->settings['dimensions']['unit']);
                }
                $dimensions[$field] = $value;
            }
        }
        foreach ($dimensions as &$dim) {
            if (!(int)$dim) {
                $this->setError(sprintf(shopOzonsellerPluginTextHelper::FAIL_REQUIRED_FEATURE_VALUE, shopOzonsellerPluginTextHelper::TEXT_DIMENSIONS), true);
                break;
            }
        }
        $sdimensions = array_values($dimensions);
        arsort($sdimensions);
        $sdimensions = array_values($sdimensions);
        $dimensions = [];
        foreach ($this->dim_fields as $key => $field) {
            $dimensions[$field] = $sdimensions[$key];
        }

        $attributes['dimensions'] = $dimensions;

        // Barcode
        $attributes['barcode'] = null;
        if ($this->settings['barcode']) {
            switch ($this->settings['barcode']) {
                case 'plugin_scanbarcode':
                    if (ifempty($sku['scanbarcode_barcode'])) {
                        $attributes['barcode'] = $sku['scanbarcode_barcode'];
                    } elseif (isset($product['scanbarcode_barcode']) && $product['scanbarcode_barcode']) {
                        $attributes['barcode'] = $product['scanbarcode_barcode'];
                    }
                    break;
                default:
                    if ($barcode = $this->_getProductFeatureValue($product_features, $sku_features, $this->features[$this->settings['barcode']]['code'], 'String')) {
                        $attributes['barcode'] = $barcode[0];
                    }
                    break;
            }
        }

        // Прочие характеристики
        foreach ($this->ozon_category_settings[$ozon_category_id]['ozon_features'] as $ofeature_id => $ozon_feature) {
            if ($attribute = $this->_prepareFeature($ozon_category_id, $ozon_feature, $product, $sku, $product_features, $sku_features)) {
                $attributes[] = $attribute;
            }

        }
        $complex_attributes = $complex_keys = [];
        foreach (shopOzonsellerPluginOzonCategoryModel::VIDEO_FEATURES as $vf_id) {
            $key = array_search($vf_id, array_column($attributes, 'id'));
            if ($key !== false) {
                $complex_attributes['attributes'][] = [
                    'id' => $vf_id,
                    'complex_id' => shopOzonsellerPluginOzonCategoryModel::VIDEO_COMPLEX_ID,
                    'values' => $attributes[$key]['values']
                ];
                $complex_keys[] = $key;
            }
        }
        if ($complex_keys) {
            sort($complex_keys, SORT_DESC);
            foreach ($complex_keys as $complex_key) {
                unset($attributes[$complex_key]);
            }
        }
        if ($complex_attributes) $attributes['complex_attributes'] = [$complex_attributes];
        return $attributes;
    }

    private function _prepareFeature($ozon_category_id, $ozon_feature, $product, $sku, $product_features, $sku_features)
    {
        $ofeature_id = $ozon_feature['id'];
        if (isset($ozon_feature['child']) && $ozon_feature['child']) {
            $collections = null;
            $chAttributes = [];
            foreach ($ozon_feature['child'] as $cfeature) {
                if ($chAttribute = $this->_prepareFeature($ozon_category_id, $cfeature, $product, $sku, $product_features, $sku_features)) {
                    $chAttributes[] = ['id' => $cfeature['id'], 'value' => $chAttribute];
                }
            }
            if ($chAttributes) {
                $collections = [
                    'id' => $ofeature_id,
                    'complex_collection' => [

                    ]
                ];
            }
            return $collections;
        }
        $type_features = $this->ozon_category_settings[$ozon_category_id]['types'][$product['type_id']];
        if (
            ifset($type_features[$ofeature_id]['feature_id']) &&
            (wa_is_int($type_features[$ofeature_id]['feature_id']) && !isset($this->features[$type_features[$ofeature_id]['feature_id']]))
        ) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_FEATURE_DELETED, $ozon_feature['name'], $this->ozon_category_settings[$ozon_category_id]['name'], $this->types[$product['type_id']]['name']));
        }
        if ($ozon_feature['is_required'] && !ifset($type_features[$ofeature_id]['feature_id'])) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::FAIL_REQUIRED_FEATURE, $ozon_feature['name']));
        }
        if (!$type_features[$ofeature_id]['feature_id']) return null;
        $vtype = $ozon_feature['type'];
        if ($vtype == 'Boolean' && $ozon_feature['dictionary_id']) {
            $vtype = 'String';
        }
        if (wa_is_int($type_features[$ofeature_id]['feature_id'])) {
            // Если характеристика
            $shop_feature = $this->features[$type_features[$ofeature_id]['feature_id']];
            $values = $this->_getProductFeatureValue($product_features, $sku_features, $shop_feature['code'], $vtype, $type_features[$ofeature_id]['value']);
            if ($ozon_feature['type'] == 'String' && strpos($shop_feature['type'], 'dimension.') === 0 && ifempty($type_features[$ofeature_id]['ext'])) {
                foreach ($values as &$v) {
                    $v = shopOzonsellerPluginHelper::getDimWithText($v, ifempty($type_features[$ofeature_id]['value'], $shop_feature['default_unit']));
                }
                unset($v);
            }
        } else {
            // Если строка или доп.параметр
            if (!$type_features[$ofeature_id]['value']) {
                if ($ozon_feature['is_required']) {
                    $this->setError(sprintf(shopOzonsellerPluginTextHelper::FAIL_REQUIRED_FEATURE, $ozon_feature['name']));
                }
                return null;
            }
            switch ($type_features[$ofeature_id]['feature_id']) {
                case 'string':
                    $values[] = trim(str_replace(
                        ['{$product_id}', '{$sku_id}', '{$sku_name}', '{$sku_sku}', '{$product_name}'],
                        [$product['id'], $sku['id'], $sku['name'], $sku['sku'], $product['name']],
                        $type_features[$ofeature_id]['value']));
                    break;
                case 'params':
                    $values = isset($product['params'][$type_features[$ofeature_id]['value']]) ? [$product['params'][$type_features[$ofeature_id]['value']]] : [];
                    break;
                case 'rich':
                    $values = [];
                    if (shopOzonsellerPluginHelper::checkInstallPlugin('richcontent')) {
                        try {
                            $values[] = shopRichcontentPlugin::getJSON($type_features[$ofeature_id]['value'], $product['id'], $sku['id']);
                        } catch (waException $e) {
                            shopOzonsellerPluginHelper::setLog($e->getMessage() . ' (rich)', 'error');
                        }
                    }
                    break;
                default:
                    return null;
            }
            foreach ($values as $key => $value) {
                $value = $this->convertValue($value, $vtype);
                if ($value === null) {
                    unset($values[$key]);
                } else {
                    $values[$key] = $value;
                }
            }
            if (!$values) $values = null;
        }

        if ($values && count($values) > 1) {
            $tmp_values = [];
            foreach ($values as $k => $v) {
                unset($values[$k]);
                if (in_array($v, $tmp_values)) continue;
                $tmp_values[] = $v;
            }
            $values = $tmp_values;
        }

        if (!$ozon_feature['is_collection'] && $values && count($values) > 1) {
            $values = [implode(', ', $values)];
        }

        if ($values === null) {
            if ($ozon_feature['is_required'] || !$this->settings['soft_fail']) {
                $const = constant('shopOzonsellerPluginTextHelper::' . ($ozon_feature['is_required'] ? 'FAIL_REQUIRED_FEATURE_VALUE' : 'FAIL_FEATURE_VALUE'));
                $this->setError(sprintf($const, $ozon_feature['name']), true);
            }
            return null;
        }
        // Проверка $ozon_feature['values'] - на случай big data. Их не проверяем отправляем как есть
        if ($ozon_feature['dictionary_id']) {
            if (wa_is_int($type_features[$ofeature_id]['feature_id']) && !isset($this->shop_feature_values[$shop_feature['id']])) {
                $this->shop_feature_values[$shop_feature['id']] = shopOzonsellerPluginHelper::getShopFeatureValues($shop_feature);
            }
            foreach ($values as $key => $value) {
                // $match и все что с этим связано - проверка наличия выставленного соответствия значений шопа значениям Ozon
                $match = false;
                if (wa_is_int($type_features[$ofeature_id]['feature_id']) &&
                    isset($this->matches[$ofeature_id][$shop_feature['id']])
                ) {
                    $shop_value_id = false;
                    if (wa_is_int($type_features[$ofeature_id]['feature_id']) && strpos($shop_feature['type'], 'dimension.') === 0) {
                        foreach ([$sku_features, $product_features] as $features) {
                            if (!isset($features[$shop_feature['code']])) {
                                continue;
                            } elseif (is_object($features[$shop_feature['code']])) {
                                switch (get_class($features[$shop_feature['code']])) {
                                    case 'shopCompositeValue':
                                    case 'shopDimensionValue':
                                        $shop_value_id = $features[$shop_feature['code']]['id'] ?? false;
                                        break;
                                }
                            }
                        }
                    } else {
                        $shop_value_id = array_search($value, $this->shop_feature_values[$shop_feature['id']]);
                    }
                    if ($shop_value_id !== false) {
                        $ovalue = array_search($shop_value_id, array_column($this->matches[$ofeature_id][$shop_feature['id']], 'value_id'));
                        if ($ovalue !== false) {
                            $match = $this->matches[$ofeature_id][$shop_feature['id']][$ovalue]['ozon_value_id'];
                        }
                    }
                }
                if ($match) {
                    $values[$key] = ['dictionary_value_id' => (int)$match];
                } else {
                    $options = $this->model_ozon_feature_values->getAllFeatureValues($ozon_category_id, $ofeature_id, $this->model_ozon_category->getDictionaryId($ozon_category_id, $ofeature_id));
                    $idx = $this->checkValueOptions($value, $options);
                    unset($options);
                    if (!wa_is_int($idx)) {
                        unset($values[$key]);
                    } else {
                        $values[$key] = ['dictionary_value_id' => (int)$idx];
                    }
                }
            }
            if (count($values) > 1) {
                $tmp_values = [];
                foreach ($values as $k => $v) {
                    unset($values[$k]);
                    if (in_array($v['dictionary_value_id'], array_column($tmp_values, 'dictionary_value_id'))) continue;
                    $tmp_values[] = $v;
                }
                $values = $tmp_values;
            }
        } else {
            foreach ($values as &$value) {
                $value = ['value' => $value];
            }
        }
        if (!$values) {
            if ($ozon_feature['is_required'] || !$this->settings['soft_fail']) {
                $const = constant('shopOzonsellerPluginTextHelper::' . ($ozon_feature['is_required'] ? 'FAIL_REQUIRED_FEATURE_VALUE' : 'FAIL_FEATURE_VALUE'));
                $this->setError(sprintf($const, $ozon_feature['name']), true);
            }
            return null;
        }
        $values = array_values($values);
        $attribute = ['id' => $ozon_feature['id'], 'values' => $values];
        return $attribute;
    }

    public function prematchFeatureValues($ozon_category_id, $shop_feature_id, $ozon_feature_id)
    {
        if (!$shop_feature = ifset($this->features[$shop_feature_id])) {
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_FEATURE_SHOP_NOT_FOUND, $shop_feature_id));
        }
        $matches = [];
        $shop_values = (new shopFeatureModel())->getValues([$shop_feature]);
        $shop_values = $shop_values[0]['values'];
        try {
            $ozon_values = $this->model_ozon_category->getFeatureValues($ozon_category_id, $ozon_feature_id);
        } catch (waException $e) {
            if ($e->getCode() == 5000) {
                return $matches;
            }
        }
        $type_values = $this->_checkValuesInts($ozon_values);
        foreach ($shop_values as $key => $value) {
            if ($type_values == 'int') {
                $value = $this->convertValue($value, $type_values);
            }
            $idx = $this->checkValueOptions($value, $ozon_values);
            if ($idx === false) continue;
            $matches[$key] = $idx;
        }
        return $matches;
    }

    public function checkValueOptions($value, $options)
    {
        if (is_object($value)) {
            $value = $value['value'];
        }
        $value = str_replace('  ', ' ', $value);
        $variants = [$value];
        $tmp_value = explode(' ', $value);
        $cparts = count($tmp_value);
        if ($cparts === 2) {
            $variants[] = $tmp_value[1] . ' ' . $tmp_value[0];
        }
        if ($cparts > 2) {
            for ($i = 0; $i < $cparts - 1; $i++) {
                foreach (['-', '/'] as $delimeter) {
                    $cv = $tmp_value;
                    $cv[$i] = $cv[$i] . $delimeter . $cv[$i + 1];
                    unset($cv[$i + 1]);
                    $variants[] = implode(' ', $cv);
                }
            }
        }
        $consts = [MB_CASE_TITLE, MB_CASE_LOWER, MB_CASE_UPPER];
        foreach ($consts as $const) {
            $variants[] = mb_convert_case($value, $const, 'UTF-8');
        }
        foreach ([',', '/', '\\', ' ', '-'] as $delimeter) {
            $tmp_value = str_replace($delimeter, ' ', $value);
            if (!in_array($tmp_value, $variants)) {
                $variants[] = $tmp_value;
            }
            $parts = explode($delimeter, $value);
            if (count($parts) > 1) {
                foreach ($parts as $part) {
                    $tmp_value = $value;
                    $tmp_value = trim(str_replace('  ', ' ', str_replace($part, '', $tmp_value)));
                    $variants[] = $tmp_value;
                    foreach ($consts as $const) {
                        $variants[] = mb_convert_case($tmp_value, $const, 'UTF-8');
                    }
                    if (count($parts) > 2) {
                        $part = trim($part);
                        $variants[] = $part;
                        foreach ($consts as $const) {
                            $variants[] = mb_convert_case($part, $const, 'UTF-8');
                        }
                    }
                }
            }
        }
        array_multisort(array_map('strlen', $variants), $variants);
        $variants = array_merge([$value], array_reverse($variants));
        foreach ($variants as $variant) {
            $idx = array_search(mb_strtoupper(trim($variant)), array_map('mb_strtoupper', $options));
            if ($idx !== false) {
                $idx = (string)$idx;
                break;
            }
        }
        return $idx;
    }

    private function _getProductFeatureValue($product_features, $sku_features, $code, $type, $units = null)
    {
        $values = [];
        foreach ([$sku_features, $product_features] as $features) {
            if (!isset($features[$code])) {
                continue;
            } else {
                if (is_array($features[$code])) {
                    foreach ($features[$code] as $fvalue) {
                        if (is_array($fvalue)) {
                            $values[] = $fvalue['value'];
                        } elseif (is_object($fvalue)) {
                            $values[] = $fvalue['value'];
                        } else {
                            $values[] = $fvalue;
                        }
                    }
                } elseif (is_object($features[$code])) {
                    switch (get_class($features[$code])) {
                        case 'shopCompositeValue':
                            $dims = [];
                            for ($i = 0; $i <= 2; $i++) {
                                if ($features[$code][$i]['value'] === null) {
                                    break;
                                } else {
                                    $dims[] = $features[$code][$i]['value'];
                                }
                            }
                            if ($dims) {
                                $values[] = implode('x', $dims);
                            }
                            break;
                        case 'shopDimensionValue':
                            $dvalue = $features[$code]['value'];
                            if ($units && $units != $features[$code]['unit']) {
                                $dvalue = $this->convertDimension($dvalue, $features[$code]['type'], $units, $features[$code]['unit']);
                            }
                            $values[] = $dvalue;
                            break;
                        default:
                            $values[] = $features[$code]['value'];
                    }
                } else {
                    $values[] = $features[$code];
                }
                break;
            }
        }
        foreach ($values as $key => $value) {
            $check_value = $this->convertValue($value, $type);
            if ($check_value === null) {
                unset($values[$key]);
            } else {
                $values[$key] = $check_value;
            }
        }
        if (!count($values)) $values = null;
        return $values;
    }

    private function convertValue($value, $type)
    {
        if (!in_array($type, shopOzonsellerPluginOzonCategoryModel::REAL_VALUE_TYPES)) {
            return null;
        }
        switch ($type) {
            case 'Integer':
                if (wa_is_int($value)) break;
                $parts = explode(' ', $value);
                if (wa_is_int($parts[0])) {
                    $value = $parts[0];
                }
                break;
            case 'Decimal':
                if (wa_is_int($value)) break;
                $tmp = str_replace(',', '.', $value);
                $parts = explode(' ', $tmp);
                $tmp = $parts[0];
                if (wa_is_int($tmp)) {
                    $value = $tmp;
                    break;
                }
                $parts = explode('.', $tmp);
                if (count($parts) != 2) {
                    $value = null;
                    break;
                }
                foreach ($parts as $part) {
                    if (!wa_is_int($part)) break;
                }
                $value = implode('.', $parts);
                break;
            case 'Boolean':
                if ($value) {
                    if (in_array(mb_strtoupper($value), shopOzonsellerPluginOzonCategoryModel::BOOL_FALSE)) {
                        $value = 'false';
                    } else {
                        $value = 'true';
                    }
                } else {
                    $value = 'false';
                }
                break;
            case 'URL':
            case 'ImageURL':
                if (filter_var($value, FILTER_VALIDATE_URL) === false) {
                    if ($type === 'URL') {
                        $values = explode(',', $value);
                        if (count($values) === 1) {
                            $value = null;
                            break;
                        }
                        foreach ($values as $key => $url) {
                            if (filter_var($value, FILTER_VALIDATE_URL) === false) {
                                unset ($values[$key]);
                            }
                        }
                        if ($values) $value = implode(',', $values);
                    } else $value = null;
                }
                break;
        }
        if ($value && $type != 'Boolean') {
            $value = (string)$value;
        }
        return $value;
    }

    private function _checkValuesInts($values)
    {
        if (!is_array($values)) {
            return 'String';
        }
        $is_int = true;
        foreach ($values as $value) {
            if (!wa_is_int($value)) {
                $is_int = false;
                break;
            }
        }
        return $is_int ? 'Integer' : 'String';
    }

    private function preparePrice($value, $in_currency, $ozon_category_id, $params = [], $price_type = 'price', $with_markups = true)
    {
        $this->updateOzonCategorySettings($ozon_category_id);
        if ($in_currency != 'RUB') {
            $value = shop_currency($value, $in_currency, 'RUB', false);
        }
        if ($with_markups && ifset($this->settings['price_markups'][$price_type], '1')) {
            $markups = null;
            if ($this->settings['markup_product']['type']) {
                if (isset($params[$this->settings['markup_product']['key']])) {
                    if (wa_is_int($params[$this->settings['markup_product']['key']])) {
                        $markups = [[
                            'markup' => (int)$params[$this->settings['markup_product']['key']],
                            'price_from' => 0,
                            'currency' => 'RUB',
                            'markup_type' => '%',
                        ]];
                    }
                }
            }
            if ($markups === null) {
                if (isset($this->ozon_category_settings[$ozon_category_id]['markups']) && $this->ozon_category_settings[$ozon_category_id]['markups']) {
                    $markups = $this->ozon_category_settings[$ozon_category_id]['markups'];
                } else {
                    $markups = $this->default_markups;
                }
            }
            // Наценки отсортированы по убыванию по price_from, поэтому достаточно найти первое соответствие
            foreach ($markups as $markup) {
                if ($markup['currency'] != 'RUB') {
                    $markup['price_from'] = shop_currency($markup['price_from'], $markup['currency'], 'RUB', false);
                }
                if ($value > $markup['price_from']) {
                    if ($markup['markup_type'] == '%') {
                        $value = $value * (1 + $markup['markup'] / 100);
                    } else {
                        $value += shop_currency($markup['markup'], $markup['markup_type'], 'RUB', false);
                    }
                    break;
                }
            }
        }
        return shop_currency($value, 'RUB', 'RUB', false);
    }

    private function _getProductPrice($sku, $setting)
    {
        $value = 0;
        switch ($setting['type']) {
            case 'params':
                $query = <<<SQL
SELECT value FROM shop_product_params WHERE product_id=i:product_id and name=s:name
SQL;
                $svalue = (float)(new shopProductParamsModel())->query($query, ['product_id' => $sku['product_id'], 'name' => $setting['key']])->fetchField('value');
                if ($svalue !== false) {
                    $value = (float)$svalue;
                }
                break;
            case 'plugin_price':
                if (!shopOzonsellerPluginHelper::checkInstallPlugin('price', '4.2.3')) break;
                $skus = shopPricePlugin::prepareSkus([$sku], null, null, null, $setting['key']);
                foreach ($skus as $item) {
                    if ($item['id'] == $sku['id']) {
                        $value = $item['price'];
                        break;
                    }
                }
                break;
            case 'plugin_pricetype':
                if (!shopOzonsellerPluginHelper::checkInstallPlugin('pricetype')) break;
                $value = shopPricetypePlugin::getPrice($sku['id'], $setting['key'], true);
                break;
            case '0':
                $value = 0;
                break;
            default:
                $value = $sku[$setting['type']];
        }
        return $value;
    }

    private function prepareProductName($product, $sku)
    {
        $name = null;
        switch ($this->settings['name']['type']) {
            case 'name':
                $name = $product['name'];
                break;
            case 'name_sku':
                $name = $product['name'] . ($sku['name'] ? ', ' . $sku['name'] : '');
                break;
            case 'name_sku_bracket':
                $name = $product['name'] . ($sku['name'] ? ' (' . $sku['name'] . ')' : '');
                break;
            case 'sku':
                $name = $sku['name'];
                break;
            case 'params':
                $name = ifset($product['params'][$this->settings['name']['key']]);
                break;
            case 'auto':
                $name = $product['name'];
                break;
            case 'features':
                $product_features = $product->getFeatures();
                $skus_features = $product->getSkuFeatures();
                $sku_features = ifset($skus_features[$sku['id']], []);
                $values = $this->_getProductFeatureValue($product_features, $sku_features, $this->features[$this->settings['name']['key']]['code'], 'String');
                $name = ifset($values[0]);
                break;
            case 'title_og':
                $name = $this->getOgParams($product, 'title');
                break;
        }
        if (!trim($name)) {
            if (in_array($this->settings['name']['type'], ['params', 'features'])) {
                $name = $product['name'];
            }
            if (!trim($name)) {
                $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_EMPTY_PRODUCT_FIELD, shopOzonsellerPluginTextHelper::TEXT_NAME), true);
            }
        } elseif (mb_strlen($name) > 500) {
            $name = mb_substr($name, 0, 499);
        }
        $params = [
            'product_id' => $product['id'],
            'sku_id' => $sku['id'],
            'name' => $name
        ];
        wa()->event('ozonseller.product_name', $params);
        return trim($params['name']);
    }

    private function prepareProductDescription($product, $sku)
    {
        // https://docs.ozon.ru/partners/trebovaniya-k-tovaram/opisanie
        $view = wa()->getView();
        $view->assign('product', $product);
        switch ($this->settings['description']['type']) {
            case 'description':
            case 'summary':
                $description = $view->fetch('string:' . str_replace(['{', '}'], ['(', ')'], $product[$this->settings['description']['type']]));
                break;
            case 'params':
                if (isset($product['params'][$this->settings['description']['key']])) {
                    $description = $view->fetch('string:' . str_replace(['{', '}'], ['(', ')'], $product['params'][$this->settings['description']['key']]));
                }
                break;
            case 'block':
                wa('site');
                if ($block = (new siteBlockModel())->getById($this->settings['description']['key'])) {
                    $description = $view->fetch('string:' . str_replace(['{', '}'], ['(', ')'], $block['content']));
                }
                break;
            case 'features':
                if (!isset($this->features[$this->settings['description']['key']])) {
                    $description = '';
                    break;
                }
                if (!$description = $this->_getProductFeatureValue($product->getFeatures(), $product->getSkuFeatures()[$sku['id']], $this->features[$this->settings['description']['key']]['code'], 'String')) {
                    $description = '';
                } elseif (is_array($description)) {
                    $description = $description[0];
                }
                break;
            case 'description_og':
                $description = $this->getOgParams($product, 'description');
                break;
        }
        $description = strip_tags($this->_brReplace($description), '<ul><li><br>');
        if (!$description = trim(strip_tags($this->_brReplace($description), '<ul><li><br>'))) {
            switch ($this->settings['empty_description']['type']) {
                case 'summary':
                    if (trim($product['summary'])) {
                        $description = $this->_brReplace($product['summary']);
                    }
                    break;
                case 'params':
                    if (isset($product['params'][$this->settings['empty_description']['key']])) {
                        $description = $view->fetch('string:' . $product['params'][$this->settings['empty_description']['key']]);
                        $description = $this->_brReplace($description);
                    }
                    break;
                case 'blocks':
                    wa('site');
                    if ($block = (new siteBlockModel())->getById($this->settings['empty_description']['key'])) {
                        $description = $view->fetch('string:' . $block['content']);
                        $description = $this->_brReplace($description);
                    }
                    break;
            }
            if (!$tmp_description = trim(strip_tags($description, '<ul><li><br>'))) {
                if (!$this->settings['empty_description']) {
                    $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_EMPTY_PRODUCT_FIELD, shopBackendfilterPluginTextHelper::FIELD_DESCRIPTION), true);
                }
            }
        }
        $params = [
            'product_id' => $product['id'],
            'sku_id' => $sku['id'],
            'description' => $description
        ];
        wa()->event('ozonseller.product_description', $params);
        if (mb_strlen($params['description']) > 6000) $params['description'] = mb_substr($params['description'], 0, 5996) . '...';
        return $params['description'];
    }

    private function _brReplace($value)
    {
        $brs = ['\r\n'];
        if (trim($this->settings['br_replace'])) {
            $brs = array_merge($brs, explode(',', $this->settings['br_replace']));
        }
        return str_replace($brs, '<br>', $value);
    }

    public function getProductImages(shopProduct $product, $sku)
    {
        $url_domain = false;
        $routing = wa()->getRouting();
        $domain_routes = $routing->getByApp('shop');
        foreach ($domain_routes as $domain => $routes) {
            foreach ($routes as $r) {
                if (empty($r['type_id']) || (in_array($product['type_id'], (array)$r['type_id']))) {
                    $url_domain = 'http://' . $domain;
                    break 2;
                }
            }
        }
        if (!$url_domain) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_DOMAIN_NOT_DEFINED);
            return false;
        }
        $images = $tmp_photos = [];
        $product_images = $product->getImages();
        switch ($this->settings['image_source']['type']) {
            case 'product_image':
            case 'sku_image':
            case 'sku_image_overall':
                foreach ($product_images as $image_id => $pi) {
                    if (!in_array(strtolower($pi['ext']), self::OZON_IMAGE_EXTENSIONS)) {
                        unset($product_images[$image_id]);
                    }
                }
                if (!$product_images) {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_NO_IMAGES, true);
                    return [];
                }
                if ($this->settings['image_source']['type'] === 'sku_image_overall') $this->settings['image_source']['key'] = '';
                switch ($this->settings['image_source']['type'] . '_' . $this->settings['image_source']['key']) {
                    case 'product_image_main':
                        if (isset($product_images[$product['image_id']])) {
                            $images[] = $product_images[$product['image_id']];
                        }
                        break;
                    case 'product_image_all':
                        foreach ($product_images as $product_image) {
                            $images[] = $product_image;
                            if (count($images) >= self::OZON_IMAGE_COUNT) break;
                        }
                        break;
                    case 'sku_image_0':
                        if ($sku['image_id'] && isset($product_images[$sku['image_id']])) {
                            $images[] = $product_images[$sku['image_id']];
                        }
                        break;
                    case 'sku_image_main':
                        if (
                            (!$sku['image_id'] || !isset($product_images[$sku['image_id']])) &&
                            (isset($product_images[$product['image_id']]))
                        ) {
                            $images[] = $product_images[$product['image_id']];
                        } elseif (isset($product_images[$sku['image_id']])) {
                            $images[] = $product_images[$sku['image_id']];
                        }
                        break;
                    case 'sku_image_all':
                        if ($sku['image_id'] && isset($product_images[$sku['image_id']])) {
                            $images[] = $product_images[$sku['image_id']];
                        } else {
                            foreach ($product_images as $product_image) {
                                $images[] = $product_image;
                                if (count($images) >= self::OZON_IMAGE_COUNT) break;
                            }
                        }
                        break;
                    case 'sku_image_overall_':
                        if ($sku['image_id'] && isset($product_images[$sku['image_id']])) {
                            $images[] = $product_images[$sku['image_id']];
                        }
                        $skus = $product->getSkus();
                        foreach ($product_images as $product_image) {
                            $idx = array_search($product_image['id'], array_column($skus, 'image_id'));
                            if ($idx === false) $images[] = $product_image;
                        }
                        break;
                }

                foreach ($images as $key => $idata) {
                    $workSide = $idata['width'] > $idata['height'] ? 'width' : 'height';
                    if ($idata[$workSide] >= self::OZON_IMAGE_MIN_SIZE && $idata[$workSide] <= self::OZON_IMAGE_MAX_SIZE) {
                        $img_size = $idata[$workSide];
                    } else {
                        if ($idata[$workSide] < self::OZON_IMAGE_MIN_SIZE) {
                            $img_size = self::OZON_IMAGE_MIN_SIZE;
                        } elseif ($idata[$workSide] > self::OZON_IMAGE_MAX_SIZE) {
                            $img_size = self::OZON_IMAGE_MAX_SIZE;
                        }
                    }

                    $img_file = shopImage::getThumbsPath($idata, $img_size);
                    try {
                        if (!file_exists($img_file) || $this->settings['reimages']) {
                            if (file_exists($img_file)) {
                                try {
                                    waFiles::delete($img_file);
                                } catch (waException $e) {
                                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                                }
                            }
                            shopImage::generateThumbs($idata, array($img_size));
                        }
                    } catch (waException $e) {
                        $this->helper->setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_IMAGE_GENERATE . ': ' . $e->getMessage(), $product['id']), 'error');
                        unset($images[$key]);
                        continue;
                    }
                    try {
                        $tmp_img = waImage::factory($img_file);
                    } catch (waException $e) {
                        $this->helper->setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_PRODUCT_IMAGE, $product['id']));
                        unset($images[$key]);
                        continue;
                    }

                    if ($tmp_img->$workSide != $img_size) {
                        $width = $workSide == 'width' ? $img_size : null;
                        $height = $workSide == 'height' ? $img_size : null;
                        $tmp_img->resize($width, $height, strtoupper($workSide), false);
                    }

                    try {
                        $tmp_img->save($img_file);
                    } catch (waException $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                        continue;
                    }
                    $url_photo = str_replace(['http://localhost', 'https://localhost'], $url_domain, shopImage::getUrl($idata, $img_size, true));
                    $tmp_photos[] = $url_photo;
                }
                $images = $tmp_photos;
                break;
            case 'params':
                $aparams = (new shopProductParamsModel())->getData($product);
                if ($value = ifset($aparams[$this->settings['image_source']['key']], [])) {
                    foreach (explode(',', $value) as $url) {
                        $images[] = $url;
                        if (count($images) >= self::OZON_IMAGE_COUNT) break;
                    }
                }
                break;
            case 'image_og':
                if ($url = $this->getOgParams($product, 'image')) $images[] = $url;
                break;
            default:
                if (!wa_is_int($this->settings['image_source']['type'])) {
                    $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'source_image feature_id: ' . $this->settings['image_source']['value']), true);
                    break;
                }
                $sku_features = $product->getSkuFeatures();
                $values = $this->_getProductFeatureValue($product->getFeatures(), ifset($sku_features[$sku['id']]), $this->features[$this->settings['image_source']['type']]['code'], 'url');
                foreach ($values as $url) {
                    $images[] = $url;
                    if (count($images) >= self::OZON_IMAGE_COUNT) break;
                }
                break;
        }

        $params = [
            'product_id' => $product['id'],
            'sku_id' => $sku['id'],
            'images' => $images
        ];
        wa()->event('ozonseller.product_images', $params);
        if (!$params['images']) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_NO_IMAGES, $sku['id']);
        }
        return ifset($params['images']);
    }


    private function checkPossibilityPublic($product, $ozon_category_id)
    {
        if (!$category_settings = ifset($this->ozon_category_settings[$ozon_category_id])) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_EMPTY_TYPE_FILLED, true);
        }
        if (!isset($category_settings['types'][$product['type_id']])) {
            $this->setError(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_TYPE_NOT_FOUND, true);
        }
        if (!ifset($category_settings['ozon_features'])) {
            $this->setError(sprintf(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_FEATURES_NOT_FOUND, $ozon_category_id), true);
        }
    }

    private function convertDimension($value, $type, $unit, $value_unit = null)
    {
        return shopDimension::getInstance()->convert($value, $type, $unit, $value_unit);
    }

    private function getPublicsByProductId($product_id)
    {
        $publics = [];
        foreach (ifset($this->all_publics[$product_id], []) as $item) {
            $publics[$item['sku_id']] = $item;
        }
        return $publics;
    }

    public function upgradePublics($offer_ids = null)
    {
        if (!$this->settings['upgrade'] || $this->settings['upgrade'] == '2') return;
        foreach ($this->all_publics as $product_id => $publics) {
            foreach ($publics as $public) {
                if ($offer_ids !== null && !in_array($public['offer_id'], $offer_ids)) continue;
                $this->importProduct($product_id, $public['ozon_category_id'], $public['sku_id']);
            }
        }
    }

    public function checkPublicsState($check_publics)
    {
        $checked = [];
        foreach ($check_publics as $product_id => $publics) {
            foreach ($publics as $pkey => $public) {
                try {
                    $items = $this->checkPublic($public);
                    foreach ($items as $key => $item) {
                        $data = [
                            'ozon_product_id' => ifset($item['product_id']),
                            'state' => $item['status']
                        ];
                        if (!in_array($item['status'], ['moderating', 'failed']) && $item['product_id']) {
                            $data['task_id'] = null;
                        }
                        $dataErrors = [];
                        if (isset($item['errors']) && is_array($item['errors']) && $item['errors']) {
                            $itemErrors = [];
                            foreach ($item['errors'] as $data) {
                                $message = '';
                                foreach (['code', 'description', 'message'] as $field) {
                                    if (ifset($data[$field])) {
                                        $message .= ($message ? PHP_EOL : '') . $data[$field];
                                    }
                                }
                                if ($message) {
                                    $itemErrors[] = $message;
                                }
                            }
                            if ($itemErrors) {
                                $dataErrors = [
                                    'product_id' => $product_id,
                                    'sku_id' => $public['sku_id'],
                                    'ozon_category_id' => $public['ozon_category_id'],
                                    'errors' => $itemErrors
                                ];
                            }
                        }
                        if ($dataErrors) $this->model_fail_log->updateLog($this->account_id, $dataErrors);
                        if ($item['status'] === 'failed') {
                            $this->model_ozon_product->deleteById(['account_id' => $public['account_id'], 'sku_id' => $public['sku_id']]);
                            if ($this->settings['error_set']) {
                                (new shopSetProductsModel())->add([$product_id], [$this->settings['error_set']]);
                            }
                            unset($items[$key]);
                        } else {
                            $this->model_ozon_product->updateById(['account_id' => $public['account_id'], 'sku_id' => $public['sku_id']], $data);
                        }
                    }
                    if ($items) $checked[$product_id] = $items;
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                }
            }
        }
        return $checked;
    }

    private function checkExcludePublic($product, $sku)
    {
        $check = true;
        foreach (['exclude', 'skip_upgrade'] as $setting) {
            if ($this->settings[$setting]['type']) {
                switch ($this->settings[$setting]['type']) {
                    case 'params':
                        if (isset($product['params'][$this->settings[$setting]['key']]) && $product['params'][$this->settings[$setting]['key']]) {
                            $check = false;
                            break 2;
                        }
                        break;
                    case 'sets':
                        if ((new shopSetProductsModel())->getByField(['product_id' => $product['id'], 'set_id' => $this->settings[$setting]['key']])) {
                            $check = false;
                            break 2;
                        }
                        break;
                    default:
                        if ($feature = (new shopFeatureModel())->getById($this->settings[$setting]['type'])) {
                            $product_features = $product->getFeatures();
                            $skus_features = $product->getSkuFeatures();
                            if (ifset($skus_features[$sku['id']][$feature['code']]['value'])) {
                                $check = false;
                                break 2;
                            } elseif (isset($product_features[$feature['code']]['value']) && $product_features[$feature['code']]['value']) {
                                $check = false;
                                break 2;
                            }
                            unset($skus_features);
                            unset($product_features);
                            break;
                        }
                }
            }
        }
        /*        if (!$check) {
                    $this->setError(shopOzonsellerPluginTextHelper::ERROR_SKU_EXCLUDE, true);
                    $this->model_fail_log->updateLog($this->result);
                }*/
        return $check;
    }

    private function setError($error, $hard_fail = false)
    {
        if ($error) {
            $this->result['errors'][] = $error;
        }
        if ($hard_fail) {
            $this->result['status'] = 'fail';
        }
    }

    private function resetStatus($product_id = null, $sku_id = null, $ozon_category_id = null)
    {
        $this->result = [
            'status' => 'ok',
            'product_id' => $product_id,
            'sku_id' => $sku_id,
            'ozon_category_id' => $ozon_category_id,
            'errors' => []
        ];
    }

    public function getOfferId($product_id, $sku_id, $sku = null)
    {
        $offer_id = null;
        if (isset($this->all_publics[$product_id])) {
            foreach ($this->all_publics[$product_id] as $public) {
                if ($public['sku_id'] == $sku_id) {
                    $offer_id = $public['offer_id'];
                    break;
                }
            }
        }
        if ($offer_id === null) {
            switch ($this->settings['offer_id']) {
                case 'product_id':
                    $offer_id = $product_id;
                    break;
                default:
                    if ($sku && $sku[$this->settings['offer_id']]) {
                        $offer_id = $sku[$this->settings['offer_id']];
                    }
                    break;
            }
        }
        if (!$offer_id) $offer_id = $sku_id;

        return (string)$offer_id;
    }

    public function updateOzonCategorySettings($ozon_category_id)
    {
        if (!ifempty($this->ozon_category_settings[$ozon_category_id])) {
            try {
                $this->ozon_category_settings[$ozon_category_id] = $this->model_ozon_category->getCategoryFullData($ozon_category_id, $this->account_id);
            } catch (waException $e) {
                if ($e->getCode() == 704) {
                    $message = sprintf(shopOzonsellerPluginTextHelper::ERROR_CATEGORY_NOT_FOUND, $ozon_category_id) . ' .' . shopOzonsellerPluginTextHelper::MESSAGE_CATEGORY_UPDATE;
                    shopOzonsellerPluginHelper::setLog($message);
                    $this->ozon_category_settings[$ozon_category_id] = null;
                } else {
                    throw new waException($e->getMessage(), $e->getCode());
                }
            }
        }
    }

    private function getOgParams($product, $property)
    {
        $value = '';
        if ($data = $this->model_product_og->getByField(['product_id' => $product['id'], 'property' => $property])) {
            $view = wa()->getView();
            $params = [
                'name' => $product['name'],
                'summary' => $product['summary'],
            ];
            $view->assign(compact($params));
            $value = $view->fetch('string:' . $data['content']);
        }
        return trim($value);
    }

    private function getProduct($product_id)
    {
        $product = new shopProduct($product_id);
        if (!$product->getId()) return false;
        return $product;
    }
}