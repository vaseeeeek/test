<?php

class shopOzonsellerPluginCategoryPreparator
{
    protected $model_category;

    public function __construct()
    {
        $this->model_category = new shopOzonsellerPluginOzonCategoryModel();
    }

    public function addCategory($category)
    {
        $this->model_category->add($category);
    }

    public function getOzonCategoryTree($account_id, $preUpdate = false)
    {
        $categories =  (new shopOzonsellerPluginOzonApi($account_id))->getCategoryTree();
        if ($preUpdate && $categories) $this->preUpdate();
        return $categories;
    }

    public function preUpdate() {
        $this->model_category->query('update shop_ozonseller_ozon_category set to_del=1');
    }

    public function postUpdate() {
        $query = <<<SQL
select distinct ozon_category_id from shop_ozonseller_category_features
SQL;
        if (!$ozon_ids = $this->model_category->query($query)->fetchAll(null, true)) $ozon_ids =[0];
        $query = <<<SQL
delete from {$this->model_category->getTableName()} where id not in (i:ids) and to_del=1
SQL;
        $this->model_category->query($query, ['ids' => $ozon_ids]);
        $query = <<<SQL
update {$this->model_category->getTableName()} set status=2 where id in (i:ids) and to_del=1
SQL;
        $this->model_category->query($query, ['ids' => $ozon_ids]);
    }
}