<?php

class shopOzonsellerPluginHelper
{
    const REAL_PATH = 'plugins/ozonseller/lib/';

    public static function validatePlugin(object $class, $relative_path = null)
    {
        $reflection = new ReflectionClass($class);
        $checking_path = $reflection->getFileName();
//        $debug_mode = wa()->getPlugin('ozonseller')->getSettings('debug');
        $path = wa('shop')->getAppPath(self::REAL_PATH);
        if ($relative_path) $check = $path . $relative_path === $checking_path;
        else $check = strpos($checking_path, $path) === 0;
        /*        if ($debug_mode) {
                    self::setLog(sprintf('validate %s: %s', $reflection->getShortName(), $check ? 'true' : 'false'), 'debug', $debug_mode == 2 ? $reflection->getFileName() : null);
                }*/
        if (!$check) {
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_VALIDATE_CLASS, $reflection->getShortName()));
        }
        unset($reflection);
    }

    public function getCollectionProducts($type_ids, $product_ids)
    {
        switch ($type_ids) {
            case 'hash':
                $hash = $product_ids == 'all' ? '' : $product_ids;
                break;
            case 'presentation':
                if (version_compare(wa()->getVersion('shop'), '10.0.2', '<')) {
                    $hash = shopImportexportHelper::getCollectionHash($product_ids);
                } else $hash = $product_ids;
                break;
            case 'ids':
                $hash = explode(',', $product_ids);
                break;
            case 'category':
                $hash = 'category/' . $product_ids;
                break;
            default:
                throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'type_ids'));
        }
        return new shopProductsCollection($hash);
    }

    public function getFeaturesType($type_id = null, $alltype = true, $ftypes = null)
    {
        $model_type = new shopTypeModel();
        $model_type_features = new shopTypeFeaturesModel();
        $types = $model_type->getAll('id');
        $features_by_type = array();
        foreach ($model_type_features->getByType(0) as $f) {
            if ($this->checkFeature($f)) {
                $features_by_type[0][$f['id']] = $f;
            }
        }
        if ($type_id !== null) {
            foreach ($model_type_features->getByType($type_id) as $tf) {
                if ($this->checkFeature($tf)) {
                    $features_by_type[$type_id][$tf['id']] = $tf;
                }
            }
        } else {
            foreach ($types as $type) {
                foreach ($model_type_features->getByType($type['id']) as $tf) {
                    if ($this->checkFeature($tf)) {
                        $features_by_type[$type['id']][$tf['id']] = $tf;
                    }
                }
            }
        }
        if ($ftypes) {
            foreach ($features_by_type as $typeId => $features) {
                foreach ($features as $feature) {
                    if (!in_array($feature['type'], $ftypes)) {
                        unset($features_by_type[$typeId][$feature['id']]);
                    }
                }
                if (!$features_by_type[$typeId]) unset($features_by_type[$typeId]);
            }
        }
        foreach ($features_by_type as $type_id => $tfeatures) {
            $features_by_type[$type_id] = array_values(shopOzonsellerPluginHelper::sortArray($tfeatures, 'name', 'asc', true));
        }
        if ($type_id !== null) {
            if ($alltype) {
                $features[0] = $features_by_type[0];
                $features[$type_id] = ifset($features_by_type[$type_id], []);
            } else {
                $features = ifset($features_by_type[$type_id], []);
            }
            return $features;
        } else {
            return $features_by_type;
        }
    }

    /**
     * Проверка наличия плагина
     *
     * @param string $plugin_id
     * @param string $min_version
     * @return bool
     * @throws waException
     */

    public static function checkInstallPlugin($plugin_id, $min_version = '')
    {
        $plugins = wa()->getConfig()
            ->getAppConfig('shop')
            ->getPlugins();
        if ($min_version && isset($plugins[$plugin_id])) {
            return version_compare(wa()->getPlugin($plugin_id)->getVersion(), $min_version, '>=');
        }
        return isset($plugins[$plugin_id]);
    }

    public function getTaxesByRus()
    {
        $query = <<<SQL
select t.id,t.name,tr.tax_value as value from shop_tax_regions tr join shop_tax t on t.id=tr.tax_id 
where tr.country_iso3="rus" and tr.region_code is null
SQL;
        return (new waModel())->query($query)->fetchAll('id');
    }

    private function checkFeature($feature)
    {
        if ($feature['type'] == 'divider' ||
            $feature['parent_id'] !== null /*||
            strpos($feature['type'], '.') !== false*/
        ) {
            return false;
        } else {
            return true;
        }
    }

    public static function getConfigFile($file, $path_only = false)
    {
        $custom_path = wa()->getDataPath('plugins/ozonseller/' . $file, false, 'shop', false);
        if (file_exists($custom_path)) {
            $path = $custom_path;
        } else {
            $path = wa()->getAppPath('plugins/ozonseller/lib/config/data/' . $file);
        }
        if ($path_only) {
            $data = $path;
        } else {
            $data = include($path);
        }
        return $data;
    }

    public static function getAccountSettingsType($account_id, $type, $value_only = true)
    {
        $source_settings = include(wa()->getAppPath('plugins/ozonseller/lib/config/settings.php'));
        $full_settings = wa()->getPlugin('ozonseller')->getSettings(null, $account_id);
        $subjects = [$type];
        switch ($type) {
            case 'general':
                $subjects[] = 'general_features';
                break;
            case 'prices':
                $subjects[] = 'prices_extend';
                break;
            case 'orders':
                $subjects[] = 'orders_extend';
                break;
        }
        $trueSettings = [];
        foreach ($source_settings as $name => $setting) {
            if (in_array(ifset($setting['subject']), $subjects) || self::checkExceptionalSetting($type, $name)) {
                if ($value_only) $trueSettings[$name] = ifset($full_settings[$name]);
                else {
                    $set = $setting;
                    $set['value'] = ifset($full_settings[$name]);
                    $trueSettings[$name] = $set;
                }
            }
        }
        return $trueSettings;
    }

    private static function checkExceptionalSetting($type, $set_id) {
        $exSettings = [];
        switch ($type) {
            case 'orders':
                $exSettings = ['shop_orders'];
                break;
        }
        return in_array($set_id, $exSettings);
    }

    public static function convertDateFromUtc($string)
    {
        if (!$string) return '';
        $date = new DateTime($string, new DateTimeZone('UTC'));
        $date->setTimezone(new DateTimeZone(waDateTime::getDefaultTimeZone()));
        return $date->format('Y-m-d H:i:s');
    }

    /**
     * @param string $message
     * @return void
     * @throws waException
     */
    public static function setAnnouncement($message)
    {
        $params = [
            'app_id' => 'shop',
            'text' => shopOzonsellerPluginTextHelper::TEXT_OZONSELLER . ': ' . $message,
            'datetime' => date('Y-m-d H:i:s')
        ];
        try {
            (new waAnnouncementModel())->insert($params);
        } catch (Exception $e) {
            self::setLog($e->getMessage(), 'error');
        }
    }

    /**
     * @param string $message
     * @param string $type error|debug|null
     * @param null $data
     */
    public static function setLog($message, $type = '', $data = null, $source = true)
    {
        switch ($type) {
            case 'error':
                $file = shopOzonsellerPluginTextHelper::FILE_LOG_ERROR;
                break;
            case 'debug':
                $file = shopOzonsellerPluginTextHelper::FILE_LOG_DEBUG;
                break;
            case 'ext':
                $file = shopOzonsellerPluginTextHelper::FILE_LOG_DEBUG_EXT;
                break;
            case 'import':
                $file = shopOzonsellerPluginTextHelper::FILE_LOG_IMPORT;
                break;
            default:
                $file = shopOzonsellerPluginTextHelper::FILE_LOG;
        }
        if ($source) {
            if (is_object($source)) {
                $message = $message . PHP_EOL . $source->getTraceAsString();
            } elseif (function_exists('debug_backtrace')) {
                $bt = debug_backtrace(1)[0];
                $source = str_replace(wa()->getAppPath('plugins/'), '', $bt['file']) . ' (' . $bt['line'] . ')' . ($message ? PHP_EOL . '------------------' : '');
                $message = $source . PHP_EOL . $message;
            }
        }

        if ($message && wa()->getEnv() === 'backend') $message = 'UI' . wa()->whichUI('shop') . '. ' . $message;
        if ($message) waLog::log($message, $file);
        if ($data) {
            waLog::dump($data, $file);
        }
    }

    public static function sortArray($data, $field, $index = 'asc', $with_keys = false)
    {
        if (!$data) return $data;
        $result = array();
        foreach ($data as $key => $value) {
            $tmp_arr[$key] = $value[$field];
        }
        if ($index == 'asc') {
            asort($tmp_arr, SORT_LOCALE_STRING);
        } else {
            arsort($tmp_arr, SORT_LOCALE_STRING);
        }

        $keys = array_keys($tmp_arr);
        foreach ($keys as $key) {
            if ($with_keys) {
                $result[$key] = $data[$key];
            } else {
                $result[] = $data[$key];
            }
        }
        return $result;
    }

    public static function getShopFeatureValues($feature)
    {
        $values = [];
        $fvalues = (new shopFeatureModel())->getValues([$feature]);
        if ($fvalues[0]['values']) {
            if (is_object($fvalues[0]['values'][array_keys($fvalues[0]['values'])[0]])) {
                foreach ($fvalues[0]['values'] as $value) {
                    switch ($feature['type']) {
                        case 'range.double':
                            $values[$value['id']] = 'от ' . $value['begin_base_unit'] . ' — до ' . $value['end_base_unit'];
                            break;
                        default:
                            $values[$value['id']] = $value['value'];
                    }
                }
            } else {
                $values = $fvalues[0]['values'];
            }
        }
        return $values;
    }

    public static function getDimensionUnits()
    {
        $units = null;
        $config = wa('shop')->getConfig();
        $files = array(
            $config->getConfigPath('dimension.php'),
            $config->getConfigPath('data/dimension.php', false),

        );
        foreach ($files as $file_path) {
            if (file_exists($file_path)) {
                $config = include($file_path);
                if ($config && is_array($config)) {
                    $units = $config;
                    break;
                }
            }
        }
        return $units;
    }

    public static function getCountryIso($name)
    {
        $countries = [
            'РОССИЯ' => 'Russian Federation',
            'РОССИЙСКАЯ ФЕДЕРАЦИЯ' => 'Russian Federation',
            'УКРАИНА' => 'Ukraine',
            'КАЗАХСТАН' => 'Kazakhstan',
            'БЕЛАРУСЬ' => 'Belarus',
            'БЕЛОРУССИЯ' => 'Belarus',
            'МОЛДОВА' => 'Moldova, Republic of',
            'УЗБЕКИСТАН' => 'Uzbekistan',
            'ТАДЖИКИСТАН' => 'Tajikistan'
        ];
        if (!isset($countries[mb_strtoupper($name)])) return null;
        if (!$data = (new waCountryModel())->getByField('name', $countries[mb_strtoupper($name)])) return null;
        return $data['iso3letter'];
    }

    public static function getVueComponent($name)
    {
        $newUi = wa()->whichUI() !== '1.3';
        $view = wa()->getView();
        switch ($name) {
            case 'actionButton':
                $file = $newUi ? 'actionButton.vue' : 'actionButton_old.vue';
                $template = wa()->getAppPath('plugins/ozonseller/templates/actions/' . $file);
                break;
            case 'gradusnik':
                $file = $newUi ? 'gradusnik.vue' : 'gradusnik_old.vue';
                $template = wa()->getAppPath('plugins/ozonseller/templates/actions/' . $file);
                break;
            case 'matchFeature':
                $file = $newUi ? 'matchFeature.vue' : 'matchFeature_old.vue';
                $template = wa()->getAppPath('plugins/ozonseller/templates/actions/' . $file);
                $advParams = (new shopProductParamsModel())->query('select distinct name from shop_product_params order by name')->fetchAll(null, 1);
                $sets = (new shopSetModel())->where('type=0')->order('name')->fetchAll();
                $richOptions = false;
                if (shopOzonsellerPluginHelper::checkInstallPlugin('richcontent')) {
                    try {
                        $richOptions = shopRichcontentPlugin::getTemplatesList();
                    } catch (Exception $e) {
                        shopOzonsellerPluginHelper::setLog($e->getMessage() . ' (rich)', 'error');
                    }
                }
                $videoFetatures = shopOzonsellerPluginOzonCategoryModel::VIDEO_FEATURES;
                $units = shopOzonsellerPluginHelper::getDimensionUnits();
                $ozonFeatureTypes = [
                    'String' => shopOzonsellerPluginTextHelper::VTYPE_STRING,
                    'ImageURL' => shopOzonsellerPluginTextHelper::VTYPE_IMAGEURL,
                    'URL' => shopOzonsellerPluginTextHelper::VTYPE_URL,
                    'text' => shopOzonsellerPluginTextHelper::VTYPE_MULTILINE,
                    'multiline' => shopOzonsellerPluginTextHelper::VTYPE_MULTILINE,
                    'Decimal' => shopOzonsellerPluginTextHelper::VTYPE_DECIMAL,
                    'Integer' => shopOzonsellerPluginTextHelper::VTYPE_INTEGER,
                    'Boolean' => shopOzonsellerPluginTextHelper::VTYPE_BOOL,
                    'child' => shopOzonsellerPluginTextHelper::VTYPE_CHILD
                ];
                $matches = (new shopOzonsellerPluginFeatureValuesMatchesModel())->getAllMatches();
                $view->assign([
                    'advParams' => json_encode($advParams),
                    'sets' => json_encode($sets),
                    'rich' => json_encode($richOptions),
                    'richContentId' => json_encode(shopOzonsellerPluginOzonCategoryModel::RICH_CONTENT_ID),
                    'ozonFeatureTypes' => json_encode($ozonFeatureTypes),
                    'videoFeatures' => json_encode($videoFetatures),
                    'matches' => json_encode($matches),
                    'units' => json_encode($units)
                ]);
                break;
            case 'accountsMenu':
                $accounts = (new shopOzonsellerPluginAccountModel())->getAll('id');
                $view->assign(compact('newUi', 'accounts'));
                $template = wa()->getAppPath('plugins/ozonseller/templates/actions/accountsMenu.vue');
                break;
            case 'cronInfo':
                $template = wa()->getAppPath('plugins/ozonseller/templates/actions/' . 'cronInfo.vue');
                break;
            case 'combiControl':
                $template = wa()->getAppPath('plugins/ozonseller/templates/actions/combiControl.vue');
                break;
            default:
                return false;
        }
        return $view->fetch($template);
    }

    public static function checkPhpVersion()
    {
        if (!$requirements = include wa()->getAppPath('plugins/ozonseller/lib/config/data/requirements.php')) return false;
        if (!isset($requirements['php']['version'])) return true;
        preg_match_all('/^([<>]?=?)?(\d+(\.\d+)*)$/', $requirements['php']['version'], $matches, PREG_SET_ORDER, 0);
        if (!$result = version_compare(phpversion(), $matches[0][2], $matches[0][1])) {
            $message = sprintf(shopOzonsellerPluginTextHelper::ERROR_PHP_VERSION, $matches[0][1], $matches[0][2], phpversion());
            self::setLog($message);
            self::setAnnouncement(wa()->getPlugin('ozonseller')->getName() . ': ' . $message);
        }
        return $result;
    }

    public static function isDebug($with_vue = true)
    {
        $debug = waSystemConfig::isDebug();
        if ($debug && $with_vue) {
            if (!file_exists(wa()->getAppPath('plugins/ozonseller/js/vendors/vue/vue.global.js'))) $debug = false;
        }
        return $debug;
    }

    public static function preIntData($data)
    {
        if (!is_array($data)) return $data;
        foreach ($data as $key => $value) {
            if (is_array($value)) $data[$key] = self::preIntData($value);
            elseif (wa_is_int($value)) $data[$key] = (int)$value;
        }
        return $data;
    }

    public static function checkLicense($premium = false)
    {
        // return waLicensing::check('shop/plugins/ozonseller')->isPremium();
        return true;
    }

    public static function getDimWithText($value, $dim)
    {
        $dims = shopOzonsellerPluginTextHelper::DIMS;
        if (isset($dims[$dim])) {
            $value .= ' ' . $dims[$dim];
        }
        return $value;
    }

}