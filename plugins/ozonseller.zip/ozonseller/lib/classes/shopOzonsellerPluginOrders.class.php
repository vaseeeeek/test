<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginOrders
{
    protected $account_id;
    protected $settings;
    protected $model_order;
    protected $model_order_log;
    protected $model_order_params;
    protected $model_product;
    protected $model_product_stocks;
    protected $model_ozon_product;
    protected $ozon_stocks;
    protected $sp_methods = [];
    protected $shop_stocks;
    protected $workflow;

    public function __construct($account_id = null)
    {
        shopOzonsellerPluginHelper::validatePlugin($this, 'classes/shopOzonsellerPluginOrders.class.php');
        $is_event = func_num_args() !== 0;
        $this->ozon_stocks = [];
        if ($account_id && wa_is_int($account_id)) {
            $this->account_id = $account_id;
            $this->settings = wa()->getPlugin('ozonseller')->getSettings(null, $account_id);
            $this->ozon_stocks = self::getOzonStocks($account_id);
            if (!$this->settings['contact_id'] || !(new waContact($this->settings['contact_id']))->getId()) {
                if (!$is_event) {
                    throw new waException(shopOzonsellerPluginTextHelper::ERROR_SETTING_CONTACT_ID);
                }
            }
        }
        $this->model_product = new shopProductModel();
        $this->model_product_stocks = new shopProductStocksModel();
        $this->model_order_log = new shopOrderLogModel();
        $this->model_order = new shopOrderModel();
        $this->model_order_params = new shopOrderParamsModel();
        $this->model_ozon_product = new shopOzonsellerPluginProductModel();
        $this->workflow = new shopWorkflow();
        $this->shop_stocks = shopHelper::getStocks();
    }

    public function processingOrders($schema, $ozon_orders)
    {
        foreach (['payment', 'shipping'] as $type) {
            $this->sp_methods[$type] = shopOzonsellerPlugin::getPaymentsShippingsMethods($type, false);
        }
        if (!in_array($schema, ['fbo', 'fbs'])) {
            throw new waException(sprintf(shopOzonsellerPluginTextHelper::ERROR_INCORRECT_PARAMETER, 'schema'));
        }
        $orders_data = [];
        if ($ozon_posting_ids = array_column($ozon_orders, 'posting_number')) {
            $query = <<<SQL
select sop.order_id,so.state_id,sop.value ozon_posting_number from shop_order_params sop 
    join shop_order so on sop.order_id=so.id 
where sop.name="ozon_posting_number" and sop.value in (i:ids)
SQL;
            $orders_data = $this->model_order_params->query($query, ['ids' => $ozon_posting_ids])->fetchAll('ozon_posting_number');
        }
        foreach ($ozon_orders as $ozon_order) {
            if ($this->settings['order_by_stocks']) {
                if (!$this->settings['stock_ids'][$ozon_order['delivery_method']['warehouse_id']]) continue;
            }
            if ($ozon_order['status'] == 'cancelled' && ifset($ozon_order['cancellation']['cancelled_after_ship'])) {
                $ozon_order['status'] = 'cancelled_after_ship';
            }
            try {
                if (isset($orders_data[$ozon_order['posting_number']])) {
                    $this->updateOrder($ozon_order, $orders_data[$ozon_order['posting_number']]['order_id']);
                } else {
                    $this->createOrder($schema, $ozon_order);
                }
            } catch (waException $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            }
        }
    }

    protected function updateOrder($ozon_order, $order_id, $check_status = true, $hard_action = false)
    {
        $order_params = $this->model_order_params->get($order_id);
        if (isset($order_params['ozon_products_md5'])) {
            $order_params['ozon_products_md5'] = json_decode($order_params['ozon_products_md5'], true);
        }
        if ($check_status) {
            $breaker = true;
            if ($ozon_order['status'] == ifset($order_params['ozon_order_status'], null) ||
                (isset($ozon_order['in_process_at']) && shopOzonsellerPluginHelper::convertDateFromUtc($ozon_order['in_process_at']) == $order_params['ozon_in_process_at']) ||
                (isset($ozon_order['shipment_date']) && shopOzonsellerPluginHelper::convertDateFromUtc($ozon_order['shipment_date']) == $order_params['ozon_shipment_date']) ||
                $ozon_order['posting_number'] == ifset($order_params['ozon_posting_number'])
            ) {
                $breaker = false;
            }
            if ($breaker && isset($order_params['ozon_products_md5'])) {
                if ($order_params['ozon_products_md5']['changed']) $breaker = false;
                else $breaker = $this->getProductsHash($ozon_order['products']) === $order_params['ozon_products_md5']['hash'];
            }
            if (
                $breaker &&
                (
                    $order_params['ozon_schema'] != 'rfbs' ||
                    $order_params['ozon_address_tail_md5'] == md5($ozon_order['customer']['address']['address_tail'])
                )
            ) return;
        }
        switch ($order_params['ozon_schema']) {
            case 'fbo':
                if ($this->settings['schema'] == 'fbs') return;
                break;
            case 'fbs':
            case 'rfbs':
                if ($this->settings['schema'] == 'fbo') return;
                break;
            default:
                throw new waException(shopOzonsellerPluginTextHelper::ERROR_UNEXPECTED_MODE . '(' . $order_params['ozon_schema'] . ', order_id ' . $order_id . ')');
        }
        $ozon_params = $this->generateOrderParams($ozon_order);
        if ($order_params['ozon_schema'] == 'rfbs') {
            $contact_data = $this->getContactByOzonOrder($ozon_order, 'rfbs');
            $ozon_params = array_merge($ozon_params, ifempty($contact_data['address']));
            $ozon_params['ozon_address_tail_md5'] = md5($ozon_order['customer']['address']['address_tail']);
        }
        if (isset($order_params['ozon_products_md5'])) {
            if ($order_params['ozon_products_md5']['changed'] || $order_params['ozon_products_md5']['hash'] != $ozon_params['ozon_products_md5']['hash']) {
                $ozon_params['ozon_products_md5']['changed'] = true;
            }
        }
        $ozon_params['ozon_products_md5'] = json_encode($ozon_params['ozon_products_md5']);
        foreach ($ozon_params as $key => $value) {
            if (ifset($order_params[$key]) != $value) {
                $this->model_order_params->set($order_id, array_merge($order_params, $ozon_params));
                break;
            }
        }
        if ($order_params['ozon_order_status'] != $ozon_order['status']) {
            $params = ['posting_number' => $ozon_order['posting_number'], 'ozon_state_id' => $ozon_order['status']];
            wa()->event('ozonseller.change_order', $params);
        }
        if (!$action_id = ifempty($this->settings['ozon_order_status']['fbo'][$ozon_order['status']])) return;
        if (!$action = $this->workflow->getActionById($action_id)) {
            if (defined('shopOzonsellerPluginTextHelper::OZON_ORDER_' . strtoupper($ozon_order['status']))) {
                $const = constant('shopOzonsellerPluginTextHelper::OZON_ORDER_' . strtoupper($ozon_order['status']));
            } else {
                $const = $ozon_order['status'];
            }
            shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_INVALID_ORDER_ACTION, $action_id, $const), 'error');
            return;
        }
        if ($hard_action || $order_params['ozon_order_status'] != $ozon_order['status']) {
            $action->run($order_id);
        }
    }

    protected function createOrder($schema, $ozon_order)
    {
        if ($this->settings['debug'] == 1) {
            shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::TEXT_NEW_ORDER, '', $ozon_order);
        }
        $items = [];
        if ($schema == 'fbs') {
            if ($warehoise_id = ifset($ozon_order['delivery_method']['warehouse_id'])) {
                if (isset($this->ozon_stocks[$warehoise_id]) && $this->ozon_stocks[$warehoise_id]['is_rfbs']) {
                    $schema = 'rfbs';
                }
            }
        }
        $contact_data = $this->getContactByOzonOrder($ozon_order, $schema);
        $contact = $contact_data['contact'];
        $stock_skus = [];
        $skus = $this->model_ozon_product->getSkusByOfferIds($this->account_id, array_column($ozon_order['products'], 'offer_id'));
        $model_currency = new shopCurrencyModel();
        if (!$ozon_order['products']) {
            shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_ORDER_NO_PRODUCTS, $ozon_order['posting_number']));
            return;
        }
        foreach ($ozon_order['products'] as $pdata) {
            $order_price = 0;
            if (isset($skus[$pdata['offer_id']])) {
                $sku = $skus[$pdata['offer_id']];
                $stock_skus[$sku['id']] = $sku;
            } else {
                try {
                    $empty_ids = $this->getEmptyIds();
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                }
                $sku = [
                    'id' => $empty_ids['sku_id'],
                    'product_id' => $empty_ids['product_id'],
                    'sku' => null,
                    'purchase_price' => 0,
                    'compare_price' => 0,
                    'name' => $pdata['name'],
                    'currency' => 'RUB'
                ];
            }
            $item = [
                'contact_id' => $contact->getId(),
                'product_id' => $sku['product_id'],
                'sku_id' => $sku['id'],
                'quantity' => $pdata['quantity'],
                'type' => 'product',
                'product' => $this->model_product->getById($sku['product_id']),
                'sku_code' => $sku['sku'],
                'purchase_price' => $sku['currency'] !== 'RUB' ? $model_currency->convert($sku['purchase_price'], $sku['currency'], 'RUB') : $sku['purchase_price'],
                'compare_price' => $sku['currency'] !== 'RUB' ? $model_currency->convert($sku['compare_price'], $sku['currency'], 'RUB') : $sku['compare_price'],
                'sku_name' => $sku['name'],
                'currency' => 'RUB',
                'price' => $pdata['price'],
                'name' => $pdata['name']
            ];
            if (isset($ozon_order['delivery_method'])) {
                $item_stock_id = ifset($this->settings['order_params']['fbs'][$ozon_order['delivery_method']['warehouse_id']]['stock_id'], 'auto');
                if ($item_stock_id !== 'auto' && !wa_is_int($item_stock_id)) {
                    if (isset($this->shop_stocks[$item_stock_id])) {
                        $skuStoks = $this->model_product_stocks->getBySkuId([$sku['id']]);
                        foreach ($this->shop_stocks[$item_stock_id]['substocks'] as $substock_id) {
                            if (isset($skuStoks[$sku['id']][$substock_id]) && $skuStoks[$sku['id']][$substock_id]['count']) {
                                $new_stock_id = $substock_id;
                                if ((float)$skuStoks[$sku['id']][$substock_id]['count'] >= (float)$item['quantity']) {
                                    $item_stock_id = $new_stock_id;
                                    break;
                                }
                            }
                        }
                    }
                }
            } else {
                $item_stock_id = ifset($this->settings['order_params']['fbo']['stock_id'], 'auto');
            }
            if ($item_stock_id && $item_stock_id != 'auto') {
                $item['stock_id'] = $item_stock_id;
            }
            $items[] = $item;
            $order_price += $pdata['price'];
        }
        $order_params = $this->generateOrderParams($ozon_order, $schema, true);
        $order_params['ozon_products_md5'] = json_encode($order_params['ozon_products_md5']);
        if ($schema == 'rfbs') {
            $order_params = array_merge($order_params, ifempty($contact_data['address']));
            $order_params['ozon_address_tail_md5'] = md5($ozon_order['customer']['address']['address_tail']);
        }
        $order = [
            'contact' => $contact,
            'items' => $items,
            'total' => $order_price,
            'currency' => 'RUB',
            'discount' => 0,
            'shipping' => 0,
            'comment' => null,
            'create_datetime' => shopOzonsellerPluginHelper::convertDateFromUtc($ozon_order['in_process_at']),
            'params' => $order_params
        ];
        if ($this->settings['order_comment']) {
            $ozon_shipment_date = ifset($order['params']['ozon_shipment_date']);
            if (defined('shopOzonsellerPluginTextHelper::OZON_ORDER_' . strtoupper($ozon_order['analytics_data']['delivery_type']))) {
                $const = constant('shopOzonsellerPluginTextHelper::TEXT_DELIVERY_' . strtoupper($ozon_order['analytics_data']['delivery_type']));
            } else {
                $const = $ozon_order['analytics_data']['delivery_type'];
            }
            $order['comment'] = sprintf(shopOzonsellerPluginTextHelper::TEXT_DELIVERY_COMMENT, $ozon_order['posting_number'], $ozon_order['delivery_method']['tpl_provider'], $const, ifset($ozon_order['customer']['address']['address_tail']), sprintf(shopOzonsellerPluginTextHelper::TEXT_DELIVERY_COMMENT_SHIPMENT_DATE, $ozon_shipment_date));
        }
        foreach (['shipping', 'payment'] as $sptype) {
            if ($schema == 'fbo') {
                $sp_id = ifset($this->settings['order_params[fbo][' . $sptype . ']'], 0);
            } else {
                $sp_id = ifset($this->settings['order_params']['fbs'][$ozon_order['delivery_method']['warehouse_id']][$sptype], 0);
            }
            if ($sp_id && isset($this->sp_methods[$sptype][$sp_id])) {
                $order['params'][$sptype . '_id'] = $sp_id;
                $order['params'][$sptype . '_name'] = $this->sp_methods[$sptype][$sp_id]['name'];
                $order['params'][$sptype . '_plugin'] = $this->sp_methods[$sptype][$sp_id]['plugin'];
            }
            if ($sptype === 'shipping' && ifset($this->settings['shipping_rate_id'])) {
                $order['params']['shipping_rate_id'] = $this->settings['shipping_rate_id'];
            }
        }
        try {
            if (!$order_id = $this->workflow->getActionById('create')->run($order)) {
                shopOzonsellerPluginHelper::setLog(shopOzonsellerPluginTextHelper::ERROR_FAIL_CREATE_ORDER, 'error', $order);
            }
        } catch (Exception $e) {
            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
        }
        $this->model_order_log->updateByField(['order_id' => $order_id, 'action_id' => 'create'], ['datetime' => $order['create_datetime']]);
        $this->model_order->updateById($order_id, ['create_datetime' => $order['create_datetime']]);
        $create_date = strtotime($order['create_datetime']);
        $paid_data = [
            'paid_date' => date('Y-m-d', $create_date),
            'paid_month' => date('m', $create_date),
            'paid_year' => date('Y', $create_date),
            'paid_quarter' => round(ceil(date('m', $create_date) / 3))
        ];
        $this->model_order->updateById($order_id, $paid_data);

        $params = ['posting_number' => $ozon_order['posting_number'], 'ozon_state_id' => $ozon_order['status']];
        wa()->event('ozonseller.change_order', $params);

        if ($ozon_order['status'] !== 'awaiting_package') {
            $this->updateOrder($ozon_order, $order_id, false, true);
        }

        if ($this->settings['sync_additionals']['order'] && $stock_skus) {
            try {
                $socket = new shopOzonsellerPluginOzonApi($this->account_id);
                $preparator = new shopOzonsellerPluginPreparator($this->account_id);
                $new_skus = (new shopProductSkusModel())->getByField('id', array_column($stock_skus, 'id'), 'id');
                $model_public = new shopOzonsellerPluginProductModel();
                $model_log = new shopOzonsellerPluginFailLogModel();
                foreach ($stock_skus as $sku_id => $stock_sku) {
//                    if ($stock_sku['count'] != $new_skus[$sku_id]['count']) {
                    $fields = ['account_id' => $this->account_id, 'sku_id' => $sku_id];
                    if (!$public = $model_public->getByField($fields, true)) continue;
                    $items = $preparator->getQuantityByPublics($public);
                    if ($items) {
                        try {
                            $result = $socket->updateProductsStocks($items);
                            if ($errors = shopOzonsellerPlugin::preparePQResult('quantity', $result)) {
                                $publics = $this->model_ozon_product->getDataForFailLog($this->account_id, array_keys($errors));
                                foreach ($publics as $public) {
                                    $public['errors'] = $errors[$public['offer_id']];
                                    $model_log->updateLog($this->account_id, $public);
                                }
                            }
                        } catch (Exception $e) {
                            shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                        }
                    }
//                    }
                }
            } catch (Exception $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage());
            }
        }
        return $order_id;
    }

    protected function getContactByOzonOrder($ozon_order, $schema)
    {
        if ($schema == 'rfbs' && !isset($ozon_order['customer'])) {
            $schema = 'fbs';
        }
        $contact_data = ['contact' => null, 'address' => null];
        switch ($schema) {
            case 'rfbs':
                $contact_id = $data = null;
                $emails = $phones = [];
                if ($exist_data = (new waContactDataModel())->getByField(['field' => 'ozon_id', 'value' => $ozon_order['customer']['customer_id']])) {
                    $contact_id = $exist_data['contact_id'];
                }
                $aname = explode(' ', $ozon_order['customer']['name']);
                $name = ['firstname' => array_shift($aname)];
                if (count($aname)) {
                    switch (count($aname)) {
                        case 1:
                            $name['lastname'] = array_shift($aname);
                            break;
                        case 2:
                            $name['lastname'] = array_shift($aname);
                            $name['middlename'] = array_pop($aname);
                            break;
                        default:
                            $name['middlename'] = array_pop($aname);
                            $name['lastname'] = implode(' ', $aname);
                            break;
                    }
                }
                $data = [
                    'name' => $name['firstname'] . ' ' . ifset($name['lastname']),
                    'firstname' => $name['firstname'],
                    'middlename' => ifset($name['middlename']),
                    'lastname' => ifset($name['lastname']),
                ];

                if ($ozon_order['customer']['customer_email']) {
                    foreach (explode(',', $ozon_order['customer']['customer_email']) as $mail) {
                        $emails[] = [
                            'value' => trim($mail),
                            'ext' => 'work'
                        ];
                    }
                } elseif ($this->settings['rfbs_customer_email']) {
                    $emails[] = [
                        'value' => trim($this->settings['rfbs_customer_email']),
                        'ext' => 'work'
                    ];
                }
                if ($emails) {
                    $data['email'] = $emails;
                }

                if ($ozon_order['customer']['phone']) {
                    foreach (explode(',', $ozon_order['customer']['phone']) as $phone) {
                        $phones[] = [
                            'value' => trim($phone),
                            'ext' => 'work'
                        ];
                    }
                }
                if ($phones) {
                    $data['phone'] = $phones;
                }

                $ozon_address = $ozon_order['customer']['address'];
                $address = [
                    'shipping_address.street' => '',
                    'shipping_address.city' => ifempty($ozon_address['city']),
                    'shipping_address.region' => '',
                    'shipping_address.zip' => ifempty($ozon_address['zip_code'], ''),
                    'shipping_address.country' => shopOzonsellerPluginHelper::getCountryIso($ozon_address['country']),
                ];
                $ciso3 = $address['shipping_address.country'];
                if (ifempty($ozon_address['region']) && $ciso3) {
                    $model_region = new waRegionModel();
                    $where = <<<SQL
country_iso3="$ciso3" and upper(name) like upper(?)
SQL;

                    if (!$region = $model_region->where($where, '%' . $ozon_address['region'] . '%')->fetchAssoc()) {
                        $ar = explode(' ', $ozon_address['region']);
                        foreach ($ar as $pr) {
                            if ($region = $model_region->where($where, '%' . $pr . '%')->fetchAssoc()) break;
                        }
                    }
                    if ($region) {
                        $address['shipping_address.region'] = $region['code'];
                    }
                }

                if (ifempty($ozon_address['city'])) {
                    if ($street = mb_substr($ozon_address['address_tail'], mb_strpos($ozon_address['address_tail'], $ozon_address['city'] . ',') + mb_strlen($ozon_address['city']) + 1)) {
                        $address['shipping_address.street'] = trim($street);
                    }
                }

                $contact = new waContact($contact_id, $data);
                $contact->save($data);
                (new waContactDataModel())->insert(['contact_id' => $contact->getId(), 'field' => 'ozon_id', 'value' => $ozon_order['customer']['customer_id']], 1);
                $contact_data['contact'] = $contact;
                $contact_data['address'] = $address;
                break;
            default:
                $contact_data['contact'] = (new waContact($this->settings['contact_id']));
                break;
        }
        return $contact_data;
    }

    public static function getOzonStocks($account_id)
    {
        $cahce = new waSerializeCache('ozon_stocks_data_' . $account_id, 1800);
        if ($cahce->isCached()) {
            $data = $cahce->get();
        } else {
            $data = [];
            if ($stocks = shopOzonsellerPlugin::getOzonStocks($account_id)) {
                $socket = new shopOzonsellerPluginOzonApi($account_id);
                $methods = $socket->getOzonDeliveryMethods();
                foreach ($stocks as $stock) {
                    $data[$stock['warehouse_id']] = $stock;
                    $data[$stock['warehouse_id']]['methods'] = isset($methods[$stock['warehouse_id']]) ? $methods[$stock['warehouse_id']] : [];
                }
            }
            $cahce->set($data);
        }
        return $data;
    }

    public function handlerOrderActions($params)
    {
        $order_params = $this->model_order_params->get($params['order_id']);
        if (!ifset($order_params['ozon_account_id'])) return;
        try {
            $settings = wa()->getPlugin('ozonseller')->getSettings(null, $order_params['ozon_account_id']);
        } catch (waException $e) {
            return;
        }
        $order_status = $settings['ozon_order_status']['fbs'];
        if (!ifset($order_status[$params['action_id']]) && $order_status == '1') return;
        if ($order_status[$params['action_id']]) {
            if (!isset($order_params['ozon_schema']) || !ifset($order_params['ozon_posting_number']) || $order_params['ozon_schema'] != 'fbs') return;
            try {
                $socket = new shopOzonsellerPluginOzonApi($order_params['ozon_account_id']);
                $socket->setOzonOrderStatus($order_params['ozon_posting_number'], $order_status[$params['action_id']]);
            } catch (Exception $e) {
                shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
            }
        }
        if (isset($order_params['ozon_order_status']) && $settings['order_collect'] == $params['action_id'] && $order_params['ozon_order_status'] == 'awaiting_packaging') {
            if ($settings['order_collect_weight_restriction']) {
                $orderWeight = $this->getOrderWeight((new shopOrderItemsModel())->getItems($params['order_id']));
            } else $orderWeight = 0;
            if (!$settings['order_collect_weight_restriction'] || $orderWeight < $settings['order_collect_weight_restriction']) {
                try {
                    $this->collectOrder($order_params['ozon_account_id'], $order_params['ozon_posting_number']);
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error', ['order_id' => $params['id']]);
                }
            }
        }
    }

    public function handlerBackendOrder($order)
    {
        if (!isset($order['params']['ozon_order_id']) || !isset($order['params']['ozon_account_id'])) return null;
        if (!$account_id = ifset($order['params']['ozon_account_id'])) return null;
        $settings = wa()->getPlugin('ozonseller')->getSettings(null, $account_id);
        $debug = $settings['debug'];
        $warnings = [];
        $print_label = ($order['params']['ozon_order_status'] == 'awaiting_deliver');
        $order_collect_button = $settings['order_collect'] == '1' && $order['params']['ozon_order_status'] == 'awaiting_packaging';
        if (ifset($order['params']['ozon_order_status'])) {
            if (defined('shopOzonsellerPluginTextHelper::OZON_ORDER_' . strtoupper($order['params']['ozon_order_status']))) {
                $const = constant('shopOzonsellerPluginTextHelper::OZON_ORDER_' . strtoupper($order['params']['ozon_order_status']));
            } else {
                $const = $order['status'];
            }
            $order['params']['ozon_order_status'] = $const;
        }
        $schema = strtoupper($order['params']['ozon_schema']);
        $collect = $tracking = false;
        $cancel_statuses = [shopOzonsellerPluginTextHelper::OZON_ORDER_CANCEL, shopOzonsellerPluginTextHelper::OZON_ORDER_CANCELLED, shopOzonsellerPluginTextHelper::OZON_ORDER_CANCELLED_AFTER_SHIP];
        if ($order['params']['ozon_order_status'] == constant('shopOzonsellerPluginTextHelper::OZON_ORDER_' . strtoupper('awaiting_packaging'))) {
            if ($settings['order_collect_weight_restriction']) $orderWeight = $this->getOrderWeight($order['items']);
            else $orderWeight = 0;
            if (!$settings['order_collect_weight_restriction'] || $orderWeight < $settings['order_collect_weight_restriction']) $collect = true;
            if (!$collect) {
                if (is_bool($orderWeight)) {
                    shopOzonsellerPluginHelper::setLog(sprintf(shopOzonsellerPluginTextHelper::ERROR_ORDER_WEIGHT, $order['id_str']), 'error');
                } else {
                    $warnings[] = sprintf(shopOzonsellerPluginTextHelper::ERROR_ORDER_MAX_WEIGHT, $settings['order_collect_weight_restriction']);
                }
            }
        }
        $ozon_stocks = self::getOzonStocks($account_id);
        $order_ozon_stock_id = ifset($order['params']['ozon_warehouse_id']);
        if ($order_ozon_stock_id && $ozon_stocks[$order_ozon_stock_id]['is_rfbs'] && !$order['params']['ozon_tracking_number']) {
            $tracking = true;
        }
        if ($order['params']['ozon_delivery_id']) {
            $order['params']['ozon_stock_name'] = ifset($ozon_stocks[$order['params']['ozon_warehouse_id']]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE);
            $order['params']['ozon_delivery_name'] = ifset($ozon_stocks[$order['params']['ozon_warehouse_id']]['methods'][$order['params']['ozon_delivery_id']]['name'], shopOzonsellerPluginTextHelper::TEXT_FAIL_DEFINE);
        }

        if (isset($order['params']['ozon_products_md5'])) $order['params']['ozon_products_md5'] = json_decode($order['params']['ozon_products_md5'], true);
        else $order['params']['ozon_products_md5'] = ['hash' => '', 'changed' => false];

        $actionButton = shopOzonsellerPluginHelper::getVueComponent('actionButton');
        $newUi = wa()->whichUI('shop') !== '1.3';
        $bannerText = false;
        if (!shopOzonsellerPluginHelper::checkInstallPlugin('ozonstat')) {
            $ozonstaUrl = 'https://www.webasyst.ru/store/plugin/shop/ozonstat/';
            $bannerDate = waRequest::cookie(shopOzonsellerPluginTextHelper::BANNER_COOKIES_KEY);
            if (!$bannerDate || (new DateTime()) > (new DateTime($bannerDate)) ) {
                if (wa()->getUser()->getRights('installer')) $ozonstaUrl = wa()->getAppUrl('installer') . 'store/plugin/shop/ozonstat/';
                $bannerText = sprintf(shopOzonsellerPluginTextHelper::BANNER_TEXT, $ozonstaUrl);
            }
        }
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/order/') . ($newUi ? 'order.vue' : 'order.old.vue');
        $view->assign([
            'accounts' => json_encode((new shopOzonsellerPluginAccountModel())->getAllAccounts(false, 'id')),
            'shopOrder' => json_encode($order),
            'schema' => json_encode($schema),
            'collect' => json_encode($collect),
            'track' => json_encode($tracking),
            'cancel_statuses' => json_encode($cancel_statuses),
            'print_label' => json_encode($print_label),
            'collect_button' => json_encode($order_collect_button),
            'debug' => $debug,
            'warnings' => json_encode($warnings),
            'actionButton' => json_encode($actionButton, 256),
            'newUi' => json_encode($newUi),
            'bannerText' => json_encode($bannerText)
        ]);

        return array(
            'title_suffix' => null,
            'action_button' => null,
            'action_link' => null,
            'info_section' => $view->fetch($template),
        );
    }

    public function handlerOrdersCollection($params)
    {
        $collection = $params['collection'];
        $hash = $collection->getHash();
        if ($hash[0] !== 'ozonseller') {
            return false;
        }
        if ($hash[1] == 'all') {
            $collection->addJoin('shop_order_params', 'o.id = :table.order_id', 'name="ozon_order_id"');
        } else {
            $hash_parts = explode('/', $hash[1]);
            if (count($hash_parts) > 1) {
                $date = date('Y-m-d 00:00:00', strtotime($hash_parts[1]));
                $date_to = date('Y-m-d 00:00:00', strtotime($date) + 86400);
                $where = <<<SQL
:table.name='ozon_shipment_date' AND :table.value>="$date" AND :table.name='ozon_shipment_date' AND :table.value<"$date_to"
SQL;
                $collection->addJoin('shop_order_params', 'o.id = :table.order_id', $where);
                $where = <<<SQL
:table.name='ozon_order_status' AND :table.value="$hash_parts[0]"
SQL;
                $collection->addJoin('shop_order_params', 'o.id = :table.order_id', $where);
            } else {
                $where = sprintf(':table.name="ozon_order_status" and value="%s"', $hash_parts[0]);
                $collection->addJoin('shop_order_params', 'o.id = :table.order_id', $where);
            }
        }
        $collection->addTitle(shopOzonsellerPluginTextHelper::TEXT_OZON_ORDERS);
        return true;
    }

    public function handlerOrdersCollectionFilter($params)
    {
        return;
    }

    public function handlerOrdersCollectionPrepared($params)
    {
        return;
    }

    public function handlerWorkflowPrepare($params)
    {
        if ($account_id = (new shopOrderParamsModel())->select('value')->where('name="ozon_account_id"')->fetchField('value')) {
            if ($restriction = (int)wa()->getPlugin('ozonseller')->getSettings('order_collect_weight_restriction', $account_id)) {
                $order_id = waRequest::post('id');
                $action = waRequest::post('action_id');
                if ($action === wa()->getPlugin('ozonseller')->getSettings('order_collect', $account_id)) {
                    $items = (new shopOrderItemsModel())->getItems($order_id);
                    if ($restriction < $this->getOrderWeight($items)) {
                        $data = [
                            'order_id' => $order_id,
                            'action_id' => $action,
                            'before_state_id' => '',
                            'after_state_id' => '',
                            'text' => shopOzonsellerPluginTextHelper::ERROR_ORDER_MAX_WEIGHT_ACTION
                        ];
                        (new shopOrderLogModel())->add($data);
                        return false;
                    }
                }
            }
        }
    }

    public function handlerBackendOrders()
    {
        $count_all = $this->model_order_params->countByField('name', 'ozon_order_id');
        $statuses = [];
        $setting = wa()->getPlugin('ozonseller')->getSettings('shop_orders');
        foreach ($setting as $key) {
            $statuses[$key] = [
                'name' => constant('shopOzonsellerPluginTextHelper::OZON_ORDER_' . strtoupper($key)),
                'count' => $this->model_order_params->countByField(['name' => 'ozon_order_status', 'value' => $key])
            ];
        }
        $is_debug = shopOzonsellerPluginHelper::isDebug();
        $version = wa('shop')->getPlugin('ozonseller')->getVersion();
        //TODO
//        $docs = wa()->getPlugin('ozonseller')->getSettings('schema') != 'fbo';
        $docs = false;
        $view = wa()->getView();
        $template = wa()->getAppPath('plugins/ozonseller/templates/actions/backend/orders/') . (wa()->whichUI('shop') === '1.3' ? 'orders_old.html' : 'orders.html');
        $view->assign(compact('statuses', 'count_all', 'docs', 'is_debug', 'version'));
        return array(
            'sidebar_top_li' => null,
            'sidebar_bottom_li' => null,
            'sidebar_section' => $view->fetch($template),
        );
    }

    public function handlerOrderAutocomplete($params)
    {
        if (waRequest::get('type', 'product', waRequest::TYPE_STRING_TRIM) !== 'order') {
            return;
        }
        if (!$needle = trim(waRequest::request('term', '', waRequest::TYPE_STRING_TRIM))) return;
        $order_ozon_params = [
            'name' => ['ozon_posting_number', 'ozon_order_number'],
            'value' => $needle
        ];
        $order_params = (new shopOrderParamsModel())->getByField($order_ozon_params, 'order_id');
        if (!$order_params) return;
        $orders = (new shopOrderModel())->getById(array_keys($order_params));
        foreach ($orders as &$o) {
            $o['autocomplete_item_type'] = 'order';
        }
        $original_data = (new shopBackendAutocompleteController())->ordersAutocomplete($needle);
        $orders = $orders + $original_data;
        shopHelper::workupOrders($orders);
        foreach ($orders as &$item) {
            if ($item['autocomplete_item_type'] == 'order') {
                $item['value'] = shopHelper::encodeOrderId($item['id']);
                $item['label'] = '';
                if (!empty($item['icon'])) {
                    $item['label'] .= "<i class='{$item['icon']}'></i>";
                }
                $item['label'] .= $item['value'] . " " . $item['total_str'];
                $item['label'] .= ' <span class="hint">Ozon order</span>';
                $item = array(
                    'id' => $item['id'],
                    'value' => $item['value'],
                    'label' => $item['label'],
                    'amount' => wa_currency($item['total'], $item['currency']),
                    'state' => ifset($item['state']['name'], $item['state_id']),
                    'autocomplete_item_type' => 'order',
                );
            }
        }
        echo json_encode(array_values($orders));
        exit();
    }

    protected function generateOrderParams($ozon_order, $schema = null, $is_new = false)
    {
        $order_params = [
            'ozon_order_status' => $ozon_order['status'],
            'ozon_order_number' => $ozon_order['order_number'],
            'ozon_posting_number' => $ozon_order['posting_number'],
            'ozon_in_process_at' => shopOzonsellerPluginHelper::convertDateFromUtc($ozon_order['in_process_at']),
            'ozon_shipment_date' => shopOzonsellerPluginHelper::convertDateFromUtc(ifset($ozon_order['shipment_date'])),
            'ozon_tracking_number' => ifset($ozon_order['tracking_number']),
            'ozon_cancel_reason' => ifset($ozon_order['cancellation']['cancel_reason']),
        ];
        $order_params['ozon_delivery_id'] = ifset($ozon_order['delivery_method']['id'], '');
        $order_params['ozon_warehouse_id'] = ifset($ozon_order['delivery_method']['warehouse_id'], '');
        $order_params['ozon_products_md5'] = ['hash' => $this->getProductsHash($ozon_order['products']), 'changed' => false];
        if ($is_new) {
            $new_order_params = [
                'ozon_account_id' => $this->account_id,
                'ozon_order_id' => $ozon_order['order_id'],
                'ozon_doc_task_id' => '0',
                'ozon_collect' => '0',
                'ozon_schema' => $schema,
                'storefront' => 'Ozon',
                'sales_channel' => 'Ozon (' . strtoupper($schema) . ')',
            ];
            $order_params = array_merge($order_params, $new_order_params);
        }
        return $order_params;
    }

    protected function getProductsHash($ozon_products)
    {
        $data = [];
        foreach ($ozon_products as $product) {
            $item = [];
            foreach (['offer_id', 'sku', 'quantity'] as $field) {
                $item[$field] = $product[$field];
            }
            $data[] = $item;
        }
        $data = shopOzonsellerPluginHelper::sortArray($data, 'sku');
        return md5(json_encode($data));
    }

    private function getEmptyIds()
    {
        $empty_ids = ifset($this->settings['empty_ids']);
        $change = false;
        foreach (['sku', 'product'] as $type) {
            if (!ifset($empty_ids[$type . '_id'], 0)) {
                if ($type == 'product') {
                    $model = new shopProductModel();
                } else {
                    $model = new shopProductSkusModel();
                }
                $item = $model->getById($model->where(1)->fetchField('id'));
                unset($item['id'], $item['moyskladapi_id']);
                try {
                    $empty_ids[$type . '_id'] = $model->insert($item);
                } catch (Exception $e) {
                    shopOzonsellerPluginHelper::setLog($e->getMessage(), 'error');
                    continue;
                }
                $model->deleteById($empty_ids[$type . '_id']);
                $change = true;
            }
        }
        if ($change) {
            $this->settings['empty_ids'] = $empty_ids;
            wa()->getPlugin('ozonseller')->saveSettings($this->settings);
        }
        return $empty_ids;
    }

    public function collectOrder($account_id, $posting_number)
    {
        $socket = new shopOzonsellerPluginOzonApi($account_id);
        $order_data = $socket->getPostingInfo('fbs', $posting_number);
        $items = [];
        $required = [
            'gtd' => $order_data['requirements']['products_requiring_gtd'] ? $order_data['requirements']['products_requiring_gtd'] : [],
            'country' => [],
            'mandatory_mark' => [],
            'rnpt' => []
        ];
        if (isset($order_data['products']) && is_array($order_data['products'])) {
            foreach ($order_data['products'] as $p) {
                $exemplar_info = [
                    'mandatory_mark' => $p['mandatory_mark'] ?: '',
                    'is_gtd_absent' => true,
                    'is_rnpt_absent' => true,
                ];
                foreach ($required as $key => $values) {
                    if ($values) {
                        switch ($key) {
                            case 'gtd':
                                if (in_array($p['sku'], $values)) {
                                    $exemplar_info['gtd'] = '';
                                }
                                break;
                        }
                    }
                }
                $item = [
                    'exemplar_info' => array_fill(0, $p['quantity'], $exemplar_info),
                    'product_id' => $p['sku'],
                    'quantity' => $p['quantity']
                ];

                $items[] = $item;
            }
        } else {
            throw new waException(shopOzonsellerPluginTextHelper::ERROR_OZON_ORDER_EMPTY);
        }
        $params = [
            'packages' => [['products' => $items]]
        ];
        $result = $socket->collectPosting($posting_number, $params);
        if ($order_data = $socket->getPostingInfo('fbs', $posting_number)) {
            (new shopOzonsellerPluginOrders($account_id))->processingOrders('fbs', [$order_data]);
        }
    }

    protected function getOrderWeight($items)
    {
        $data = [];
        if (!$code = wa()->getPlugin('ozonseller')->getSettings('weight_code')) return false;
        foreach ($items as $item) {
            $product_id = $item['product_id'];
            $sku_id = $item['sku_id'];
            if (!isset($data[$product_id])) {
                $product = new shopProduct($product_id);
                if (!$product->getId()) return false;

                $data[$product_id]['skus_features'] = $product->getSkuFeatures();
                if (!isset($data[$product_id]['features'])) {
                    $data[$product_id]['features'] = $product->getFeatures();
                }
            }
            $source = isset($data[$product_id]['skus_features'][$sku_id][$code]) ?: ifset($data[$product_id]['features'][$code]);
            if (!$source) return false;
            $sku_features = ifset($data[$product_id]['skus_features'][$sku_id], []);
            if (isset($sku_features[$code])) {
                $data_weight = is_array($sku_features[$code]) ? array_shift($sku_features[$code]) : $sku_features[$code];
                $weight = $data_weight['value'];
                $wunit = $data_weight['unit'];
            } elseif (isset($data[$product_id]['features'][$code])) {
                $data_weight = is_array($data[$product_id]['features'][$code]) ? array_shift($data[$product_id]['features'][$code]) : $data[$product_id]['features'][$code];
                $weight = $data_weight['value'];
                $wunit = $data_weight['unit'];
            } else return false;
            if ($weight !== null && $wunit !== null) {
                if ($wunit != shopOzonsellerPluginPreparator::UNIT_WEIGHT) {
                    $weight = shopDimension::getInstance()->convert($weight, 'weight', shopOzonsellerPluginPreparator::UNIT_WEIGHT, $wunit);
                }
            }
            return (int)$weight;
        }
    }

    public function getOrderInfoFromOzon($account_id, $posting_number, $params = [], $schema = 'fbs')
    {
        $socket = new shopOzonsellerPluginOzonApi($account_id);
        return $socket->getPostingInfo($schema, $posting_number, $params);
    }
}