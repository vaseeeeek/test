<?php
/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2021 waResearchLab
 */

class shopOzonsellerPluginPrintController extends waController
{
    protected $file_name;
    protected $file_path;

    public function display()
    {
        wa()->getResponse()->addHeader('Content-type', 'application/pdf');
        wa()->getResponse()->addHeader('Content-Disposition', 'inline; filename="' . $this->file_name . '"');
        wa()->getResponse()->addHeader('filename', $this->file_name);
        wa()->getResponse()->sendHeaders();
        echo readfile($this->file_path);
    }
}