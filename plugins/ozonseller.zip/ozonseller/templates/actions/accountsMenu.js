ozonAccounts = {
    props: ['account', 'action'],
    emits: ['setaccount'],
    data: function () {
        return {
            accounts: {$accounts}
        };
    },
    methods: {
        setAccount: function (acc_id) {
            if (this.action !== false) return;
            this.$emit('setaccount', acc_id);
        },
        getSpanClass: function (acc) {
            let spanClass = (this.action !== false) ? 'disabled' : '';
            if (acc.id-0 === this.account) spanClass += ' selected';
            return spanClass;
        }
    },
    template: {$accountsMenu},
};