{if $is_debug}
<script src="{$wa_app_static_url}plugins/ozonseller/js/vendors/vue/vue.global.js"></script>
{else}
<script src="{$wa_app_static_url}plugins/ozonseller/js/vendors/vue/vue.global.prod.js"></script>
{/if}
{literal}
<div id="ozonseller-product-publics" style="display: flex;flex-direction: column;">
<accounts-menu @setAccount="account_id=$event-0" :account="account_id" :action="runAction"></accounts-menu>
<template v-if="accounts[account_id].publics.length>0">
    <figure v-for="(item, index) in accounts[account_id].publics" class="ozonseller-product-public">
        <div>
            <strong>[`Артикул в Ozon`]: {{ item.offer_id }}</strong>
            <span style="margin-left: 300px;">
                    <i class="icon10 settings"></i>
                    <a @click="showActions(item.sku_id)" class="small ozonseller-a-dotted">[`Действия в Ozon...`]</a>
                </span>
            <table style="padding-bottom: 5px;">
                <tr>
                    <td class="ozonseller-td-name">[`Код артикула в магазине`]</td>
                    <td class="ozonseller-td-value">{{item.shop_sku}}</td>
                </tr>
                <tr>
                    <td class="ozonseller-td-name">[`Название в Ozon`]</td>
                    <td class="ozonseller-td-value">{{item.name}}</td>
                </tr>
                <tr>
                    <td class="ozonseller-td-name">[`Состояние в Ozon`]</td>
                    <td class="ozonseller-td-value">{{item.state_name}}</td>
                </tr>
                <template v-if="checkItemErrors(index)">
                    <tr v-if="item.hasOwnProperty('error_message')">
                        <td class="ozonseller-td-name">[`Причина отказа`]</td>
                        <td class="ozonseller-td-value">{{getItemErrors(index)}}</td>
                    </tr>
                </template>
                <tr>
                    <td class="ozonseller-td-name">[`Цена в Ozon`]</td>
                    <td class="ozonseller-td-value">{{ item.price }}</td>
                </tr>
                <tr>
                    <td class="ozonseller-td-name">[`Цена в магазине`]</td>
                    <td class="ozonseller-td-value">{{item.shop_price}}</td>
                </tr>
                <tr>
                    <td class="ozonseller-td-name">[`Категория в Ozon`]</td>
                    <td class="ozonseller-td-value">{{ item.category_name }}</td>
                </tr>
            </table>
            <template v-if="item.hasOwnProperty('commissions') && item.commissions.length">
                <strong class="small">[`Комиссии Озон`]</strong>
                <table class="small">
                    <tr>
                        <td class="ozonseller-td-head">[`Схема`]</td>
                        <td class="ozonseller-td-head">[`Процент`]</td>
                        <td class="ozonseller-td-head">[`Мин.комиссия`]</td>
                        <td class="ozonseller-td-head">[`Комиссия`]</td>
                        <td class="ozonseller-td-head">[`Стоимость доставки`]</td>
                        <td class="ozonseller-td-head">[`Стоимость возврата`]</td>
                    </tr>
                    <tr v-for="(com, idx) in item.commissions">
                        <td class="ozonseller-td-comm">{{com.sale_schema.toUpperCase()}}</td>
                        <td class="ozonseller-td-comm">{{com.percent}} %</td>
                        <td class="ozonseller-td-comm">{{com.min_value}}</td>
                        <td class="ozonseller-td-comm">{{com.value}}</td>
                        <td class="ozonseller-td-comm">{{com.delivery_amount}}</td>
                        <td class="ozonseller-td-comm">{{com.return_amount}}</td>
                    </tr>
                </table>
            </template>
            <div class="ozonseller-product-actions" v-if="actionSku==item.sku_id">
                <action-button @click="ozonAction('price',  item.sku_id)" title="[`Обновить цену`]" icon="icon16 dollar" action="price" :run="runAction" bclass="middle"></action-button>
                <action-button @click="ozonAction('quantity',  item.sku_id)" title="[`Обновить остатки`]" icon="icon16 box" action="quantity" :run="runAction" bclass="middle"></action-button>
                <action-button @click="ozonAction('imgUpdate',  item.sku_id)" title="[`Обновить изображения`]" icon="icon16 image" action="imgUpdate" :run="runAction" bclass="middle"></action-button>
                <action-button @click="ozonAction('upgrade',  item.sku_id)" :title="item.hasOwnProperty('error_message') ? '[`Обновить данные`]' : '[`Обновить описание`]'" icon="icon16 sync" action="upgrade" :run="runAction" bclass="middle"></action-button>
                <action-button @click="ozonAction('unmatch',  item.sku_id)" title="[`Убрать сопоставление`]" icon="icon16 trash" action="unmatch" :run="runAction" style="float: right !important;" bclass="middle"></action-button>
            </div>
        </div>
        <hr>
    </figure>
</template>
<template v-if="accounts[account_id].publics.length<=0 && !checkFreeErrors()">
    <br><br><br><br>
    <div class="double-padded align-center gray">
        <p>
            <strong>[`Товар не публиковался в выбранном аккаунте Озон`]</strong>
        </p>
    </div>
</template>

<template v-if="accounts[account_id].unpublics.length>0 && accounts[account_id].publics.length>0">
    <strong>[`Неопубликованные артикулы`]</strong>
    <br><br>
    <table class="zebra" style="width: 700px;">
        <tr v-for="(sku, index) in accounts[account_id].unpublics" class="ozonseller-product-unpublic">
            <td style="width:80%">
                <span v-if="sku.name">{{sku.name}} (</span>
                <span v-if="sku.sku">{{sku.sku}}</span>
                <span v-if="sku.name">)</span>
            </td>
            <td>
                <div>
                    <a v-if="sku.available == 1" @click="ozonAction('public',  sku.id, $event, 'dd')"
                       class="small">
                        <i class="icon16 loading" style="display: none; opacity: 1 !important;"></i>
                        <i class="icon16 yes" style="display: none;"></i>
                        [`Опубликовать`]
                    </a>
                    <span v-if="sku.available == 0" class="gray small">
                                [`недоступен для продажи`]
                            </span>
                </div>
            </td>

        </tr>
    </table>
</template>
<template v-if="checkFreeErrors()">
    <strong>[`Ошибки публикаций`]</strong>
    <ul>
        <li v-for="(err, idx) in getFreeErrors()">{{err.message}}</li>
    </ul>
</template>
</div>
{/literal}
<script>
$(function () {
    {include '../../actionButton.js'}
    {include '../../accountsMenu.js'}
    {include './product.js'}
});
</script>
