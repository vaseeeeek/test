ozonseller = Vue.createApp({
    data() {
        return {
            account_id: {$account_id},
            accounts: {$accounts},
            actionSku: 0,
            product_id: {$product_id},
            runAction: false
        }
    },
    methods: {
        ozonAction: function (mode, sku_id) {
            this.runAction = mode;
            $.post('?plugin=ozonseller&module=products&action=updateProduct', {
                account_id: this.account_id,
                mode: mode,
                sku_id: sku_id
            }, r => {
                if (r.status === 'ok') {
                    if (mode === 'public' || mode === 'unmatch') {
                        this.accounts[this.account_id].publics = r.data.publics;
                        this.accounts[this.account_id].unpublics = r.data.unpublics;
                    }
                } else {
                    alert(r.errors);
                }
                this.runAction = false;
            });
        },
        checkFreeErrors: function () {
            let acc = this.accounts[this.account_id];
            if (!acc.errors.length) return false;
            let check = false;
            acc.errors.forEach( e => {
                let idx = acc.publics.findIndex( p => { return e.sku_id-0 === p.sku_id-0});
                if (idx < 0) check = true;
            });
            return check;
        },
        getFreeErrors: function () {
            let errors = [];
            this.accounts[this.account_id].errors.forEach( err => {
                let idx = this.accounts[this.account_id].publics.findIndex( p => { return err.sku_id-0 === p.sku_id-0});
                if (idx < 0) errors.push(err);
            });
            return errors;
        },
        getItemErrors: function (index) {
            let message = '';
            if (this.accounts[this.account_id].publics[index].hasOwnProperty('error_message')) message += this.accounts[this.account_id].publics[index].error_message;
            let sku_id = this.accounts[this.account_id].publics[index].sku_id;
            this.accounts[this.account_id].errors.forEach( er => {
                if (er.sku_id-0 === sku_id) {
                    message += ' ' + er.message;
                }
            });
            return message;
        },
        checkItemErrors: function (index) {
            if (this.accounts[this.account_id].publics[index].hasOwnProperty('error_message')) return true;
            let sku_id = this.accounts[this.account_id].publics[index].sku_id;
            let idx = this.accounts[this.account_id].errors.findIndex( el => { return el.sku_id-0 === sku_id});
            return idx >= 0;
        },
        getPublicsDialog: function () {
            $.post('?plugin=ozonseller&module=products&action=getDialogProducts', { product_id: [this.product_id]}, function (r) {
                if (r.status === 'ok') {
                    $.waDialog({
                        html: r.data,
                        onClose: function (f) {
                            if (ozonsellerDlgPublics.runAction !== false) return;
                            dlgPublics.unmount();
                            ozonsellerdlgPublics = undefined;
                            dlgPublics = undefined;
                            $(this).remove();
                        },
                        esc: false
                    });
                } else {
                    alert(r.errors);
                }
            });
            return false;
        },
        showActions: function (sku_id) {
            if (this.actionSku-0 === sku_id-0) this.actionSku = 0;
            else this.actionSku = sku_id;
        }
    }
});
ozonseller.component('accountsMenu', ozonAccounts);
ozonseller.component('actionButton', actionButton);
ozonsellerData = ozonseller.mount('#ozonseller-product-publics');
$('a.ozonseller-a-product-actions').on('click', function () {
    $('#ozonseller-product-publics').find('div.ozonseller-product-actions').hide();
    $(this).closest('div').find('div.ozonseller-product-actions').show();
    return false;
});
