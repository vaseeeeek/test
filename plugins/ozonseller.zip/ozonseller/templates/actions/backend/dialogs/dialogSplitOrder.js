dlgSplit = Vue.createApp({
    data() {
        return {
            accountId: {$account_id},
            posting_number: {$posting_number},
            products: {$products}
        }
    },
    methods: {
        setError: function (texts) {
            if (Array.isArray(texts)) {
                text = texts.join('; ');
            } else {
                text = texts;
            }
            if (!text.length) text = 'Непредвиденная ошибка сервера';
            this.runAction = false;
            alert(text);
        }
    }
});
dlgSplit.component('actionButton', actionButton);
ozonsellerDlgSplit = dlgSplit.mount('#ozonseller-split-dialog');
