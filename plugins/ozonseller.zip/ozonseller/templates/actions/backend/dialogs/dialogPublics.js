dlgPublics = Vue.createApp({
    data() {
        return {
            accountId: null,
            accounts: {$accounts},
            accSettings: {$accSettings},
            categories: false,
            cCategory: false,
            productIds: {$product_ids},
            typeProductIds: {$typeProductIds},
            totalCount: false,
            catCount: 0,
            goProducts: 0,
            validatedProducts: 0,
            validatedIds: '',
            failProducts: 0,
            mode: 'prepare',
            newUi: {$newUi},
            runAction: false,
            errorText: false
        }
    },
    computed: {
        getPublics() {
            return this.cCategory ? this.catCount : this.totalCount;
        }
    },
    mounted: function () {
        this.accountId = this.accounts[0].id;
        this.setAccountSettings();
    },
    watch: {
        accountId: function() {
            this.setAccountSettings();
        }
    },
    methods: {
        checkProducts: function () {
            this.errorText = false;
            this.runAction = 'validateProducts';
            let params = {
                account_id: this.accountId,
                type_ids: this.typeProductIds,
                product_ids: this.productIds,
                ozon_category_id: this.cCategory
            };
            $.post('?plugin=ozonseller&action=validateProducts', params, data => {
                let procId = data.processId;
                if (!procId) this.setError(data.errors);
                let step = setInterval(f => {
                    $.wa.errorHandler = function (xhr) {
                        return !((xhr.status >= 500) || (xhr.status == 0));
                    };
                    try {
                        $.post('?plugin=ozonseller&action=validateProducts', {
                            processId: procId
                        }, r => {
                            if (r.hasOwnProperty('exception')) {
                                this.errorText = r.exception;
                                this.setEmptyValues();
                                clearInterval(step);
                            } else if (r.ready == true) {
                                clearInterval(step);
                                if (r.errors != undefined && r.errors.length) {
                                    this.setError(r.errors);
                                }
                                if (r.fail != undefined && r.fail) {
                                    this.failProducts = r.fail;
                                }
                                if (r.done != undefined && r.done) {
                                    this.validatedProducts = r.done;
                                    this.validatedIds = r.done_ids;
                                }
                                this.runAction = false;
                                this.mode = 'validated';
                            }
                        }, 'json');
                    } catch (e) {
                        this.errorText = e.message;
                        this.setEmptyValues();
                        clearInterval(step);
                    }
                }, 4000);
            }, 'json').fail( f => {
                console.log('sdfsdfsd');
            });
        },
        queueProducts: function () {
            this.errorText = false;
            this.mode = 'setWaits';
            $.post('?plugin=ozonseller&module=products&action=addWaitProducts', {
                account_id: this.accountId,
                type_ids: this.typeProductIds,
                product_ids: this.productIds,
                ozon_category_id: this.cCategory,
                ids_to_public: this.validatedIds
            }, r => {
                if (r.status === 'ok') {
                    this.mode = 'done';
                    setTimeout(f => {
                        this.setEmptyValues();
                    }, 5000);
                } else this.setError(r.errors);

            });
        },
        setEmptyValues: function () {
            this.runAction = false;
            this.validatedProducts = 0;
            this.validatedIds = '';
            this.mode = 'prepare';
            this.failProducts = 0;
        },
        changeOzonCategory: function () {
            this.errorText = false;
            this.setEmptyValues();
            if (!this.cCategory) return;
            this.runAction = 'getCategoryInfo';
            $.post('?plugin=ozonseller&module=products&action=checkDialogProducts',
                { account_id: this.accountId, product_ids: this.productIds, type_ids: this.typeProductIds, ozon_category_id: this.cCategory},
                r => {
                if (r.status == 'ok') {
                    this.goProducts = r.data.go;
                    this.catCount = r.data.ocount;
                } else {
                    alert(r.errors);
                    this.cCategory = false;
                }
                this.runAction = false;
            });
        },
        setAccountSettings: function () {
            this.cCategory = false;
            this.catCount = 0;
            this.goProducts = 0;
            this.validatedProducts = 0;
            this.validatedIds = '';
            this.failProducts = 0;
            this.mode = 'prepare';
            this.categories = { };
            this.errorText = '';
            if (this.accSettings[this.accountId].categories) {
                this.categories = this.accSettings[this.accountId].categories;
            }
            this.totalCount = this.accSettings[this.accountId].count;
        },
        setError: function (texts) {
                if (Array.isArray(texts)) {
                    text = texts.join('; ');
                } else {
                    text = texts;
                }
                if (!text.length) text = 'Непредвиденная ошибка сервера';
                this.errorText = text;
                this.runAction = false;
        }
    }
});
dlgPublics.component('actionButton', actionButton);
ozonsellerDlgPublics = dlgPublics.mount('#ozonseller-main-import');
