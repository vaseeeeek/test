{if $isDebug}
<script src="{$wa_app_static_url}plugins/ozonseller/js/vendors/vue/vue.global.js"></script>
{else}
<script src="{$wa_app_static_url}plugins/ozonseller/js/vendors/vue/vue.global.prod.js"></script>
{/if}
<div id="ozonseller-category-settings" class="field">
<div class="name">[`Ozon: Интеграция`]</div>
<div class="value no-shift">
    <input type="checkbox" name="ozonseller[subcategories]" value="1" {if $subcats}checked{/if}>&nbsp;
    <span>[`включая товары из подкатегорий`]</span>
    {literal}
    <div>
        <template v-for="(data, acc_id) in accSettings">
            <div id="ozonseller-category-info" class="ozonseller-tags" v-if="data.items.length">
                <span class="tag" v-for="(item, idx) in data.items">
                    <input :name="'ozonseller[ozon_category_ids]['+acc_id+'][]'" :value="item.id" type="hidden">
                    <span>{{item.name}} ({{getAccountName(acc_id)}})</span><a @click="removeOzonCategory(acc_id, idx)"
                                                             title="[`Убрать`]">x</a>
                </span>
            </div>
        </template>
    </div>
    <br><br>
    <div class="block">
        <a class="ozonseller-category-settings-a-add" @click="mode='add'" v-if="!mode"><i class="icon10 add"></i>
            [`добавить`]
        </a>
        <template v-else>
        <select v-model="accountId">
            <option :value="null">[`Выберите аккаунт Ozon`]</option>
            <option v-for="(acc, idx) in accounts" :value="acc.id">{{acc.name}}</option>
        </select>&nbsp;&nbsp;&nbsp;
        <template v-if="accountId">
            <template v-if="accSettings[accountId].ozon_categories.length">
                <select class="ozonseller-select-category" v-model="selected" @change="selectNewCategory()">
                    <option :value="null">[`Выберите категорию Ozon`]</option>
                    <option v-for="(cat,idx) in accSettings[accountId].ozon_categories" :value="cat.id"
                            :disabled="checkCatItem(cat.id)">
                        {{cat.name}}</option>
                </select>
            </template>
            <span v-else>[`Для выбранного аккаунта Ozon нет ни одной полностью настроенной категории Ozon`]</span>
        </template>
        </template>
    </div>
</div>
</div>
{/literal}
<script>
$(function () {
    dlgCategories = Vue.createApp({
        data() {
            return {
                accountId: null,
                selected: null,
                accounts: {$accounts},
                accSettings: {$accSettings},
                mode: false,
            }
        },
        methods: {
            checkCatItem: function (cat_id) {
                let idx = this.accSettings[this.accountId].items.findIndex( (c) => { return c.id-0 === cat_id-0});
                return idx >= 0;
            },
            getAccountName: function (acc_id) {
                let name = 'undefined';
                let idx = this.accounts.findIndex( acc => { return acc.id-0 === acc_id-0});
                if (idx >= 0) name = this.accounts[idx].name;
                return name;
            },
            removeOzonCategory: function (acc_id, idx) {
                this.accSettings[acc_id].items.splice(idx, 1);
            },
            selectNewCategory: function() {
                if (this.selected === null) return;
                let idx = this.accSettings[this.accountId].ozon_categories.findIndex( cat => {
                    return cat.id-0===this.selected-0
                });
                if (idx >= 0) {
                    let data = {
                        id: this.selected,
                        name: this.accSettings[this.accountId].ozon_categories[idx].name
                    };
                    this.accSettings[this.accountId].items.push(data);
                }
                this.selected = null;
                this.mode = false;
            }
        }
    });
    ozonsellerCatDialog = dlgCategories.mount('#ozonseller-category-settings');
});
</script>