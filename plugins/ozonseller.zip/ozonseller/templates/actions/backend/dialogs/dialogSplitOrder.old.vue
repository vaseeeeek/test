{literal}
<div id="ozonseller-split-dialog" class="dialog-content block double-padded">
    <div class="block">
        <div class="block" style="max-height: 400px;overflow: auto;">
            <span class="alert info">
                [`Выберите какие товары и в каком количестве перенести в новое отправление`]<br>
                [`Если вам необходимо разделить текущий заказ на более чем 2 отправления, сделайте это последовательно, каждый раз выбирая товары заказа для каждого из новых отправлений`]
            </span>
            <table>
                <tr v-for="(op, idx) in products">
                    <td style="padding: 3px;"><input :id="op.sku" @change="changeCheckbox(op.sku)" type="checkbox"> </td>
                    <td style="padding: 3px;"><label :for="op.sku">{{op.name}}</label></td>
                    <td style="padding: 3px;"><input v-if="checkCheckbox(op.sku) >= 0" type="number" min="1" :max="op.quantity" v-model="items[checkCheckbox(op.sku)].quantity"></td>
                </tr>
            </table>
        </div>
    </div>
    <div class="dialog-buttons">
        <action-button @bClick="splitOrder()" title="Создать новое отправление" icon="icon16 split" action="splitOrder" :run="runAction" :bclass="'middle ' + (items.length?'':'disabled')"></action-button>
        <action-button id="ozonseller-split-dialog-cancel" title="[`Отмена`]" icon="icon16 no" action="tmp" :run="runAction" bclass="middle cancel" style="float: right;margin-right: 50px;"></action-button>
    </div>
</div>
{/literal}