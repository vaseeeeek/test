if (typeof ozonsellerOrder !== "undefined") {
    console.log(typeof ozonsellerOrder);
    ozonsellerOrder.unmount();
    ozonsellerOrder = undefined;
    ozonsellerOrderMount = undefined;
}
ozonsellerOrder = Vue.createApp({
    data() {
        return {
            account_id: null,
            accounts: {$accounts},
            order: {$shopOrder},
            schema: {$schema},
            collect: {$collect},
            collect_button: {$collect_button},
            print_label: {$print_label},
            tracking: {$track},
            cancelStatuses: {$cancel_statuses},
            ozonOrderProducts: null,
            bannerText: {$bannerText},
            warnings: {$warnings},
            newUi: {$newUi},
            cancelMode: false,
            copyPosting: false,
            runAction: false
        }
    },
    mounted: function () {
        this.account_id = this.order.params.ozon_account_id;
    },
    computed: {
        cancelReason() {
            return this.cancelStatuses.includes(this.order.params.ozon_order_status);
        },
        totalQuantity() {
            let total = 0;
            Object.keys(this.order.items).forEach( (key) => { total += this.order.items[key].quantity});
            return total;
        }
    },
    methods: {
        orderCollect: function () {
            this.runAction = 'orderCollect';
            $.post('?plugin=ozonseller&module=orders&action=collectOrder', { 'account_id': this.account_id, 'posting_number': this.order.params.ozon_posting_number}, r => {
                if (r.status === 'ok') $.order.reload();
                else alert(r.errors);
            });
        },
        orderTrack: function () {
            $.post('?plugin=ozonseller&module=orders&action=getDialogTrackNumber', {
                account_id: this.account_id,
                order_id: this.order.id,
                posting_number: this.order.params.ozon_posting_number
            }, r => {
                if(r.status === 'ok'){
                    $(r.data).waDialog({
                        'height': '150px',
                        'width': '450px',
                        'onClose': function (f) {
                            $(this).remove();
                        },
                        'esc': true,
                    });
                }else{
                    alert(r.errors);
                }
            });
        },
        cancelPosting: function () {
            this.runAction = 'cancelPosting';
            $.post('?plugin=ozonseller&module=orders&action=getDialogCancelReasons', {
                account_id: this.account_id,
                posting_number: this.order.params.ozon_posting_number
            }, r => {
                if (r.status === 'ok') {
                    $(r.data).waDialog({
                        'height': '150px',
                        'width': '500px',
                        'onClose': function (f) {
                            $(this).remove();
                        },
                        'esc': true,
                    });
                } else {
                    alert(r.errors);
                }
            });
        },
        copyPostingNumber: function () {
            let $temp = $("<input>");
            $("body").append($temp);
            $temp.val(this.order.params.ozon_posting_number).select();
            document.execCommand("copy");
            $temp.remove();
            this.copyPosting = true;
            setTimeout(f => {
                this.copyPosting = false;
            }, 2000);
            return false;
        },
        splitOrder: function () {
            let that = this;
            this.runAction = 'splitOrder';
            let posting_number = this.order.params.ozon_posting_number;
            $.post('?plugin=ozonseller&module=orders&action=getPostingInfo', { account_id: this.account_id, posting_number: posting_number}, r => {
                if (r.status === 'ok') {
                    this.ozonOrderProducts = r.data;
                    if (this.newUi) {

                    } else {
                        $(r.data.template).waDialog({
                            width: '750px',
                            onClose: function (f) {
                                dlgSplit.unmount();
                                ozonsellerDlgSplit = undefined;
                                dlgSplit = undefined;
                                $(this).remove();
                            },
                            onLoad: function () {
                                that.activateSplitDialog(r.data.products);
                            },
                            esc: true,
                        });
                    }
                } else {
                    alert.r.errors;
                }
                this.runAction = false;
            });
        },
        activateSplitDialog: function (products) {
            let that = this;
            dlgSplit = Vue.createApp({
                data() {
                    return {
                        account_id: that.account_id,
                        posting_number: that.order.params.ozon_posting_number,
                        products: JSON.parse(JSON.stringify(products)),
                        items: [],
                        runAction: false
                    }
                },
                methods: {
                    splitOrder: function () {
                        if (!this.items.length) return;
                        this.runAction = 'splitOrder';
                        let total = 0;
                        this.items.forEach( (el) => { total += el.quantity});
                        if (total >= ozonsellerOrder.totalQuantity) {
                            this.setError('Нельзя перенести все товары отправления');
                            return;
                        }
                        $.post('?plugin=ozonseller&module=orders&action=splitOrder', { account_id: this.account_id, posting_number: this.posting_number, items: this.items}, r => {
                            if (r.status === 'ok') {
                                $('#ozonseller-split-dialog-cancel').trigger('click');
                                $.order.reload();
                            }
                            else this.setError(r.errors);
                            this.runAction = false;
                        })
                    },
                    changeCheckbox: function (sku) {
                        let idx = this.items.findIndex(el => { return el.product_id===sku});
                        if (idx >= 0) this.items.splice(idx, 1);
                        else {
                            let pidx = this.products.findIndex( pel => { return pel.sku === sku});
                            if (pidx >= 0) {
                                this.items.push({
                                    product_id: sku,
                                    quantity: this.products[pidx].quantity,
                                    exemplar_info: this.products[pidx].exemplar
                                });
                            }
                        }
                    },
                    checkCheckbox: function (sku) {
                        return idx = this.items.findIndex( el => { return el.product_id === sku});
                    },
                    setError: function (texts) {
                        if (Array.isArray(texts)) {
                            text = texts.join('; ');
                        } else {
                            text = texts;
                        }
                        if (!text.length) text = 'Непредвиденная ошибка сервера';
                        this.runAction = false;
                        alert(text);
                    }
                }
            });
            dlgSplit.component('actionButton', actionButton);
            ozonsellerDlgSplit = dlgSplit.mount('#ozonseller-split-dialog');
        },
        updateProductsMd5: function () {
            this.runAction = 'updateProductsMd5';
            $.post('?plugin=ozonseller&module=orders&action=updateProductsMd5', { order_id: this.order.id, hash: this.order.params.ozon_products_md5.hash }, r => {
                if (r.status === 'ok') this.order.params.ozon_products_md5.changed = false;
                else alert(r.errors);
                this.runAction = false;
            });
        },
        printLabel: function () {
            let url = '?plugin=ozonseller&module=orders&action=printLabel&posting_number=' + this.order.params.ozon_posting_number + '&account_id='+this.account_id;
            window.open(url);
        },
        closeBanner: function() {
            this.bannerText = false;
            $.post('?plugin=ozonseller&action=closeBanner', r => {
                if (r.status !== 'ok') console.log(r.errors);
            });
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        }
    }
});
{include '../../actionButton.js'}
ozonsellerOrder.component('actionButton', actionButton);
ozonsellerOrderMount = ozonsellerOrder.mount('div#ozonseller-order-info');

