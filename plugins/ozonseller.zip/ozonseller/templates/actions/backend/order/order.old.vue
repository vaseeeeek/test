{literal}
<div id="ozonseller-order-info">
<hr style="border-style: groove;border-width: 5px 0 0;"/>
<div class="alert" v-if="order.params.ozon_products_md5.changed">
    <strong><i class="icon16 burn"></i> [`Внимание!!! В Ozon изменился состав заказа!`]</strong><br>
    <span><i class="icon16 exclamation"></i> [`Вам следует сверить состав заказа с ЛК Ozon и при необходимости внести изменения в заказ в Shop-Script вручную!`]</span>
    <a @click="updateProductsMd5()" class="small" style="float: right;">[`Скрыть`]</a>
</div>
<span class="alert info" v-if="bannerText">
            <span v-html="bannerText"></span>
            <a @click="closeBanner()" class="alert-close" title="[`Скрыть`]"><i class="icon16 no"></i></a>
</span>

<span class="alert" v-if="warnings.length">
    <span v-for="(warning,idx) in warnings" v-html="warning" style="display: block;"></span>
</span>
<div class="field-group">
        <span style="font-weight: bold"> <i class="ozonseller-icon16 ozon icon16"></i> <span
                id="ozonseller-posting-number">{{ order.params.ozon_posting_number }}</span>&nbsp;({{accounts[order.params.ozon_account_id].name}}, {{ schema }})</span>&nbsp;
    <a @click="copyPostingNumber()" title="[`скопировать в буфер`]"> <i class="icon16 notebooks"></i></a>
    <span v-if="copyPosting" class="small gray">[`скопировано`]</span>
</div>
<div class="field-group">
    <div class="field">
        <div class="name">[`Статус`]</div>
        <div class="value">
            <span>{{order.params.ozon_order_status}}</span>
            <span v-if="cancelReason" class="grey">({{order.params.ozon_cancel_reason}})</span>
        </div>
    </div>
    <div class="field">
        <div class="name">[`Принят в обработку`]</div>
        <div class="value">{{formatDate(order.params.ozon_in_process_at, 'humanDateTime')}}</div>
    </div>
    <div class="field">
        <div class="name">[`Дата отгрузки`]</div>
        <div class="value">{{formatDate(order.params.ozon_shipment_date, 'humanDateTime')}}</div>
    </div>
</div>
<div v-if="order.params.ozon_delivery_id-0>0" class="field-group">
    <div class="field">
        <div class="name">[`Склад`]</div>
        <div class="value">{{order.params.ozon_stock_name}}</div>
    </div>
    <div class="field">
        <div class="name">[`Метод доставки`]</div>
        <div class="value">{{order.params.ozon_delivery_name}}</div>
    </div>
</div>
<template v-if="schema!=='FBO'">
    <div class="block" style="margin-top: 25px;">
        <action-button v-if="collect_button" @bClick="orderCollect()" title="[`Собрать заказ`]" icon="icon16 cart"
                       action="orderCollect" :run="runAction" :bclass="(collect ? '' : 'disabled ') + 'middle'"></action-button>
<!--        <action-button v-if="order.params.ozon_order_status === 'Ожидает сборки' && totalQuantity > 1" @bClick="splitOrder()" title="[`Разделить отправление...`]"
                       icon="icon16 split" action="splitOrder" :run="runAction" bclass="middle"></action-button>-->
        <action-button v-if="print_label" @bClick="printLabel()" title="[`Маркировка`]" icon="icon16 print"
                       action="printLabel" :run="runAction" bclass="middle"></action-button>
        <action-button v-if="tracking" @bClick="orderTrack()" title="[`Указать трек-номер`]" icon="icon16 tags"
                       action="orderTrack" :run="runAction" bclass="middle"></action-button>
        <action-button v-if="!cancelMode" @bClick="cancelMode=true" title="[`Отменить отправление...`]" icon="icon16 update" action="cancelPosting" :run="runAction"
                       :bclass="'middle '+(order.params.ozon_order_status==='[`Ожидает сборки`]'?'':'disabled')"></action-button>
        <action-button v-if="cancelMode" @bClick="cancelPosting()" title="[`Точно отменить!`]" icon="icon16 update" action="cancelPosting"
                       :run="runAction" :bclass="'middle '+(order.params.ozon_order_status==='[`Ожидает сборки`]'?'':'disabled')" style="float: right;"></action-button>
    </div>
</template>
<hr style="border-style: groove;border-width: 5px 0 0;margin-top: 50px;"/>
</div>
{/literal}
<script>
$(function () {
    {include './order.js'}
});
</script>