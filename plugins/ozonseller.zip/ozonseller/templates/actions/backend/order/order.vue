{literal}
<div class="fields" id="ozonseller-order-info">
<hr style="border-style: groove;border-width: 5px 0 0;margin: 10px 0px 5px 0px;"/>
    <div class="alert" v-if="order.params.ozon_products_md5.changed">
        <strong><i class="fas fa-exclamation-circle"></i> [`Внимание!!! В Ozon изменился состав заказа!`]</strong><br>
        <span style="display: block;">[`Вам следует сверить состав заказа с ЛК Ozon и при необходимости внести изменения в заказ в Shop-Script вручную!`]</span>
        <a @click="updateProductsMd5()" class="small">[`Скрыть`]</a>
    </div>
    <span class="alert info" v-if="bannerText">
            <span v-html="bannerText"></span>
            <a @click="closeBanner()" class="alert-close" title="[`Скрыть`]"><i class="fas fa-times"></i></a>
    </span>
    <span class="alert" v-if="warnings.length">
        <span v-for="(warning,idx) in warnings" v-html="warning" style="display: block;"></span>
    </span>
    <span style="font-weight: bold"> <i class="ozonseller-icon16 ozon icon16"></i> <span
                id="ozonseller-posting-number">{{ order.params.ozon_posting_number }}</span>&nbsp;({{accounts[order.params.ozon_account_id].name}}, {{ schema }})</span>&nbsp;
    <a @click="copyPostingNumber()" title="[`скопировать в буфер`]"> <i class="far fa-copy"></i></a>
    <span v-if="copyPosting" class="small gray">&nbsp;&nbsp;[`скопировано`]</span>
    <div class="field">
        <div class="name">[`Статус`]</div>
        <div class="value">
            <span>{{order.params.ozon_order_status}}</span>
            <span v-if="cancelReason" class="grey">({{order.params.ozon_cancel_reason}})</span>
        </div>
    </div>
    <div class="field">
        <div class="name">[`Принят в обработку`]</div>
        <div class="value">{{formatDate(order.params.ozon_in_process_at, 'humanDateTime')}}</div>
    </div>
    <div class="field">
        <div class="name">[`Дата отгрузки`]</div>
        <div class="value">{{formatDate(order.params.ozon_shipment_date, 'humanDateTime')}}</div>
    </div>
<template v-if="order.params.ozon_delivery_id-0>0">
    <div class="field">
        <div class="name">[`Склад`]</div>
        <div class="value">{{order.params.ozon_stock_name}}</div>
    </div>
    <div class="field">
        <div class="name">[`Метод доставки`]</div>
        <div class="value">{{order.params.ozon_delivery_name}}</div>
    </div>
</template>
<template v-if="schema!=='FBO'">
    <div class="block" style="margin-top: 25px;">

        <action-button v-if="collect_button" @bClick="orderCollect()" title="[`Собрать заказ`]" icon="far fa-calendar-check"
                       action="orderCollect" :run="runAction" :bclass="collect ? '' : 'disabled ' + 'smallest'"></action-button>
        <action-button v-if="print_label" @bClick="printLabel()" title="[`Маркировка`]" icon="fas fa-print"
                       action="printLabel" :run="runAction" bclass="smallest"></action-button>
        <action-button v-if="tracking" @bClick="orderTrack()" title="[`Указать трек-номер`]" icon="fas fa-truck"
                       action="orderTrack" :run="runAction" bclass="smallest"></action-button>
        <action-button v-if="!cancelMode" @bClick="cancelMode=true" title="[`Отменить отправление...`]" icon="far fa-trash-alt" action="cancelPosting" :run="runAction"
                       :bclass="'smallest gray '+(collect?'':'disabled')"></action-button>
        <action-button v-if="cancelMode" @bClick="cancelPosting()" title="[`Точно отменить!`]" icon="fas fa-dumpster-fire" action="cancelPosting"
                       :run="runAction" :bclass="'smallest red '+(collect?'':'disabled')" style="float: right;"></action-button>
    </div>
</template>
<hr style="border-style: groove;border-width: 5px 0 0;margin: 10px 0px 5px 0px;"/>
</div>
{/literal}
<script>
$(function () {
    {include './order.js'}
});
</script>