ocats = Vue.createApp({
    data() {
        return {
            accountId: null,
            accounts: {$accounts},
            accSettings: {$accSettings},
            categories: [],
            schema: null,
            currencies: {$currencies},
            markups: [],
            types: {$types},
            cCategory: false,
            catFeatures: false,
            editMarkups: false,
            modeMarkups: 'view',
            mode: false,
            ozonCategories: [],
            ozonCatsCount: {$ocount},
            newUi: {$newUi},
            bar: {
                prerunText: '[`Получение данных из Ozon...`]',
                runText: '[`Идёт обработка категорий Ozon`]',
                doneText: 'Процесс успешно завершен',
                errorText: 'В процессе работы возникли ошибки. Подробности см. в ozonseller.error.log',
                value: 0,
                max: null,
                width: '70%',
                height: '1em',
                state: 'wait',
                small: false,
                time: true,
                result: { },
                lis: []
            },
            runAction: false
        }
    },
    computed: {
        getCategoryId() {
            let category_id = 'default';
            if (this.cCategory) category_id = this.cCategory.id;
            return category_id;
        },
        sourceCopyAccounts() {
            let accounts = [];
            Object.keys(this.accSettings).forEach( (acc_id) => {
                if (this.accountId-0 !== acc_id-0 && this.accSettings[acc_id].categories.length) {
                    let cidx = this.accSettings[acc_id].categories.findIndex( (cat) => { return cat.id==this.cCategory.id});
                    if (cidx >= 0) {
                        let aidx = this.accounts.findIndex( (a) => { return a.id==acc_id});
                        if (aidx >=0) accounts.push({ id: acc_id, name: this.accounts[aidx].name});
                    }
                }
            });
            return accounts;
        }
    },
    mounted: function () {
        ozonseller.cApp = ocats;
        this.accountId = ozonseller.accountId;
        this.setSettings();
    },
    watch: {
        runAction: function () {
            ozonseller.runAction = this.runAction;
            if (this.runAction === 'newCategoryDialog') {
                this.$nextTick( function () {
                    $('#ozonseller-ozon-categories-select').select2({ 'width': '400px', 'margin-bottom': '5px'});
                });
            }
            if(this.runAction === false) this.ozonCategories = [];
        },
        accountId: function () {
            ozonseller.accountId = this.accountId;
            this.setSettings();
        }
    },
    methods: {
        saveCategoryFeatures: function () {
            let type_id = false;
            this.runAction = 'saveCategoryFeatures';
            if (this.cCategory.hasOwnProperty('cType') && this.cCategory.cType.hasOwnProperty('id')) type_id = this.cCategory.cType.id;
            if (type_id === false) ozonseller.setError('Не удалось определить тип товаров');
            $.post('?plugin=ozonseller&action=saveCategoryTypeFeatures', {
                account_id: this.accountId,
                features: this.cCategory.cType.values,
                category_id: this.cCategory.id,
                type_id: type_id
                }, r => {
                if (r.status == 'ok') {
                    if (r.data.hasOwnProperty('attention')) {
                        $('#ozonseller-required-warning').html(r.data.attention);
                    }
                    this.cCategory.types[this.cCategory.cType.id].values = JSON.parse(JSON.stringify(this.cCategory.cType.values));
                } else {
                    ozonseller.setError(r.errors);
                }
                this.runAction = false;
            });
        },
        setOzonCategory: function (category_id) {
            let idx = this.getIdxById('categories', category_id, 'id');
            if (idx >= 0 || this.categories.hasOwnProperty(category_id)) {
                this.runAction = 'getCategoryInfo';
                $.post('?plugin=ozonseller&action=getCategorySettings', { account_id: this.accountId, category_id: category_id}, r => {
                    if (r.status === 'ok') {
                        this.cCategory = r.data;
                        this.cCategory.cType = false;
                        this.cCategory.newType = 0;
                        $('#ozonseller-required-warning').html('');
                    } else ozonseller.setError(r.errors);
                    this.runAction = false;
                });
            } else {
                ozonseller.setError('Не удалось найти запрашиваемую категорию');
            }
        },
        refreshDictionaries: function () {
            this.runAction = 'refreshDictionaries';
            let url = '?plugin=ozonseller&action=updateDictionaries';
            $.post(url, { account_id: this.accountId, category_id: this.cCategory.id}, data => {
                if (data.error !== undefined) {
                    ozonseller.setError(data.error);
                } else {
                    let step = setInterval(() => {
                        $.wa.errorHandler = function (xhr) {
                            return !((xhr.status >= 500) || (xhr.status == 0));
                        };
                        let processId = data.processId;
                        $.post(url, { 'processId': processId}, r => {
                            if (r.ready == true) {
                                this.runAction = false;
                                clearInterval(step);
                            }
                        }, 'json');
                    }, 3000);
                }
            }, 'json');
        },
        addTypeFeatures: function () {
            let type_id = $('#ozonseller-add-type-select').val();
            if (Number.isInteger(type_id-0) && type_id-0 === 0) return;
            $.post('?plugin=ozonseller&action=getCategoryFeaturesByTypeId', { account_id:this.accountId, category_id: this.cCategory.id, type_id: type_id}, r => {
                if (r.status === 'ok') {
                    if (this.cCategory.types === false) this.cCategory.types = { };
                    this.cCategory.types[type_id] = r.data;
                    let idx = this.types.findIndex(function (type, idx) { return type.id-0 === type_id-0 });
                    if (idx >= 0) {
                        this.cCategory.types[type_id].id = this.types[idx].id;
                        this.cCategory.types[type_id].name = this.types[idx].name;
                        this.cCategory.cType = this.cCategory.types[type_id];
                    } else {
                        ozonseller.setError('Не удалось получить данные о типе товаров');
                    }
                } else {
                    ozonseller.setError(r.errors);
                }
            });
        },
        removeCategory: function () {
            this.runAction = 'removeCategory';
            this.removeCategoryData();
        },
        removeCategoryType: function () {
            this.runAction = 'removeCategoryType';
            this.removeCategoryData(this.cCategory.cType.id);
        },
        removeCategoryData: function (type_id=null) {
            $.post('?plugin=ozonseller&action=removeCategoryType', {
                account_id: this.accountId,
                category_id: this.cCategory.id,
                type_id: type_id
            }, r => {
                if (r.status == 'ok') {
                    if (type_id) {
                        this.cCategory.cType = false;
                        let types = { };
                        Object.keys(this.cCategory.types).forEach(tid => {
                            if (tid-0 !== type_id-0) types[tid] = this.cCategory.types[tid];
                        });
                        this.cCategory.types = types;
                    } else {
                        let category_id = this.cCategory.id-0;
                        let idx = this.categories.findIndex(function (category, idx) { return category.id-0 === category_id });
                        this.cCategory = false;
                        this.cType = false;
                        if (idx >= 0) {
                            this.categories.splice(idx, 1);
                        }
                    }
                } else {
                    ozonseller.setError(r.errors);
                }
                this.runAction = false;
                this.mode = false;
            });
        },
        saveMarkups: function (){
            let category_id = this.getCategoryId;
            this.runAction = 'saveMarkups';
            $.post('?plugin=ozonseller&action=saveMarkups', { account_id: this.accountId, ozon_category_id: category_id, markups:this.editMarkups}, r => {
                if (r.status === 'ok') {
                    if (r.data.length) {
                        this.markups[category_id] = r.data;
                        this.accSettings[this.accountId]['markups'][category_id] = r.data;
                    }
                    else if (this.markups.hasOwnProperty(category_id)) this.markups[category_id] = undefined;
                } else ozonseller.setError(r.errors);
                this.modeMarkups = 'view';
                this.runAction = false;
            });
        },
        setEditMarkups: function (){
            let category_id = this.getCategoryId;
            this.modeMarkups = 'edit';
            if (this.markups.hasOwnProperty(category_id)) this.editMarkups = JSON.parse(JSON.stringify(this.markups[category_id]));
            else this.editMarkups = [];
        },
        getIdxById: function (env, value, field = null) {
            if (field) {
                return this[env].findIndex(function (el, idx) {
                    if (!el.hasOwnProperty(field)) return false;
                    else return el[field] === value;
                });
            } else {
                return this[env].findIndex(function (el, idx) { return el === value });
            }
        },
        addMarkup: function () {
            this.editMarkups.push({ account_id:this.accountId, price_from: 0, currency: 'RUB', markup:0, markup_type: '%'});
        },
        getMarkups: function () {
            if (this.cCategory) {
                if (this.markups.hasOwnProperty(this.cCategory.id)) return this.markups[this.cCategory.id];
                else return [];
            } else if(this.markups.hasOwnProperty('default')) return this.markups.default;
            else return [];
        },
        setCategoryType: function (type_id) {
            if (!this.cCategory.types.hasOwnProperty(type_id)) ozonseller.setError('Данные для выбранного типа товаров отсутствуют');
            this.mode = false;
            this.cCategory.cType = JSON.parse(JSON.stringify(this.cCategory.types[type_id]));
            this.cCategory.cType.id = type_id;
            let category_id = this.cCategory.id;
            let type_name = 'undefined';
            let type_idx = this.getIdxById('types', type_id, 'id');
            if (type_idx >= 0) type_name = this.types[type_idx].name;
            this.cCategory.cType.name = type_name;
        },
        getTypeName: function (type_id) {
            let name = 'undefined';
            let idx = this.getIdxById('types', type_id, 'id');
            if (idx >= 0) name = this.types[idx].name;
            return name;
        },
        getTypeIcon: function (type_id) {
            let icon = 'icon16 ss pt box';
            let idx = this.getIdxById('types', type_id, 'id');
            if (idx >= 0) icon = this.types[idx].icon + ' icon16';
            return icon;
        },
        setCategorySchema: function (schema) {
            let type_id = false;
            let value = schema === 'fbs' ? 1 : 0;
            if (this.cCategory.hasOwnProperty('cType') && this.cCategory.cType.hasOwnProperty('id')) type_id = this.cCategory.cType.id;
            if (type_id === false) return;
            this.cCategory.cType.values[0].value = value;
        },
        checkCategorySchema: function (type) {
            let value = type === 'fbs' ? 1 : 0;
            let type_id = false;
            if (this.cCategory.hasOwnProperty('cType') && this.cCategory.cType.hasOwnProperty('id')) type_id = this.cCategory.cType.id;
            else return false;
            return this.cCategory.cType.values[0].value-0 === value;
        },
        addNewCategory: function () {
            let category_id = $('#ozonseller-ozon-categories-select').val()-0;
            if (category_id === 0) return;
            let idx = this.getIdxById('categories', category_id, 'id');
            if (idx !== -1) return;
            idx = this.getIdxById('ozonCategories', category_id, 'id');
            if (idx === -1) return;
            this.categories.push(JSON.parse(JSON.stringify(this.ozonCategories[idx])));
            this.setOzonCategory(category_id);
        },
        getOzonCategories: function () {
            if (!this.ozonCategories.length) {
                this.runAction = 'getOzonCategories';
                $.post('?plugin=ozonseller&action=getOzonCategories', r => {
                    if (r.status === 'ok') {
                        this.ozonCategories = r.data;
                        this.runAction = 'newCategoryDialog';
                    } else ozonseller.setError(r.errors);
                });
            } else this.runAction = 'newCategoryDialog';
        },
        checkDisabledCategory: function (idx) {
            if (this.ozonCategories[idx].status-0 === 0) return true;
            let cidx= this.getIdxById('categories', this.ozonCategories[idx].id);
            return cidx-0 !== -1;
        },
        copyCategorySettings: function () {
            let account_id = $('#source-account-id').val();
            let category_id = this.cCategory.id;
            if (!account_id) return;
            this.runAction = 'copyCategorySettings';
            $.post('?plugin=ozonseller&action=copyCategorySettings', { source_id: account_id, category_id: category_id, target_id: this.accountId}, r => {
                if (r.status === 'ok') {
                    this.setOzonCategory(category_id-0);
                    let idx = this.accSettings[account_id].categories.findIndex( (cat) => { return cat.id-0 === category_id-0});
                    if (idx >=0) {
                        this.accSettings[this.accountId].categories.push(JSON.parse(JSON.stringify(this.accSettings[account_id].categories[idx])));
                    }
                } else {
                    ozonseller.setError(r.errors);
                    this.runAction = false;
                }
                this.mode = false;
            });
        },
        setSettings: function () {
            let categories = [];
            let markups = [];
            let schema = null;
            if (this.accountId && this.accSettings.hasOwnProperty(this.accountId)) {
                categories = JSON.parse(JSON.stringify(this.accSettings[this.accountId].categories));
                schema = JSON.parse(JSON.stringify(this.accSettings[this.accountId].schema));
                markups = JSON.parse(JSON.stringify(this.accSettings[this.accountId].markups));
            } else {
                categories = [];
                schema = null;
            }
            this.cCategory = false;
            this.catFeatures = false;
            this.editMarkups = false;
            this.modeMarkups = 'view';
            this.mode = false;
            this.categories = categories;
            this.markups = markups;
            this.schema = schema;
        },
        getOzonCategoryTreeName: function (idx) {
            return '&nbsp;'.repeat(3 * (this.ozonCategories[idx].depth-0)) + this.ozonCategories[idx].name;
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        }
    }
});
{include '../../../accountsMenu.js'}
ocats.component('accountsMenu', ozonAccounts);
ocats.component('actionButton', actionButton);
ocats.component('gradusnik', gradusnik);
ocats.component('matchFeature', matchFeature);
osOcats = ocats.mount('div#ozonseller-import-tab-categories');
