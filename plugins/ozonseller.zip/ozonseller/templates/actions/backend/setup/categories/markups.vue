{literal}
<div class="ozonseller-markups-div">
<div class="ozonseller-category-markups view" v-if="modeMarkups==='view'">
    <span class="gray small" v-if="!cCategory">[`Наценки по умолчанию`]:</span>
    <div class=" gray ozonseller-category-markups-view-table">
        <div style="margin: 10px 0 10px 0">
            <table class="ozonseller-table-markups small">
                <tr v-for="(markup, idx) in getMarkups()" v-if="markups.hasOwnProperty(getCategoryId) && markups[getCategoryId]!==undefined && markups[getCategoryId].length">
                    <td>[`от`]</td>
                    <td>{{markup.price_from}}</td>
                    <td>{{markup.currency}}</td>
                    <td>[`наценка`]</td>
                    <td>{{markup.markup}}</td>
                    <td>{{markup.markup_type}}</td>
                </tr>
                <tr v-else>
                    <td>[`Используются наценки по умолчанию`]</td>
                </tr>
            </table>
        </div>
    </div>
    <span class="small">
    <a @click="setEditMarkups()" class="button outlined smallest gray"><i class="far fa-edit"></i> [`изменить`]</a>
    </span>
</div>
<div class="ozonseller-category-markups edit" v-else>
    <div class="ozonseller-category-markup-fields">
            <table class="ozonseller-table-markups edit">
                <tr v-for="(markup, idx) in editMarkups">
                    <td>[`от`]</td>
                    <td><input type="number" min="0" v-model="editMarkups[idx].price_from" class="shorter"></td>
                    <td>
                        <select v-model="editMarkups[idx].currency">
                            <option :value="currency" v-for="(currency, idx) in currencies">{{currency}}</option>
                        </select>
                    </td>
                    <td>[` наценка `]</td>
                    <td><input v-model="editMarkups[idx].markup" type="number" class="shortest"></td>
                    <td>
                        <select v-model="editMarkups[idx].markup_type">
                            <option value="%">[`%`]</option>
                            <option :value="currency" v-for="(currency, idx) in currencies">{{currency}}</option>
                        </select>
                    </td>
                    <td>
                        <a @click="editMarkups.splice(idx,1)" v-show="cCategory || (!cCategory && idx!==0)" class="smaller">[`удалить`]</a>
                    </td>
                </tr>
            </table>
        <span class="smallest">
            <a @click="addMarkup()" class="button outlined"><i class="far fa-plus-square"></i> [`добавить`]</a>
        </span>
    </div>
    <br>
    <span class="smaller">
        <a @click="saveMarkups()" class="button"><i class="far fa-save"></i> [`Сохранить`]</a>&nbsp;&nbsp;&nbsp;[`или`]&nbsp;&nbsp;&nbsp;
        <a @click="editMarkups=false;modeMarkups='view'" class="button outlined" style="display: inline"><i class="fas fa-undo"></i> [`Отмена`]</a>
    </span>
</div>
</div>
{/literal}