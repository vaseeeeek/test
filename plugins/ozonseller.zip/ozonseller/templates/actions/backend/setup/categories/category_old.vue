{literal}
<div class="ozonseller-button small"><a @click="cCategory=false"><i class="icon16 larr"></i>
    [`Назад`]</a></div>
<h2 style="display: contents;">{{cCategory.name}} <span class="gray small" style="display: inline;">(id {{cCategory.id}})</span></h2>
&nbsp;&nbsp;<action-button v-if="!cCategory.types && !mode && sourceCopyAccounts.length" @bClick="mode='copyCategorySettings'" title="[`Скопировать настройки`]" bclass="middle" action="tmp" :run="runAction" icon="icon16 split" style="float: unset;"></action-button>
<template v-if="mode==='copyCategorySettings'">
    <div style="display: flex;align-items: center;margin: 20px 0px 20px 0px">
        <span>[`Выберите аккаунт Ozon`]:</span>
        <select id="source-account-id" style="margin-left: 10px;">
            <option>[`Выберите аккаунт`]</option>
            <option v-for="(acc, idx) in sourceCopyAccounts" :value="acc.id">{{acc.name}}</option>
        </select>
        <div style="display: inline-block; margin-left: 10px;">
            <action-button @bClick="copyCategorySettings()" title="[`Копировать`]" action="copyXategorySettings" :run="runAction" icon="icon16 split" bclass="middle"></action-button>
            <action-button @bClick="mode=false" bclass="middle" icon="icon16 no" action="tmp" :run="runAction" title="[`Отмена`]"></action-button>
        </div>
    </div>
</template>
<!-- Левая колонка -->
<div class="ozonseller-category-property">
<div class="sidebar left250px">
    <div class="block double-padded">
        <span id="ozonseller-yes-type" class="gray" v-if="Object.keys(cCategory.types)">[`Настроенные типы товаров`]</span>
        <span id="ozonseller-no-type" class="gray" v-else>[`Для категории Ozon пока не настроен ни один тип товара`]</span>
        <ul id="ozonseller-list-types" class="menu-v with-icons">
            <li v-for="(type, type_id) in cCategory.types" :class="type_id == cCategory.cType.id ? 'selected' : ''">
                <a @click="setCategoryType(type_id)" class="ozonseller-type">
                    <i :class="getTypeIcon(type_id)"></i>
                    {{getTypeName(type_id)}}
                </a>
            </li>
        </ul>
        <div class="hr"></div>
        <select id="ozonseller-add-type-select" style="margin-top: 5px;width:-webkit-fill-available;" v-model="cCategory.newType">
            <option :value="0">[`Выберите тип товаров`]</option>
            <template v-for="(t, idx) in types">
                <option :value="t.id" :disabled="cCategory.types.hasOwnProperty(t.id)">{{t.name}}</option>
            </template>
        </select>
        <a @click="addTypeFeatures()"  class="small" style="display: block; padding-top: 10px;"><i class="icon10 add"></i> [`добавить`]</a><br>
        <br><br><br>
        <action-button @bClick="refreshDictionaries()" title="[`Обновить справочники`]" action="refreshDictionaries" :run="runAction" icon="icon16 view-table"></action-button>
        <div class="block" style="margin-top: 100px;">
            <a v-if="mode===false" @click="mode='removeCategory'" class="small"><i class="icon10 no-bw"></i> [`убрать категорию из обработки`]</a>
            <div class="ozonseller-category-del-buttons" v-if="mode==='removeCategory'">
                <div class="block">
                    <span class="red small ozonseller-del-category-attention">
                        <i class="icon16 exclamation"></i> [`При удалении данной категории из Ozon будут сняты с продажи {{cCategory.count}} товаров`]
                    </span>
                </div>
                <action-button @bClick="removeCategory()" title="[`Удалить`]" action="removeCategory" :run="runAction" icon="icon16 trash" bclass="small red"></action-button>
                <div @click="mode=false" class="ozonseller-button small">
                    <i class="icon16 no"></i>
                    <a class="ozonseller-category-cancel">[`Отмена`]</a>
                </div>
            </div>
        </div>
    </div>
</div>
{/literal}
<!-- Характеристики-->
<div class="content left250px bordered-left blank">
    {include './category_features_old.vue'}
</div>
</div>
