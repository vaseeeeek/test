{literal}
<a @click="cCategory=false" class="button gray outlined smaller"><i class="fas fa-chevron-left"></i>&nbsp;&nbsp;[`Назад`]</a>
<h3 style="display: contents;">
    {{cCategory.name}} <span class="gray small" style="display: inline;">(id {{cCategory.id}})</span>
</h3>&nbsp;&nbsp;&nbsp;
<span v-if="cCategory.status-0===2" style="font-weight: bold;color: red">[`Категория удалена из Ozon`]</span>
    <a @click="mode='copyCategorySettings'" class="button smallest custom-ml-12" v-if="!cCategory.types && !mode && sourceCopyAccounts.length"><i class="far fa-copy"></i>&nbsp;&nbsp;[`Скопировать настройки`]</a>
<template v-if="mode==='copyCategorySettings'">
    <div class="custom-mt-24 flexbox small">
        <span>[`Выберите аккаунт Ozon`]:</span>
        <select class="custom-ml-12" id="source-account-id">
            <option>[`Выберите аккаунт`]</option>
            <option v-for="(acc, idx) in sourceCopyAccounts" :value="acc.id">{{acc.name}}</option>
        </select>
        <div  class="custom-ml-12" style="display: inline-block">
            <action-button @bClick="copyCategorySettings()" title="[`Копировать`]" action="copyXategorySettings" :run="runAction" icon="far fa-copy" bclasss="smallest green"></action-button>
            <action-button @bClick="mode=false" bclass="gray smallest" icon="fas fa-undo-alt" action="tmp" :run="runAction" title="[`Отмена`]"></action-button>
        </div>
    </div>
</template>
<!-- Левая колонка -->
<!--<div class="ozonseller-category-property">-->
<div class="flexbox small">
<div class="sidebar ozonseller custom-mt-24">
        <span id="ozonseller-yes-type" class="gray" v-if="Object.keys(cCategory.types)">[`Настроенные типы товаров`]</span>
        <span id="ozonseller-no-type" class="gray" v-else>[`Для категории Ozon пока не настроен ни один тип товара`]</span>
        <ul id="ozonseller-list-types" class="list">
            <li v-for="(type, type_id) in cCategory.types" :class="type_id == cCategory.cType.id ? 'item selected' : 'item'">
                <a @click="setCategoryType(type_id)" class="image"><i class="fas fa-box "></i></a>
                <a @click="setCategoryType(type_id)" class="details">{{getTypeName(type_id)}}</a>
            </li>
        </ul>
        <div class="hr"></div>
        <select id="ozonseller-add-type-select" style="margin-top: 5px;width:-webkit-fill-available;" v-model="cCategory.newType">
            <option :value="0">[`Выберите тип товаров`]</option>
            <template v-for="(t, idx) in types">
                <option :value="t.id" :disabled="cCategory.types.hasOwnProperty(t.id)">{{t.name}}</option>
            </template>
        </select>
        <a @click="addTypeFeatures()"  class="button smallest gray outlined" style="margin-top: 20px;"><i class="fas fa-plus"></i> [`добавить`]</a><br>
        <br><br><br>
        <action-button @bClick="refreshDictionaries()" title="[`Обновить справочники`]" action="refreshDictionaries" :run="runAction" icon="far fa-list-alt" bclass="gray outlined"></action-button>
        <div class="block" style="margin-top: 100px; line-height: 1">
            <a v-if="mode===false" @click="mode='removeCategory'" class="smaller button gray outlined" style="font-size: 65%;"><i class="fas fa-times"></i> [`убрать категорию из обработки`]</a>
            <div class="ozonseller-category-del-buttons" v-if="mode==='removeCategory'">
                <div class="block">
                    <span class="red smaller ozonseller-del-category-attention">
                        <i class="fas fa-exclamation-circle"></i> [`При удалении данной категории из Ozon будут сняты с продажи {{cCategory.count}} товаров`]
                    </span>
                </div>
                <action-button @bClick="removeCategory()" title="[`Удалить`]" action="removeCategory" :run="runAction" icon="fas fa-trash-alt" bclass="smallest red outlined"></action-button>
                <a @click="mode=false" class="button green outlined smallest" style="margin-left: 25px;"><i class="fas fa-undo"></i> [`Отмена`]</a>
            </div>
        </div>
</div>
{/literal}
<!-- Характеристики-->
<div class="content custom-p-16" style="position: unset !important;">
    {include './category_features.vue'}
</div>
</div>
<!--
</div>
-->
