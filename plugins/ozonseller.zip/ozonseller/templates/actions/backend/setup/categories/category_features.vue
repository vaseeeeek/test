{literal}
<template v-if="cCategory.cType">
    <div class="ozonseller-markups-div" v-if="schema==='free'">
        <div class="ozonseller-of-description">
            [` Товары данного типа публикуемые в данной категории Ozon будут публиковаться по схеме:`]<br>
        </div>
        <template v-if="schema==='free'">
            <input @change="setCategorySchema('fbo')" type="radio" value="0" id="category-schema-fbo" :checked="checkCategorySchema('fbo')" style="margin: 5px;">&nbsp;<label for="category-schema-fbo">[`По схеме FBO`]</label><br>
            <input @change="setCategorySchema('fbs')" type="radio" value="1" id="category-schema-fbs" :checked="checkCategorySchema('fbs')" style="margin: 5px;">&nbsp;<label for="category-schema-fbs">[`По схеме FBS`]</label>
        </template>
    </div>
    <div>
    <div class="tablebox">
        <div class="cell-icons"></div>
        <div class="cell-ozon header">[`Характеристики Ozon`]</div>
        <div class="cell-shop header">[`Характеристики магазина`]</div>
        <div class="cell-ext header"></div>
    </div>
        <template v-for="(of, of_id) in cCategory.ozon_features">
            <match-feature :of="of" :type="cCategory.cType" :child="false" :pname="of.name"
                           :ocat_id="cCategory.id"></match-feature>
            <template v-if="of.hasOwnProperty('child') && of.child">
                <match-feature :of="of" :type="cCategory.cType" :child="true" :pname="of.name"
                               :ocat_id="cCategory.id"></match-feature>
            </template>
        </template>
    </div>
    <div class="ozonseller-footer" style="height: 6rem;">
        <div style="display: block; margin-bottom: 8px;">
            <div id="ozonseller-required-warning" style="color: red;"></div>
        </div>
        <action-button @bClick="saveCategoryFeatures()" title="[`Сохранить`]" icon="fas fa-save" action="saveCategoryFeatures"
                       :run="runAction"></action-button>
        <action-button @bClick="mode='delCategoryType'" v-if="!mode" title="[`Убрать тип товаров из обработки`]" action="delCategoryType" :run="runAction" icon="far fa-trash-alt" bclass="gray outlined" style="margin-left: 220px"></action-button>
        <template v-if="mode==='delCategoryType'">
            <div class="ozonseller-category-del-buttons" style="margin-left: 150px; display: inline-block">
                    <span class="red smaller" style="float: left; margin-right: 40px;">
                        <i class="fas fa-exclamation-circle"></i> [`При удалении данного типа товаров из Ozon будут сняты с продажи`] {{cCategory.cType.count}} [`товаров`]
                    </span>
                <action-button @bClick="removeCategoryType()" title="[`Удалить`]" action="removeCategoryType" :run="runAction" icon="far fa-trash-alt" bclass="red outlined smaller"></action-button>
                <a @click="mode=false" class="button green outlined smaller" style="margin-left: 40px;"><i class="fas fa-undo"></i> [`отмена`]</a>
            </div>
        </template>
    </div>
</template>
<template v-else>
    <div class="block double-padded align-center gray">
        <p><strong>[`Выберите или добавьте тип товара в левом столбце`]</strong></p>
    </div>
</template>
{/literal}