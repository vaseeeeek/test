<accounts-menu @setAccount="accountId=$event-0" :account="accountId" :action="runAction"></accounts-menu>
{include './markups.vue'}
<template v-if="!cCategory">
    <div class="hr"></div>
    {literal}
    <div style="display: flex">
        <div id="ozonseller-categories" class="ozonseller-categories">
            <div class="block double-padded">
                <span class="grey">[`Всего категорий Ozon`]: {{ ozonCatsCount }}, [`настроено`]: {{
                        categories.length
                    }}</span>
            </div>
            <div class="block" v-if="runAction==='newCategoryDialog'">
                <div>
                    <select id="ozonseller-ozon-categories-select">
                        <option v-for="(oc, idx) in ozonCategories" :value="oc.id" :disabled="checkDisabledCategory(idx)" v-html="getOzonCategoryTreeName(idx)"></option>
                    </select>&nbsp;&nbsp;&nbsp;&nbsp;
                </div>
                <div style="margin-top:25px;">
                    <action-button @bClick="addNewCategory()" title="[`Настроить выбранную категорию`]" icon="fas fa-cogs" action="setNewCategory" :run="runAction==='setNewCategory'?'setNewCategory': false" bclass="smallest outlined"></action-button>&nbsp;&nbsp;&nbsp;
                    <action-button @bClick="runAction=false" title="[`Отмена`]" icon="fas fa-times" action="cancelNewCategory" :run="runAction==='setNewCategory'?'setNewCategory': false" bclass="smallest outlined gray"></action-button>
                </div>
            </div>
            <div class="block">
                <action-button v-if="runAction!=='setNewCategory' && runAction!=='newCategoryDialog'" @bClick="getOzonCategories()" title="[`Добавить категорию Ozon`]" icon="far fa-plus-square" action="getOzonCategories" :run="runAction" bclass="smallest outlined gray"></action-button>
            </div>
                <ul id="ozonseller-list-categories" class="list">
                    <li v-for="(category, idx) in categories" class="item" style="position: unset !important;">
                        <a @click="setOzonCategory(category.id)" class="image"><i style="color: green" class="far fa-folder"></i></a>&nbsp;&nbsp;
                        <div class="details">
                            <a @click="setOzonCategory(category.id)" :style="category.status-0===2?'text-decoration: line-through;':''">{{ category.name }}</a>&nbsp;&nbsp;&nbsp;
                            <span v-if="category.status-0===2" style="font-weight: bold;color: red">[`Категория удалена из Ozon`]</span>
                        </div>
                    </li>
                </ul>
            <div class="block ozonseller-categories">
                <div v-show="runAction==='refreshOzonCategories'" class="small">
                    <gradusnik
                            @donerun="runAction=false"
                            :bar="bar"
                            url="?plugin=ozonseller&action=refreshOzonCategory"
                            :timeout="5000"
                            :run="runAction==='refreshOzonCategories'"
                            :params="{ account_id: accountId}"
                    >
                    </gradusnik>
                </div>
                <action-button @bClick="runAction='refreshOzonCategories'" title="[`Обновить список категорий Ozon`]"
                               icon="fas fa-sync-alt"
                               action="refreshOzonCategories"
                               :run="runAction" v-show="runAction!=='refreshOzonCategories'"
                               bclass="smallest outlined gray"
                ></action-button>
            </div>
        </div>
        <div style="margin-top: 50px">
            <div v-if="runAction==='getCategoryInfo'" class="spinner custom-p-8"></div>
        </div>
    </div>
    {/literal}
</template>
<div id="ozonseller-category" v-else>
    {include './category.vue'}
</div>
