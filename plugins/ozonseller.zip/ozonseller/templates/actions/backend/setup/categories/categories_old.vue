<accounts-menu @setAccount="accountId=$event-0" :account="accountId" :action="runAction"></accounts-menu>
{include './markups.old.vue'}
<template v-if="!cCategory">
    <div class="hr"></div>
    {literal}
    <div style="display: flex">
        <div id="ozonseller-categories" class="ozonseller-categories">
            <div class="block double-padded">
                <span class="grey">[`Всего категорий Ozon`]: {{ ozonCatsCount }}, [`настроено`]: {{ categories.length }}</span>
            </div>
            <div class="block" v-if="runAction==='newCategoryDialog'">
                <div>
                    <select id="ozonseller-ozon-categories-select">
                        <option v-for="(oc, idx) in ozonCategories" :value="oc.id" :disabled="checkDisabledCategory(idx)" v-html="getOzonCategoryTreeName(idx)"></option>
                    </select>&nbsp;&nbsp;&nbsp;&nbsp;
                </div>
                <div style="margin-top:25px;">
                    <action-button @bClick="addNewCategory()" title="[`Настроить выбранную категорию`]" icon="icon16 settings" action="setNewCategory" :run="runAction==='setNewCategory'?'setNewCategory': false" bclass="middle"></action-button>&nbsp;&nbsp;&nbsp;
                    <action-button @bClick="runAction=false" title="[`Отмена`]" icon="icon16 no" action="cancelNewCategory" :run="runAction==='setNewCategory'?'setNewCategory': false" bclass="middle"></action-button>
                </div>
            </div>
            <div class="block">
                <action-button v-if="runAction!=='setNewCategory' && runAction!=='newCategoryDialog'" @bClick="getOzonCategories()" title="[`Добавить категорию Ozon`]" icon="icon16 add" action="getOzonCategories" :run="runAction" bclass="small"></action-button>
            </div>
            <div class="block" style="margin-top: 20px;">
                <ul id="ozonseller-list-categories" class="menu-v with-icons">
                    <li v-for="(category, idx) in categories">
                        <span style="display: inline-flex">
                            <a @click="setOzonCategory(category.id)" class="disabled" :style="category.status-0===2?'text-decoration: line-through;':''"><i class="icon16 folder"></i> {{ category.name }}</a>
                            <span v-if="category.status-0===2" class="small" style="font-weight: bold;color: red;margin-left: 5px;">[`Категория удалена из Ozon`]</span>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
        <div style="margin-top: 50px">
            <i v-if="runAction==='getCategoryInfo'" class="icon16 loading"></i>
        </div>
    </div>
    <div class="clear"></div>
    <div class="block ozonseller-categories">
        <div v-show="runAction==='refreshOzonCategories'">
            <gradusnik
                    @donerun="runAction=false"
                    :bar="bar"
                    url="?plugin=ozonseller&action=refreshOzonCategory"
                    :timeout="5000"
                    :run="runAction==='refreshOzonCategories'"
                    :params="{ account_id: accountId}"
            >
            </gradusnik>
        </div>
        <action-button @bClick="runAction='refreshOzonCategories'" title="[`Обновить список категорий Ozon`]"
                       icon="icon16 update"
                       action="refreshOzonCategories"
                       :run="runAction" v-show="runAction!=='refreshOzonCategories'"></action-button>
    </div>
    {/literal}
</template>
<div id="ozonseller-category" v-else>
{include './category_old.vue'}
</div>