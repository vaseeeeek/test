{literal}
<div class="ozonseller-markups-div">
<div class="ozonseller-category-markups view" v-if="modeMarkups==='view'">
    <span class="gray" v-if="!cCategory">[`Наценки по умолчанию`]:</span>
    <div class=" gray ozonseller-category-markups-view-table">
        <div style="margin: 10px 0 10px 0">
            <table class="ozonseller-table-markups">
                <tr v-for="(markup, idx) in getMarkups()" v-if="markups.hasOwnProperty(getCategoryId) && markups[getCategoryId]!==undefined && markups[getCategoryId].length">
                    <td>[`от`]</td>
                    <td>{{markup.price_from}}</td>
                    <td>{{markup.currency}}</td>
                    <td>[`наценка`]</td>
                    <td>{{markup.markup}}</td>
                    <td>{{markup.markup_type}}</td>
                </tr>
                <tr v-else>
                    <td>[`Используются наценки по умолчанию`]</td>
                </tr>
            </table>
        </div>
    </div>
    <a @click="setEditMarkups()" class="small"><i class="icon10 edit"></i> [`изменить`]</a>
</div>
<div class="ozonseller-category-markups edit" v-else>
    <div class="ozonseller-category-markup-fields">
        <table class="ozonseller-table-markups edit">
            <tr v-for="(markup, idx) in editMarkups">
                <td>[`от`]</td>
                <td><input type="number" min="0" v-model="editMarkups[idx].price_from" class="short"></td>
                <td>
                    <select v-model="editMarkups[idx].currency">
                        <option :value="currency" v-for="(currency, idx) in currencies">{{currency}}</option>
                    </select>
                </td>
                <td>[` наценка `]</td>
                <td><input v-model="editMarkups[idx].markup" type="number" class="short"></td>
                <td>
                    <select v-model="editMarkups[idx].markup_type">
                        <option value="%">[`%`]</option>
                        <option :value="currency" v-for="(currency, idx) in currencies">{{currency}}</option>
                    </select>
                </td>
                <td>
                    <a @click="editMarkups.splice(idx,1)" v-show="cCategory || (!cCategory && idx!==0)" class="small">[`удалить`]</a>
                </td>
            </tr>
        </table>
        <a @click="addMarkup()" class="small"><i class="icon10 add"></i> [`добавить`]</a>
    </div>
    <br>
    <span class="small">
        <a @click="saveMarkups()" class="inline-link ozonseller-category-checked-a"><b><i>[`Сохранить`]</i></b></a> [`или`]
        <a @click="editMarkups=false;modeMarkups='view'" class="inline-link" style="display: inline"><b><i>[`отмена`]</i></b></a>
    </span>
</div>
</div>
{/literal}