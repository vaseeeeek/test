{literal}
<div class="block double-padded">
<accounts-menu @setAccount="accountId=$event-0" :account="accountId" :action="runAction"></accounts-menu>
<div class="fields">
    <template v-for="(set, set_id) in settings">
        <div class="field" v-if="set && set.subject==='orders' && checkBySchema(set_id)">
            <div class="name" v-if="checkBySchema(set_id)">{{set.title}}</div>
            <div class="value">
                <span :set_id="set_id" style="display: none"></span>
                <template v-if="set.control_type==='input'">
                    <input :type="set.field_type ? set.field_type : 'text'" :class="set.class" v-model="settings[set_id].value">
                    <span v-if="set.hasOwnProperty('description') && set.description.length"
                          class="small gray setting-hint" v-html="set.description"></span>
                </template>
                <template v-else-if="set.control_type==='select'">
                    <select v-model="settings[set_id].value">
                        <option value="">[`Выберите значение`]</option>
                        <template v-for="(n, v) in set.options">
                            <template v-if="n.hasOwnProperty('title')">
                                <option :value="n.value">{{n.title}}</option>
                            </template>
                            <template v-else>
                                <option :value="v">{{n}}</option>
                            </template>
                        </template>
                    </select>
                    <span v-if="set.hasOwnProperty('description') && set.description.length"
                          class="small gray setting-hint" v-html="set.description"></span>
                </template>
                <template v-else-if="set.control_type==='checkbox'">
                    <input type="checkbox" @change="changeCheckbox(set_id)" :checked="settings[set_id].value==1">
                    <span class="small gray setting-hint" v-if="set.description.length">{{set.description}}</span>
                </template>
                <template v-else-if="set.control_type==='orderCollect'">
                    <template v-if="settings.schema.value!=='fbo'">
                        <select v-model="settings[set_id].value">
                            <option value="1">Отдельная кнопка "Собрать заказ"</option>
                            <optgroup label="Действия с заказом">
                                <option v-for="(act, idx) in actions" :value="act.value">{{act.title}}</option>
                            </optgroup>
                        </select>
                        <span class="small gray setting-hint">[`Выберите каким образом будет осуществляться "сборка" заказа в Озон: отдельной кнопкой в заказе или при выполнении одного из действий с заказом`]</span>
                    </template>
                </template>
                <template v-else-if="set.control_type==='orderContact'">
                    <div v-show="!editContact">
                        <template v-if="settings.contact">
                            <span>{{settings.contact.name}}</span>&nbsp;&nbsp;&nbsp;
                        </template>
                        <a @click="editContact=true" class="small"><i class="far fa-edit"></i> <span
                                v-html="settings.contact?'[`Изменить`]':'[`Выбрать`]'"></span></a>
                        <span class="small gray setting-hint">{{set.description}}</span>
                    </div>
                    <div v-show="editContact">
                        <input id="ozonseller-settings-contact-id" class="long" placeholder="[`Введите часть имени`]">
                        &nbsp&nbsp;<i class="icon16 update"></i> <a @click="editContact=false"
                                                                    class="small">[`отмена`]</a>
                    </div>
                </template>
                <template v-else-if="set.control_type==='OzonsellerUniversalCombiSelect'">
                    <combi-control :setting="set" :set_id="set_id"></combi-control>
                </template>
                <template v-else-if="set.control_type==='help'">
                    <h5>{{set.value}}</h5>
                </template>
                <template v-else>
                    <div class="red">[`Неизвестный тип настройки:`] {{set.control_type}}</div>
                </template>
            </div>
        </div>
    </template>
    <template v-for="(set, set_id) in settings">
        <template v-if="set && (set.subject==='orders_extend' || !set.subject) && set.control_type">
            <template v-if="set.control_type==='orderParams'">
                <div style="margin-top: 25px;">
                    <h5>[`Выберите параметры для создания заказа поступившего из Ozon`]</h5>
                    <template v-if="settings.ozonStocks.length">
                        <div style="display:table; margin-top: 25px;">
                            <div style="display: table-row">
                                <div class="ozonseller-cell header">
                                    <strong class="ozonseller-table-title ozonseller-ozon-order-params title">[`Склады
                                        Ozon`]</strong>
                                </div>
                                <div class="ozonseller-cell header">
                                    <strong>[`Списание остатков`]</strong>
                                </div>
                                <div class="ozonseller-cell header">
                                    <strong>[`Метод доставки`]</strong>
                                </div>
                                <div class="ozonseller-cell header">
                                    <strong>[`Способ оплаты`]</strong>
                                </div>
                            </div>

                            <div style="display: table-row" v-if="settings.schema.value!=='fbs'">
                                <div class="ozonseller-cell">
                                    <span class="ozonseller-ozon-order-params-stock-name help">[`Склад FBO`]</span>
                                </div>
                                <div class="ozonseller-cell">
                                    <select v-model="settings.order_params.value.fbo.stock_id">
                                        <option :value="0">[`Выберите значение`]</option>
                                        <option :value="stock.id" v-for="(stock, idx) in stocks">{{stock.name}}</option>
                                    </select>
                                </div>
                                <div class="ozonseller-cell">
                                    <select v-model="settings.order_params.value.fbo.shipping">
                                        <option v-for="(shipping, idx) in shippings" :value="shipping.value">
                                            {{shipping.title}}
                                        </option>
                                    </select>
                                </div>
                                <div class="ozonseller-cell">
                                    <select v-model="settings.order_params.value.fbo.payment">
                                        <option v-for="(payment, idx) in payments" :value="payment.value">
                                            {{payment.title}}
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <template v-for="(ostock, idx) in settings.ozonStocks" v-if="settings.schema.value!=='fbo'">
                                <div style="display: table-row" v-if="settings.schema.value!=='fbo'">
                                    <div class="ozonseller-cell">
                                        <span class="ozonseller-ozon-order-params-stock-name help">{{ostock.name}}</span>
                                    </div>
                                    <div class="settings-order-params  ozonseller-cell">
                                        <select v-model="settings.order_params.value.fbs[ostock.warehouse_id].stock_id">
                                            <option :value="0">[`Выберите значение`]</option>
                                            <option :value="stock.id" v-for="(stock, idx) in stocks">{{stock.name}}
                                            </option>
                                        </select>
                                    </div>
                                    <div class="settings-order-params ozonseller-cell">
                                        <select v-model="settings.order_params.value.fbs[ostock.warehouse_id].shipping">
                                            <option v-for="(shipping, idx) in shippings" :value="shipping.value">
                                                {{shipping.title}}
                                            </option>
                                        </select>
                                    </div>
                                    <div class="settings-order-params ozonseller-cell">
                                        <select v-model="settings.order_params.value.fbs[ostock.warehouse_id].payment">
                                            <option v-for="(payment, idx) in payments" :value="payment.value">
                                                {{payment.title}}
                                            </option>
                                        </select>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </template>
                    <template v-else>
                        <span>
                            <i class="icon16 exclamation"></i> [`Ошибка получения складов Ozon`]
                        </span>
                    </template>
                </div>
            </template>
            <template v-else-if="set.control_type==='orderStatuses'">
                <div style="margin: 35px 0 15px 0;">
                    <h5>[`Выберите какое действие выполнять с заказом при изменении статуса заказа в Ozon`]</h5>
                </div>
                <div style="display:table;">
                    <div style="display: table-row; margin-bottom: 2px;">
                        <div class="ozonseller-cell">
                            <strong>[`Статус заказа в Ozon`]</strong>
                        </div>
                        <div class="ozonseller-cell">
                            <strong>[`Действие с заказом в Shop-Script`]</strong>
                        </div>
                    </div>

                    <div style="display: table-row;" v-for="(ost, val) in ozonStatuses">
                        <div class="ozonseller-cell">
                            <span>{{ost.title}}</span>
                        </div>
                        <div class="ozonseller-cell">
                            <select v-model="settings.ozon_order_status.value.fbo[ost.value]">
                                <option :value="0">[`Не выполнять действие`]</option>
                                <option v-for="(act, idx) in actions" :value="act.value">{{act.title}}</option>
                            </select>
                        </div>
                    </div>
                </div>
                <template v-if="settings.schema.value!=='fbo'">
                    <div style="margin: 35px 0 15px 0;">
                        <h5>[`Выберите в какой статус переводить заказы в Ozon при совершении действий с заказом в
                            Shop-Script (схема rFBS)`]</h5>
                    </div>
                    <div style="display:table;">
                        <div style="display: table-row">
                            <div class="ozonseller-cell">
                                <strong>[`Действие с заказом в Shop-Script`]</strong>
                            </div>
                            <div class="ozonseller-cell">
                                <strong>[`Статус заказа в Ozon`]</strong>
                            </div>
                        </div>
                        <div style="display: table-row" v-for="(action, idx) in actions">
                            <div class="ozonseller-cell">
                                <span>{{action.title}}</span>
                            </div>
                            <div class="ozonseller-cell">
                                <select name="shop_ozonseller[ozon_order_status][fbs][process]"
                                        v-model="settings.ozon_order_status.value.fbs[action.value]">
                                    <option :value="0">[`Не изменять статус заказа в Ozon`]</option>
                                    <option :value="fs.value" v-for="(fs, idx) in fbsActions">{{fs.title}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </template>
            </template>
            <template v-else-if="set.control_type==='groupbox'">
                <div style="margin-top: 25px;">
                    <div class="field">
                        <div class="name">{{set.title}}</div>
                        <div class="value">
                            <span class="setting-hint" v-for="(opt, idx) in set.options">
                                <input @change="changeGroupbox(set_id, opt.value)"
                                       :checked="checkGroupbox(set_id, opt.value)" type="checkbox" :value="opt.value"
                                       :id="'groupbox-'+set_id+'-'+opt.value">
                                <label :for="'groupbox-'+set_id+'-'+opt.value"
                                       style="margin-left: 5px;">{{opt.title}}</label>
                            </span>
                        </div>
                    </div>
                </div>
            </template>
            <template v-else>
                <div class="red">[`Неизвестный тип настройки:`] {{set.control_type}}</div>
            </template>
        </template>
    </template>
    <div class="ozonseller-footer">
    <action-button @click="saveSettings()" title="[`Сохранить`]" icon="fas fa-save" action="saveSettings"
                   :run="runAction" :result="runResult"></action-button>
    </div>
</div>
</div>
{/literal}