ords = Vue.createApp({
    data() {
        return {
            accountId: null,
            settings: { },
            accSettings: {$accSettings},
            stocks: {$stocks},
            options: {$options},
            actions: {$actions},
            payments: {$payments},
            shippings: {$shippings},
            fbsActions: {$fbs_actions},
            ozonStatuses: {$ozon_statuses},
            editContact: false,
            newUi: {$newUi},
            runAction: false,
            runResult: null
        }
    },
    computed: {
        checkBoolFeatures() {
            let check = false;
            if (!this.options.hasOwnProperty('features') || !this.options.features.length) return check;
            this.options.features.forEach( (ft, idx) => {
                if (ft.type === 'boolean') check = true;
            });
            return check;
        }
    },
    mounted: function () {
        ozonseller.cApp = ords;
        this.accountId = ozonseller.accountId;
        this.setSettings();
        if (this.ozonStatuses.length) {
            this.ozonStatuses.forEach( (idx, s) => {
                if (!this.settings.ozon_order_status.value.fbo.hasOwnProperty(s.value)) this.settings.ozon_order_status.value.fbo[s.value] = 0;
            });
        }
        let acParams = {
            minLength: 2,
            source: '?plugin=ozonseller&action=findContact',
            select: (event, ui) => {
                this.settings.contact = { 'id': ui.item.value, 'name': ui.item.label};
                this.settings.contact_id.value = ui.item.value;
                this.editContact = false;
            }
        }
        if (this.newUi) {
            this.$nextTick(() => {
                $('#ozonseller-settings-contact-id').waAutocomplete( acParams);
            });
        } else {
            this.$nextTick(() => {
                $('#ozonseller-settings-contact-id').autocomplete( acParams);
            });
        }
    },
    watch: {
        accountId: function () {
            ozonseller.accountId = this.accountId;
            this.setSettings();
        },
        runAction: function () {
            ozonseller.runAction = this.runAction;
        },
        editContact: function () {
            if (this.editContact) $('#ozonseller-settings-contact-id').val('');
        }
    },
    methods: {
        saveSettings: function () {
            this.runAction = 'saveSettings';
            let settings = { };
            Object.keys(this.settings).forEach((set_id) => {
                settings[set_id] = this.settings[set_id].value;
            });
            $.post('?plugin=ozonseller&action=settingsSave', { type: 'orders', account_id:this.accountId, settings: settings}, r => {
                if (r.status === 'ok') {
                    this.finishAction();
                    this.accSettings[this.accountId] = r.data;
                    Object.keys(this.accSettings).forEach( (acc_id) => {
                        this.accSettings[acc_id].shop_orders = r.data.shop_orders;
                    });
                }
                else {
                    ozonseller.setError(r.errors);
                    this.runAction = false;
                }
            });
        },
        changeCheckbox: function (set, el = null) {
            if (!this.settings.hasOwnProperty(set)) return;
            if (el === null || !el.length) {
                this.settings[set].value = (this.settings[set].value-0 === 0 ? 1 : 0);
            } else this.settings[set].value[el] = (this.settings[set].value[el]-0 === 0 ? 1 : 0);
        },
        changeGroupbox: function (set_id, value) {
            if (!this.settings.hasOwnProperty(set_id)) return false;
            if (this.settings[set_id].value.includes(value)) {
                let idx = this.settings[set_id].value.findIndex(function (el, idx) { return el === value });
                if (idx >=0) {
                    this.settings[set_id].value.splice(idx, 1);
                }
            } else {
                this.settings[set_id].value.push(value);
            }
        },
        checkGroupbox: function(set_id, value) {
            if (!this.settings.hasOwnProperty(set_id)) return false;
            return this.settings[set_id].value.includes(value);
        },
        checkBySchema: function (set_id) {
            if (this.settings.schema.value === 'free') return true;
            let onlyFboSettings = [];
            let onlyFbsSettings = ['order_collect', 'print_label'];
            if (this.settings.schema.value === 'fbo') return !onlyFbsSettings.includes(set_id);
            else  return !onlyFboSettings.includes(set_id);
        },
        setSettings: function () {
            this.editContact = false;
            let settings = { };
            if (this.accountId && this.accSettings.hasOwnProperty(this.accountId)) {
                settings = JSON.parse(JSON.stringify(this.accSettings[this.accountId]));
            }
            this.settings = settings;
        },
        finishAction: function(timeOut = 2000) {
            this.runResult = true;
            setTimeout(() => {
                this.runAction = false;
                this.runResult = null;
            }, timeOut);
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        }
    }
});
{include '../../../combiControl.js'}
{include '../../../accountsMenu.js'}
ords.component('accountsMenu', ozonAccounts);
ords.component('actionButton', actionButton);
ords.component('combiControl', combiControl);
osOrds = ords.mount('div#ozonseller-import-tab-orders');

