{literal}
<div class="block double-padded">
<div class="fields">
    <accounts-menu @setAccount="accountId=$event-0" :account="accountId" :action="runAction"></accounts-menu>
    <template v-for="(set, set_id) in settings">
        <div class="field" v-if="set.subject==='prices'">
            <div class="name">{{set.title}}</div>
            <div class="value">
                <span :set_id="set_id" style="display: none"></span>
                <template v-if="set.control_type==='input'">
                    <input type="text" v-model="settings[set_id].value" class="long">
                    <span v-if="set.hasOwnProperty('description') && set.description.length"
                          class="small gray setting-hint" v-html="set.description"></span>
                </template>
                <template v-else-if="set.control_type==='select'">
                    <select v-model="settings[set_id].value">
                        <option value="">[`Выберите значение`]</option>
                        <template v-for="(n, v) in set.options">
                            <template v-if="n.hasOwnProperty('title')">
                                <option :value="n.value">{{n.title}}</option>
                            </template>
                            <template v-else>
                                <option :value="v">{{n}}</option>
                            </template>
                        </template>
                    </select>
                    <span v-if="set.hasOwnProperty('description') && set.description.length"
                          class="small gray setting-hint" v-html="set.description"></span>
                </template>
                <template v-else-if="set.control_type==='OzonsellerUniversalCombiSelect'">
                    <combi-control :setting="set" :set_id="set_id"></combi-control>
                    <select v-model="settings.price_markups.value[set_id]" v-if="set_id!=='markup_product'">
                        <option :value="1">[`Применять наценки к этому виду цен`]</option>
                        <option :value="0">[`Не применять наценки к этому виду цен`]</option>
                    </select>
                </template>
                <template v-else-if="set.control_type==='help'">
                    <h5>{{set.value}}</h5>
                </template>
                <template v-else>
                    <div class="red">[`Неизвестный тип настройки:`] {{set.control_type}}</div>
                </template>
            </div>
        </div>
    </template>
    <template v-for="(set, set_id) in settings">
        <template v-if="set.control_type==='ozonStocks'">
            <template v-if="settings.ozonStocks.length">
                <div id="ozonseller-settings-stock-ids"
                     v-show="settings.schema.value.length && settings.schema.value!=='fbo'">
                    <div style="display: table-row">
                        <div class="ozonseller-stock-cell header">Ozon</div>
                        <div class="ozonseller-stock-cell header">Shop-Script</div>
                        <div class="ozonseller-stock-cell header">Признак "Снять с продажи"</div>
                    </div>
                    <div style="display: table-row" v-for="(ostock, idx) in settings.ozonStocks">
                        <div class="ozonseller-stock-cell">{{ostock.name}}</div>
                        <div class="ozonseller-stock-cell">
                            <select v-model="settings[set_id].value[ostock.warehouse_id]">
                                <option :value="0">[`Не использовать`]</option>
                                <option value="count">[`Суммарное количество товара`]</option>
                                <template v-if="stocks">
                                    <option v-for="(stock, idx) in stocks" :value="idx">{{stock.name}}</option>
                                </template>
                            </select>
                        </div>
                        <div class="ozonseller-stock-cell">
                            <select v-model="settings.null_quantity.value[ostock.warehouse_id]">
                                <option :value="0">[`Не использовать`]</option>
                                <template v-if="checkBoolFeatures" v-for="(f, idx) in options.features">
                                    <option v-if="f.type==='boolean'" :value="f.value">{{f.title}}</option>
                                </template>
                                <template v-else>
                                    <option disabled>[`Отсутствуют общие характеристики с типом Да/Нет`]</option>
                                </template>
                            </select>
                        </div>
                    </div>
                </div>
            </template>
            <template v-else-if="settings.schema.value!=='fbo'">
                <div style="display: table-row">
                    <div style="display: table-cell">
                        <span>
                            <i class="icon16 exclamation"></i> [`Ошибка получения складов Ozon`]
                        </span>
                    </div>
                </div>
            </template>
        </template>
    </template>
    <div style="margin-top: 25px;">
        <div class="block">
            <h5 style="margin:10px;">[`Дополнительные настройки`]</h5>
        </div>
        <template v-for="(set, set_id) in settings">
            <div class="block" v-if="set_id === 'null_product_quantity'">
                <input v-model="settings.null_product_quantity.value" type="number" class="short">&nbsp;&nbsp;&nbsp;<span>[`Количество которое будет передаваться в Ozon при бесконечных остатках`]</span>
            </div>
            <div class="block" v-if="set_id === 'calculation'">
                <input @change="changeExtCheckbox('calculation')" :checked="settings.calculation.value==1" type="checkbox" id="ozonseller-cb-calculation"> <label
                    for="ozonseller-cb-calculation">[`Система автоматического распределения остатков`]</label>
                <span class="small gray setting-hint">[`Если для нескольких складов Озон используется одинаковые значения складов Shop-Script, то система автоматически распределит остатки между складами таким образом, чтобы суммарное количество товара по складам Озон соответствовало количеству товаров в Shop-Script`]</span>
            </div>
            <div class="block" v-if="set_id === 'sync_additionals'">
                <input @change="changeExtCheckbox('sync_additionals', 'order')" type="checkbox" :checked="settings.sync_additionals.value.order==1"
                       id="ozonseller-cb-sync_additional"> <label for="ozonseller-cb-sync_additional">[`Синхронизировать
                остатки при поступлении заказов из Озон по товарам содержащимся в заказе`]</label>
            </div>
        </template>
        <p name="" id="wahtmlcontrol" class="grey help">Обратите внимание! Это дополнительные настройки синхронизации,
            которые никак не затрагивают актуализацию цен и остатков по cron, а лишь служат дополнением</p>
    </div>
    <action-button @click="saveSettings()" title="[`Сохранить`]" icon="icon16 disk" action="saveSettings"
                   :run="runAction" :result="runResult"></action-button>
</div>
</div>
{/literal}