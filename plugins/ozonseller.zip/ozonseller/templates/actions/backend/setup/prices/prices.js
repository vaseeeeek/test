prcs = Vue.createApp({
    data() {
        return {
            accountId: null,
            accSettings: {$accSettings},
            settings: { },
            stocks: {$stocks},
            ozonStocks: [],
            options: {$options},
            runAction: false,
            runResult: null
        }
    },
    computed: {
        checkBoolFeatures() {
            let check = false;
            if (!this.options.hasOwnProperty('features') || !this.options.features.length) return check;
            this.options.features.forEach( (ft, idx) => { if (ft.type === 'boolean') check = true;});
            return check;
        }
    },
    mounted: function () {
        ozonseller.cApp = prcs;
        this.accountId = ozonseller.accountId;
        this.setSettings();
        ['price', 'old_price', 'premium_price', 'min_price'].forEach( pt => {
            if (!this.settings.price_markups.hasOwnProperty(pt)) this.settings.price_markups[pt] = 0;
        });
    },
    watch: {
        runAction: function () {
            ozonseller.runAction = this.runAction;
        },
        accountId: function () {
            ozonseller.accountId = this.accountId;
            this.setSettings();
        }
    },
    methods: {
        saveSettings: function () {
            this.runAction = 'saveSettings';
            let settings = { };
            Object.keys(this.settings).forEach((set_id) => {
                settings[set_id] = this.settings[set_id].value;
            });
            $.post('?plugin=ozonseller&action=settingsSave', { type: 'prices', account_id: this.accountId, settings: settings}, r => {
                if (r.status === 'ok') {
                    this.accSettings[this.accountId] = r.data;
                    this.finishAction();
                }
                else {
                    ozonseller.setError(r.errors);
                    this.runAction = false;
                }
            });
        },
        changeExtCheckbox: function (set, el = null) {
            if (!this.settings.hasOwnProperty(set)) return;
            if (el === null || !el.length) {
                this.settings[set].value = (this.settings[set].value-0 === 0 ? 1 : 0);
            } else this.settings[set].value[el] = (this.settings[set].value[el]-0 === 0 ? 1 : 0);
        },
        setSettings: function () {
            let settings = { };
            if (this.accountId && this.accSettings.hasOwnProperty(this.accountId)) {
                settings = JSON.parse(JSON.stringify(this.accSettings[this.accountId]));
            }
            this.settings = settings;
        },
        finishAction: function(timeOut = 2000) {
            this.runResult = true;
            setTimeout(() => {
                this.runAction = false;
                this.runResult = null;
            }, timeOut);
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        }
    }
});
{include '../../../combiControl.js'}
{include '../../../accountsMenu.js'}
prcs.component('accountsMenu', ozonAccounts);
prcs.component('actionButton', actionButton);
prcs.component('combiControl', combiControl);
osPrcs = prcs.mount('div#ozonseller-import-tab-prices');

