<div class="block double-padded">
{literal}
<template v-if="logs.length">
    <div class="ozonseller-log header" v-for="(log, idx) in logs">
        <div class="ozonseller-log-summary">
            <div class="log-product">
                <span @click="getDetails(idx)" class="row-name">{{log.name}}</span> <span class="small">({{log.category_name}})</span>
            </div>
            <div class="log-datetime">{{formatDate(log.datetime, "humanDateTime")}}</div>
        </div>
        <div class="ozonseller-log-data" v-if="cLog===log.product_id">
            <i class="icon16 loading" v-if="log.items.length === 0"></i>
            <div class="ozonseller-log sku" v-else>
                <div class="ozonseller-log-summary">
                    <div class="ozonseller-log-cell">
                        <a :href="'?action=products#/product/' + log.product_id +'/'" target="_blank" class="small">[`перейти
                            к товару`]</a> <i class="icon10 new-window"></i>
                    </div>
                    <div class="ozonseller-log-cell"></div>
                </div>
                <div class="ozonseller-log-summary" v-for="(item, idx) in log.items">
                    <div class="ozonseller-log-cell type small">
                        [`артикул`] {{item.header}}
                        <span style="display: block"
                              v-html="formatDate(item.datetime, 'simpleDateTime') + '(id ' + item.sku_id + ', ' + getAccountName(item.account_id) + ')'"></span>
                    </div>
                    <div class="ozonseller-log-cell message">
                        {{item.message}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<template v-else>
    <div class="block double-padded align-center gray" style="margin-top: 100px; margin-bottom: 100px;">
        <span>[`Ошибки валидации и публикаций отсутствуют`]</span>
    </div>
</template>
<div class="ozonseller-footer">
    <action-button @bClick="refreshLogs('update')" title="[`Обновить`]" icon="icon16 update" action="updateLogs"
                   :run="runAction"></action-button>
    <action-button @bClick="refreshLogs('trash')" title="[`Удалить все записи`]" icon="icon16 trash" action="trashLogs"
                   :run="runAction" :bclass="logs.length?'':'disabled gray'"></action-button>
</div>
{/literal}
</div>