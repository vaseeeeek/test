logs = Vue.createApp({
    data() {
        return {
            accounts: {$accounts},
            cLog: false,
            logs: {$logs},
            runAction: false
        }
    },
    mounted: function () {
        ozonseller.cApp = logs;
    },
    watch: {
        runAction: function () {
            ozonseller.runAction = this.runAction;
        }
    },
    computed: {},
    methods: {
        getDetails: function (idx) {
            let log = this.logs[idx];
            if (this.cLog === log.product_id) this.cLog = false;
            else {
                this.cLog = log.product_id;
                if (!log.items.length) {
                    $.post('?plugin=ozonseller&action=getProductLogs', { 'product_id': log.product_id }, r => {
                        if (r.status === 'ok') {
                            this.logs[idx].items = r.data;
                        } else {
                            ozonseller.setError(r.errors);
                        }
                    });
                }
            }
        },
        refreshLogs: function (mode) {
            this.runAction = mode + 'Logs';
            $.post('?plugin=ozonseller&action=refreshLogs', { 'mode': mode}, r => {
                if (r.status === 'ok') {
                    if (mode === 'trash') this.logs = [];
                    else this.logs = r.data;
                } else ozonseller.setError(r.errors);
                this.runAction = false;
                ozonseller.goTop();
            });
        },
        getProductUrl: function (product_id) {
            return ozonseller.backUrl + 'products/' + product_id + '/';
        },
        getAccountName: function (account_id) {
            let name = 'account deleted';
            let idx = this.accounts.findIndex( (acc) => { return acc.id-0 === account_id-0});
            if (idx >= 0) name = this.accounts[idx].name;
            return name;
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        }
    }
});
logs.component('actionButton', actionButton);
osLogs = logs.mount('div#ozonseller-import-tab-logs');
