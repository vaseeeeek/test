waits = Vue.createApp({
    data() {
        return {
            accounts: {$accounts},
            waitProducts: {$waitProducts},
            waitCategories: {$waitCategories},
            bar: {
                max: null,
                value: 0,
                width: '70%',
                height: '2em',
                doneText: 'Процесс успешно завершен',
                errorText: 'В процессе работы возникли ошибки. Подробности см. в ozonseller.error.log',
                prerunText: 'Получаем информацию о товарах в Ozon...',
                runText: 'Идёт публикация товаров в Ozon...',
                state: 'wait',
                small: false,
                time: true,
                result: { },
                lis: []
            },
            showGradusnik: false,
            limits: false,
            runAction: false,
            newUi: {$newUi}
        }
    },
    mounted: function () {
        ozonseller.cApp = waits;
        this.bar.lis = [
                { icon: (this.newUi ? 'fas fa-check' : 'icon16 status-green'), text: 'Успешно опубликовано: ', el: 'done', empty: true},
                { icon: (this.newUi ? 'fas fa-times' : 'icon16 status-red'), text: 'Не удалось опубликовать: ', el: 'fail', empty: false}
            ];
    },
    watch: {
        runAction: function () {
            ozonseller.runAction = this.runAction;
             if (this.runAction!==false && this.runAction!=='publicWaits') this.showGradusnik = false;
             if (this.runAction === 'publicWaits') this.showGradusnik = true;
        }
    },
    getProductUrl: function (product_id) {
        return ozonseller.backUrl + 'products/' + product_id + '/';
    },
    methods: {
        donePublics: function () {
            $.post('?plugin=ozonseller&module=products&action=getWaitProducts', r => {
                if (r.status === 'ok') this.waitProducts = r.data;
                else ozonseller.setError(r.errors);
                this.runAction = false;
            });
        },
        updateWaits: function (mode) {
            this.runAction = mode + 'Waits';
            $.post('?plugin=ozonseller&action=updateWaits', { 'mode': mode}, r => {
                if (r.status === 'ok') {
                    if (mode === 'update') {
                        this.waitProducts = r.data.waitProducts;
                        this.waitCategories = r.data.waitCategories;
                    } else {
                        this.waitProducts = [];
                    }
                } else ozonseller.setError(r.errors);
                this.runAction = false;
            });
        },
        getLimits: function () {
            this.runAction = 'checkLimits';
            this.limits = false;
            $.post('?plugin=ozonseller&action=checkLimits', r => {
                if (r.status === 'ok') this.limits = r.data;
                else ozonseller.setError(r.errors);
                this.runAction = false;
            });
        },
        getAccountName: function (account_id) {
            let idx = this.accounts.findIndex((acc) => { return acc.id-0 === account_id-0});
            if (idx >=0) return this.accounts[idx].name;
            else return 'deleted account';
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        }
    }
});
waits.component('actionButton', actionButton);
waits.component('gradusnik', gradusnik);
osWaits = waits.mount('div#ozonseller-import-tab-wait');

