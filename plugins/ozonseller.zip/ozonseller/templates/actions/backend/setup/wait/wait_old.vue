<div class="block double-padded">
{literal}
<div class="block double-padded">
    <template v-if="waitProducts.length">
        <span class="grey"><strong>[`Ожидающие публикации товары`]:</strong></span>
        <br>
        <br>
        <div class="ozonseller-log header" v-for="(p, idx) in waitProducts">
            <div class="ozonseller-log-summary">
                <div class="log-product">
                    <span class="row-name">
                        <a :href="'?action=products#/product/' + p.id + '/'" target="_blank">{{p.name}}</a> <i
                            class="icon10 new-window"></i>
                    </span><span>&nbsp;&nbsp;[`в категорию`]&nbsp;&nbsp;&nbsp;<strong>{{p.ozon_category}}</strong> ({{getAccountName(p.account_id)}})</span>
                </div>
            </div>
        </div>
    </template>
    <template v-else>
        <span class="grey"><strong>[`Нет товаров ожидающих публикации в Ozon`]</strong></span>
    </template>
</div>
<div class="block double-padded" style="margin-top: 50px;">
    <template v-if="waitCategories.length">
        <span class="grey"><strong>[`Категории Shop-Script с настроенной автоматической публикацией (по cron)`]:</strong></span>
        <br>
        <br>
        <div class="ozonseller-log header" v-for="(wc,idx) in waitCategories">
            <div class="ozonseller-log-summary">
                <div class="log-product">
                    <span class="row-name">
                        <a :href="'?action=products#/products/category_id=' + wc.category_id"
                           target="_blank"> {{wc.name}} </a><span
                            v-if="wc.subcategories"> ([`включая подкатегории`]) </span>
                    &nbsp;<i class="icon10 new-window"></i></span><span>&nbsp;&nbsp;[`в категорию`]&nbsp;&nbsp;&nbsp;<strong>{{wc.ozon_name}}</strong> ({{getAccountName(wc.account_id)}})</span>
                </div>
            </div>
        </div>
    </template>
    <template v-else>
        <span class="grey"><strong>[`Нет категорий Shop-Script с настроенной автоматической публикацией`]</strong></span>
    </template>
</div>
<div class="double-padded small" style="display: none;">
    <a @click="getLimits()"><i class="icon16 loading" v-if="runAction==='checkLimits'"></i><i class="icon16 info" v-else></i> [`Информация о лимитах`]</a>
    &nbsp;&nbsp;&nbsp;&nbsp;<span class="gray" v-if="limits">{{limits}}</span>
</div>
<div v-show="showGradusnik">
    <gradusnik @donerun="donePublics()" :bar="bar" url="?plugin=ozonseller&action=publicWaits" :timeout="5000" :run="runAction==='publicWaits'"></gradusnik>
</div>
<div class="ozonseller-footer">
    <action-button @bClick="updateWaits('update')" title="[`Обновить`]" icon="icon16 update" action="updateWaits" :run="runAction" style="margin-right: 60px;"></action-button>
    <action-button @bClick="runAction='publicWaits'" title="[`Опубликовать в Ozon`]" icon="icon16 merge" action="publicWaits" :run="runAction" :bclass="(waitProducts.length || waitCategories.length) ? '' : 'disabled'" style="margin-right: 60px;"></action-button>
    <action-button @bClick="updateWaits('trash')" title="[`Очистить очередь`]" icon="icon16 trash" action="trashWaits" :run="runAction"></action-button>
</div>
{/literal}
</div>