compare = Vue.createApp({
    data() {
        return {
            accountId: null,
            accSettings: {$accSettings},
            bar: {$bar},
            total: 0,
            totalSkus: 0,
            publics: 0,
            publicSkus: 0,
            sets: {$sets},
            selectIdentification: 0,
            selectClearCompare: 0,
            selectSetId: 0,
            runAction: false
        }
    },
    mounted: function () {
        ozonseller.cApp = compare;
        this.accountId = ozonseller.accountId;
        this.setSettings();
    },
    watch: {
        runAction: function () {
            ozonseller.runAction = this.runAction;
        },
        accountId: function () {
            ozonseller.accountId = this.accountId;
            this.setSettings();
        }
    },
    methods: {
        buttonCompareClass: function () {
            let bClass = 'middle';
            if (this.selectClearCompare === 0) bClass += ' disabled';
            if (this.selectClearCompare === 'set_in' || this.selectClearCompare === 'set_out') {
                if (this.selectSetId===0) bClass += ' disabled';
            }
            return bClass;
        },
        removeProductComparsion: function () {
            this.runAction = 'clearCompare';
            $.post('?plugin=ozonseller&action=removeProductComparsion', { account_id:this.accountId, target: this.selectClearCompare, set: this.selectSetId}, r => {
                if (r.status === 'ok') {
                    ['publics', 'publicSkus'].forEach( (field) => {
                        this[field] = r.data[field];
                        this.accSettings[this.accountId][field] = r.data[field];
                    });
                } else ozonseller.setError(r.errors);
                this.runAction = false;
            });
        },
        setSettings: function () {
            ['total', 'totalSkus', 'publics', 'publicSkus', 'selectIdentification', 'selectClearCompare', 'selectSetId'].forEach( (el) => {
                if (!this.accountId || !this.accSettings.hasOwnProperty(this.accountId) || !this.accSettings[this.accountId].hasOwnProperty(el)) {
                    this[el] = 0;
                } else this[el] = this.accSettings[this.accountId][el];
            });
            this.bar.state = 'wait';
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        }
    }
});
{include '../../../accountsMenu.js'}
compare.component('accountsMenu', ozonAccounts);
compare.component('actionButton', actionButton);
compare.component('gradusnik', gradusnik);
osImport = compare.mount('div#ozonseller-import-tab-import');
