{literal}
<accounts-menu @setAccount="accountId=$event-0" :account="accountId" :action="runAction"></accounts-menu>
<div class="block double-padded">
<p style="font-family: monospace; font-size: 0.9em;">
    [`Если у вас уже есть опубликованные другими инструментами товары в Ozon вы можете сопоставить их с товарами
    Shop-Script и актуализировать информацию о них средствами плагина.
    Сопоставление товаров OZON с товарами Shop-Script осуществляется на основе выбранного способа идентификации товаров.
    Данное действие не обновляет цены, остатки и другую информацию о товарах — только устанавливает связь.`]
</p>
<div class="block" style="min-height: 150px;">
    <div class="fields ozonseller">
        <div class="field">
            <div class="name" style="width: 15rem;">[`Всего товаров (артикулов) в Shop-Script`]</div>
            <div class="value">{{total}} ({{totalSkus}})</div>
        </div>
        <div class="field">
            <div class="name" style="width: 15rem;">[`Товаров (артикулов) опубликованных плагином в Ozon`]</div>
            <div class="value" id="ozonseller-total-publics">{{publics}} ({{publicSkus}})</div>
        </div>
        <div class="field">
            <div class="name" style="width: 15rem;">[`Сброс сопоставлений`]</div>
            <div class="value">
                <div>
                    <select v-model="selectClearCompare">
                        <option :value="0">[`Выберите один из вариантов`]</option>
                        <option value="set_in">[`Для товаров находящихся в списке...`]</option>
                        <option value="set_out">[`Для всех товаров кроме находящихся в списке...`]</option>
                        <option value="all">[`Сбросить сопоставления всех товаров`]</option>
                    </select>&nbsp;&nbsp;&nbsp;
                    <select v-model="selectSetId"
                            v-if="selectClearCompare === 'set_in' || selectClearCompare === 'set_out'">
                        <option :value="0">[`Выберите список`]</option>
                        <option :value="set.id" v-for="(set, idx) in sets">{{set.name}}</option>
                    </select>&nbsp;&nbsp;&nbsp;
                    <action-button @bClick="removeProductComparsion()" title="[`Сбросить сопоставления`]" icon="fas fa-broom" action="clearCompare"
                                   :run="runAction" :bclass="buttonCompareClass()"
                                   style="float: inherit"></action-button>
                </div>
            </div>
        </div>
        <div class="field">
            <div class="name" style="width: 15rem;">[`Идентифицировать товары по`]</div>
            <div class="value">
                <select v-model="selectIdentification">
                    <option :value="0">[`Выберите значение...`]</option>
                    <option value="id">[`ID артикула`]</option>
                    <option value="name">[`Название артикула`]</option>
                    <option value="sku">[`Код артикула`]</option>
                    <option value="product_id">[`ID товара`]</option>
                </select>

                <action-button @bClick="runAction='syncOzonProducts'" title="[`Сопоставить товары с Ozon`]" icon="fas fa-exchange-alt"
                               action="syncOzonProducts" :run="runAction"
                               :bclass="selectIdentification===0?'disabled':''" style="margin-left: 2rem;"></action-button>
            </div>
        </div>
    </div>
</div>
<div class="custom-mt-40 custom-mb-40" v-show="bar.state!=='wait'">
    <gradusnik @donerun="runAction=false" :bar="bar" url="?plugin=ozonseller&action=import" :params="{ account_id:accountId, field:selectIdentification}" :timeout="5000"
               :run="runAction==='syncOzonProducts'"></gradusnik>
</div>
<div class="clear"></div>
{/literal}