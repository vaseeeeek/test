{literal}
<accounts-menu @setAccount="accountId=$event-0" :account="accountId" :action="runAction"></accounts-menu>
<div class="flexbox">
<div class="sidebar flexbox" style="width: 20rem; height: calc(100vh - 14rem); overflow-y: auto !important;">
    <div class="sidebar-header custom-pb-20"><strong>[`Акции Ozon`] ({{promos.length}})</strong></div>
    <div id="ozonseller-promos-list" class="sidebar-body">
        <template v-if="promos.length">
            <div class="list">
                <div :class="'item ' + ((cPromo && cPromo.id===promo.id) ? ' selected' : '')"
                    v-for="(promo, idx) in promos">
                    <a @click="getPromo(idx)" class="image">
                        <span v-if="promo.hasOwnProperty('settings') && promo.settings" style="color: green">
                            <i class="fas fa-circle"></i>
                        </span>
                        <span v-else class="gray">
                            <i class="far fa-circle"></i>
                        </span>
                    </a>
                    <a @click="getPromo(idx)" class="details">
                        <div>
                            {{ promo.title }}<br>
                            <span class="hint">
                                {{ formatDate(promo.date_start, 'fullDate') }} - {{ formatDate(promo.date_end, 'fullDate') }}
                            </span>
                        </div>
                    </a>
                </div>
            </div>
        </template>
        <span v-else>[`На данный момент акций нет`]</span>
    </div>
    <div class="sidebar-footer custom-pt-20">
        <action-button @bClick="refreshPromos()" title="[`Обновить список`]" icon="fas fa-sync" action="refreshPromos"
                       :run="runAction" bclass="smallest outlined"></action-button>
    </div>
</div>
{/literal}
<div class="content left300px blank bordered-left">
    <div id="ozonseller-promo-info">
        <template v-if="cPromo">
            {include './include.promo.info.vue'}
        </template>
        <div v-else-if="runAction==='getPromo'" class="gray" style="margin: 30px;"><i class="icon16 loading"></i>
            <div class="spinner"></div> [`Подождите, получаем информацию об акции...`]
        </div>
        <div v-else class="align-center gray" style="padding-top: 100px;">
            <span>[`Выберите акцию из списка для получения информации`]</span>
        </div>
    </div>
    <div class="clear-both"></div>
</div>
</div>