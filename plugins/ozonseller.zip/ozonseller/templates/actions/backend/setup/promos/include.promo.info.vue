{literal}
<div class="block double-padded" xmlns="http://www.w3.org/1999/html">
<h3>{{cPromo.title}}</h3>
<div style="max-height:200px;max-width:1200px;overflow:auto;padding:20px;border: 1px solid #ddd;" v-html="cPromo.description + '</a>'">
</div>
<div id="ozonseller-promo-settings-view" class="ozonseller-settings promo" v-if="settings===false">
    <div class="gray" v-if="cPromo.hasOwnProperty('settings') && cPromo.settings" style="padding: 10px; line-height: 1.3em;">
        <span v-if="cPromo.settings.auto-0 > 0" style="display: block;">[`Автоматическое добавление товаров`]</span>
        <span>[`Источник цены для акции: `]{{cPromo.settings.type_name}},</span>
        <span v-if="cPromo.settings.markups-0 > 0">[`с применением наценок`]</span>
        <span v-else>[`без применения наценок`]</span>,
        <span v-if="cPromo.settings.diff-0 !== 0">[`с изменением цены на `]{{cPromo.settings.diff}}
            {{cPromo.settings.diff_type}}</span>
        <span v-else>[`без изменения цены`]</span>

        <template v-if="cPromo.action_type == 'STOCK_DISCOUNT'">
            <br>
            [`Количество для акции: по `]{{cPromo.settings.count}}
            <span v-if="cPromo.settings.count_type == 'piece'">[`шт.`]</span>
            <span v-else>[`% от остатка`]</span>
        </template>
    </div>
    <div v-if="cPromo.hasOwnProperty('settings') && cPromo.settings" class="gray" style="padding: 10px;">
        <a @click="editSettings(true)" class="ozonseller-promo-settings-change" mode="edit"><u>[`Изменить`]</u></a>
    </div>
    <div v-else class="align-center gray" style="margin-top: 20px;">
        <span>[`Чтобы добавить товары в акцию`] <a @click="editSettings(true)" class="ozonseller-promo-settings-change"><u>[`настройте`]</u></a> [`участие в акции`]</span>
    </div>
</div>
<div id="ozonseller-promo-settings-edit" class="ozonseller-settings promo" style="padding-left: 5px;" v-if="settings!==false">
    <div class="fields custom-p-20">
        <div class="field">
            <div class="name">[`Автоматически добавлять товары`]</div>
            <div class="value">
                <input @change="changeSettingsCheckbox('auto')" :checked="settings.auto-0===1" type="checkbox">
            </div>
        </div>
        <div class="field">
            <div class="name">[`Источник цены для акции`]</div>
            <div class="value">
                <combi-control :setting="cntrlSetting" set_id="promo"></combi-control>
                <div class="custom-mt-12" style="display: block;">
                    <span class="gray">
                      &nbsp;&nbsp;<input @change="changeSettingsCheckbox('markups')" :checked="settings.markups-0===1" type="checkbox"> [`применять наценки, `]
                    </span>
                    <span class="gray">[`увеличить/уменьшить на`]</span>&nbsp;
                    <input v-model="settings.diff" type="number" class="shortest">&nbsp;
                    <select v-model="settings.diff_type">
                        <option value="RUB">[`RUB`]</option>
                        <option value="%">[` % `]</option>
                    </select>
                </div>
            </div>
        </div>
        <template v-if="cPromo.action_type==='STOCK_DISCOUNT'">
            <div class="field">
                <div class="name">[`Количество каждого товара для акции`]</div>
                <div class="value">
                    <input v-model="settings.count" type="number" class="short" min="0">&nbsp;
                    <select v-model="settings.count_type">
                        <option value="">[`Выберите значение`]</option>
                        <option value="piece">[`шт.`]</option>
                        <option value="percent">[`процент от остатка (%)`]</option>
                    </select><br>
                    <span v-if="settings.count_type==='piece'" class="ozonseller-promo-count-piece hint">
                                [`Для каждого товара будет передано указанное количество остатков, если оно не превышает общее количество товара в соответствии с настройками передачи остатков в Ozon`]
                            </span>
                    <span v-if="settings.count_type==='percent'" class="ozonseller-promo-count-percent hint">
                                [`Для каждого товара будет передана указанная часть от остатков товара предназначенных для Ozon в соответствии с настройками передачи остатков в Ozon`]
                            </span>
                </div>
            </div>
        </template>
        <div class="field">
            <div class="name"></div>
            <div class="value">
                <action-button @click="savePromoSettings()" title="[`Сохранить`]" icon="fas fa-save" action="savePromoSettings" :run="runAction" bclass="smallest" style="margin-top: 20px;"></action-button>
                <action-button @bClick="editSettings(false)" title="[`Отмена`]" icon="fas fa-undo" action="cancelPromoSettings" :run="runAction" bclass="smallest" style="margin-top: 20px; margin-left: 50px;"></action-button>
                <action-button @bClick="deletePromoSettings()" v-if="cPromo.hasOwnProperty('settings') && cPromo.settings" title="[`Удалить настройки акции`]" icon="fas fa-trash-alt" action="deletePromoSettings" :run="runAction" bclass="smallest red" style="margin-top: 20px; margin-left: 50px;"></action-button>
            </div>
        </div>
    </div>
</div>
<table style="max-width: 1200px;min-width: 700px; margin-top: 30px;">
    <tr>
        <td style="width: 50%; vertical-align: top;">
            <h5 style="text-align: center; margin-bottom: 15px;">[`Добавить товары в акцию`]</h5>
            <div>
                <select v-model="actions.candidates.variant" class="ozonseller-promo-actions">
                    <option :value="0">[`Выберите вариант из списка`]</option>
                    <option value="selected" :disabled="!(cboxes.candidates.length > 0)">[`Выбранные товары`]</option>
                    <option value="set" :disabled="!(sets.length>0)">[`Товары содержащиеся в списке...`]</option>
                    <option value="all">[`Все рекомендованные товары`]</option>
                </select>&nbsp;&nbsp;&nbsp;
                <select v-model="actions.candidates.set_id" v-if="actions.candidates.variant === 'set'" class="ozonseller-promo-sets" style="margin-top: 7px;">
                    <option :value="0">[`Выберите значение`]</option>
                    <option :value="set.id" v-for="(set, idx) in sets">{{set.name}}</option>
                </select>
            </div>
            <div style="margin-top: 20px; margin-left: 30%;">
                <action-button @bClick="moveProducts('candidates')" title="[`Добавить в акцию`]" icon="fas fa-file-import" action="addToPromo" :run="runAction" :bclass="getActionButtonClass('candidates')"></action-button>
            </div>
        </td>
        <td style="width: 50%; vertical-align: top;">
            <h5 style="text-align: center; margin-bottom: 15px;">[`Исключить товары из акции`]</h5>
            <div>
                <select v-model="actions.products.variant" class="ozonseller-promo-actions">
                    <option :value="0">[`Выберите вариант из списка`]</option>
                    <option value="selected" :disabled="!(cboxes.products.length > 0)">[`Выбранные товары`]</option>
                    <option value="set" :disabled="!(sets.length>0)">[`Товары содержащиеся в списке...`]</option>
                    <option value="all">[`Все участвующие в акции товары`]</option>
                </select>&nbsp;&nbsp;&nbsp;
                <select v-model="actions.products.set_id" v-if="actions.products.variant === 'set'" class="ozonseller-promo-sets" style="margin-top: 7px;">
                    <option :value="0">[`Выберите значение`]</option>
                    <option :value="set.id" v-for="(set, idx) in sets">{{set.name}}</option>
                </select>
            </div>
            <div style="margin-top: 20px; margin-left: 30%;">
                <action-button @bClick="moveProducts('products')" title="[`Исключить из акции`]" icon="fas fa-file-export" action="delFromPromo" :run="runAction" :bclass="getActionButtonClass('products')"></action-button>
            </div>
        </td>
    </tr>
    <tr>
        <td style="text-align: center; padding-top: 40px;"><h5>[`Рекомендации Озон (всего {{candidates.total}})`] </h5></td>
        <td style="text-align: center; padding-top: 40px;"><h5>[`Товары участвующие в акции (всего {{products.total}})`]</h5></td>
    </tr>
    <tr>
        <td>
            <div id="ozonseller-promo-candidates" style="max-height: 500px;overflow: auto;margin: 10px; padding: 10px 5px 10px 5px;vertical-align: top;">
                <template v-for="(cp, idx) in candidates.items">
                    <div :class="checkPromoProduct(cp.id) ? 'gray' : '' + ' ozonseller-promo-product'" style="display: block; margin-bottom: 5px;">
                        <template v-if="cp.hasOwnProperty('ss_product_id')">
                            <input @change="changeBoxItems(cp.id, 'candidates')" v-if="!checkPromoProduct(cp.id)" type="checkbox">
                            <span v-else><i class="far fa-check-circle"></i></span>
                        </template>
                        <span v-else class="gray"><i class="far fa-times-circle"></i></span>
                        &nbsp;
                        <a v-if="cp.hasOwnProperty('ss_product_id')" :href="'?action=products#/product/' + cp.ss_product_id + '/'" target="_blank">{{cp.name}}</a>
                        <span v-else>{{cp.name}}</span>
                    </div>
                </template>
            </div>
        </td>
        <td id="ozonseller-promo-products" style="max-height: 500px;overflow: auto;margin: 10px;vertical-align: top;">
            <div style="max-height: 500px;overflow: auto;margin: 10px;">
                <div class="ozonseller-promo-product" v-for="(p, idx) in products.items">
                    <input @change="changeBoxItems(p.id, 'products')" type="checkbox">&nbsp;
                    <a v-if="p.hasOwnProperty('ss_product_id')" :href="'?action=products#/product/' + p.ss_product_id + '/'" target="_blank">{{p.name}}</a>
                    <span v-else>{{p.name}}</span>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td style="text-align: center">
            <span class="promo-count gray">{{candidates.items.length}}</span>
            <span class="promo-total gray"> [`из`] {{candidates.total}}</span>
            <span v-if="candidates.items.length < candidates.total" class="gray" style="margin-left: 10px;">
                        <div v-if="runAction==='getPromoPartList'" class="spinner"></div>
                        <a v-else @click="getPromoPartList('candidates')" class="ozonseller-promo-product-part" mode="candidates">[`Загрузить ещё`]</a>
                </span>
        </td>
        <td style="text-align: center">
            <span class="promo-count gray">{{products.items.length}}</span>
            <span class="promo-total gray"> [`из`] {{products.total}}</span>
            <span v-if="products.items.length < products.total" class="gray" style="margin-left: 10px;">
                        <div v-if="runAction==='getPromoPartList'" class="spinner"></div>
                        <a v-else @click="getPromoPartList('products')" class="ozonseller-promo-product-part" mode="products">[`Загрузить ещё`]</a>
                </span>
        </td>
    </tr>
</table>
<p class="small" style="margin-top: 20px;">
    [`Условные обозначения:`]<br>
    <span><i class="far fa-check-circle"></i></span>&nbsp;&nbsp;[`Товар уже добавлен в акцию`]<br>
    <span class="gray"><i class="far fa-times-circle"></i></span>&nbsp;&nbsp;[`Товар Озон не сопоставлен ни с одним товаром Shop-Script`]
</p>
</div>
{/literal}