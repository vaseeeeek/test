{literal}
<accounts-menu @setAccount="accountId=$event-0" :account="accountId" :action="runAction"></accounts-menu>
<div class="block">
<div class="sidebar left300px">
    <div id="ozonseller-promos-list">
        <template v-if="promos.length">
        <ul class="menu-v with-icons" id="ozonseller-promos-list">
            <li :class="'promo-info' + ((cPromo && cPromo.id===promo.id) ? ' selected' : '')" v-for="(promo, idx) in promos">
                <a @click="getPromo(idx)">
                    <i :class="'icon16 '+((promo.hasOwnProperty('settings') && promo.settings)?'status-green':'status-gray')"></i>
                    {{promo.title}}<br>
                    <span class="hint">
                        {{formatDate(promo.date_start, 'fullDate')}} - {{formatDate(promo.date_end, 'fullDate')}}
                    </span>
                </a>
            </li>
        </ul>
        </template>
        <span v-else>[`На данный момент акций нет`]</span>
    </div>
    <action-button @bClick="refreshPromos()" title="[`Обновить список`]" icon="icon16 update" action="refreshPromos" :run="runAction"></action-button>
</div>
{/literal}
<div class="content left300px blank bordered-left">
    <div id="ozonseller-promo-info">
        <template v-if="cPromo">
            {include './include.promo.info.old.vue'}
        </template>
        <div v-else-if="runAction==='getPromo'" class="gray" style="margin: 30px;"><i class="icon16 loading"></i> [`Подождите, загружается информация...`]</div>
        <div v-else class="align-center gray" style="padding-top: 100px;">
            <span>[`Выберите акцию из списка для получения информации`]</span>
        </div>
    </div>
    <div class="clear-both"></div>
</div>
</div>