opromos = Vue.createApp({
    data() {
        return {
            accountId: null,
            accSettings: {$accSettings},
            promos: [],
            sets: {$sets},
            cPromo: false,
            settings: false,
            candidates: false,
            products: false,
            cboxes: { 'candidates': [], 'products': []},
            actions: false,
            cntrlSetting: {$cntrlSetting},
            runAction: false
        }
    },
    computed: {
        checkBoolFeatures() {
            return false;
        }
    },
    mounted: function () {
        ozonseller.cApp = opromos;
        this.accountId = ozonseller.accountId;
        this.setSettings();
    },
    watch: {
        runAction: function () {
            ozonseller.runAction = this.runAction;
        },
        cPromo: function () {
            if (this.cPromo === false){
                this.candidates = false;
                this.products = false;
            }
        },
        accountId: function () {
            ozonseller.accountId = this.accountId;
            this.setSettings();
        }
    },
    methods: {
        getPromo: function (idx) {
            if (this.cPromo && this.cPromo.id-0 === this.promos[idx].id-0) return;
            window.scrollTo(0, 0);
            this.cPromo = false;
            this.settings = false;
            this.runAction = 'getPromo';
            $.post('?plugin=ozonseller&module=promos&action=getPromoInfo', { account_id: this.accountId, promo_id: this.promos[idx].id}, r => {
                if (r.status == 'ok') {
                    this.cPromo = r.data.promo;
                    this.candidates = r.data.candidates;
                    this.products = r.data.products;
                } else {
                    ozonseller.setError(r.errors);
                }
                this.runAction = false;
            });
        },
        getPromoPartList: function (type) {
            this.runAction = 'getPromoPartList';
            $.post('?plugin=ozonseller&module=promos&action=getPartList', {
                account_id: this.accountId,
                promo_id: this.cPromo.id,
                type: type,
                offset: this[type].items.length
            }, r => {
                if (r.status === 'ok') {
                    this[type].items = this[type].items.concat(r.data);
                } else {
                    ozonseller.setError(r.errors);
                }
                this.runAction = false;
            });
        },
        moveProducts: function (mode) {
            this.runAction = mode === 'products' ? 'delFromPromo' : 'addToPromo';
            let ids = this.cboxes[mode];
            $.post('?plugin=ozonseller&module=promos&action=runPromoProducts', {
                account_id: this.accountId,
                mode: mode,
                ids: ids,
                source: this.actions[mode].variant,
                set: this.actions[mode].set_id,
                promo_id: this.cPromo.id
            }, r => {
                if (r.status !== 'ok' || (r.hasOwnProperty('data') && r.data.hasOwnProperty('errors'))) {
                    let errors = r.status === 'ok' ? r.data.errors : r.errors;
                    ozonseller.setError(errors);
                }
                if (r.status === 'ok' && r.data.hasOwnProperty('products')) this.products = r.data.products;
                this.runAction = false;
            });
        },
        editSettings: function (edit) {
            if (edit) {
                let template = {
                    account_id: this.accountId,
                    promo_id: this.cPromo.id,
                    type: 'price',
                    key: '',
                    markups: 0,
                    diff: 0,
                    diff_type: 'RUB',
                    count: 0,
                    count_type: '',
                    auto: 0
                };
                if (this.cPromo.hasOwnProperty('settings') && this.cPromo.settings) template = JSON.parse(JSON.stringify(this.cPromo.settings));
                this.settings = template;
                this.cntrlSetting.value.type = this.settings.type;
                this.cntrlSetting.value.key = this.settings.key;
            } else {
                this.settings = false;
            }
        },
        savePromoSettings: function(){
            this.runAction = 'savePromoSettings';
            this.settings.type = this.cntrlSetting.value.type;
            this.settings.key = this.cntrlSetting.value.key;
            $.post('?plugin=ozonseller&module=promos&action=savePromoSettings', { 'account_id':this.accountId, 'promo': this.settings, 'promo_id': this.cPromo.id}, r => {
                if (r.status === 'ok') {
                    this.cPromo.settings = JSON.parse(JSON.stringify(this.settings));
                    this.settings = false;
                    let idx = this.promos.findIndex( el => { return el.id-0 === this.cPromo.id-0});
                    if (idx >= 0) {
                        this.promos[idx] = this.cPromo;
                    }
                    idx = this.accSettings[this.accountId].findIndex( el => { return el.id-0 === this.cPromo.id-0});
                    if (idx >= 0) {
                        this.accSettings[this.accountId][idx] = JSON.parse(JSON.stringify(this.cPromo));
                    }
                } else {
                    ozonseller.setError(r.errors);
                }
                this.runAction = false;
            });
        },
        deletePromoSettings: function () {
            this.runAction = 'deletePromoSettings';
            $.post('?plugin=ozonseller&module=promos&action=deletePromoSettings', { account_id: this.accountId, promo_id: this.cPromo.id}, r => {
                if (r.status === 'ok') {
                    this.settings = false;
                    this.cPromo.settings = undefined;
                    let idx = this.promos.findIndex( el => { return el.id-0 === this.cPromo.id-0});
                    if (idx >= 0) {
                        this.promos[idx] = this.cPromo;
                    }
                    idx = this.accSettings[this.accountId].findIndex( el => { return el.id-0 === this.cPromo.id-0});
                    if (idx >= 0) {
                        this.accSettings[this.accountId][idx] = JSON.parse(JSON.stringify(this.cPromo));
                    }
                } else {
                    ozonseller.setError(r.errors);
                }
                this.runAction = false;
            });
        },
        changeBoxItems: function (id, type) {
            let items = this.cboxes.candidates;
            if (type === 'products') items = this.cboxes.products;
            if (items.includes(id)) {
                let idx = items.findIndex( el => { return el-0 === id-0});
                if (idx >= 0) items.splice(idx, 1);
            } else items.push(id);
            if (type === 'candidates') this.cboxes.candidates = items;
            else this.cboxes.products = items;
        },
        changeSettingsCheckbox: function (field) {
            if (!this.settings.hasOwnProperty(field)) return;
            this.settings[field] = this.settings[field]-0 === 1 ? 0 : 1;
        },
        checkPromoProduct: function (product_id) {
            let idx = this.products.items.findIndex( p => { return p.id-0 === product_id-0});
            return (idx >= 0);
        },
        refreshPromos: function() {
            this.runAction = 'refreshPromos';
            $.post('?plugin=ozonseller&module=promos&action=refreshPromos', { account_id: this.accountId}, r => {
                if (r.status === 'ok') {
                    this.accSettings[this.accountId] = r.data;
                    this.promos = r.data;
                } else ozonseller.setError(r.errors);
                this.runAction = false;
            });
        },
        getActionButtonClass: function (type) {
            let bClass = 'middle ';
            if (
                !this.cPromo.hasOwnProperty('settings') ||
                this.actions[type].variant === 0 ||
                (this.actions[type].variant === 'selected' && !this.cboxes[type].length) ||
                (this.actions[type].variant === 'set' && this.actions[type].set_id === 0) ||
                (this.actions[type].variant === 'all' && !this[type].items.length)
            ) bClass += 'disabled';
            return bClass;
        },
        setSettings: function () {
            let promos = [];
            if (this.accountId && this.accSettings.hasOwnProperty(this.accountId)) {
                promos = JSON.parse(JSON.stringify(this.accSettings[this.accountId]));
            }
            this.cPromo= false;
            this.settings = false;
            this.candidates = false;
            this.products = false;
            this.cboxes = { 'candidates': [], 'products': []};
            this.actions = {
                'candidates': {
                    'variant': 0,
                    'set_id': 0
                },
                'products': {
                    'variant': 0,
                    'set_id': 0
                }
            };
            this.promos = promos;
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        }
    }
});
{include '../../../combiControl.js'}
{include '../../../accountsMenu.js'}
opromos.component('actionButton', actionButton);
opromos.component('combiControl', combiControl);
opromos.component('accountsMenu', ozonAccounts);
osOpromos = opromos.mount('div#ozonseller-import-tab-promos');

