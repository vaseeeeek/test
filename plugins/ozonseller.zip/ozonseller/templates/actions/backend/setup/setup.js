ozonseller = Vue.createApp({
    data() {
        return {
            accountId: {$accountId},
            cLi: 'logs',
            cApp: null,
            newUi: {$newUi},
            backUrl: {$backUrl},
            runAction: false,
            runResult: null,
            errorText: false
        }
    },
    mounted: function () {
        this.setLi(this.cLi);
    },
    watch: {
        cLi: function () {
            if (this.cApp !== null && this.cApp !== undefined) {
                this.cApp.unmount();
                this.cApp = undefined;
            }
            this.setLi(this.cLi);
        }
    },
    computed: {
    },
    methods: {
        dispatch: function (li_id) {
            let action = li_id + 'Action';
            if (this[action] === undefined) {
                console.log('undefined action: ' + action);
            } else this[action]();
        },
        setLi: function (li_id) {
            this.runAction = 'changeLi';
            $.post('?plugin=ozonseller&module=setup&action=' + li_id, { account_id: this.accountId}, r => {
                if (r.status === 'ok') this.setContent(r.data, li_id);
                else this.setError(r.errors);
                this.runAction = false;
            });
        },
        setContent: function(data, tab_id) {
            $('#ozonseller-tab-html').html('<div id="ozonseller-import-tab-' + tab_id +'">' + data.html + '</div>');
            $('#ozonseller-tab-js').html(data.script);
        },
        finishAction: function(timeOut = 2000) {
            this.runResult = true;
            setTimeout(() => {
                this.runAction = false;
                this.runResult = null;
            }, timeOut);
        },
        getLiClass: function (li_id) {
            let liClass = '';
            if (this.cLi === li_id) liClass = 'selected';
            if (this.runAction !== false) liClass+= ' disabled';
            return liClass;
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        },
        goTop: function (speed = 300) {
            $('html, body').animate({ scrollTop: 0}, speed);
        },
        setError: function (texts, timeOut = 7000) {
            if (Array.isArray(texts)) {
                text = texts.join('; ');
            } else {
                text = texts;
            }
            if (!text.length) text = 'Непредвиденная ошибка сервера';
            window.scrollTo(0, 0);
            this.errorText = text;
            setTimeout(() => {
                this.errorText = false;
            }, timeOut);
            this.runAction = false;
        }
    }
});
ozonseller.component('actionButton', actionButton);
ozonseller.component('gradusnik', gradusnik);
ozonseller = ozonseller.mount('div#ozonseller-main-import');