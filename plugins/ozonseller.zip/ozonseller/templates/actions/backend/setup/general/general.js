setts = Vue.createApp({
    data() {
        return {
            accountId: null,
            settings: { },
            accSettings: {$accSettings},
            options: {$options},
            lengths: {$lengths},
            runAction: false,
            runResult: null
        }
    },
    mounted: function () {
        ozonseller.cApp = setts;
        this.accountId = ozonseller.accountId;
        this.setSettings();
    },
    watch: {
        accountId: function () {
            this.setSettings();
            ozonseller.accountId = this.accountId;
        },
        runAction: function () {
            ozonseller.runAction = this.runAction;
        }
    },
    methods: {
        saveSettings: function () {
            this.runAction = 'saveSettings';
            let settings = { };
            Object.keys(this.settings).forEach((set_id) => {
                settings[set_id] = this.settings[set_id].value;
            });
            $.post('?plugin=ozonseller&action=settingsSave', { type: 'general', account_id: this.accountId, settings: settings}, r => {
                if (r.status === 'ok') {
                    this.finishAction();
                    this.accSettings[this.accountId] = r.data;
                }
                else ozonseller.setError(r.errors);
            });
        },
        finishAction: function(timeOut = 2000) {
            this.runResult = true;
            setTimeout(() => {
                this.runAction = false;
                this.runResult = null;
            }, timeOut);
        },
        setSettings: function() {
            let settings = { };
            if (this.accountId && this.accSettings.hasOwnProperty(this.accountId)) {
                settings = JSON.parse(JSON.stringify(this.accSettings[this.accountId]));
            }
            this.settings = settings;
        },
        formatDate: function (date, method) {
            return $.wrlDates[method](new Date(date));
        }
    }
});
{include '../../../accountsMenu.js'}
{include '../../../combiControl.js'}
setts.component('accountsMenu', ozonAccounts);
setts.component('actionButton', actionButton);
setts.component('combiControl', combiControl);
osSetts = setts.mount('div#ozonseller-import-tab-general');

