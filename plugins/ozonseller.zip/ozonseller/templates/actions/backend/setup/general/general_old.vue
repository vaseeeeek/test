{literal}
<div>
    <accounts-menu @setaccount="accountId=$event-0" :account="accountId" :action="runAction"></accounts-menu>
</div>
<div class="block double-padded">
<div class="fields">
    <template v-for="(set, set_id) in settings">
        <div class="field">
            <div class="name">{{set.title}}</div>
            <div class="value">
                <span :set_id="set_id" style="display: none"></span>
                <template v-if="set.control_type==='input'">
                    <input type="text" v-model="settings[set_id].value" class="long">
                    <span v-if="set.description.length" class="small gray setting-hint" v-html="set.description"></span>
                </template>
                <template v-else-if="set.control_type==='select'">
                    <select v-model="settings[set_id].value">
                        <option value="">[`Выберите значение`]</option>
                        <template v-for="(n, v) in set.options">
                            <template v-if="n.hasOwnProperty('title')">
                                <option :value="n.value">{{n.title}}</option>
                            </template>
                            <template v-else>
                                <option :value="v">{{n}}</option>
                            </template>
                        </template>
                    </select>
                    <span v-if="set.description.length" class="small gray setting-hint" v-html="set.description"></span>
                </template>
                <template v-else-if="set.control_type==='OzonsellerUniversalCombiSelect'">
                    <combi-control :setting="set" :set_id="set_id"></combi-control>
                </template>
                <template v-else-if="set.control_type==='custom shopOzonsellerPlugin::settingsDimensions'">
                    <select v-model="settings[set_id].value.type">
                        <option value="shop">[`Использовать настройки Shop-Script`]</option>
                        <option value="adv-params">[`Дополнительные параметры`]</option>
                    </select>
                    <span class="small gray setting-hint">
                            [`Выберите как определять габариты товаров`]: <a href="?action=settings#/shipping/"
                                                                             target="_blank">[`из настроек магазина`]</a> [`или с использованием дополнительных параметров`]
                        </span>
                    <template v-if="settings.dimensions.value.type==='adv-params'">
                        <div class="block">
                            <div class="block">
                                <span class="grey">Единицы измерения: </span>
                                <select v-model="settings.dimensions.value.unit">
                                    <option v-for="(unit, val) in lengths.units" :value="val">{{unit.name}}</option>
                                </select>
                            </div>
                            <div class="block">
                                <span class="grey">Высота: </span>
                                <select v-model="settings.dimensions.value.height">
                                    <option v-if="options.params" v-for="(param, idx) in options.params" :value="param.value">{{param.title}}</option>
                                </select>
                                &nbsp;&nbsp;<span class="grey">Ширина: </span>
                                <select v-model="settings.dimensions.value.width">
                                    <option v-if="options.params" v-for="(param, idx) in options.params" :value="param.value">{{param.title}}</option>
                                </select>
                                &nbsp;&nbsp;<span class="grey">Длина: </span>
                                <select v-model="settings.dimensions.value.length">
                                    <option v-if="options.params" v-for="(param, idx) in options.params" :value="param.value">{{param.title}}</option>
                                </select>
                            </div>
                        </div>
                    </template>
                </template>
                <template v-else>
                    <div class="red">[`Неизвестный тип настройки:`] {{set.control_type}}</div>
                </template>
            </div>
        </div>
    </template>
</div>
<action-button @click="saveSettings()" title="[`Сохранить`]" icon="icon16 disk" action="saveSettings" :run="runAction" :result="runResult"></action-button>
</div>
{/literal}