{literal}
<progress :value="bar.value" :max="bar.max" :style="{ width: bar.width, height: bar.height}" v-show="bar.state!=='wait'"></progress>
<div v-show="bar.state==='prerun'"><i class="icon16 loading"></i> {{bar.prerunText}}</div>
<div v-show="bar.state === 'run'"><i class="icon16 loading"></i> {{bar.runText}}</div>
<div v-show="bar.state==='done' || bar.state==='error'">
    <h4 v-html="bar.errorText" v-show="bar.state==='error'"></h4>
    <h4 v-html="bar.doneText" v-show="bar.state==='done'"></h4>
    <ul class="menu-v with-icons">
        <li v-if="bar.time"><i class="icon16 clock"></i> [`Время выполнения: `]{{getTotalTime()}}</li>
        <template v-if="bar.lis.length" v-for="(el, idx) in bar.lis">
            <li v-if="checkResultLi(idx)">
                <i :class="el.icon"> </i> {{el.text}} <span>{{bar.result.lis[el.el]}}</span>
            </li>
        </template>
    </ul>
</div>
{/literal}