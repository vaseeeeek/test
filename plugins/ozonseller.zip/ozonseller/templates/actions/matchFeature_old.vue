{literal}
<div class="ozonseller-type-feature-row">
<div class="ozonseller-type-feature-cell icons">
    <template v-if="of.dictionary_id>0">
        <a @click="getDictionaryValues()" v-if="!hintLoading" class="ozonseller-type-feature-a-collection">
            <i class="ozonseller-icon24 multivalue" title="[`Выбор из возможных вариантов`]"></i>
        </a>
        <i class="icon16 loading" v-else></i>
    </template>
    <i v-else :class="'ozonseller-icon24 ' + of.type.toLowerCase()"
       :title="'[`Тип значения: `]' + ozonFeatureTypes[of.type]"></i>
    <div v-show="of.dictionary_id>0 && hint.length" class="real-hint">
        <div class="prm-cross" @click="hint=''"><i class="icon10 close"></i></div>
        <div class="values" v-html="hint"></div>
    </div>
    <i v-if="of.is_collection==1" title="[`Возможны множественные значения`]" class="ozonseller-icon24 list"></i>
</div>
<div class="ozonseller-type-feature-cell ozon">
    <div class="ozonseller-of-name">{{child?'<b>'+pname+':</b> ' + of.name : of.name}} <i v-if="of.is_required" title="[`Обязательно для заполнения`]"
                                                   class="ozonseller-icon16 redstar"></i>
        &nbsp;&nbsp;<span class="gray small">[`id: `]{{of.id}}</span><span class="gray small" v-if="of.dictionary_id">, [`dictionary id: `]{{of.dictionary_id}}</span>
    </div>
    <div class="ozonseller-of-description">
        <strong v-if="of.id==richContentId && !rich">
            [`Для подготовки Rich-контента удобно использовать плагин <a
                href="https://www.webasyst.ru/store/plugin/shop/richcontent/" target="_blank">Rich
            Content</a>`]</strong><br>
        {{of.description}}
    </div>
    <div class="gray ozonseller-of-property">

    </div>
</div>
<div class="ozonseller-type-feature-cell shop">
    <select class="ozonseller-select-shop-features" v-model="type.values[of.id].feature_id">
        <option v-if="of.is_required" :value="0">[`Выберите характеристику`]</option>
        <option v-else :value="0">[`Не сопоставлять`]</option>
        <option value="string">[`Указать значение вручную`]</option>
        <option value="params">[`Использовать доп.параметр`]</option>
        <option v-if="of.id==videoFetures[0]" value="video">[`Видео товара`]</option>
        <option v-if="of.id==richContentId && rich" value="rich">[`Шаблон плагина Rich Content`]</option>
        <template v-if="type.features.hasOwnProperty('0')">
            <optgroup label="[`Общие характеристики`]"></optgroup>
            <template v-for="(f, idx) in type.features[0]">
                <option :value="f.id" is-dim="{if strpos($f.type, 'dimension.') === 0}1{else}0{/if}">{{f.name}}</option>
            </template>
        </template>
        <template v-for="(tfeatures, type_id) in type.features">
            <template v-if="type_id!=0">
                <optgroup :label="type.name"></optgroup>
                <option :value="f.id" v-for="(f, fidx) in tfeatures">{{f.name}}</option>
            </template>
        </template>
    </select>
    <div class="ozonseller-matches block small"
         v-if="of.dictionary_id>0 && !['string', 'params', '0', 0].includes(type.values[of.id].feature_id)">
        <i class="icon16 loading" v-show="matchLoading"></i> <a @click="matchDialog()" class="ozonseller-matches-set">[`Сопоставить
        значения характеристик`]</a>
        &nbsp;<span class="ozonseller-matches-count"
                    v-html="countMatches(of.id, type.values[of.id].feature_id)"></span>
    </div>
</div>
<div class="ozonseller-type-feature-cell ext">
    <input class="string" v-model="type.values[of.id].value"
           v-if="type.values[of.id].feature_id==='string'">

    <select v-model="type.values[of.id].value" v-if="type.values[of.id].feature_id==='params'">
        <option :value="null">[`Выберите доп.параметр`]</option>
        <option v-for="(p, idx) in advParams" :value="p">{{p}}</option>
    </select>

    <select v-model="type.values[of.id].value" v-if="type.values[of.id].feature_id==='rich' && rich">
        <option :value="null">[`Выберите шаблон`]</option>
        <option :value="ro.id" v-for="(ro, idx) in rich">{{ro.name}}</option>
    </select>
    <template v-if="checkDimensionType(type.values[of.id]['feature_id'])">
        <select v-model="type.values[of.id].value">
            <option :value="null">[`Не конвертировать`]</option>
            <optgroup label="[`Конвертировать в...`]">
                <option :value="unit_id" v-for="(unit, unit_id) in getUnitsByFeatureId(type.values[of.id]['feature_id'])">{{unit.name}}</option>
            </optgroup>
        </select>
        <template v-if="of.type==='String' || of.type==='multiline'">
            &nbsp;&nbsp;
            <input v-model="type.values[of.id].ext" type="checkbox" value="1" class="dims"
                   title="Добавить к значению единицы измерения">
            <i class="ozonseller-icon24 abc dims" title="Добавить к значению единицы измерения"></i>
        </template>
    </template>
</div>
</div>
{/literal}