combiControl = {
    props: ['setting', 'set_id'],
    data: function () {
        return {
            options: {$options}
        };
    },
    emits: {
        changeValue: null
    },
    computed: {
        valueArray() {
            if (!this.setting.source.hasOwnProperty('variants')) return false;
            let check = false;
            Object.keys(this.setting.source.variants).forEach((el) => {
                if (!this.setting.source.variants[el].hasOwnProperty('main_list')) check = true;
            });
            return check;
        }
    },
    methods: {
        checkOption: function (val, idx) {
            if (!this.setting.source.hasOwnProperty('variants') || !this.setting.source.variants.hasOwnProperty(val)) return false;
            if (this.setting.source.variants[val].hasOwnProperty('ftype')) {
                if (this.options[val][idx].type !== this.setting.source.variants[val].ftype) return false;
            }
            return true;
        },
        getIconClass: function () {
            return 'icon16 ' + this.icon;
        },
        checkLoading: function () {
            if (this.action === false) return false;
            return (this.action === this.run && this.result !== true);
        },
        checkResult: function () {
            return this.action === this.run && this.result === true;
        },
    },
    template: {$combiControl}
};

