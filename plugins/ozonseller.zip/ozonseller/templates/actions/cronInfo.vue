{literal}
<template v-if="header">
  <div v-if="isCloud">
    <span style="display: block; margin: 15px 0px 15px 0px;">[`Для выполнения задания добавьте в приложение Облако команду для приложения Shop-Script:`]</span>
    <span class="alert cli-command">
      ozonsellerPlugin -task КОМАНДА [параметры]
    </span>
  </div>
  <div v-else style="padding: 20px 0 20px 0;">
    <span style="margin-bottom: 1.2rem; display: block;">[`Для выполнения задания добавьте в ваш планировщик заданий
      команду
      вида:`]</span>
    <span class="alert cli-command">
      [путь до интерпретатора php] {{cliPath}}/cli.php shop ozonsellerPlugin -task КОМАНДА [параметры]
    </span>
    <span style="display: block; margin-top: 1.2rem;">
        Путь до интерпретатора php, а так же информацию о том, как создавать задания для cron, вы можете прочитать по <a
        href="http://www.webasyst.ru/developers/docs/tips/cron/" target="_blank">этой ссылке</a> и/или уточнить у вашего хостинг-провайдера
    </span>
  </div>
</template>
<template v-if="task">
  <div class="cli-task">
    <div style="margin: 15px; line-height: 140%;"><h5>{{task.description.title}}</h5></div>
    <span class="alert cli-command task">{{task.command}}&nbsp;</span>
    <div style="margin-top: 10px; line-height: 140%;" v-html="task.description.description"></div>
    <template v-if="task.params.length">
      <span>[`Доступные параметры:`]</span>
      <ul>
        <li v-for="(param, idx) in task.params">
          <code>-{{param.param}}</code>&nbsp;&nbsp;&nbsp;
          <span>{{param.description}}</span>
        </li>
      </ul>
    </template>
    <template v-if="task.examples.length">
      <span>[`Примеры команд:`]</span>
      <ul>
        <li v-for="(ex, idx) in task.examples">
          <code v-if="isCloud">ozonsellerPlugin -task {{task.command}} {{ex.command}}</code>
          <code v-else>shop ozonsellerPlugin -task {{task.command}} {{ex.command}}</code>&nbsp;&nbsp;&nbsp;
          <span>{{ex.description}}</span>
        </li>
      </ul>
    </template>
  </div>
</template>
{/literal}