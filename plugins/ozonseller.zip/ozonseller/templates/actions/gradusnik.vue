{literal}
<progress :value="bar.value" :max="bar.max" :style="{ width: bar.width, height: bar.height}" class="custom-mb-16" v-show="bar.state!=='wait'"></progress>
<div v-show="bar.state==='prerun'"><div class="spinner"></div> {{bar.prerunText}}</div>
<div v-show="bar.state === 'run'"><div class="spinner"></div> {{bar.runText}}</div>
<div v-show="bar.state==='done' || bar.state==='error'">
    <h6 v-html="bar.errorText" v-show="bar.state==='error'"></h6>
    <h6 v-html="bar.doneText" v-show="bar.state==='done'"></h6>
    <ul class="menu-v with-icons">
        <li v-if="bar.time"><i class="far fa-clock"></i> [`Время выполнения `]{{getTotalTime()}}</li>
        <template v-if="bar.lis.length" v-for="(el, idx) in bar.lis">
            <li v-if="checkResultLi(idx)">
                <i :class="el.icon"> </i>&nbsp;&nbsp;{{el.text}} <span>{{bar.result.lis[el.el]}}</span>
            </li>
        </template>
    </ul>
</div>
{/literal}