{literal}
<template v-if="valueArray">
    <select v-model="setting.value.type" style="margin-right: 10px;" @change="setting.value.key='0'">
        <template v-if="setting.source.hasOwnProperty('null_els') && setting.source.null_els.length">
            <option v-for="(el, idx) in setting.source.null_els" :value="el.value">{{el.title}}</option>
        </template>
        <template v-if="setting.source.hasOwnProperty('variants') && setting.source.variants">
            <template v-for="(variant, val) in setting.source.variants">
                <template v-if="variant.hasOwnProperty('main_list') && variant.main_list">
                    <template v-if="options.hasOwnProperty(val) && options[val]">
                        <optgroup :label="variant.group"></optgroup>
                        <template v-if="options.hasOwnProperty(val) && options[val]">
                            <template v-for="(el, idx) in options[val]">
                                <option :value="el.value" v-if="checkOption(val, idx)">{{el.title}}</option>
                            </template>
                        </template>
                    </template>
                </template>
                <option v-else-if="options.hasOwnProperty(val) && (options[val] || options[val] === false)" :value="val">{{variant.title}}</option>
            </template>
        </template>
    </select>
</template>
<template v-else>
    <select v-model="setting.value" style="margin-right: 10px;" @change="setting.value.key='0'">
        <template v-if="setting.source.hasOwnProperty('null_els') && setting.source.null_els.length">
            <option v-for="(el, idx) in setting.source.null_els" :value="el.value">{{el.title}}</option>
        </template>
        <template v-if="setting.source.hasOwnProperty('variants') && setting.source.variants">
            <template v-for="(variant, val) in setting.source.variants">
                <template v-if="variant.hasOwnProperty('main_list') && variant.main_list">
                    <template v-if="options.hasOwnProperty(val) && options[val]">
                        <optgroup :label="variant.group"></optgroup>
                        <template v-if="options.hasOwnProperty(val) && options[val]">
                            <template v-for="(el, idx) in options[val]">
                                <option :value="el.value" v-if="checkOption(val, idx)">{{el.title}}</option>
                            </template>
                        </template>
                    </template>
                </template>
                <option v-else :value="val">{{variant.title}}</option>
            </template>
        </template>
    </select>
</template>
<template v-if="setting.source.hasOwnProperty('variants') && setting.source.variants">
    <template v-for="(data, val) in options">
        <template v-if="val===setting.value.type">
            <select v-model="setting.value.key" v-if="data!==false">
                <option value="0">[`Выберите значение...`]</option>
                <template  v-for="(e, idx) in data">
                    <option :value="e.value" v-if="checkOption(val, idx)">{{e.title}}</option>
                </template>
            </select>&nbsp;&nbsp;&nbsp;&nbsp;
            <span class="hint" v-if="setting.source.variants[val].hasOwnProperty('description')" v-html="setting.source.variants[val].description"></span>
        </template>
    </template>
</template>
{/literal}