cronInfo = {
    props: ['task', 'header'],
    data: function () {
        return {
            newUi: {$newUi},
            cliPath: {$wa_path},
            isCloud: {$is_cloud}
        };
    },
    template: {$cronInfo},
    methods: {
    }
}