/**
 *  @bar Object
 *      max: int максимальное количество
 *      value: int обработанное количество
 *      width: string   Ширина градусника
 *      height: string Высота градусника
 *      doneText: string Текст при успешном завершении
 *      errorText: string Тект при завершении с ошибками
 *      prerunText: string Текст при подготовке к работе
 *      runText: string Текст в процессе работы
 *      state: string 'wait'|'prerun'|'run'|'done'|'error'  "Состояние" (ожидание/запущен/завершен успешно/завершен с ошибками)
 *      small: bool
 *      time: bool Показывать или нет время выполнения по окончании
 *      lis: array of Objects
 *          {
 *              icon: класс иконки
 *              text: Текст
 *              el: элемент со значением в ответе waLongAction
 *              empty: bool отображать если 0 или нет
 *          }
 */
gradusnik = {
    props: ['bar', 'url', 'params', 'timeout', 'run', 'errors'],
    emits: ['donerun'],
    data: function () {
        return { buttonClick: 'bclick' };
    },
    watch: {
        run: function () {
            if (this.run === true) {
/*                if (!this.bar.hasOwnProperty('result')) this.bar.result = { };*/
                this.bar.result = { };
                this.bar.state = 'prerun';
                this.bar.time = Math.floor(Date.now() / 1000);
                $.post(this.url, this.params, data => {
                    if (data.error !== undefined) {
                        this.bar.time = Math.floor(Date.now() / 1000) - this.bar.time;
                        this.bar.state = 'error';
                        this.bar.errorText = this.bar.errorText + ' ' + data.error;
                    } else {
                        this.bar.state = 'run';
                        this.bar.value = data.done;
                        this.bar.max = data.total;
                        let processId = data.processId;
                        let step = setInterval(f => {
                            $.wa.errorHandler = function (xhr) {
                                return !((xhr.status >= 500) || (xhr.status == 0));
                            };
                            $.post(this.url, { 'processId': processId}, r => {
                                if (r.ready === true) {
                                    let runTime = Math.floor(Date.now() / 1000) - this.bar.time;
                                    if (this.bar.state !== 'done') {
                                        this.bar.time = runTime;
                                        this.bar.value = this.bar.max;
                                    }
                                    clearInterval(step);
                                    this.bar.state = 'done';
                                    this.bar.result = r;
                                    if (r.errors !== undefined && r.errors.length > 0) {
                                        this.bar.errorText = this.bar.errorText + ' ' + r.errors.join('; ');
                                        this.bar.state = 'error';
                                    }
                                    this.$emit('donerun');
                                } else {
                                    let diff = r.done - this.bar.value;
                                    if (diff > 0) {
                                        let cnt = setInterval(f => {
                                            this.bar.value += 1;
                                            diff -= 1;
                                            if (diff === 0) clearInterval(cnt);
                                        }, 1);
                                    }
                                }
                                return true;
                            }, 'json');
                        }, this.timeout);
                    }
                }, 'json');
            } else {
//                this.bar.value = 0;
//                this.bar.state = 'wait';
            }
        }
    },
    template: {$gradusnik},
    methods: {
        getTotalTime: function (time) {
            return Math.floor(this.bar.time / 3600) + " час " + (Math.floor(this.bar.time / 60) - (Math.floor(this.bar.time / 3600) * 60)) + " мин " + this.bar.time % 60 + ' сек';
        },
        checkResult: function () {
            return this.action === this.run && this.result === true;
        },
        checkResultLi: function (idx) {
            let check = false;
            let li = this.bar.lis[idx];
            if (this.bar.result.hasOwnProperty('lis') && this.bar.result.lis.hasOwnProperty(li.el)) {
                if (!li.empty) {
                    let rli = this.bar.result.lis[li.el];
                    if (rli && rli !== 0) check = true;
                } else check = true;
            }
            return check;
        }
    }
};