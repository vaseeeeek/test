matchFeature = {
    props: ['of', 'type', 'child', 'pname', 'ocat_id', 'value'],
    data: function () {
        return {
            advParams: {$advParams},
            sets: {$sets},
            rich: {$rich},
            ozonFeatureTypes: {$ozonFeatureTypes},
            richContentId: {$richContentId},
            videoFetures: {$videoFeatures},
            matches: {$matches},
            units: {$units},
            hint: '',
            oFeature: this.of,
            categoryId: this.ocat_id,
            hintLoading: false,
            matchLoading: false,
            newUi: {$newUi}
        };
    },
    created() {
        if (this.newUi) {
        }
    },
    template: {$matchFeature},
    methods: {
        countMatches: function (ozon_feature_id, feature_id) {
            let count = 0;
            if (this.matches.hasOwnProperty(ozon_feature_id) && this.matches[ozon_feature_id].hasOwnProperty(feature_id)) {
                count = this.matches[ozon_feature_id][feature_id].length;
            }
            return '[' + count + ']';
        },
        getDictionaryValues: function () {
            this.hintLoading = true;
            $.post('?plugin=ozonseller&action=getOzonFeatureValues', {
                account_id: ozonseller.accountId,
                category_id: this.categoryId,
                feature_id: this.oFeature.id
            }, r => {
                if (r.status == 'ok') {
                    this.hint = r.data;
                } else {
                    ozonseller.setError(r.errors);
                }
                this.hintLoading = false;
            });
        },
        checkDimensionType: function (feature_id) {
            if (feature_id-0 != feature_id) return false;
            let feature = null;
            Object.keys(this.type.features).forEach((type_id) => {
                if (this.type.features[type_id].hasOwnProperty(feature_id)) feature = this.type.features[type_id][feature_id];
            });
            if (!feature) return false;
            if (feature.type.indexOf('dimension.') === 0) {
                let ftype = feature.type.split('.');
                return ftype[1];
            }
            return false;
        },
        getUnitsByFeatureId: function (feature_id) {
            let values = { };
            let uType = this.checkDimensionType(feature_id);
            if (this.units.hasOwnProperty(uType)) values = this.units[uType].units;
            return values;
        },
        matchDialog: function () {
            this.matchLoading = true;
            let feature_id = false;
            let that = this;
            if (this.type.values.hasOwnProperty(this.of.id)) feature_id = this.type.values[this.of.id].feature_id - 0;
            if (!feature_id) {
                console.log('Не удалось получить id характеристики');
                this.matchLoading = false;
                return;
            }
            let ozon_feature_id = this.of.id;
            $.post('?plugin=ozonseller&action=getDialogMatches', {
                'account_id': ozonseller.accountId,
                'ozon_feature_id': ozon_feature_id,
                'feature_id': feature_id,
                'ozon_category_id': this.ocat_id
            }, r => {
                if (r.status == 'ok') {
                    if (this.newUi) {
                        $.waDialog({
                            html: r.data,
                            onClose: function (f) {
                                ozon_values = undefined;
                                that.reloadFeatureMatch(that.of.id, feature_id);
                            },
                            onOpen: function($dialog, dialog_instance) {
                                if (typeof ozon_values !== 'undefined') {
                                    const ozon_feature_id = $('#ozon_feature_id').val();
                                    const feature_id = $('#feature_id').val();
                                    let content = $dialog.find('#ozonseller-matches');
                                    let span_count = $('.ozonseller-type-feature-row[ozon-feature-id="' + ozon_feature_id + '"]').find('span.ozonseller-matches-count');
                                    let select = '<select id="ozonseller-values-match" style="max-width: 190px;">';
                                    $.each(ozon_values, function (key, value) {
                                        select += '<option value="' + value.id + '">' + value.value + '</option>';
                                    });
                                    select += '</select><br><span class="small"><a class="ozonseller-a-match save" href="#">Сохранить</a> или <a class="ozonseller-a-match cancel" href="#">отмена</a></span>';
                                    var clearSelects = function () {
                                        var select = $('#ozonseller-matches').find('select');
                                        var td = $(select).closest('td');
                                        $(td).html($(td).attr('cvalue'));
                                    }

                                    $dialog.on('click', '.ozonseller-a-match-del', function () {
                                        var el = $(this);
                                        var tr = $(el).closest('tr');
                                        var td = $(tr).find('td.ozon-value');
                                        var i = $(tr).find('i');
                                        var action = $(el).attr('action');
                                        if (action == 'delete') {
                                            $.post('?plugin=ozonseller&action=deleteMatch', {
                                                'ozon_feature_id': ozon_feature_id,
                                                'ozon_value_id': $(tr).attr('ozon_id'),
                                                'feature_id': feature_id,
                                                'value_id': $(tr).attr('shop_id')
                                            }, function (r) {
                                                if (r.status == 'ok') {
                                                    $(td).addClass('grey').html($(tr).attr('default-value'));
                                                    $(i).removeClass('delete').addClass('edit');
                                                    $(span_count).html(parseInt($(span_count).html()) - 1);
                                                    $(el).attr('action', 'edit');
                                                } else {
                                                    alert(r.errors);
                                                }
                                            });
                                        } else {
                                            clearSelects();
                                            $(td).attr('cvalue', $(td).html());
                                            $(td).html(select);
                                            var ops = $(td).find('select');
                                            $(ops).find('option[value="' + $(tr).attr('ozon_id') + '"]').attr('selected', true);
                                        }
                                        return false;
                                    }).on("mouseover", "tr", function () {
                                        $(this).find("span.icon").show();
                                    }).on("mouseleave", "tr", function () {
                                        $(this).find("span.icon").hide();
                                    }).on('click', '.ozonseller-a-match.cancel', function () {
                                        clearSelects();
                                        return false;
                                    }).on('click', '.ozonseller-a-match.save', function () {
                                        var td = $(this).closest('td');
                                        var select = $(td).find('select');
                                        var vname = $(select).find('option:selected').html();
                                        $.post('?plugin=ozonseller&action=saveMatch', {
                                            'ozon_feature_id': ozon_feature_id,
                                            'ozon_value_id': $(select).val(),
                                            'feature_id': feature_id,
                                            'value_id': $(td).closest('tr').attr('shop_id')
                                        }, function (r) {
                                            if (r.status == 'ok') {
                                                $(td).removeClass('grey');
                                                clearSelects();
                                                $(td).html(vname);
                                                $(td).closest('tr').find('i').removeClass('edit').addClass('delete');
                                                $(td).closest('tr').find('a').attr('action', 'delete');
                                                $(td).closest('tr').attr('ozon_id', $(select).val());
                                                $(span_count).html(parseInt($(span_count).html()) + 1);
                                            } else {
                                                alert(r.errors);
                                            }
                                        });
                                        return false;
                                    });
                                }
                            }
                        });
                    } else {
                        $(r.data).waDialog({
                            'height': '550px',
                            'width': '400px',
                            'onClose': function (f) {
                                $(this).remove();
                                that.reloadFeatureMatch(that.of.id, feature_id);
                            },
                            'esc': true,
                        });
                    }
                } else {
                    ozonseller.setError(r.errors);
                }
                this.matchLoading = false;
            });
        },
        reloadFeatureMatch: function (ozon_feature_id, feature_id) {
            $.post('?plugin=ozonseller&action=reloadMeatchesByFeatures', { 'ozon_feature_id': ozon_feature_id, 'feature_id': feature_id}, r => {
                if (r.status === 'ok') {
                    if (!this.matches.hasOwnProperty(ozon_feature_id)) {
                        Object.assign(this.matches, { [ozon_feature_id]: { [feature_id]: r.data}});
                        this.$forceUpdate();
                    }
                    else this.matches[ozon_feature_id][feature_id] = r.data;
                } else ozonseller.setError(r.errors);
            });
        }
    }
};