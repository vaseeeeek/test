{if $wa->whichUi('shop') === '1.3'}
    {literal}
        <div id="accounts-menu" class="toggle accounts-menu">
            <template v-for="(acc, idx) in accounts">
                <span @click="setAccount(acc.id)" :class="getSpanClass(acc)">
                    {{acc.name}}&nbsp;&nbsp;
                    <template v-if="acc.status-0===0"><i class="icon16 no"></i></template>
                    <template v-else><i class="icon16 yes"></i></template>
                </span>
            </template>
        </div>
    {/literal}
{else}
    {literal}
        <div id="accounts-menu" class="toggle accounts-menu smallest">
            <template v-for="(acc, idx) in accounts">
                <span @click="setAccount(acc.id)" :class="getSpanClass(acc)">
                    {{acc.name}}&nbsp;&nbsp;
                    <template v-if="acc.status-0===0"><i class="fas fa-times"></i></template>
                    <template v-else><i class="far fa-check-square"></i></template>
                </span>
            </template>
        </div>
    {/literal}
{/if}