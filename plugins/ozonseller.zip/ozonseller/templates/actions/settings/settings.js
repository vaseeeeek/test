/*
 * @link https://warslab.ru/
 * @author waResearchLab
 * @Copyright (c) 2023 waResearchLab
 */
ozonseller = Vue.createApp({
    data() {
        return {
            account_id: false,
            accounts: {$accounts},
            cAccount: null,
            settings: { },
            tasks: {$tasks},
            cLi: 'system',
            tab: 'suppliers',
            appOzon: {$appOzon},
            appData: false,
            bar: {$bar},
            newUi: {$newUi},
            orderStates: {$orderStates},
            runAction: false,
            runResult: null,
            migrate: 'pre',
            wa_url: '{$wa_url}',
            errorText: false
        }
    },
    watch: {
        account_id: function () {
            this.setAccountSettings();
        }
    },
    mounted: function () {
        this.setDefaultAccount();
    },
    computed: {
        checkSaveAccount() {
            let bClass = '';
            if (!this.cAccount) return bClass;
            if (!this.cAccount.name.length || !this.cAccount.token.length || !this.cAccount.client_id) bClass = 'disabled';
            return bClass;
        }
    },
    methods: {
        saveSettings: function () {
            this.runAction = 'saveSettings';
            $.post('?plugin=ozonseller&action=settingsSave', { account_id:this.account_id, settings: this.settings, 'type': 'system'}, r => {
                if (r.status == 'ok') {
                    let idx = this.getAccountIdxById(this.account_id);
                    if (idx >= 0) this.accounts[idx].settings = r.data;
                    this.finishAction();
                }
                else this.setError(r.errors);
            });
        },
        changeGroupbox: function (set_id, value) {
            if (!this.settings.hasOwnProperty(set_id)) return false;
            if (this.settings[set_id].value.includes(value)) {
                let idx = this.settings[set_id].value.findIndex(function (el, idx) { return el === value });
                if (idx >=0) {
                    this.settings[set_id].value.splice(idx, 1);
                }
            } else {
                this.settings[set_id].value.push(value);
            }
        },
        checkGroupbox: function(set_id, value) {
            if (!this.settings.hasOwnProperty(set_id)) return false;
            return this.settings[set_id].value.includes(value);
        },
        saveAccount: function () {
            this.runAction = 'saveAccount';
            $.post('?plugin=ozonseller&module=settings&action=saveAccount', { 'account': this.cAccount}, r => {
                if (r.status === 'ok') {
                    this.finishAction();
                    if (!this.cAccount.id) {
                        this.accounts.push(r.data);
                    } else {
                        let that = this;
                        let idx = this.getAccountIdxById(this.cAccount.id);
                        if (idx >= 0) this.accounts[idx] = r.data;
                    }
                    this.cAccount = null;
                } else this.setError(r.errors);
            });
        },
        delAccount: function () {
            this.runAction = 'delAccount';
            $.post('?plugin=ozonseller&module=settings&action=deleteAccount', { 'account_id': this.cAccount.id}, r => {
                if (r.status === 'ok') {
                    let that = this;
                    let idx = this.getAccountIdxById(this.cAccount.id);
                    if (idx >= 0) {
                        this.accounts.splice(idx, 1);
                        this.setDefaultAccount();
                    }
                    this.finishAction();
                    this.cAccount = null;
                } else this.setError(r.errors);
            });
        },
        editAccount: function (idx) {
            let account = { id: null, 'name': '', 'client_id': '', 'token': '', 'status': 0};
            if (idx !== 'new') {
                account = this.accounts[idx];
            }
            this.cAccount = JSON.parse(JSON.stringify(account));
        },
        finishAction: function (timeOut = 2000) {
            this.runResult = true;
            setTimeout(() => {
                this.runAction = false;
                this.runResult = null;
            }, timeOut);
        },
        getMenuElClass: function (acc) {
            let spanClass = acc.status===0 ? 'disabled' : '';
            if (acc.id === this.account_id) spanClass += ' selected';
            return spanClass;
        },
        setDefaultAccount: function () {
            if (this.account_id) {
                let idx = this.getAccountIdxById(this.account_id);
                if (idx >= 0) return;
            }
            if (this.accounts.length) {
                this.account_id = this.accounts[0].id;
            }
        },
        setAccountSettings: function (account_id = null) {
            if (!account_id) { account_id = this.account_id;}
            if (!account_id) this.settings = { };
            let idx = this.getAccountIdxById(account_id);
            if (idx >= 0) {
                this.settings = JSON.parse(JSON.stringify(this.accounts[idx].settings));
            } else this.settings = { };
        },
        preMigrate: function() {
            this.runAction = 'preMigrate';
            $.post('?plugin=ozonseller&module=migrate&action=preMigrate', r => {
                if (r.status === 'ok') {
                    this.appData = r.data;
                    this.migrate = 'migrate';
                } else {
                    this.setError(r.errors);
                }
                this.runAction = false;
            });
        },
        goMigrate: function () {
            this.runAction = 'goMigrate';
            $.post('?plugin=ozonseller&module=migrate&action=goMigrate', this.appData, r => {
                if (r.status === 'ok') {
                    this.appData = r.data.appData;
                    this.accounts = r.data.accounts;
                } else this.setError(r.errors);
                this.runAction = false;
                this.migrate = 'done';
            })
        },
        migrateChangeTypeCheckbox: function (ozon_category_id, type_id) {
            let value = this.appData.ozon_categories[ozon_category_id].types[type_id].checked === 0 ? 1 : 0;
            this.appData.ozon_categories[ozon_category_id].types[type_id].checked = value;
        },
        migrateChangeCategoryCheckbox: function (idx) {
            let value = this.appData.categories[idx].checked === 0 ? 1 : 0;
            this.appData.categories[idx].checked = value;
        },
        getAccountIdxById: function(account_id) {
            return this.accounts.findIndex((el, idx) => {
                return el.id === account_id;
            });
        },
        setLi: function (li) {
            if (this.runAction !== false) return;
            if (this.cLi === li) return;
            this.cLi = li;
            this.cAccount = null;
            this.migrate = 'pre';
            this.bar.state = 'wait';
            if (this.appData !== false) this.appData = true;
        },
        setError: function (texts, timeOut = 5000) {
            window.scrollTo(0, 0);
            let text = '';
            if (Array.isArray(texts)) {
                text = texts.join('; ');
            } else {
                text = texts;
            }
            if (!text.length) text = 'Непредвиденная ошибка сервера';
            this.errorText = text;
            setTimeout(() => {
                this.errorText = false;
            }, timeOut);
            this.runAction = false;
        }
    }
});
{include '../cronInfo.js'}
{include '../gradusnik.js'}
ozonseller.component('cronInfo', cronInfo);
ozonseller.component('actionButton', actionButton);
ozonseller.component('gradusnik', gradusnik);
ozonseller = ozonseller.mount('div#ozonseller-settings');