{literal}
<template v-else-if="cLi==='bodysite'">
    <template v-if="migrate==='pre'">
        <div class="block double-padded">
            <table style="max-width: 1000px; line-height: 1.5;">
                <tr>
                    <td style="padding: 10px;"><img :src="wa_url + 'wa-apps/ozon/assets/ozon48.png'"></td>
                    <td style="padding: 10px;">
                        [`Будут импортированы настройки аккаунта, основные настройки экспотра (настройки общих характеристик), настройки категорий Ozon и сопоставления характеристик.
                        Так как не все настройки приложения "Интеграция с Ozon" совместимы с настройками плагина "Ozon: Интеграция", после импорта всех
                        настроек необходимо будет убедиться что настройки импортировались корректно и выставить недостающие настройки в разделе
                        "Магазин - Импорт/экспорт - Ozon: интеграция"`]
                    </td>
                </tr>
            </table>
        </div>
        <action-button @bClick="preMigrate()" title="[`Подготовить данные для миграции...`]" action="preMigrate"
                       :run="runAction"
                       icon="icon16 merge"></action-button>
    </template>
    <template v-if="migrate==='migrate'">
        <div class="block double-padded">
            <div class="block">
                <template v-if="appData.account_id-0 === 0">
                    <strong>[`Укажите название нового аккаунта Ozon для импорта настроек`]</strong>
                    <input v-model="appData.name" class="long" style="display: block; margin: 20px 0 20px 0;">
                </template>
                <template v-else>
                    <span class="alert" style="max-width: 1000px;">[`В плагине "Ozon: Интеграция" уже зарегистрирован аккаунт Ozon с указанными в настройках приложения "Интеграция с Ozon" данными.`]
                    [`Будут импортированы только настройки выбранных категорий`]</span>
                </template>
            </div>
            <h5>[`Выберите настройки каких категорий и типов товаров импортировать из приложения Интеграция с Ozon`]</h5>
            <table class="zebra" style="margin: 25px 0 25px 10px; max-width: 1000px;">
                <tr>
                    <th><h5>[`Категория Ozon`]</h5></th>
                    <th><h5>[`Типы товаров`]</h5></th>
                </tr>
                <tr v-for="(ocat, ocat_id) in appData.ozon_categories">
                    <td style="vertical-align: top;">{{ocat.name}}</td>
                    <td style="vertical-align: top;">
                        <ul style="list-style: none;line-height: 1.2;margin-bottom: unset;">
                            <li v-for="(type, type_id) in ocat.types">
                                <input @change="migrateChangeTypeCheckbox(ocat_id, type_id)" :id="ocat_id + '_' + type_id" type="checkbox" v-if="!type.exist" :checked="appData.ozon_categories[ocat_id].types[type_id].checked!==0">&nbsp;&nbsp;
                                <label :for="ocat_id + '_' + type_id">{{type.name}}</label>&nbsp;&nbsp;<span class="small" v-if="type.exist">(уже настроен)</span>
                            </li>
                        </ul>
                    </td>
                </tr>
            </table>
            <h5>[`Выберите для каких категорий Shop-Script включить автоматическую публикацию новых товаров в Ozon`]</h5>
            <ul style="list-style: none;line-height: 1.2">
                <li v-for="(cat, idx) in appData.categories">
                    <input @change="migrateChangeCategoryCheckbox(idx)" :id="'cat_' + cat.id" type="checkbox"> <label :for="'cat_' + cat.id" :checked="cat.checked===1"> {{cat.name}}</label>
                </li>
            </ul>
        </div>
        <action-button @bClick="goMigrate()" title="[`Начать миграцию`]" action="goMigrate" :run="runAction" icon="icon16 merge"></action-button>
        <action-button @bClick="migrate='pre'" title="[`Отмена`]" action="tmp" :run="runAction" icon="icon16 update" style="margin-left: 100px;"></action-button>
    </template>
    <template v-if="migrate==='orders'">

    </template>
    <template v-if="migrate==='done'">
        <div style="font-size: 1.25rem;margin: 25px 0 10px 20px; line-height: 1.5">
            Импорт настроек завершен! Для начала работы с плагином "Ozon: Интеграция" перейдите в раздел
            <a href="?action=importexport#/ozonseller/">Импорт/экспорт - Ozon: Интеграция</a>
        </div>
        <template v-if="appData.warnings.length">
            <span class="alert cli-task" style="color: unset;">
                [`В процессе импорта возникли следующие несоответствия:`]
                <ul style="line-height: 1.2">
                    <li v-for="(warning, idx) in appData.warnings" v-html="warning"></li>
                </ul>
            </span>
        </template>
        <span class="alert" style="color: unset;">
            [`
                Осталось сопоставить товары опубликованные в Ozon товарам вашего Shop-Script. Вы можете сделать это
            сейчас или после проверки настроек в разделе "Импорт/экспорт - Ozon: Интеграция" на вкладке "Сопоставление товаров Ozon",
            выбрав в качестве идентификатора`] <strong>{{appData.offer_id_name}}</strong><br>
            <action-button @bClick="runAction='syncOzonProducts'" action="syncOzonProducts" :run="runAction" title="[`Сопоставить товары с Ozon`]" icon="icon16 sync" style="float: right;margin-top:25px;"
                           v-if="bar.state==='wait'"></action-button>
        </span>
        <div class="block" style="margi-top:25px;">
            <gradusnik @donerun="runAction=false" :bar="bar" url="?plugin=ozonseller&action=import" :params="{ account_id:appData.account_id, field:appData.offer_id}" :timeout="5000" :run="runAction==='syncOzonProducts'"></gradusnik>
        </div>
    </template>
</template>
{/literal}