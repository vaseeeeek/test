{literal}
<div class="tab-content">
<template v-if="cLi==='system'">
    <div v-if="account_id && settings"  style="margin-top: 25px;">
        <div id="accounts-menu" class="toggle accounts-menu" style="margin-top: unset;">
            <template v-for="(acc, idx) in accounts">
                <span @click="account_id=acc.id" :class="getMenuElClass(acc)">
                    {{acc.name}}&nbsp;&nbsp;
                <template v-if="acc.status===0"><i class="icon16 no"></i></template><template v-else><i class="icon16 yes"></i></template>
                </span>
            </template>
        </div>
        <div class="fields wrl">
            <div class="field">
                <div class="name">[`Разрешить обновление описаний и характеристик товара в Ozon`]</div>
                <div class="value">
                    <select v-model="settings.upgrade">
                        <option value="1" selected="selected">[`Разрешить`]</option>
                        <option value="2">[`Разрешить только ручное обновление`]</option>
                        <option value="0">[`Запретить`]</option>
                    </select><br>
                    <span class="hint">[`Опция "Запретить" не позволит ни при каких условиях обновлять плагином описание и характеристики товара в Озон. Опция Разрешить только вручную позволит обновлять описание/характеристики только со страницы товара`]</span>
                </div>
            </div>
            <div class="field">
                <div class="name">[`Сохранять запросы к API в JSON`]</div>
                <div class="value">
                    <select v-model="settings.json_query">
                        <option value="0">[`Не сохранять`]</option>
                        <option value="1">[`Сохранять`]</option>
                    </select><br>
                    <span class="hint">[`Не включайте если не знаете для чего это нужно`]</span>
                </div>
            </div>
            <div class="field">
                <div class="name">[`Ведение лог-файлов`]</div>
                <div class="value">
                    <input v-model="settings.debug" type="radio" value="0" name="ozonseller-log" id="ozonseller-log-0"
                           class="radiogroup">&nbsp;<label for="ozonseller-log-0">[`Минимальное логгирование
                    (рекомендуется)`]</label>
                    <br><input v-model="settings.debug" type="radio" value="1" name="ozonseller-log"
                               id="ozonseller-log-1"
                               class="radiogroup">&nbsp;<label for="ozonseller-log-1">[`Умеренное расширенное
                    логгирование`]</label>
                    <br><input v-model="settings.debug" type="radio" value="2" name="ozonseller-log"
                               id="ozonseller-log-2"
                               class="radiogroup">&nbsp;<label for="ozonseller-log-2">[`Полное логгирование (используйте
                    только если понимаете для чего это вам необходимо)`]</label>
                </div>
            </div>
            <div class="field">
                <div class="name">[`Выводить информацию о комиссиях Озон`]</div>
                <div class="value">
                    <select v-model="settings.product_commisions">
                        <option :value="0">[`Не выводить`]</option>
                        <option :value="1">[`Выводить`]</option>
                    </select><br>
                    <span class="hint">[`Вывод информации о комиссиях Озон на вкладке Ozon на странице товара в бекенде Shop-Script. Включение этой опции может замедлить загрузку данной вкладки. Предоставляемая Озон информация о комиссиях зачастую не является полной`]</span>
                </div>
            </div>
        </div>
        <div class="wrl-footer">
            <action-button @bclick="saveSettings()" title="[`Сохранить`]" icon="icon16 disk" action="saveSettings" :run="runAction" :result="runResult"></action-button>
        </div>
    </div>
    <div v-else>
        <div class="block double-padded gray">
            <p>
                <strong>[`Добавьте хотя бы один аккаунт Ozon`]</strong>
            </p>
        </div>
    </div>
</template>
<template v-else-if="cLi==='accounts'">
    <div style="margin-top: 25px;">
        <template v-if="cAccount===null">
            <template v-if="accounts.length">
                <template v-for="(acc, idx) in accounts">
                    <div @click="editAccount(idx)" :class="acc.status===1 ? 'ozonseller-account' : 'ozonseller-account disabled'">
                        <strong :style="acc.status===0 ? 'color: darkgray;':''">{{acc.name}}</strong>
                        <span style="float: right">[`ID: `]{{acc.id}}</span>
                    </div>
                </template>
            </template>
            <template v-else>
                <div class="block double-padded gray">
                    <p>
                        <strong>[`Пока не добавлено ни одного аккаунта Ozon`]</strong>
                    </p>
                </div>
            </template>
            <div class="wrl-footer">
                <action-button @bClick="editAccount('new')" title="[`Добавить аккаунт`]" icon="icon16 plus"
                               :run="false" action="null" bclass="green" :result="runResult"></action-button>
            </div>
        </template>
        <template v-else>
            <div class="fields">
                <div v-if="cAccount.id" class="field">
                    <div class="name">[`ID аккаунта`]</div>
                    <div class="value"><span class="large">{{cAccount.id}}</span></div>
                </div>
                <div class="field">
                    <div class="name">[`Название аккаунта`]</div>
                    <div class="value">
                        <input type="text" v-model="cAccount.name" class="long">
                    </div>
                </div>
                <div class="field">
                    <div class="name">[`Состояние`]</div>
                    <div class="value">
                        <select v-model="cAccount.status">
                            <option :value="0">[`Выключен`]</option>
                            <option :value="1">[`Включен`]</option>
                        </select>
                    </div>
                </div>
                <div class="field">
                    <div class="name">[`ID клиента`]</div>
                    <div class="value">
                        <input type="number" v-model="cAccount.client_id" class="shorter">
                    </div>
                </div>
                <div class="field">
                    <div class="name">[`Токен`]</div>
                    <div class="value">
                        <input type="password" v-model="cAccount.token" class="long">
                    </div>
                </div>
                <div class="field" style="margin-top: 50px;">
                    <div class="name"></div>
                    <div class="value">
                        <action-button @bClick="saveAccount()" title="Сохранить" icon="icon16 disk" action="saveAccount" :run="runAction" :result="runResult" :bclass="checkSaveAccount"></action-button>
                        <action-button @bClick="cAccount=null;" style="margin-left: 35px;" title="Закрыть" icon="icon16 no-bw" action="closeAcc" :run="runAction" :result="runResult" btype="undo" bclass="smallest"></action-button>
                        <action-button v-if="cAccount.id" @bClick="delAccount()" style="float: right;" title="Удалить" icon="icon16 trash" action="delAccount" :run="runAction" :result="runResult" btype="trash" bclass="smallest"></action-button>
                    </div>
                </div>
            </div>
        </template>
    </div>
</template>
<template v-else-if="cLi==='cron'">
    <cron-info :header="true" :task="false"></cron-info>
    <h6>[`Перечень доступных команд`]:</h6>
    <template v-for="(task, idx) in tasks">
        <cron-info :header="false" :task="task"></cron-info>
    </template>
</template>
{/literal}
{include './migrate.old.vue'}
</div>
