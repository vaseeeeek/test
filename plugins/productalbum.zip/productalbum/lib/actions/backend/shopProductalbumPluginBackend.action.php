<?php

class shopProductalbumPluginBackendAction extends waViewAction
{
    public function execute()
    {   
        
    }
}