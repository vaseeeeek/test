<?php
return array (
  'name' => 'Product Album',
  'img' => 'img/productalbum.gif',
  'version' => '1.0.0',
  'vendor' => '123456',
  'handlers' => 
  array (
		'backend_product' => 'handleBackendProduct',
		'frontend_head' => 'frontendHead',
  ),
  'frontend' => true,
);
