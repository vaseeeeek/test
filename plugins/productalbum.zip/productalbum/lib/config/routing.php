<?php
return array (
  'productalbum/*' => 'frontend/',
);
